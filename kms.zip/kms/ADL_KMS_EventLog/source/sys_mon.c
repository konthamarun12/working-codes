/*
 * sys_mon.c
 *
 *  Created on: Nov 5, 2024
 *      Author: USER
 */

#include "gio.h"
#include "het.h"
#include "sys_main.h"
#include "user_can1.h"
#include "MAIN.h"

gDipinfo_t DipInfo;

void ReadDipSwitchAdd(void)
{
    uint8_t u8Dip_Addr = gioGetPort(gioPORTA);
    uint8_t u8Dip_Switch_addr = (u8Dip_Addr & 0xFFu);
    DipInfo.u8Address = u8Dip_Switch_addr;
}
/***********************************************************************************/
void ReadDipSwitchConfig(void)
{
    gioSetDirection(gioPORTB, 0x000000F0u);
    uint8_t u8Dip_Config = gioGetPort(gioPORTB);
    uint8_t u8Dip_Config_add = (u8Dip_Config & 0x0Fu);
    DipInfo.u8Config = u8Dip_Config_add;
}
/***********************************************************************************/

void ReadSlotDetect(void)
{
//    uint8_t u8Data = 0u;
    uint8_t u8Add0 = gioGetBit(hetPORT1, 11u);
    uint8_t u8Add1 = gioGetBit(hetPORT1, 14u);
    uint8_t u8Add2 = gioGetBit(hetPORT1, 15u);
    uint8_t u8Add3 = gioGetBit(hetPORT1, 16u);
    uint8_t u8Add4 = gioGetBit(hetPORT1, 22u);
    uint8_t u8Add5 = gioGetBit(hetPORT1, 18u);
    uint8_t u8Add6 = gioGetBit(hetPORT1, 25u);
    uint8_t u8Add7 = gioGetBit(hetPORT1, 20u);

    DipInfo.u8Slot = u8Add0 << 7 | u8Add1 << 6 |u8Add2 << 5 | u8Add3 << 4 | u8Add4 << 3 | u8Add5 << 2 | u8Add6 << 1 | u8Add7;
//    DipInfo.u8Slot = FPGA_ReadByte(SLOTDETADD, u8Data);
}

