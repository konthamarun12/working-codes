/*
 * gsm.c
 *
 *  Created on: 13-Oct-2023
 *      Author: User
 */


#include "sys_common.h"
#include "sys_main.h"
#include "sci.h"
#include "gio.h"
#include "crc.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#include "user_can.h"
#include "gsm.h"

uint8_t u8Key_set_cnt[30] = {0};
uint8_t key = 0u;
char close_buff[14];
uint8_t u8Recievebit = 0;

gsm_info_t GSM1_Info;

void GSM_init(void)
{
    sciDisplayText((sciBASE_t *)scilinREG, (const uint8_t *)"AT\r\n", 4u);                          /* AT command initialization with AT */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGMI\r\n", 9u);                                      /* Recall stored profile */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+URAT=3\r\n", 11u);                               /* Radio access technology for enabling the LTE mode */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        Delay(4000000u);
        gioSetBit(gioPORTB, 2u, 0u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"ATE0\r\n", 6u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

/*    sciDisplayText(scilinREG, (const uint8_t *)"AT+CPIN=1234\r\n", 14U);
    Delay(4000000U);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }*/

    sciDisplayText(scilinREG, (const uint8_t *)"AT+IPR?\r\n", 9u);                                  /* command for checking baudrate */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CMEE=2\r\n", 11u);                               /* Report mobile equipment error */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CMGF=1\r\n",11u);                                /* command for SMS mode */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CNMI=1,1\r\n",13u);                              /* New message indication */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (uint8_t *)"AT+CNMI=1,2,0,0,0\r\n",19u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CREG=1\r\n", 11u);                               /* Network registered status */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

/*    sciDisplayText(scilinREG, (const uint8_t *)"AT+CPIN=1234\r\n", 14U);
        Delay(4000000U);
        if(!GSM_wait("OK"))
        {
            gioSetBit(gioPORTB, 1u, 1u);
        }
        else
        {
        }*/


    sciDisplayText(scilinREG, (const uint8_t *)"AT+CPIN?\r\n", 10U);              /* SIM PIN number */
    Delay(4000000U);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+COPS?\r\n", 10u);                                 /* command to check operator selection */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (uint8_t *)"AT+CSQ\r\n", 8u);
    wait(100u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    /*sciDisplayText(scilinREG, (const uint8_t *)"AT+UDCONF=20,1\r\n", 16u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }*/
    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGDCONT=1,\"IP\",\"airtelgprs.com\"\r\n",33u);
       Delay(4000000u);
       if(!GSM_wait("OK"))
       {
          gioSetBit(gioPORTB, 2u, 1u);
       }
       else
       {
          gioSetBit(gioPORTB, 2u, 0u);
       }


    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGACT=1,1\r\n", 11u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

/*
    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGDCONT=1,\"IP\",\"airtelgprs.com\"\r\n",33u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 4u, 1u);
    }
    else
    {
       gioSetBit(gioPORTB, 4u, 0u);
    }
*/

}

void Read_SMS(uint8 data)
{
    uint8 u8readotp[64];
    uint8 u8storeotp[512];

    sprintf((char *)u8readotp, "AT+CMGR=%d\r\n", data);                                            /* read the SMS using SMS index */
    sciSend(scilinREG, 12u, u8readotp);                                                               /* send the request for the received the message */
    Delay(8000000u);
    if(1)
    {
        if(!my_strncmp("+CMGR", strstr2(&Receive_Data[2 ],"+CMGR"),5u))
        {
            strncpy((char *)u8storeotp, strstr2(&Receive_Data[2], "L65522:"),11u);                  /* storing the otp(SMS) */
            otp[0] = u8storeotp[7];
            otp[1] = u8storeotp[8];
            otp[2] = u8storeotp[9];
            otp[3] = u8storeotp[10];

            aut_key.OTP_status = 1u;                                                             /* set high the OTP status variable */
            GSM_reg.OTP_receive = (uint8)OTPRCVD;
            a2i(otp);
        }
        else
        {
        }
    }
    Delete_SMS(data);                                                                            /* Delete SMS ofter reading and storing of data */
}

void Delete_SMS(uint8 otp_data)
{
    sprintf((char *)DisBuf, "AT+CMGD=%d\r\n", otp_data);                                         /* Delete message */
    sciDisplayText(scilinREG, (const uint8_t *)DisBuf, 12U);                                        /* Delete the message based on message index number */
    Delay(2000000u);

    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
        gioSetBit(gioPORTB, 1u, 0u);
    }
}

void Process_GSMRcv(void)
{
    if(!my_strncmp("+CMTI", strstr2(&Receive_Data[2], "+CMTI"),5u)) /* wait for GSM module receive some messages , wait for +CMTI command to be sent by the GSM module to board */
    {                                                                                            /* CMTI incoming message indicator */
       strncpy((char *)rcvotp, strstr2(&Receive_Data[4], "+CMTI:"), 14u);
       DataBuf[0] = rcvotp[12];
       if(rcvotp[13] != 0x0DU)
       {
           DataBuf[1] = rcvotp[13];
           DataBuf[2] = (uint8)'\0';
       }
       else
       {
           DataBuf[1] = (uint8)'\0';
       }
       Read_SMS(a2i(DataBuf));                                                                   /* Read SMS function call */
    }
    else if(!my_strncmp("+CSQ",strstr2((uint8_t *)Receive_Data,"+CSQ"),4U))                      /* signal quality */
    {
        strncpy(TempBuf, strstr2((uint8_t *)Receive_Data, ":"),10u);
        DataBuf[0] = (uint8)TempBuf[1];
        DataBuf[1] = (uint8)TempBuf[2];
        if(TempBuf[3] != ',')
        {
            DataBuf[2] = (uint8)TempBuf[3];
            DataBuf[3] = (uint8)'\0';
        }
        else
        {
            DataBuf[2] = (uint8)'\0';
        }
    }
    else
    {
    }
}

void resend_pck(void)
{
    if(aut_key.status == (uint8)KEYNOTRCVD)                 /* if identification message is not sent 1st time it will send every 5 min to KMS until get the response */
    {
        Delay(90000000u);                                                                        /* 5 minutes wait */
        GSM_txData();
    }
    else
    {
        aut_key.status = (uint8)KEYRCVD;
    }
}

void NewMsg_Notification(void)
{
    sciDisplayText(scilinREG, (const uint8_t *)"AT+CNMI=1,1\r\n",13u);                              /* New Message indication */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CMGL=\"REC UNREAD\"\r\n",23u);                   /* Read the Unreaded message */
    Delay(2000000u);
    if(!GSM_wait("*"))
    {
        copystring((uint8_t *)TempBuf, strstr2(&Receive_Data[1], ":"));
        DataBuf[0] = (uint8)TempBuf[1];

        if(TempBuf[3] != ',')
        {
            DataBuf[1] = (uint8)TempBuf[3];
            DataBuf[2] = (uint8)'\0';
        }
        else
        {
        }
        sms = a2i(DataBuf);
    }
    Delete_SMS((uint8)sms);                                                                      /* function call for Delete SMS */
}

void Close_socket(void)                                                                          /* close socket function for UDP socket */
{
    sciDisplayText(scilinREG, (const uint8_t *)"AT+USOCL?\r\n",13u);
    if(!my_strncmp("+USOCL", strstr2((uint8_t *)Receive_Data,"+USOCL"),6u))
    {
        sprintf(TempBuf, "AT+USOCL=%d\r\n",GSM_reg.UDP_closeBit);                                /* Close socket of created UDP socket */
        sciDisplayText(scilinREG, (const uint8_t *)TempBuf, 128U);
        Data_Buffer((uint8_t *)&TempBuf[0]);
    }
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
        gioSetBit(gioPORTB, 1u, 0u);
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+USOCTL=0,1\r\n",15u);                             /* socket control */
    Delay(4000000u);
    if(!GSM_wait("+CME"))                                                                        /* Error message */
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }
}


void GSM_txData(void)                                                                            /* function for transmit data packets formation */
{
/*    GSM_DateTime();  */
    uint32_t CrC = 0u;
    uint8 len_crc;
    tx_packet[0] = 0xA5u;                                                                        /* start of frame */
    tx_packet[1] = 0xC3u;

    tx_packet[2] = 0x90u;                                                                        /* Message type */

    tx_packet[3] = 0x00u;
    tx_packet[4] = 0x0Fu;                                                                        /* Message length */

    tx_packet[5] = GSM1_Info.chDate;                                                               /* Date (IST) */
    tx_packet[6] = GSM1_Info.chMonth;
    tx_packet[7] = GSM1_Info.chYear;

    tx_packet[8] = GSM1_Info.chHours;                                                              /* Time (IST) */
    tx_packet[9] = GSM1_Info.chMins;
    tx_packet[10] = GSM1_Info.chSecs;

   /* tx_packet[5] = 0x14u;
    tx_packet[6] = 0x0Cu;
    tx_packet[7] = 0x18u;
    tx_packet[8] = 0x0Bu;
    tx_packet[9] = 0x2Du;
    tx_packet[10] = 0x08u;*/

//    tx_packet[11] = 0x11u;                                                                       /* Type of Kavach unit, Stationary KAVACH */
    tx_packet[11] = 0x22u;                                                                       /* Type of Kavach unit, Onboard KAVACH */

    tx_packet[12] = 0x00u;                                                                       /*Onboard Kavach unit ID */
    tx_packet[13] = 0xFFu;
    tx_packet[14] = 0xF2u;
//    tx_packet[12] = 0x00u;                                                                         /*Stationary Kavach unit ID */
//    tx_packet[13] = 0xC3u;
//    tx_packet[14] = 0x5Bu;

//    tx_packet[15] = 0x02u;                                                                       /* SIM ID-primary or secondary */
    tx_packet[15] = 0x01;

      CrC = crc_calc(14,(uint8 *)&tx_packet[2]);                                          /* CRC function for calculating the crc for Iden msg data packet */

    if(aut_key.OTP_status == 1u)                                                                 /* condition for authentication key request packet */
    {
        tx_packet[2] = 0x92u;                                                                   /* message type */
        tx_packet[3] = 0x00u;
        tx_packet[4] = 0x13u;                                                                   /* message length */

        tx_packet[16] = otp[0];                                                                  /* OTP received in SMS */
        tx_packet[17] = otp[1];
        tx_packet[18] = otp[2];
        tx_packet[19] = otp[3];

        CrC = crc_calc(18,(uint8 *)&tx_packet[2]);                                        /* CRC function for calculating the crc for Aut key req data packet */
    }
    else if(GSM_reg.Aut_queryBit == 1u)
    {
        tx_packet[2] = 0x94u;                                                              /* message type */
        tx_packet[3] = 0x00u;                                                              /* message length */
        tx_packet[4] = 0x0Eu;
        tx_packet[15] = 0u;

        CrC = crc_calc(13, (uint8 *)&tx_packet[2]);                                            /* CRC function for calculating the crc for Aut query data packet */
    }
    else
    {
    }
    len_crc = my_strlen(tx_packet);


    if(aut_key.OTP_status == 1u)                                                                 /* crc calculation for authentication key request data packet */
    {
        tx_packet[20] = (CrC >> 24) & 0xffu;                                                     /* Packet CRC */
        tx_packet[21] = (CrC >> 16) & 0xffu;
        tx_packet[22] = (CrC >> 8) & 0xffu;
        tx_packet[23] = (CrC >> 0) & 0xffu;
        len = 24;
    }
    else if(GSM_reg.Aut_queryBit == 1u)                                                          /* calculating crc for authentication query message data packet */
    {
        tx_packet[15] = (CrC >> 24) & 0xffu;
        tx_packet[16] = (CrC >> 16) & 0xffu;
        tx_packet[17] = (CrC >>  8) & 0xffu;
        tx_packet[18] = (CrC >>  0) & 0xffu;
        tx_packet[19] = 0u;
        tx_packet[20] = 0u;
        tx_packet[21] = 0u;
        tx_packet[22] = 0u;
        tx_packet[23] = 0u;
        len = 19;
    }
    else                                                                                         /* crc calculation for identification message */
    {
        tx_packet[16] = (CrC >> 24) & 0xffu;
        tx_packet[17] = (CrC >> 16) & 0xffu;
        tx_packet[18] = (CrC >>  8) & 0xffu;
        tx_packet[19] = (CrC >>  0) & 0xffu;

        len = 20;
    }

    GSM_reg.UDP_TxBit = 1u;
    transmit_udp();                                                                              /* calling function for next process of UDP communication */
}


void transmit_udp(void)                                                                          /* function for transmit and receive the data packet */
{
/*    GSM_UDP_init();  */
    uint8 KeyData7[512];
    sciDisplayText(scilinREG, (const uint8_t *)"AT+USOCR=17\r\n",13u);                              /* create socket for UDP communication */
    Delay(2000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
        gioSetBit(gioPORTB, 2u, 0u);
    }

    sprintf((char *)KeyData7, "AT+USOST=%d,%s,%d,%d\r\n", u8Socket,ip_address,u32port,len);           /*storing the socket,ip_address,port number,data length into the variablres */
    sciDisplayText(scilinREG, (uint8_t *)KeyData7, 36u);
    Delay(8000000u);
    if(!GSM_wait("@"))                                                                                /* waiting for the '@' symbol */
    {
        Delay(2000000u);

        sciDisplayText(scilinREG, (uint8_t *)tx_packet, len);                                         /* transmit the data packet with length of the packet */
        Delay(16000000u);
        gioSetBit(gioPORTB, 2u, 1u);                                   /* LED for indicating the KMS server communication */
        if(!GSM_wait1("+USOST"))
        {
            Delay(200000u);
            if(!GSM_wait("+UUSORD")){
            Rx_size = 0u;
            GSM_reg.UDP_TxBit = 0u;
            GSM_reg.UDP_closeBit = 1u;
            }
        }
        Delay(4000000u);
        GSM_reg.UDP_TxBit = 1u;
        GSM_reg.UDP_closeBit = 0u;
    }
    else
    {
        gioSetBit(gioPORTB, 2u, 0u);
    }
                                                                 /* function calling for received data segregation */
}



void GSM_DateTime(void)                                                                          /* function for finding the current time and date and stored into the variables */
{
    Data_Buffer((uint8_t *)&TempBuf[0]);
    sciDisplayText(scilinREG, (const uint8_t *)"AT+CCLK?\r\n",10u);
    Delay(8000000u);
    if(!my_strncmp("+CCLK", strstr2(&Receive_Data[1], "+CCLK"),5u))
    {
        strncpy(TempBuf, strstr2(&Receive_Data[2],"+CCLK:"),25u);
        DataBuf[0] = (uint8)TempBuf[8];
        DataBuf[1] = (uint8)TempBuf[9];
        DataBuf[2] = (uint8)0;
        date_time.year = a2i(DataBuf);

        DataBuf[0] = (uint8)TempBuf[11];
        DataBuf[1] = (uint8)TempBuf[12];
        DataBuf[2] = (uint8)0;
        date_time.month = a2i(DataBuf);

        DataBuf[0] = (uint8)TempBuf[14];
        DataBuf[1] = (uint8)TempBuf[15];
        DataBuf[2] = (uint8)0;
        date_time.date = a2i(DataBuf);

        DataBuf[0] = (uint8)TempBuf[17];
        DataBuf[1] = (uint8)TempBuf[18];
        DataBuf[2] = (uint8)0;
        date_time.hours = a2i(DataBuf);

        DataBuf[0] = (uint8)TempBuf[20];
        DataBuf[1] = (uint8)TempBuf[21];
        DataBuf[2] = (uint8)0;
        date_time.minutes = a2i(DataBuf);

        DataBuf[0] = (uint8)TempBuf[23];
        DataBuf[1] = (uint8)TempBuf[24];
        DataBuf[2] = (uint8)0;
        date_time.seconds = a2i(DataBuf);
    }
}


uint8 Data_Buffer(uint8_t *u8buffer)                                                               /* function for clearing the data buffer */
{
    uint16 u16clear;
    uint16 store = my_strlen((uint8 *)u8buffer);                                                   /* checking the length of the data buffer */

    for(u16clear = 0U; u16clear < store; ++u16clear)
    {
        u8buffer[u16clear] = (uint8)'\0';                                                                 /* filling the NULL to the buffer based on length of the buffer */
    }
    return u8buffer[0];
}


void Clear_Buffer1(void)
{
    uint16 u8index;
    for(u8index = 0;u8index <= 2000u;u8index++)
    {
        Receive_Data[u8index] = 0u;
    };
    size = 0u;
}


void Data_separation(void)                                                                       /* function for data segregation */
{
    uint8 c = 0, j = 0, k = 0, l = 0;

    if(!my_strncmp("+USORF", strstr2(&Receive_Data[2], "+USORF"), 6u))
    {
        strncpy((char *)KeyData6, strstr2(&Receive_Data[5], "\xA5"), valu);                      /* copying received data into temp variable */
    }

    while((i < valu) && ((KeyData1[2] == 0x91u) || (KeyData6[2] == 0x93u) || (KeyData6[2] == 0x95u)))         /* checking in loop if i value is lessthan size */
    {

        if(i < 2u)                                                                               /* based on index value segregating the data */
        {
            gsm.SOF[i] = KeyData6[i];                                                            /* start of frame 2 Byte data */
        }
        else if(i == 2u)
        {
            gsm.Msg_type = KeyData6[i];                                                          /* message type 1 byte */
        }
        else if((i >= 3u) && (i < 5u))
        {
            gsm.Msg_length[c] = KeyData6[i];                                                     /* Message length of data packet 2 byte */
            c++;
        }
        else if((i >= 5u) && (i < 8u))
        {
            gsm.Date[j] = KeyData6[i];                                                           /* date 3 byte (date, month, year */
            j++;
        }
        else if((i >= 8u) && (i < 11u))
        {
            gsm.Time[k] = KeyData6[i];                                                           /* Time 3 byte (hour, minute, second */
            k++;
        }
        else if(i == 11u)
        {
            gsm.Kavach_unit_type = KeyData6[i];                                                  /* storing kavach unit type 1 byte */
        }
        else if((i >= 12u) && (i < 15u))
        {
            gsm.Kavach_unit_ID[l] = KeyData6[i];                                                 /* storing kavach unit ID 3 Byte */
            l++;
        }
        else if(gsm.Msg_type == 0x91u)                                                           /* conditions for segregating all receiving data packets */
        {
            Ide_Ack_Msg();
        }
        else if(gsm.Msg_type == 0x93u)
        {
            Aut_key_Msg();
        }
        else if(gsm.Msg_type == 0x95u)
        {
            Aut_status_Msg();
        }
        else
        {
        }
        i++;
    }
    Data_Buffer((uint8*)KeyData6);
}

void Ide_Ack_Msg(void)                                                                           /* function for segregating the identification message data */
{
    uint8 u8data = 0u;

    if((gsm.Msg_type == 0x91u) && (i >= 15u))                                                    /* checking the message type */
    {
        while(i < 21u)
        {
            if(i == 15u)
            {
                gsm.Ack_status = KeyData6[i];                                                    /* acknowledgment byte to the variable */
            }
            else if(i >= 16u)
            {
                gsm.crc[u8data] = KeyData6[i];                                                        /* crc data of identification acknowledge message data packet*/
                u8data++;
            }
            else
            {
            }
            i++;
        }
    }
}

void Aut_key_Msg(void)                                                                           /* function for segregating the authentication key message data */
{
    uint8 b = 0, m = 0, n = 0, r = 0, t = 0;
    uint8 index;
    uint8 currindex;
    uint8 currindex1;
    uint8 currIndex;
    uint8 currkey=28;
    uint8 end, cnt, j, k;

    if((gsm.Msg_type == 0x93u) && (i >= 15u))                                                    /* Message type checking */
    {
        while(i < var3)                                                                          /* condition for i is greater than size */
        {
            if((i >= 15u) && (i < 19u))
            {
                gsm.Key_set_unique_ID[r] = KeyData6[i];                                          /* storing 4 Byte unique id */
                r++;
            }

            else if(i == 19u)
            {
                gsm.key_set = KeyData6[i];                                                       /* number of authentication key set 1 byte */
            }

            for(index = 0u;index < gsm.key_set; index++)                                         /* for loop for storing each set of keys into the variables */
            {
                currIndex = 20u;
                for(currindex = currIndex;currindex < var3; currindex += 40u)
                {
                    aut_key.AutKeystarthours[t] = KeyData6[currindex + 0u];
                    aut_key.AutKeystartdate[t] = KeyData6[currindex + 1u];
                    aut_key.AutKeystartmonth[t] = KeyData6[currindex + 2u];
                    aut_key.AutKeystartyear[t] = KeyData6[currindex + 3u];
                    aut_key.AutKeyendhours[t] = KeyData6[currindex + 4u];
                    aut_key.AutKeyenddate[t] = KeyData6[currindex + 5u];
                    end++;
                    aut_key.AutKeyendmonth[t] = KeyData6[currindex + 6u];
                    aut_key.AutKeyendyear[t] = KeyData6[currindex + 7u];
/*                    startdate = KeyData6[21];   */
                    t++;
                }

/*                for(currindex1 = currkey;currindex1 < valu ; currindex1 += 40u)
                {
                    if(m <= 16u)
                    {
                        aut_key.AutKey1[m] = KeyData6[currindex1++];
                        m++;
                    }
                    else if((m > 16u) && (m <= 32u))
                    {
                        aut_key.AutKey2[n] = KeyData6[currindex1++];
                        n++;
                    }
                    else
                    {
                    }
                    u8Key_set_cnt[key++];
                }*/

                for(currindex1 = currkey;currindex1 < valu ; currindex1 += 40u)
                {
                    if(m <= 16u)
                    {
                        CAN_Info.u8Aut_key1[index][m] = KeyData6[currindex1++];                             /* storing 16 byte authentication key1 */
                        m++;
                    }
                    else if((m > 16u) && (m <= 32u))
                    {
                        CAN_Info.u8Aut_key2[index][n] = KeyData6[currindex1++];                             /* storing 16 byte of authentication key2 */
                        n++;
                    }
                    else
                    {
                    }
                    u8Key_set_cnt[key++];
               }

               if(aut_key.AutKeyenddate[t] < date_time.date)
               {
                   cnt++;
               }
            }

            k = end;
            for(j = 0u;j < end; j += 7u)
           /* for(j = 0;j < end; aut_key.AutKeyenddate[j] += 0)*/
            {
                if(aut_key.AutKeyenddate[j] < date_time.date)                                    /* condition to check every authentication key validity */
                {
                    aut_key.AutKeyenddate[j] = (uint8)' ';
                   /* j += 7;*/
                    k--;
                }
                else
                {
                }
            }


            if(k <= 60u)                                                                         /* checking total authentication keys is less than 60 */
            {
                GSM_reg.Key_receive = 1u;
            }

            if(i < 4u)
            {
                i = (uint8)valu - 4u;

                gsm.crc[b] = KeyData6[i];                                                        /* storing authentication crc data to the variable */
                b++;
            }
            else
            {
            }
            i++;
        }
     }
}


void Aut_status_Msg(void)                                                                        /* function for segregating the received authentication key status message */
{
    uint8 u8index = 0u;
    uint8 u8subindex = 0u;
    if((gsm.Msg_type == 0x95u) && (i >= 15u))                                                    /* checking the message type */
    {
        while(i < valu)
        {
            if((i >= 15u) && (i < 19u))
            {
                gsm.Key_set_unique_ID[u8index] = KeyData6[i];                                          /* storing the 4 Byte unique ID to variable */
                u8index++;
            }

            else if((i >= 19u) && (i < 23u))
            {
                gsm.crc[u8subindex] = KeyData6[i];                                                        /* storing 4 Byte crc */
                u8subindex++;
            }
            else
            {
            }
            i++;                                                                                 /* incrementing i value */
        }
    }
}

void cal_rcvdata(void)
{
    uint8 KeyData8[128];
    if(!my_strncmp("+UUSORD", strstr2(&Receive_Data[1], "+UUSORD"),7u))                          /* function for received data length from server and storing into temp variable */
    {
        strncpy((char *)KeyData8, strstr2(&Receive_Data[1], "+UUSORD:"),16u);

        var = KeyData8[9];
        var = var - 48u;

        var1[0] = KeyData8[11];                                                                  /* storing data into the one temporary buffer */
        var1[1] = KeyData8[12];
        var1[2] = KeyData8[13];
        var1[3] = KeyData8[14];

        arry(var1);                                                                              /* function call for to convert array data to decimal data */
    }
}

char *my_strncpy(char *dest, const char *src, uint8 n)                                           /* string copy function */
{
    char *original = dest;
    while((n > 0u) && (*src != '\0'))
    {
        *dest++ = *src++;
        n--;
    }

    while(n > 0u)
    {
        *dest = '\0';
        n--;
    }
    return original;
}


void close_UDPsocket(void)
{
    uint8_t u8index;

    for(u8index = 0u;u8index < 7u;u8index++)
    {
        wait(100u);
        sprintf(close_buff, "AT+USOCL=%d\r\n", u8index);
        sciDisplayText(scilinREG, (uint8_t *)close_buff, 10u);
    }
    if(u8Socket >= 6u)
    {
        u8Socket = 0u;
    }
    else
    {
    }
}

void close_UDPsocket1(void)
{
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=0\r\n", 12u);
    wait(100u);
/*    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=1\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=2\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=3\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=4\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=5\r\n", 12u);*/
}

void GSM_UDP_init(void)
{
    sciDisplayText((sciBASE_t *)scilinREG, (const uint8_t *)"AT\r\n", 4u);                          /* AT command initialization with AT */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGATT=1\r\n", 11u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }


    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGMI\r\n", 9u);                                      /* Recall stored profile */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGMM\r\n", 9u);                                      /* Recall stored profile */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGSN\r\n", 9u);                                      /* Recall stored profile */
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGDCONT=1,\"IP\",\"airtelgprs.com\"\r\n", 36u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }

    sciDisplayText(scilinREG, (const uint8_t *)"AT+CGACT=1,1\r\n", 13u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
       gioSetBit(gioPORTB, 1u, 1u);
    }
    else
    {
    }
    /*sciDisplayText(scilinREG, (const uint8_t *)"ATE0\r\n", 6u);
    Delay(4000000u);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2u, 1u);
    }
    else
    {
    }*/


}

void read_sms_otp(void)
{
    uint8 u8storeotp[512];
    if(!my_strncmp("+CMT", strstr2(&Receive_Data[2],"+CMT"),4u))
    {
        strncpy((char *)u8storeotp, strstr2(&Receive_Data[2], "L65522:"),11u);                  /* storing the otp(SMS) */
        otp[0] = u8storeotp[7];
        otp[1] = u8storeotp[8];
        otp[2] = u8storeotp[9];
        otp[3] = u8storeotp[10];

        aut_key.OTP_status = 1u;                                                             /* set high the OTP status variable */
        GSM_reg.OTP_receive = (uint8)OTPRCVD;
        a2i(otp);
    }
    else
    {
    }
}

/*void copyStringStartingWithWord(const char *source, const char *startWord, char *destination)
{
    // Find the starting position of the word
    const char *start = strstr(source, startWord);

    if (start != NULL)
        {
        // Calculate the length of the substring to copy
        size_t length = strlen(start);

        // Copy the substring starting from the found position
        memcpy(destination, start, 1450); // +1 to include the null terminator
    }
        else
        {
        // If the word is not found, copy an empty string
        *destination = '\0';
    }
}
*/



void UDPRcvdData(void)
{
    Delay(4000000u);
    if(!my_strncmp("+UUSORD", strstr2(&Receive_Data[100], "+UUSORD"),7u))                          /* checking the transmitted data */
    {
        uint8 KeyData5[128];
        strncpy((char *)KeyData5, strstr2(&Receive_Data[110], "+UUSORD:"),15u);                   /* storing the  socket number and data length to temp variable */
        var = KeyData5[9];
        var = var - 48u;

        var1[0] = KeyData5[11];
        var1[1] = KeyData5[12];
        var1[2] = KeyData5[13];
        var1[3] = KeyData5[14];

        arry(var1);

        cal_rcvdata();
     }

        if(valu > 1023u)                                                                             /* checking received is more than 1024 bits */
        {
            Clear_Buffer1();
     //        sciSend(scilinREG, 17U, (uint8_t *)"AT+USORF=0,1023\r\n");                                  /* sending request to receive the first 1023 bits data*/
            sprintf(KeyData4,"AT+USORF=%d,%d\r\n",0u,valu);                                         /*send request to server for send the received data using socket number,data length*/

            sciDisplayText(scilinREG, (uint8_t *)KeyData4, 17u);
    //        sciDisplayText(scilinREG, (uint8_t *)"AT+USORF=0,1023\r\n",17u);
            Delay(16000000u);
            valu = 0u;
            if(!my_strncmp("+USORF", strstr2(&Receive_Data[1], "+USORF"), 6u))
            {
                strncpy(KeyData1, strstr2(&Receive_Data[5], "\xa5" ),1023u);                       /* copying the 1023 bits data to temp variable */
            }

            if(1)
            {
                uint8 u8index;
                uint8 var2[4];
                uint8 KeyData3[700];
                uint8 KeyData2[128];
                if(!my_strncmp("+UUSORF", strstr2(&Receive_Data[10],"+UUSORF"), 7u));              /* KMS gives the response of available data */
                {
                    strncpy((char *)KeyData2, strstr2(&Receive_Data[10], "+UUSORF:"), 15u);        /* copying socket number and data length */
                    uint8 A = KeyData2[9];
                    A = A - 48u;
                    var2[0] = KeyData2[11];                                                          /* storing the socket and data length to another variable */
                    var2[1] = KeyData2[12];
                    var2[2] = KeyData2[13];
                    var2[3] = KeyData2[14];

                    arry(var2);

                    Delay(16000000u);
                    sprintf(KeyData4, "AT+USORF=%d,%d\r\n",A,valu);                                  /* sending request for available data using dynamic variable */
                    sciDisplayText(scilinREG, (uint8_t *)KeyData4, 14u);
                    Delay(2000000u);

                    if(!my_strncmp("+USORF", strstr2(&Receive_Data[500], "+USORF"), 6U))             /* checking the +USORF is present in the received buffer */
                    {
                        strncpy((char *)KeyData3, strstr2(&Receive_Data[1200], "+USORF:"),valu);     /* copying and storing the available data into temp variable */
                    }
                    else
                    {
                    }

                    valu = 0u;
                }

                uint16 u16d_size = my_strlen((uint8 *)KeyData1);                                        /* finding the first buffer data length */
                uint16 u16loc = my_strlen((uint8 *)KeyData3);                                           /* finding the second buffer data length using strlen string library fucntion */
                for(u8index = 0u; u8index < u16loc; u8index++ )
                {
                   KeyData1[u16d_size] = KeyData3[u8index];                                                   /* two different buffer data storing in one buffer */
                   u16d_size++;
                }
                if(u8index >= u16loc)
                {
                    EEPROM_write_function();
                }
            }
        }
        else
        {
            sprintf(KeyData4,"AT+USORF=%d,%d\r\n",var,valu);                                         /*send request to server for send the received data using socket number,data length*/
                                                                       /* send the request with storing of data into the temp variables */
            sciDisplayText(scilinREG, (uint8_t *)KeyData4, 15u);
            wait(100u);
            Delay(8000000U);
            if(!my_strncmp("+USORF", strstr2(&Receive_Data[100], "+USORF"), 6u))                     /* comparing the substring into the string */
            {
                strncpy(KeyData1, strstr2(&Receive_Data[110], "\xa5"),valu);                         /* checking first byte data and copying the received data and storing into the temp variable */
            }
            else
            {
            }
        }
        wait(100u);

        wait(100u);
        Data_separation();
}

void UDPRcvdData1(void)
{
    Delay(4000000u);
    if(!my_strncmp("+UUSORD", strstr2(&Receive_Data[100], "+UUSORD"),7u))                          /* checking the transmitted data */
    {
        uint8 KeyData5[128];
        strncpy((char *)KeyData5, strstr2(&Receive_Data[110], "+UUSORD:"),15u);                   /* storing the  socket number and data length to temp variable */
        var = KeyData5[9];
        var = var - 48u;

        var1[0] = KeyData5[11];
        var1[1] = KeyData5[12];
        var1[2] = KeyData5[13];
        var1[3] = KeyData5[14];

        udp_data.u16UDPRcvDataCnt = arry(var1);                   /* available data count */

        Clear_Buffer1();                                          /* clear the received buffer */
        cal_rcvdata();
    }

    if(udp_data.u16UDPRcvDataCnt > 1024u)                 /* id data cnt is more than 1024 bytes then data need to receive as two or three data depend upon the received data cnt */                                                             /* checking received is more than 1024 bits */
    {
        uint16 u16KeysRcvbuf=1023u;
                                                                   /* sending request to receive the first 1023 bits data*/
        sprintf(KeyData4,"AT+USORF=%d,%d\r\n",0u,u16KeysRcvbuf);                                         /*send request to server for send the received data using socket number,data length*/
        u8Recievebit = 1;
        Delay(16000000u);
        sciDisplayText(scilinREG, (uint8_t *)KeyData4, 17u);
 /*        sciDisplayText(scilinREG, (uint8_t *)"AT+USORF=0,1023\r\n",17u);   */
        udp_data.u8ProcesPendDataBit = 1u;
        Delay(16000000u);


        uint8 u8index;
        uint8 var2[4];
        uint8 KeyData3[700] = {0};
        uint8 KeyData2[128] = {0};
        if(!my_strncmp("+UUSORF", strstr2(&Receive_Data[100],"+UUSORF"), 7u));              /* KMS gives the response of available data */
        {
             strncpy((char *)KeyData2, strstr2(&Receive_Data[100], "+UUSORF:"), 15u);        /* copying socket number and data length */
             uint8 A = KeyData2[9];
             A = A - 48u;
             var2[0] = KeyData2[11];                                                          /* storing the socket and data length to another variable */
             var2[1] = KeyData2[12];
             var2[2] = KeyData2[13];
             var2[3] = KeyData2[14];

             udp_data.u16UDPRcvDataCnt = arry(var2);                                       /* checking the available data from UDP socket */
             udp_data.u16UDPRcvDataCnt = 524u;
             A = 0;
             Delay(16000000u);
             sprintf(KeyData4, "AT+USORF=%d,%d\r\n",A,udp_data.u16UDPRcvDataCnt);                                  /* sending request for available data using dynamic variable */
             u8Recievebit = 1;
             Delay(2000000u);
             sciDisplayText(scilinREG, (uint8_t *)KeyData4, 16u);
             Delay(8000000u);

             uint16_t u8indx;
             if(!my_strncmp("+USORF", strstr2(&Receive_Data[500], "+USORF"), 6U))             /* checking the +USORF is present in the received buffer */
             {
                 strncpy((char *)KeyData3, strstr2(&Receive_Data[500], "+USORF:"),valu);     /* copying and storing the available data into temp variable */
                 for(u8indx = 0;u8indx < udp_data.u16UDPRcvDataCnt; u8indx++)
                 {
                     KeyData3[u8indx] = Receive_Data[u8indx];                                 /* copying the received available data */
                     if(u8indx == (udp_data.u16UDPRcvDataCnt - 1u))
                     {
//                         Clear_Buffer1();                                                     /* after receiving of all data clear the received buffer */
                     }
                 }
                 u8Recievebit = 0;
             }
             else
             {
             }

             udp_data.u8ProcesPendDataBit = 0u;
             valu = 0u;
         }

             uint16 u16d_size = my_strlen((uint8 *)KeyData1);                                        /* finding the first buffer data length */
             u16d_size = 1024;
             uint16 u16loc = my_strlen((uint8 *)KeyData3);                                           /* finding the second buffer data length using strlen string library fucntion */
             u16loc = 201;
             for(u8index = 0u; u8index < u16loc; u8index++ )
             {
                 KeyData1[u16d_size] = KeyData3[u8index];                                                   /* two different buffer data storing in one buffer */
                 u16d_size++;
             }
             if(u8index >= u16loc)
             {
/*                 EEPROM_write_function();    */
             }

             wait(100u);
    }

    else if(udp_data.u16UDPRcvDataCnt < 1024u)                                                        /* maximum data cnt could be read from UDP socket is 1024 bytes only for one time */
    {
        sprintf(KeyData4,"AT+USORF=%d,%d\r\n",0u,udp_data.u16UDPRcvDataCnt);                                         /*send request to server for send the received data using socket number,data length*/
        u8Recievebit = 1;
        Delay(16000000u);
        sciDisplayText(scilinREG, (uint8_t *)KeyData4, 17u);
        Delay(4000000u);
    }
    else
    {
    }

    valu = 0u;
    uint16_t u8idx;
    uint16_t u16subidx = 60u;
    if(!my_strncmp("+USORF", strstr2(&Receive_Data[1], "+USORF"), 6u))                      /* checking the UDP received data */
    {
        wait(1000u);
        if(Receive_Data[42] == 0x93)
        {
        strncpy(KeyData1, strstr2(&Receive_Data[5], "\xa5" ),1024u);                         /* copying the 1023 bits data to temp variable */
        for(u8idx = 0; u8idx <= 1002u; u8idx++)
        {
            KeyData1[u8idx] = Receive_Data[u16subidx];
            u16subidx++;
        }

        u16subidx = 1129u;
        for(u8idx = 1003u; u8idx <= 1270u; u8idx++)
        {
            KeyData1[u8idx] = Receive_Data[u16subidx];
            u16subidx++;
        }
        }

        if(u8idx == 1270u)
        {
            EEPROM_write_function();
        }

        wait(100u);
        Data_separation();

    }

}

void ProcessPendingUDPData()
{
   /* If the UDP received data byte count is more than 1024 then only this function will run */
     uint8 u8index;
     uint8 var2[4];
     uint8 KeyData3[700];
     uint8 KeyData2[128];
     if(!my_strncmp("+UUSORF", strstr2(&Receive_Data[100],"+UUSORF"), 7u));              /* KMS gives the response of available data */
     {
         strncpy((char *)KeyData2, strstr2(&Receive_Data[100], "+UUSORF:"), 15u);        /* copying socket number and data length */
         uint8 A = KeyData2[9];
         A = A - 48u;
         var2[0] = KeyData2[11];                                                          /* storing the socket and data length to another variable */
         var2[1] = KeyData2[12];
         var2[2] = KeyData2[13];
         var2[3] = KeyData2[14];

         udp_data.u16UDPRcvDataCnt = arry(var2);                                       /* checking the available data from UDP socket */

         Delay(16000000u);
         sprintf(KeyData4, "AT+USORF=%d,%d\r\n",A,udp_data.u16UDPRcvDataCnt);                                  /* sending request for available data using dynamic variable */
         u8Recievebit = 1;
         Delay(2000000u);
         sciDisplayText(scilinREG, (uint8_t *)KeyData4, 14u);
         Delay(8000000u);

         uint16_t u8indx;
         uint16_t u16subidx = 1100;
         if(!my_strncmp("+USORF", strstr2(&Receive_Data[500], "+USORF"), 6U))             /* checking the +USORF is present in the received buffer */
         {
             strncpy((char *)KeyData3, strstr2(&Receive_Data[500], "+USORF:"),valu);     /* copying and storing the available data into temp variable */
             for(u8indx = 0;u8indx < udp_data.u16UDPRcvDataCnt; u8indx++)
             {
                 KeyData3[u8indx] = Receive_Data[u16subidx];                                 /* copying the received available data */
                 u16subidx++;
                 if(u8indx == (udp_data.u16UDPRcvDataCnt - 1u))
                 {
//                     Clear_Buffer1();                                                     /* after receiving of all data clear the received buffer */
                 }
             }
/*             Clear_Buffer1();  */
             u8Recievebit = 0;
         }
         else
         {
         }

         udp_data.u8ProcesPendDataBit = 0u;
         valu = 0u;
     }

     uint16 u16d_size = my_strlen((uint8 *)KeyData1);                                        /* finding the first buffer data length */
     u16d_size = 1024;
     uint16 u16loc = my_strlen((uint8 *)KeyData3);                                           /* finding the second buffer data length using strlen string library function */
     u16loc = 201;
     for(u8index = 0u; u8index < u16loc; u8index++ )
     {
         KeyData1[u16d_size] = KeyData3[u8index];                                                   /* two different buffer data storing in one buffer */
         u16d_size++;
     }
     if(u8index >= u16loc)
     {
/*         EEPROM_write_function();   */
     }

     wait(100u);
     Data_separation();
}


void GSM_health_status(void)
{
/*    TempBuf[256] = {0}; */
    uint8 u8DataBuf[32] = {0};
       if(!my_strncmp("CSQ", strstr2(&Receive_Data[1], "CSQ"), 3u))
       {
           strncpy(TempBuf, strstr2(&Receive_Data[1], "CSQ:"), 7u);
           DataBuf[0] = TempBuf[5];
           DataBuf[1] = TempBuf[6];
           if(TempBuf[7] != ',')
           {
               DataBuf[7] = TempBuf[3];
               DataBuf[8] = '\0';
           }
           else
           {
               DataBuf[2] = '\0';
           }
           udp_data.u32NetworkCSQ1 = a2i(DataBuf);
           if(udp_data.u32NetworkCSQ1 > 31)
           {
               udp_data.u32NetworkCSQ1 = 0;
           }
       }

       if(!my_strncmp("CREG", strstr2(&Receive_Data[10], "CREG: "), 4))
       {
           strcpy((char*)u8DataBuf, strstr2(&Receive_Data[10], ","));
           udp_data.chCGREG1 = u8DataBuf[1] - 0x30;
       }
       else
       {
       }
}


void GSM_health_status_monitor_interrupt(void)
{
    if(gGenCntReg1 > 5)
    {
        gGenCntReg1 = 0;
        if(++GenCnt1 > 2)
            GenCnt1 = 0;

        switch(GenCnt1)
        {
            case 0:
                   size = 0u;
                   sciDisplayText(scilinREG, (uint8_t *)"AT+CCLK?\r\n", 10u);
                   break;
            case 1:
                   size = 0u;
                   sciDisplayText(scilinREG, (uint8_t *)"AT+CSQ\r\n", 8u);
                   break;
            case 2:
                   size = 0u;
                   sciDisplayText(scilinREG, (uint8_t *)"AT+CREG?\r\n", 10u);
                   break;
            default:
                   break;
        }
    }
}

