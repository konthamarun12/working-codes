/***************************************************************************
 Serial0.c - Mian file for Logica project.
 This is SW-LM3S-5727 of the EK-LM3S8962 Firmware driver library Package.
 ***************************************************************************/


#include "MAIN.h"
#include "ff.h"
#include "diskio.h"

/***************************************************************************
 The filesystem structure for the SD card.
***************************************************************************/

FATFS g_sFatFs;
char SDCardBuf[1024] = {0};



/***************************************************************************
The file object for the current opened file, which will be key.txt for
reading during startup, or for writing if the access code is changed.
***************************************************************************/
unsigned long bcnt;
UINT usCount;
FIL sFile;


unsigned long 
Get_MemoryStatus(void)
{
	unsigned long ulTotalSize = 0U;
	char fresult = 0;
	FATFS *pFatFs;

	fresult = f_getfree("/", &ulTotalSize, &pFatFs);

	if(fresult == FR_OK)
    {
        return(ulTotalSize);
    }
	else
	{
		return 0;
	}
}

/*****************************************************************************************************************
                                           Function to create a file.
******************************************************************************************************************/

void
SDCard_CreateFile(const char *Filename,const char * Code)
{
  /*  FRESULT fr =  f_mkfs (BYTE vol, BYTE sfd, UINT au);*/

//    FRESULT fr =  f_mkfs (0u,1u,512u);
    f_mount(0U, &g_sFatFs);
	if(f_open(&sFile, Filename, FA_CREATE_ALWAYS | FA_WRITE) == FR_OK)
	{
		/* Attempt to write the access code to the file.*/
		if(f_write(&sFile, Code, my_strlen(Code), &usCount) == FR_OK)
		{
			/* Synchronize the file with the disk, flushing any cached data.*/
			f_sync(&sFile);
		}
		
		/* Close the file.*/
		f_close(&sFile);
	}
}

/***************************************************************************
 Changes the access code, saving it to a file on the SD card (if present).
***************************************************************************/

void
SDCard_WriteFile(char * Filename, char * Code)
{
	/* Attempt to create the file to hold the access code.*/
	if(f_open(&sFile, Filename, FA_WRITE) == FR_OK)
	{
		/* Attempt to write the access code to the file.*/
		if(f_write(&sFile, Code, my_strlen(Code), &usCount) == FR_OK)
		{
			/* Synchronize the file with the disk, flushing any cached data.*/
			f_sync(&sFile);
		}
		
		/* Close the file.*/
		f_close(&sFile);
	}
}

/***************************************************************************
           Seek file R/W pointer in the SD card (if present)
***************************************************************************/

void
SDCard_SeekPipe(const char * Filename, uint64 LineCnt, int Pipe_Cnt, const char * Data,
				char Mode, uint32 Len)			/* unsigned long ReadCount*/
{
	
 /* uint16 gSDCard_Cnt = 0U;*/
	
	/* Mount the SD card filesystem.*/
	f_mount(0U, &g_sFatFs);
	
	/* Attempt to open the file containing the access code.*/
	if(f_open(&sFile, Filename, FA_READ | FA_WRITE) == FR_OK)
	{
		if(Pipe_Cnt)
		{
			f_lseek(&sFile, LineCnt);
			while(Pipe_Cnt)
			{
				f_read(&sFile, SDCardBuf, 1U, &usCount);
				LineCnt++;
				if(SDCardBuf[0] == ',')
				{
					Pipe_Cnt--;
				}else{}
			}
		}
		if(Mode == 'R')
		{
			if(f_lseek(&sFile, LineCnt) == FR_OK)
			{
               if(u8init == 0u){
				 f_read(&sFile, SDCardBuf, 500U, &usCount);
               }
               else
               {
                   f_read(&sFile, Data, Len, &usCount);
               }

			}
	 	}
		else if(Mode == 'W')
		{
			
			if((f_lseek(&sFile, LineCnt )) == FR_OK)
			{
				
				f_write(&sFile, Data, Len, &usCount);
				
				
	  		     if(!my_strcmp(Filename,"/LIVEDAT.txt"))
				 {
					  live_data_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/CRITDAT.txt"))
				 {
					 crit_data_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/TRIGDAT.txt"))
				 {
					 trig_data_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/TRIGMDAT.txt"))
				 {
					 trigm_data_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/SVKDAT.txt"))
				 {
					 svk_data_line_count = f_tell(&sFile);

				 }
				 else if(!my_strcmp(Filename,"/TSRMSDAT.txt"))
				 {
					 tsrms_data_line_count = f_tell(&sFile);
				 }
                 else if(!my_strcmp(Filename,"/tcas.txt"))
                 {
					 tcas_data_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/DataLR.txt"))
				 {
					 locoreg_line_cnt = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/DataAR.txt"))
				 {
					  arpkt_line_count = f_tell(&sFile);
				 }
				 else if(!my_strcmp(Filename,"/DataAG.txt"))
				 {
					  agpkt_line_count = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/DataTAG.txt"))
				 {
				     tag_dat_line_cnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/LLIVEDAT.txt"))
				 {
				     locolivedatalinecnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/LTRIGDAT.txt"))
				 {
				     locotrigdatalinecnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/LTRGMDAT.txt"))
				 {
				     locotrigmaintdatalinecnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/LCRITDAT.txt"))
				 {
				     lococritdatalinecnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/DataSR.txt"))
				 {
				     stnreg_line_cnt = (uint64)(f_tell(&sFile));
				 }
				 else if(!my_strcmp(Filename,"/DataAE.txt"))
				 {
				     aepkt_line_count = (uint64)(f_tell(&sFile));
				 }
				 else
				 {
					 
				 }
					 
		         /*		gSDCard_Cnt = usCount; */
					 
				/* Synchronize the file with the disk, flushing any cached data.*/
				f_sync(&sFile);
			}
		}
		else{}
	}
	else{}
	/* Close the file.*/
	f_close(&sFile);
}



/********************************************************************************************************************************************/

