/*
 * ADL_can.c
 *
 *  Created on: Aug 30, 2024
 *      Author: HP
 */

#include "MAIN.h"


gATPTest_ ATP;
gInputData IPData;
//gcanFun CAN_Info;
gDipinfo_t DipInfo;

//uint8 u8index=0;
uint8 u8MCU2_CANTx = 0;
uint8 u8cani,u8canj;
uint8 u8canbuff = 0u;

void ADL_health_data_packet(void)
{
    u8canTxbuff[0] = 0x18u;
    u8canTxbuff[1] = DipInfo.u8Address;
    u8canTxbuff[2] = DipInfo.u8Config;
    u8canTxbuff[3] = DipInfo.u8Slot;
    u8canTxbuff[4] = ATP.u8SLEDTest;
    u8canTxbuff[5] = u8GSMBuff[0];
    u8canTxbuff[6] = u8GSMBuff[1];
    u8canTxbuff[7] = u8GSMBuff[2];

    CAN_Info.u32canMsgID = create_can_msg_object(2);
    canUpdateID(canREG1, canMESSAGE_BOX1, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX1, (uint8*)u8canTxbuff);

//    for(u8index = 0;u8index < 8;u8index++)
//    {
//        u8canTxbuff[u8index] = 0u;
//    }
}

//uint32 create_can_msg_object(uint8 u8CANMsg_ID)
//{
//    /*CAN_Info.u32canMsg_id = (uint32)u8CANMsg_ID;*/
//    CAN_Info.u32CAN_arbitration_value = 0u;
//
//    CAN_Info.u32cpuID = ADLBASEID + u8CANMsg_ID + (DipInfo.u8Address * 256u);
//    CAN_Info.u32CAN_arbitration_value = (((0x01u << 30u) | (0x01u << 29u) | (CAN_Info.u32cpuID & 0x1FFFFFFFu)) & 0x7FFFFFFFu);
//
//    return CAN_Info.u32CAN_arbitration_value;
//}


void ADL_CAN_Pkt_Transmit(void)
{
    //uint8 offset = 0;
    u8canTxbuff[0] = ATP.u8ATPTestData[0];
    u8canTxbuff[1] = ATP.u8ATPTestData[1];
    u8canTxbuff[2] = ATP.u8ATPTestData[2];
    u8canTxbuff[3] = ATP.u8ATPTestData[3];
    u8canTxbuff[4] = ATP.u8ATPTestData[4];
    u8canTxbuff[5] = ATP.u8ATPTestData[5];
    u8canTxbuff[6] = ATP.u8ATPTestData[6];
    u8canTxbuff[7] = ATP.u8ATPTestData[7];
   /* for(u8index = 0;u8index < 8;u8index++)
    {
        u8canTxbuff[u8index] = ATP.u8ATPTestTxd[offset];
    }*/

    CAN_Info.u32canMsgID = create_can_msg_object(1);
    canUpdateID(canREG1, canMESSAGE_BOX1, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX1, (uint8*)u8canTxbuff);
    if(u8MCU2_CANTx || ATP.isCANTestDataRxd2)
    {
        canUpdateID(canREG2, canMESSAGE_BOX2, CAN_Info.u32canMsgID);
        canTransmit(canREG2, canMESSAGE_BOX2, (uint8*)u8canTxbuff);
    }
    CAN_buffer_free_function();


    u8canTxbuff[0] = ATP.u8ATPTestData[8];
    u8canTxbuff[1] = ATP.u8ATPTestData[9];
    u8canTxbuff[2] = ATP.u8ATPTestData[10];
    u8canTxbuff[3] = ATP.u8ATPTestData[11];
    u8canTxbuff[4] = ATP.u8ATPTestData[12];
    u8canTxbuff[5] = ATP.u8ATPTestData[14];
    u8canTxbuff[6] = ATP.u8ATPTestData[15];
    u8canTxbuff[7] = ATP.u8ATPTestData[16];

    CAN_Info.u32canMsgID = create_can_msg_object(2);
    canUpdateID(canREG1, canMESSAGE_BOX1, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX1, (uint8*)u8canTxbuff);
    if(u8MCU2_CANTx || ATP.isCANTestDataRxd2)
    {
        canUpdateID(canREG2, canMESSAGE_BOX2, CAN_Info.u32canMsgID);
        canTransmit(canREG2, canMESSAGE_BOX2, (uint8*)u8canTxbuff);
    }
    CAN_buffer_free_function();


    u8canTxbuff[0] = ATP.u8ATPTestData[17];
    u8canTxbuff[1] = ATP.u8ATPTestData[18];
    u8canTxbuff[2] = ATP.u8ATPTestData[19];
    u8canTxbuff[3] = ATP.u8ATPTestData[20];
    u8canTxbuff[4] = ATP.u8ATPTestData[21];
    u8canTxbuff[5] = ATP.u8ATPTestData[22];
    u8canTxbuff[6] = ATP.u8ATPTestData[23];
    u8canTxbuff[7] = ATP.u8ATPTestData[24];

    CAN_Info.u32canMsgID = create_can_msg_object(3);
    canUpdateID(canREG1, canMESSAGE_BOX1, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX1, (uint8*)u8canTxbuff);
    if(u8MCU2_CANTx || ATP.isCANTestDataRxd2)
    {
        canUpdateID(canREG2, canMESSAGE_BOX2, CAN_Info.u32canMsgID);
        canTransmit(canREG2, canMESSAGE_BOX2, (uint8*)u8canTxbuff);
    }
    CAN_buffer_free_function();

}


//void CAN_buffer_free_function(void)
//{
//    for(u8index = 0;u8index < 8;u8index++)
//    {
//        u8canTxbuff[u8index] = 0u;
//    }
//}


void CAN_Data_separation(void)
{
    //memcpy(CAN_Data.u8EventLogData1[CAN_Data.u8EVENTcurpktidx],ucMsgData,8U);
    uint8_t u8index = 0u;//, u8subindex = 0u;

    for(u8index = 0; u8index < 4u; u8index++)
    {
        ATP.u8ATPTestData[u8index] = u8CANRx_Msg[0][u8index];
    }

    if (u8CANRx_Msg[0][4] != 0u)
    {
        ATP.u8SLEDTest = SET_HIGH;
        ATP.u8SLEDTest = u8CANRx_Msg[0][4];
    }

    ATP.u8DIP1Test = u8CANRx_Msg[0][5];
    ATP.isTestDIP1 = (bool) SET_HIGH;
    ATP.u8DIP2Test = u8CANRx_Msg[0][6];
    ATP.isTestDIP2 = (bool) SET_HIGH;
    ATP.u8SlotTest = u8CANRx_Msg[0][7];
    ATP.isSlotDete = (bool) SET_HIGH;

    if(u8CANRx_Msg[1][0] != 0u)
    {
        ATP.isTestSCI1 = SET_HIGH;
        ATP.u8SciTest1 = u8CANRx_Msg[1][0];
    }
    if(u8CANRx_Msg[1][1] != 0u)
    {
        ATP.isTestSCI2 = SET_HIGH;
        ATP.u8ScITest2 = u8CANRx_Msg[1][1];
    }

    /*if (u8CANRx_Msg[0][7] != 0u)
    {
        ATP.isTestRS4851 = SET_HIGH;
        ATP.u8RS4851Test = u8CANRx_Msg[0][7];
    }

    if (u8CANRx_Msg[1][0] != 0u)
    {
        ATP.isTestRS4852 = SET_HIGH;
        ATP.u8RS4852Test = u8CANRx_Msg[1][0];
    }
*/
    if (u8CANRx_Msg[1][2] != 0u)
    {
        ATP.isTestCAN1 = SET_HIGH;
        ATP.u8CAN1Test = u8CANRx_Msg[1][2];
    }
    if (u8CANRx_Msg[1][3] != 0u)
    {
        ATP.isTestCAN2 = SET_HIGH;
        ATP.u8CAN2Test = u8CANRx_Msg[1][3];
    }
    if (u8CANRx_Msg[1][4] != 0u)
    {
        ATP.isTestGSMEn = SET_HIGH;
        ATP.u8GSMInit = u8CANRx_Msg[1][4];
    }

    if (u8CANRx_Msg[1][5] != 0u)
    {
        ATP.isTestSIMdetect = SET_HIGH;
        ATP.u8SIMDetect = u8CANRx_Msg[1][5];
    }
    if (u8CANRx_Msg[1][6] != 0u)
    {
        ATP.isTestSDEn = SET_HIGH;
        ATP.u8SDcard_Detect = u8CANRx_Msg[1][6];
    }

    if (u8CANRx_Msg[1][7] != 0u)
    {
        ATP.isTestSPI = SET_HIGH;
        ATP.u8SPITest = u8CANRx_Msg[1][7];
    }
    if (u8CANRx_Msg[2][0] != 0u)
    {
        ATP.isTestI2C = SET_HIGH;
        ATP.u8I2CTest = u8CANRx_Msg[2][0];
    }

    for(u8cani = 0u;u8cani < 3; u8cani++)
    {
        for(u8canj = 0u;u8canj < 8; u8canj++)
        ATP.u8ATPTestData[u8canbuff] = u8CANRx_Msg[u8cani][u8canj];
    }
    u8MCU2_CANTx = 1u;
}

