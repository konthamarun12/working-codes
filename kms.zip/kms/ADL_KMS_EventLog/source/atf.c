/*
 * atf.c
 *
 *  Created on: 01-Aug-2024
 *      Author: User
 */


/*#include "sci.h"
#include "gio.h"
#include "het.h"
#include "can.h"
#include "atf.h"
#include "parallel.h"
#include "kavach.h"
#include "user_can.h"*/

#include "MAIN.h"

#define Tsize (2000u)

/* Function Declarations */
void sciDisplayText(sciBASE_t *sci, const uint8 *text, uint32 length);
void InitPeripherals(void);
void TestCanComm(void);
void ReadDipSwitchAdd(void);
void ReadDipSwitchConfig(void);
void ReadSlotDetect(void);
void Update_IPStatus(void);
void ProcessSciRxdData();
uint32_t Bit2Byte(bool *datainbits, uint16_t u16Spos, uint8_t u8Offset);
void BuildATPRespons();
void processLogData(uint8_t u8canidentifier);
void process_TSRMS_data(void);
void process_gps_time(void);
//void process_CAN_data(uint8_t u8canidentifier);
//void InitDataport();
uint8_t cpu_id=0;
/* Variable Declaration */
static unsigned char chRxByte1;
static unsigned char chRxByte2;
bool ScilinRxd = (bool)SET_LOW;
uint8 u8sci1DataRxd[Tsize];
uint8 u8sci2DataRxd[Tsize];
uint8 tx_data[8] = {'t','e','s','t','d','a','t','a'};
uint8 tx_data1[8] = {'T','E','S','T','D','A','T','A'};
uint32 Size;
//uint8_t u8CanMesg[8] = {0};
uint8 u8LenghtRxd1;
//uint8 u8LenghtRxd2;
//uint8_t u8canidentifier =0;
uint8 set;

//uint8 u8CANRx_Msg[8][8] = {0};
uint8 u8CAN_RxCnt = 0u;
uint32_t u32MsgID=0u;
uint8 u8CANRx_offset = 0u;
uint8 u8GSMBuff[50] = {0};
/* structure declaration */
gATPTest_ ATP;
gDipinfo_t DipInfo;


/*********************************************
                  for radio
 *********************************************/
RADIO_PKT_t radio_pkt;
/*void RADIO_CAN_pkt(void); */
CRITICAL_PKT_t critical_pkt;
GPS_PKT_t gps_pkt;
TSRMS_PKT_t tsrms_pkt;
/********************************************/

void InitPeripherals(void)
{
    canEnableErrorNotification(canREG1);
    canEnableErrorNotification(canREG2);

    sciEnableNotification(scilinREG, (uint32) SCI_RX_INT);
    sciReceive(scilinREG, 1u, (unsigned char*) &chRxByte1);
    sciEnableNotification(sciREG, (uint32) SCI_RX_INT);
    sciReceive(sciREG, 1u, (unsigned char*) &chRxByte2);

    gioSetDirection(gioPORTA, (uint32_t)0u);

    gioSetDirection(gioPORTB, (uint32_t)0u);

    gioSetDirection(gioPORTB, 0x000000F0u);
//    gioSetDirection(gioPORTB, (uint32_t)0x0Cu);
    //gioSetDirection(mibspiPORT1, 0x01 << 1u | 0x01 << 8u);

    gioSetDirection(EMIFPORT, (uint32_t)0xFFFFF4E0u);          //* EMIF PORT */
}


/***********************************************************************************/
/*void sciDisplayText(sciBASE_t *sci, uint8 *text, uint32 length)
{
    while(length--)
    {
        if(sci == scilinREG)
        {
            while((scilinREG->FLR & 0x4u) == 4u);
            sciSendByte(scilinREG, *text++);
        }
        if(sci == sciREG)
        {
            while((sciREG->FLR & 0x4u) == 4u);
            sciSendByte(sciREG, *text++);
        }
    };
}*/
/***********************************************************************************/
void ProcessSciRxdData()
{
    uint8_t u8index = 0u;//, u8subindex = 0u;
    uint8_t SOF[4] = {0};
    //uint32_t u32temp = 0u;

    for(u8index = 0; u8index < 4u; u8index++)
    {
        SOF[u8index] = ATP.u8ATPTestData[u8index];
    }

    if(ATP.u8ATPTestData[4] != 0u)
    {
        ATP.u8SLEDTest = SET_HIGH;
        ATP.u8SLEDTest = ATP.u8ATPTestData[4];
    }

    ATP.u8DIP1Test = ATP.u8ATPTestData[5];
    ATP.isTestDIP1 = (bool) SET_HIGH;
    ATP.u8DIP2Test = ATP.u8ATPTestData[6];
    ATP.isTestDIP2 = (bool) SET_HIGH;
    ATP.u8SlotTest = ATP.u8ATPTestData[7];
    ATP.isSlotDete = (bool) SET_HIGH;


    if (ATP.u8ATPTestData[8] != 0u)
    {
        ATP.isTestSCI1 = SET_HIGH;
        ATP.u8SciTest1 = ATP.u8ATPTestData[8];
    }
    if (ATP.u8ATPTestData[9] != 0u)
    {
        ATP.isTestSCI2 = SET_HIGH;
        ATP.u8ScITest2 = ATP.u8ATPTestData[9];
    }

    /*if (ATP.u8ATPTestData[10] != 0u)
    {
        ATP.isTestRS4851 = SET_HIGH;
        ATP.u8RS4851Test = ATP.u8ATPTestData[10];
    }
    if (ATP.u8ATPTestData[11] != 0u)
    {
        ATP.isTestRS4852 = SET_HIGH;
        ATP.u8RS4852Test = ATP.u8ATPTestData[11];
    }
    if (ATP.u8ATPTestData[12] != 0u)
    {
        ATP.isTestRS4853 = SET_HIGH;
        ATP.u8RS4853Test = ATP.u8ATPTestData[12];
    }*/
    if (ATP.u8ATPTestData[10] != 0u)
    {
        ATP.isTestCAN1 = SET_HIGH;
        ATP.u8CAN1Test = ATP.u8ATPTestData[10];
    }
    if (ATP.u8ATPTestData[11] != 0u)
    {
        ATP.isTestCAN2 = SET_HIGH;
        ATP.u8CAN2Test = ATP.u8ATPTestData[11];
    }
    if (ATP.u8ATPTestData[12] != 0u)
    {
        ATP.isTestGSMEn = SET_HIGH;
        ATP.u8GSMInit = ATP.u8ATPTestData[12];
    }
    if(ATP.u8ATPTestData[13] != 0u)
    {
        ATP.isTestSIMdetect = SET_HIGH;
        ATP.u8SIMDetect = ATP.u8ATPTestData[13];
    }

    if(ATP.u8ATPTestData[14] != 0u)
    {
        ATP.isTestSDEn = SET_HIGH;
        ATP.u8SDcard_Detect = ATP.u8ATPTestData[14];
    }
    if(ATP.u8ATPTestData[15] != 0u)
    {
        ATP.isTestSPI = SET_HIGH;
        ATP.u8SPITest = ATP.u8ATPTestData[15];
    }

    if (ATP.u8ATPTestData[16] != 0u)
    {
       ATP.isTestI2C = SET_HIGH;
       ATP.u8I2CTest = ATP.u8ATPTestData[16];
    }
}
/***********************************************************************************/
/*void sciNotification(sciBASE_t *sci, uint32 flags)
{
    if (sci == scilinREG)
    {
        sciReceive(scilinREG, 1u, (unsigned char*) &chRxByte1);
        //memcpy(ATP.u8ATPTestData, (unsigned char*)chRxByte1,10u);
        if (chRxByte1 == '$' || chRxByte1 == 0xAA)
        {
            Size = (uint32_t)SET_LOW;
        }
        u8sci1DataRxd[Size++] = chRxByte1;
        if (chRxByte1 == 0x0a && u8sci1DataRxd[Size - 2u] == 0x0d)
        {
            if (u8sci1DataRxd[0] == '$') {
                ScilinRxd = (bool) SET_HIGH;
            }
            if (u8sci1DataRxd[0] == 0xAA) {
                ATP.isTestDataRxd = (bool) SET_HIGH;
                memcpy(ATP.u8ATPTestData, u8sci1DataRxd, Size);
            }
        };
        u8LenghtRxd1 = Size;
    }
    if (sci == sciREG) {
        sciReceive(sciREG, 1u, (unsigned char*) &chRxByte2);
        u8sci2DataRxd[Size++] = chRxByte2;
        if((chRxByte2 == 0x0A) && (u8sci2DataRxd[Size - 2u] == 0x0D))
        {
            ATP.isTestDataRxd1 = (bool)SET_HIGH;
        }
        u8LenghtRxd2 = Size;

    }
}*/
/***********************************************************************************/
void BuildATPRespons()
{
    ATP.u8ATPTestTxd[0] = 0xAAu;
    ATP.u8ATPTestTxd[1] = 0xCCu;
    ATP.u8ATPTestTxd[2] = 0x4Fu;
    ATP.u8ATPTestTxd[3] = 0xA4u;

    ATP.u8ATPTestTxd[4] = ATP.u8GSMInit;
    ATP.u8ATPTestTxd[5] = ATP.u8SIMDetect;
    ATP.u8ATPTestTxd[6] = ATP.u8SPITest;
    ATP.u8ATPTestTxd[7] = ATP.u8I2CTest;

    ATP.u8ATPTestTxd[8] = ATP.u8SLEDTest;
    ATP.u8ATPTestTxd[9] = DipInfo.u8Address;
    ATP.u8ATPTestTxd[10] = DipInfo.u8Config;
    ATP.u8ATPTestTxd[11] = DipInfo.u8Slot;
    ATP.u8ATPTestTxd[12] = ATP.u8ParallelTest;
    ATP.u8ATPTestTxd[13] = 0x00u;
    ATP.u8ATPTestTxd[14] = ATP.u8ScITest2;
    ATP.u8ATPTestTxd[15] = ATP.u8SciTest1;
    ATP.u8ATPTestTxd[16] = ATP.u8RS4851Test;
    ATP.u8ATPTestTxd[17] = ATP.u8RS4852Test;
    ATP.u8ATPTestTxd[18] = ATP.u8RS4853Test;
    ATP.u8ATPTestTxd[19] = ATP.u8CAN1Test;
    ATP.u8ATPTestTxd[20] = ATP.u8CAN2Test;

    ATP.u8ATPTestTxd[21] = ATP.u8SDcard_Detect;

    ATP.u8ATPTestTxd[22] = 0x00u;
    ATP.u8ATPTestTxd[23] = 0x00u;
    ATP.u8ATPTestTxd[24] = 0x0D;
    ATP.u8ATPTestTxd[25] = 0x0A;


/*    sciDisplayText(sciREG, ATP.u8ATPTestTxd,26u);*/

}
/***********************************************************************************/
void TestCanComm(void)
{
    uint32_t u32cnt = 0u;
    canTransmit(canREG1, canMESSAGE_BOX1, (uint8 *)tx_data1);
    for(u32cnt = 0; u32cnt <10000000; u32cnt++){}
    canTransmit(canREG2, canMESSAGE_BOX2, (uint8 *)tx_data);
    for(u32cnt = 0; u32cnt <10000000; u32cnt++){}
}
/***********************************************************************************/
/*
void canMessageNotification(canBASE_t *node, uint32 messageBox)
{
    if (node == canREG1)
    {
        if (messageBox == canMESSAGE_BOX3)
        {
             u32MsgID = canGetID(canREG1, messageBox);
            if(((u32MsgID & 0xFFFF0)== 0x18000)  || ((u32MsgID & 0xFFFF0)== 0x28000))
            {

            u8canidentifier = u32MsgID & 0xFFu;
            canGetData(canREG1, messageBox, (uint8 *) ucMsgData);
            processLogData(u8canidentifier);

            }
            else if(((u32MsgID & 0xFFFF0)== 0x38000)  || ((u32MsgID & 0xFFFF0)== 0x48000))
            {
            u8canidentifier = u32MsgID & 0xFFu;
            canGetData(canREG1, messageBox, (uint8 *) ucMsgData);
            processLogData(u8canidentifier);
            }
            else
            {

            }

        }
        if(messageBox == canMESSAGE_BOX7)
        {
            u32MsgID = canGetID(canREG1, canMESSAGE_BOX7);
            canGetData(canREG1, canMESSAGE_BOX7, (uint8 *) ucMsgData);
            if((u32MsgID & 0xFF00)==0x3100u)
            {
              u8canidentifier = u32MsgID & 0xFFu;

              process_CAN_data(u8canidentifier);
            }
            else
            {

            }

        }

*/

/*
        if(messageBox == canMESSAGE_BOX1 )
        {
            u32MsgID = canGetID(canREG1, canMESSAGE_BOX1);

            canGetData(canREG1, canMESSAGE_BOX1, (uint8 *) ucMsgData);
            if(((u32MsgID & 0xFF00)==0x2100) || ((u32MsgID & 0xFF00)==0x2400))
            {

              process_gps_time();
            }
            else
            {

            }


            if((u32MsgID & 0xFF00)==0x2300u)
            {
                u8canidentifier =(uint8_t) (u32MsgID & 0xFFu);
                memcpy(tsrms_pkt.u8TSRMS_tmp_buff,ucMsgData,8u);
                process_TSRMS_data();
            }
        }


    }

    if (node == canREG2)
    {
        if ( messageBox == canMESSAGE_BOX3)
        {
            u32MsgID = canGetID(canREG2, messageBox);
            u8canidentifier = u32MsgID & 0xFFu;
           cpu_id = (u32MsgID & 0xF0000u) >> 16u;
            canGetData(canREG2, messageBox, (uint8 *) u8CanMesg);


            if(((u32MsgID & 0xFF00u) == 0x3200u) && ((u8canidentifier & 0xFFu) < 27u))
            {
                ExtractLocoEventdata(u8canidentifier);
            }

            if(((u8canidentifier & 0xFFu) >= 27u) && ((u8canidentifier & 0xFFu) <= 53u))
            {
                ExtractLiveEventdata(u8canidentifier);
            }

        }
    }
  }
*/

/***********************************************************************************/
uint8_t CheckCANData(void)
{
    uint8_t u8index = 0u, u8result = 0u;
    for (u8index = 0; u8index < 8u; ++u8index)
    {
        if (tx_data1[u8index] != u8CanMesg[u8index])
        {
            u8result++;
        }
        else
        {

        }
    }
    return u8result;
}
/***********************************************************************************/

/***************************************************************************************************************/

void controller_test_function(void)
{
    if((DipInfo.u8Address == 0x01u) && (DipInfo.u8Config == 0x00u))
    {
        ATP.isUSBTestData = SET_HIGH;
    }
    else if((DipInfo.u8Address == 0x02u) && (DipInfo.u8Config == 0x01u))
    {
        ATP.isCANTestData = SET_HIGH;
    }
    else
    {
    }
}

void GSM_siganl_strength(void)
{
    sciDisplayText(scilinREG, (uint8_t *)"AT+CSQ\r\n", 8u);
    wait(10u);
    if(!GSM_wait("OK"))
    {
        if(strncmp("+CSQ", strstr((const char*)&u8sci1DataRxd[Size],"+CSQ"),5U))
        {
            strncpy((char *)u8GSMBuff, strstr((const char*)&u8sci1DataRxd[Size], "+CSQ: "),5U);
        }
    }
}

void GSM_SIM_Detection(void)
{
    sciDisplayText(scilinREG, (uint8_t *)"AT+CPIN?\r\n", 10u);
    wait(10u);
    if(strncmp("+CPIN", strstr((const char *)&u8sci1DataRxd[Size], "+CPIN"), 5u))
    {
        strncpy((char*)u8GSMBuff, strstr((const char*)&u8sci1DataRxd[Size], "+CPIN"), 5u);
    }

    if(!GSM_wait("OK"))
    {
        ATP.isTestSIMdetect = SET_HIGH;
    }
    else
    {
    }
}

void can_msg_send1(uint8 u8CANMsg_ID)                                           /* create CAN message ID */
{
    DipInfo.u8Address = 2u;
    CAN_Info.u32cpuID = VPMBASEID + u8CANMsg_ID + (DipInfo.u8Address * 256u);
    CAN_Info.u32canMsgID = (((0x01u << 30u) | (0x01u << 29u) | (CAN_Info.u32cpuID & 0x1FFFFFFFu)) & 0x7FFFFFFFu);
    canUpdateID(canREG1, canMESSAGE_BOX5, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, ucMsgTxBOX8);
}


void process_CAN_data(uint8_t u8canidentifier)
{
    uint8_t ID = u8canidentifier;

    if(ID == INFO_PKT)
    {
        memcpy(radio_pkt.u8Info,ucMsgData,8u);
        radio_pkt.u8pkt_type=radio_pkt.u8Info[0];
        radio_pkt.u8sub_pkt_type=radio_pkt.u8Info[1];
        radio_pkt.u16Total_byte=(((uint16_t)radio_pkt.u8Info[2] <<8u) | ((uint16_t )radio_pkt.u8Info[3] <<0u));
        radio_pkt.u8Total_pkt= radio_pkt.u8Info[4];
        radio_pkt.u8Current_pkt=radio_pkt.u8Info[5];
        radio_pkt.u8pre_command=INFO_PKT;

    }

    if((ID == DATA_PKT) && (radio_pkt.u8pre_command == INFO_PKT) && (radio_pkt.u8pkt_type == RADIO_PKT))
    {
        if(radio_pkt.u8Total_pkt >= radio_pkt.u8Current_pkt)
        {
            switch(radio_pkt.u8sub_pkt_type)
            {
            case (0x0Du):
                    my_MemCpy(radio_pkt.u8AR,ucMsgData,8u, radio_pkt.u8Current_pkt);
                    if(radio_pkt.u8Total_pkt== radio_pkt.u8Current_pkt)
                    {

                        radio_pkt.u16AR_pkt_count= radio_pkt.u16Total_byte;
                        WriteSDCard(&radio_pkt.u8AR[0], 3u, radio_pkt.u16AR_pkt_count,0u);
                    }
                    else
                    {

                    }
                    break;

            case (0x0Bu):
                    my_MemCpy(radio_pkt.u8AG,ucMsgData,8u, radio_pkt.u8Current_pkt);
                    if(radio_pkt.u8Total_pkt== radio_pkt.u8Current_pkt)
                    {

                        radio_pkt.u16AG_pkt_count= radio_pkt.u16Total_byte;
                        WriteSDCard(&radio_pkt.u8AG, 4u, radio_pkt.u16AG_pkt_count,0u);
                    }
                    else
                    {

                    }
                    break;
            case (0x09u):
                                           my_MemCpy(radio_pkt.u8STL,ucMsgData,8u, radio_pkt.u8Current_pkt);
                                           if(radio_pkt.u8Total_pkt== radio_pkt.u8Current_pkt)
                                           {

                                               radio_pkt.u16STL_pkt_count= radio_pkt.u16Total_byte;
                                               WriteSDCard(&radio_pkt.u8STL, 1u, radio_pkt.u16STL_pkt_count,0u);
                                           }
                                           else
                                           {

                                           }
                                           break;
            case (0x0Au):
                                           my_MemCpy(radio_pkt.u8LTS,ucMsgData,8u, radio_pkt.u8Current_pkt);
                                           if(radio_pkt.u8Total_pkt== radio_pkt.u8Current_pkt)
                                           {


                                               radio_pkt.u16LTS_pkt_count= radio_pkt.u16Total_byte;
                                               WriteSDCard(&radio_pkt.u8LTS, 2u, radio_pkt.u16LTS_pkt_count,0u);
                                           }
                                           else
                                           {

                                           }
                                           break;
            case (0x0Cu):
                                           my_MemCpy(radio_pkt.u8AE,ucMsgData,8u, radio_pkt.u8Current_pkt);
                                           if(radio_pkt.u8Total_pkt== radio_pkt.u8Current_pkt)
                                           {


                                               radio_pkt.u16AE_pkt_count= radio_pkt.u16Total_byte;
                                               WriteSDCard(&radio_pkt.u8AE, 5u, radio_pkt.u16AE_pkt_count,0u);
                                           }
                                           else
                                           {

                                           }
                                           break;
            default:
                                           break;



            }
        }
    }


}

void RADIO_CAN_pkt(void)
{
    data_pkt_buffer[0]=RADIO_PKT;
    data_pkt_buffer[1]=0x0Du;
    data_pkt_buffer[2]=0x00u;
    data_pkt_buffer[3]=0x0Fu;
    data_pkt_buffer[4]=0x02u;
    data_pkt_buffer[5]=0x01u;
    data_pkt_buffer[6]=0x00u;
    data_pkt_buffer[7]=0x00u;
    uint32_t message_ID= 3101;
    uint32_t u32arbit_value= (((uint32_t)1<<29u) | ((uint32_t)1<<29u)|((uint32_t)message_ID<<0u));
    canUpdateID(canREG1,canMESSAGE_BOX2,u32arbit_value);
    canTransmit(canREG1, canMESSAGE_BOX2, &data_pkt_buffer[0]);
    wait(10000u);

    data_pkt_buffer[0]=RADIO_PKT;
    data_pkt_buffer[1]=0x0Du;
    data_pkt_buffer[2]=0x00u;
    data_pkt_buffer[3]=0x0Fu;
    data_pkt_buffer[4]=0x02u;
    data_pkt_buffer[5]=0x01u;
    data_pkt_buffer[6]=0x00u;
    data_pkt_buffer[7]=0x00u;
    message_ID= 3102;
    u32arbit_value= (((uint32_t)1<<29u) | ((uint32_t)1<<29u)|((uint32_t)message_ID<<0u));
    canUpdateID(canREG1,canMESSAGE_BOX2,u32arbit_value);
    canTransmit(canREG1, canMESSAGE_BOX2, &data_pkt_buffer[0]);
    wait(10000u);

    data_pkt_buffer[0]=RADIO_PKT;
    data_pkt_buffer[1]=0x0Du;
    data_pkt_buffer[2]=0x00u;
    data_pkt_buffer[3]=0x0Fu;
    data_pkt_buffer[4]=0x02u;
    data_pkt_buffer[5]=0x02u;
    data_pkt_buffer[6]=0x00u;
    data_pkt_buffer[7]=0x00u;
    message_ID= 3101;
    u32arbit_value= (((uint32_t)1<<29u) | ((uint32_t)1<<29u)|((uint32_t)message_ID<<0u));
    canUpdateID(canREG1,canMESSAGE_BOX2,u32arbit_value);
    canTransmit(canREG1, canMESSAGE_BOX2, &data_pkt_buffer[0]);
    wait(10000u);

    data_pkt_buffer[0]=RADIO_PKT;
    data_pkt_buffer[1]=0x0Du;
    data_pkt_buffer[2]=0x00u;
    data_pkt_buffer[3]=0x0Fu;
    data_pkt_buffer[4]=0x02u;
    data_pkt_buffer[5]=0x02u;
    data_pkt_buffer[6]=0x00u;
    data_pkt_buffer[7]=0x00u;
    message_ID= 3102;
    u32arbit_value= (((uint32_t)1<<29u) | ((uint32_t)1<<29u)|((uint32_t)message_ID<<0u));
    canUpdateID(canREG1,canMESSAGE_BOX2,u32arbit_value);
    canTransmit(canREG1, canMESSAGE_BOX2, &data_pkt_buffer[0]);
    wait(10000u);

}


void processLogData(uint8_t u8canidentifier)
{
    uint8_t CAN_ID=u8canidentifier;
    if(CAN_ID==DATE_PKT)
    {
        my_MemCpy((uint8_t*)critical_pkt.critical_buff,ucMsgData,8u,DATE_PKT);
        critical_pkt.pre_command=DATE_PKT;
    }
    if((CAN_ID==ABS_PKT) && (critical_pkt.pre_command==DATE_PKT))
    {
        my_MemCpy((uint8_t*)critical_pkt.critical_buff,ucMsgData,8u,ABS_PKT);
        critical_pkt.pre_command=ABS_PKT;
    }
    if((CAN_ID==ERROR_PKT) && (critical_pkt.pre_command==ABS_PKT))
    {
        my_MemCpy((uint8_t*)critical_pkt.critical_buff,ucMsgData,8u,ERROR_PKT);
        critical_pkt.pre_command=ERROR_PKT;
        critical_pkt.event_type=CRITICALDATA;
        critical_pkt.sub_pkt=critical_pkt.critical_buff[17];
        ProcessEventdata( critical_pkt.event_type,0u);
    }
}


void my_MemCpy(uint8_t * dest, uint8_t * src, uint8 len,uint8_t can_ID)
{
  /*  uint8 k;

    uint8 * csrc = (uint8 *)src;
    uint8 * cdest = (uint8 *)dest;

    for(k = 0u; k < num; k++)
    {
        cdest[k] = csrc[k];
    } */


       uint8_t i=0;

       can_ID=can_ID*len;
       can_ID=can_ID-len;
       for(i=0u;i<len;i++)
       {
           dest[can_ID]=src[i];

         can_ID++;
       }
}


void creating_buff()
{
    critical_pkt.critical_buff[0]=0xA3u;
    critical_pkt.critical_buff[1]=0x0cu;
    critical_pkt.critical_buff[2]=0x01u;
    critical_pkt.critical_buff[3]=0x07u;
    critical_pkt.critical_buff[4]=0xE8u;
    critical_pkt.critical_buff[5]=0x0Bu;
    critical_pkt.critical_buff[6]=0x0Cu;
    critical_pkt.critical_buff[7]=0x09u;
    critical_pkt.critical_buff[8]=0xA3u;
    critical_pkt.critical_buff[9]=0x01u;
    critical_pkt.critical_buff[10]=0xF6u;
    critical_pkt.critical_buff[11]=0x94u;
    critical_pkt.critical_buff[12]=0x00u;
    critical_pkt.critical_buff[13]=0x00u;
    critical_pkt.critical_buff[14]=0x00u;
    critical_pkt.critical_buff[15]=0x00u;
    critical_pkt.critical_buff[16]=0xA3u;
    critical_pkt.critical_buff[17]=0x13u;
    critical_pkt.critical_buff[18]=0x4Du;
    critical_pkt.critical_buff[19]=0x47u;
    critical_pkt.critical_buff[20]=0x00u;
    critical_pkt.critical_buff[21]=0x00u;
    critical_pkt.critical_buff[22]=0x00u;
    critical_pkt.critical_buff[23]=0x00u;

    WriteCritDatatoSDCard(&critical_pkt.critical_buff[0], 0, (uint8) critical_pkt.critical_buff[16],23u );

}


void process_gps_time(void)
{

    memcpy(gps_pkt.gps_buff,ucMsgData,8u);
    gps_pkt.hour=gps_pkt.gps_buff[0];
    gps_pkt.minute=gps_pkt.gps_buff[1];
    gps_pkt.seconds=gps_pkt.gps_buff[2];
    gps_pkt.date=gps_pkt.gps_buff[3];
    gps_pkt.month=gps_pkt.gps_buff[4];
    gps_pkt.year_MSB=gps_pkt.gps_buff[5];
    gps_pkt.year_LSB=gps_pkt.gps_buff[6];

}


/* void process_gps_abs()
{
    memcpy(gps_pkt.gps_buff,ucMsgData,8u);


}  */



void process_TSRMS_data()
{
    tsrms_pkt.u8TSRMS_pkt_type= tsrms_pkt.u8TSRMS_tmp_buff[0];
    if( tsrms_pkt.u8TSRMS_pkt_type == 0xAB &&(u8canidentifier == 0x02u) )
    {
        tsrms_pkt.u8Total_pkt=tsrms_pkt.u8TSRMS_tmp_buff[1];
        tsrms_pkt.u16message_type=(( (uint16_t)tsrms_pkt.u8TSRMS_tmp_buff[2] <<8u) | ((uint16_t)tsrms_pkt.u8TSRMS_tmp_buff[3] <<0));
        tsrms_pkt.u8Total_len=tsrms_pkt.u8TSRMS_tmp_buff[4];
        tsrms_pkt.u8current_pkt=tsrms_pkt.u8TSRMS_tmp_buff[5];
        tsrms_pkt.pre_command=0x01u;
    }

    if((tsrms_pkt.pre_command==0x01u)&&(u8canidentifier == 0x02u) && (tsrms_pkt.u8TSRMS_pkt_type != 0xAB))
    {
        if(tsrms_pkt.u8Total_pkt >=  tsrms_pkt.u8current_pkt )
        {
            switch( tsrms_pkt.u16message_type)
            {

            case (PDI_MESS) :
                             my_MemCpy(&tsrms_pkt.PDI_mes[0],&tsrms_pkt.u8TSRMS_tmp_buff[0],8u, tsrms_pkt.u8current_pkt);
                              if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                              {
                                  tsrms_pkt.event_type = 0x06u;
                                  ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                              }
                              break;

            case (PDI_ACK_MESS) :
                                         my_MemCpy(&tsrms_pkt.PDI_ACK_mes[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;

            case (TSR_INFO_MESS) :
                                         my_MemCpy(&tsrms_pkt.TSR_info[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;

            case (GET_TSR_MESS) :
                                         my_MemCpy(&tsrms_pkt.GET_TSR_mes[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;

            case (SK_ACK_MESS) :
                                         my_MemCpy(&tsrms_pkt.SK_ACK[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;

            case (DATA_INT_MESS) :
                                         my_MemCpy(&tsrms_pkt.DATA_INT_mes[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;

            case (ACK_MESS) :
                                         my_MemCpy(&tsrms_pkt.ACK_mes[0],tsrms_pkt.u8TSRMS_tmp_buff,8u, tsrms_pkt.u8current_pkt);
                                          if(tsrms_pkt.u8Total_pkt ==  tsrms_pkt.u8current_pkt)
                                          {
                                              tsrms_pkt.event_type = 0x06u;
                                              ProcessEventdata( tsrms_pkt.event_type,&tsrms_pkt.PDI_mes[0]);
                                          }
                                          break;
            default :
                                          break;

            }
        }
    }
}

