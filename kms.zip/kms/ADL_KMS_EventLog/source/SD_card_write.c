/*
 * SD_card_write.c
 *
 *  Created on: Apr 23, 2024
 *      Author: HP
 */


#include "MAIN.h"

char TempDataBuf[100],TempDataBuf1[100];



uint64 live_data_line_count = 0UL;
uint64 crit_data_line_count = 0UL;
uint64 trig_data_line_count = 0UL;
uint64 trigm_data_line_count = 0UL;
uint64 svk_data_line_count = 0UL;
uint64 tsrms_data_line_count = 0UL;
uint64 tcas_data_line_count = 0UL;
uint64 agpkt_line_count = 0UL;
uint64 arpkt_line_count = 0UL;
uint64 locoreg_line_cnt = 0UL;
uint64 stnreg_line_cnt = 0UL;
uint64 tag_dat_line_cnt = 0UL;



char templogbufcrit[512]     = {'\0'};
char templogbuftrig[512]     = {'\0'};
uint8 templogbufLive[512]     = {0u};
char templogbufTrigMain[512] = {'\0'};
char templogbufSvkSvk[512]   = {'\0'};
char templogbufTSRMS[512]    = {'\0'};
char templogbufKMS[512]      = {'\0'};
uint8_t templogradioandtagbuffer[512] = {0u};

/*void WriteSDCard(uint8* log_data , uint8 logtype);*/
void CopytoSDbuf(const uint8* cStrIN, char* cStrOUT, uint16 u8Strcnt);
/*void copytoSDbuf_in_hex_format(char* cStrIN, char* cStrOUT, uint16 u8Strcnt);*/
void formatString(char* buffer, size_t bufferSize, const char* format, int value);
/*void WriteLiveDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 CAN_pkt_cnt);*/


/********************************************************************************************************************************************************
                                                        PROCESS FIELD SD FUNCTION
 **********************************************************************************************************************************************************/


uint32
ProcessFieldSD(uint8 index, const uint8 *pucBuffer, char _val, char _end)
{
    unsigned int i,j;

    if(index == 1U){
        j = 1U;
    }else{
        j = 0U;
    }
    for(i = 0U; i < index ;i++){         /* skip till teh required data field*/
        while(pucBuffer[j] != (uint8)_val)
        {
            if( j > 512U){                /* if data retrived is more tha 50 bytes.. treat as junk*/
                return '\0';
            }else{}

            j++;                         /* discard the data and return NULL*/
        }
    }

    i = 0U;
    while(pucBuffer[j] != (uint8) _val)         /* process the actual data required*/
    {
        if(pucBuffer[j] == (uint8)_end){            /* check for end if data in data recieved buffer*/
            break;
        }else{}
        TempDataBuf1[i] = (char)pucBuffer[j];
        i++;
        j++;
        if(j > 512U){
            return '\0';
        }else{}
    }
    TempDataBuf1[i] = '\0';             /* terminate the string with null*/
    return atoi(TempDataBuf1);          /* return integer value*/


}

/********************************************************************************************************************************************************
                                                        INIT SD CARD FUNCTION
 **********************************************************************************************************************************************************/
void
Init_SD_Card(void)
{
   /* FRESULT f_mkfs (BYTE vol, BYTE sfd, UINT au);*/

    SDCard_SeekPipe("/tcas.txt", 0UL, 0, NULL, 'R', 0U);
    if(!strstr3(SDCardBuf, "$Created\r\n"))
    {
        /*Creating required FIles*/

        SDCard_CreateFile("/tcas.txt", "$Created\r\n");

        SDCard_CreateFile("/DataLog.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataAG.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataAR.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataLR.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataSR.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataAE.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/DataTAG.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/TRIGDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/CRITDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/LIVEDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/TRIGMDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/SVKDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/KMSDAT.txt", "$TCAS data log!\r\n");

        SDCard_CreateFile("/TSRMSDAT.txt", "$TCAS data log!\r\n");

        /*The numbers 0,0x29,0x53.. are  the position numbers to seek placement to print the particular text.
          The numbers are assigned in such a way that any two data lines , there will be an empty line*/

        my_sprintf1s(SDCardBuf,"DataLog.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x00UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"DataAG.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x1EUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"DataAR.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x3BUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"DataLR.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x58UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"DataTAG.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x75UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"TRIGDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x93UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"CRITDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0xB1UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"LIVEDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0xCFUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"TRIGMDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0xEDUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"SVKDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x10CUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"KMSDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x129UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        my_sprintf1s(SDCardBuf,"TSRMSDAT.txt: $85,Count,0,0!\r\n");
        SDCard_SeekPipe("/tcas.txt", 0x146UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));


    }

}


/********************************************************************************************************************************************************
                                                        ASCII TO HEXA FUNCTION
 **********************************************************************************************************************************************************/
uint16
astohex(const uint8 *p)
{

    uint16 n = 0U;
    uint8 i = 0U;
    while((p[i] == ' ') || (p[i] == '  ')){
        i++;
    }

    if((p[i] == 0x30U) && ((p[(i+1)] == 0x78U) || (p[(i+1)] == 0x58U))){
        i+=2U;
    }else{}



    while (((p[i] >= 0x30U) && (p[i] <= 0x39U)) || ((p[i] >= 0x61U) && (p[i] <= 0x66U)) || ((p[i] >= 0x41U) && (p[i] <= 0x46U)))
    {
        n *= 16U;
        if((p[i] >= 0x30U) && (p[i] <= 0x39U)){
            n += (uint16)(p[i] - (uint16)0x30U);
        }else if((p[i] >= 0x61U) && (p[i] <= 0x66U)){
            n += (uint16)(10U + (p[i] - (uint16)0x61U));
        }else{
            n += (uint16)(10U + (p[i] - (uint16)0x41U));
        }

        i++;
    }
    return(n);
}

/********************************************************************************************************************************************************
                                                        PROCESS FIELD FUNCTION
 **********************************************************************************************************************************************************/


uint32
ProcessField(uint8 index, const uint8 *pucBuffer, char _val, char _end)
{
    uint32 i = 1U,j = 1U;

        if(index == 1U){
            j = 0U;
        }else{
            j = 0u;
        }

        for(i = 0U; i < index ;i++){                /* skip till teh required data field*/
            while(pucBuffer[j] != (uint8)_val)
            {
                if( j > 512U){                     /* if data retrived is more tha 50 bytes.. treat as junk*/
                    return '\0';
                }else{}

                  j++;                               /* discard the data and return NULL*/
            }
        }
        i = 0U;
        while(pucBuffer[j] != (uint8)_val)         /* process the actual data required */
        {
            if(pucBuffer[j] == (uint8)_end) {           /* check for end if data in data recieved buffer */
                break;
            }else{}
            TempDataBuf[i] = (char)pucBuffer[j];
            i++;
            j++;
            if(j > 512U){
                return '\0';
            }else{}
        }
        TempDataBuf[i] = '\0';              /* terminate the string with null*/
        return atoi(TempDataBuf);           /* return integer value */
}



/********************************************************************************************************************************************************
                                                              LIVE DATA WRITE FUNCTION
 **********************************************************************************************************************************************************/

void WriteLiveDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length)
{
    uint32 lcnt = 0;
    uint32 i;

        SDCard_SeekPipe("/tcas.txt", 0xCFUL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            lcnt = ProcessField(2U, (uint8 *)SDCardBuf, ',', '\r');
            lcnt++;
            my_sprintfint(SDCardBuf,"LIVEDAT.txt: $85,Count,%u,%u!\r\n", lcnt, lcnt);
            SDCard_SeekPipe("/tcas.txt", 0xCFUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            lcnt++;
            lcnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            my_sprintf1s(SDCardBuf,"LIVEDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0xCFUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        }

    for(i=0U;i<512U;i++)
    {
        SDCardBuf[i] = '\0';
        templogbufLive[i] = 0u;
    }

    /*CopytoSDbuf((char*)log_data, (char *)templogbufLive, (uint16)(( data_pkt_length)+2));*/
  /*  memcpy(log_data,templogbufLive,(( data_pkt_length)+2u)); */
    /*    my_sprintf(SDCardBuf,"$1,%s",(const char *)templogbufLive);*/

    memcpy(templogbufLive,log_data,(( data_pkt_length)+3u));

    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;

    memcpy(&SDCardBuf[3],templogbufLive,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/LIVEDAT.txt", live_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 6u));

}


/********************************************************************************************************************************************************
                                                        CRITICAL DATA WRITE FUNCTION
 **********************************************************************************************************************************************************/
void WriteCritDatatoSDCard(uint8* log_data , uint8 u8EventID, uint8 logtype,uint8 data_pkt_length)      /*Critical data*/
{
    uint32 ccnt = 0U;
    uint32 i;

        SDCard_SeekPipe("/tcas.txt", 0xB1UL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            ccnt = ProcessField(2U, (uint8 *)SDCardBuf, ',', '\r');
            ccnt++;
            my_sprintfint(SDCardBuf,"CRITDAT.txt: $85,Count,%u,%u!\r\n", ccnt, ccnt);
            SDCard_SeekPipe("/tcas.txt", 0xB1UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            ccnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            ccnt++;
            my_sprintf1s(SDCardBuf,"CRITDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0xB1UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }


    for(i=0U;i<1024U;i++)
    {
        SDCardBuf[i] = '\0';
    }


   /*  CopytoSDbuf(log_data, templogbufcrit, (uint16)((data_pkt_length)+(uint16)2)); */
    /*copytoSDbuf_in_hex_format((char*)log_data, (char *)templogbufcrit, (uint16)((data_pkt_length)+2));*/


    /* my_sprintf(SDCardBuf,"$1,%s!\r\n",templogbufcrit);*/


    for(i=0U;i<512U;i++)
    {
        templogbufcrit[i] = '\0';
        SDCardBuf[i] = '\0';
    }

    memcpy(templogbufcrit,log_data,(( data_pkt_length)+0u));

    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;

    memcpy(&SDCardBuf[4],templogbufcrit,(( data_pkt_length )+3));

    SDCard_SeekPipe("/CRITDAT.txt", crit_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 3u));

  /*  SDCard_SeekPipe("/CRITDAT.txt", crit_data_line_count, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));*/

}

/********************************************************************************************************************************************************
                                                        TRIGGERED DATA WRITE FUNCTION
 **********************************************************************************************************************************************************/
void WriteTrigDatatoSDCard(uint8* log_data , uint8 EventID,  uint8 logtype, uint8 data_pkt_length)      /*Triggered data*/
{
    uint32 tcnt = 0U;
    uint32 i;

    SDCard_SeekPipe("/tcas.txt", 0x93UL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            tcnt = ProcessField(2U, (uint8 *)SDCardBuf, ',', '\r');
            tcnt++;
            my_sprintfint(SDCardBuf,"TRIGDAT.txt: $85,Count,%u,%u!\r\n", tcnt, tcnt);
            SDCard_SeekPipe("/tcas.txt", 0x93UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            tcnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            tcnt++;
            my_sprintf1s(SDCardBuf,"TRIGDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0x93UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }

    for(i=0U;i<1024U;i++)
    {
        SDCardBuf[i] = '\0';
        templogbuftrig[i] = '\0';
    }


    /* CopytoSDbuf(log_data, templogbuftrig, (uint16)((data_pkt_length)+(uint16)2U));*/
   /* copytoSDbuf_in_hex_format((char*)log_data, (char *)templogbuftrig, (uint16)((data_pkt_length)+2));*/


   /*  my_sprintf(SDCardBuf ,"$1,%s!\r\n",templogbuftrig);*/

    memcpy(templogbuftrig,log_data,(( data_pkt_length)+3u));


    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;


    memcpy(&SDCardBuf[3],templogbuftrig,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/TRIGDAT.txt", trig_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 6u));


   /* SDCard_SeekPipe("/TRIGDAT.txt", trig_data_line_count, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));*/
}


/********************************************************************************************************************************************************
                                                         TRIGGERED MAINTEMANACE DATA WRITE FUNCTION
 **********************************************************************************************************************************************************/


void WriteTrigMaintDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length)
{
    uint32 lcnt = 0U;
    uint32 i;

        SDCard_SeekPipe("/tcas.txt", 0xEDUL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            lcnt = ProcessField(2U, (uint8 *)SDCardBuf, ',', '\r');
            lcnt++;
            my_sprintfint(SDCardBuf,"TRIGMDAT.txt: $85,Count,%u,%u!\r\n", lcnt, lcnt);
            SDCard_SeekPipe("/tcas.txt", 0xEDUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            lcnt++;
            lcnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            my_sprintf1s(SDCardBuf,"TRIGMDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0xEDUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        }


    for(i=0U;i<1024U;i++)
    {
        SDCardBuf[i] = '\0';
        templogbufTrigMain[i] = '\0';
    }

   /* CopytoSDbuf(log_data, templogbufTrigMain, (uint16)((data_pkt_length)+(uint16)2));*/
    /* copytoSDbuf_in_hex_format((char*)log_data, (char *)templogbufTrigMain, (uint16)((data_pkt_length)+2));*/

    /*my_sprintf(SDCardBuf,"$1,%s!\r\n",templogbufTrigMain);*/

    memcpy(templogbufTrigMain,log_data,(( data_pkt_length)+3u));

    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;


    memcpy(&SDCardBuf[3],templogbufTrigMain,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/TRIGMDAT.txt", trigm_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 6u));


  /*  SDCard_SeekPipe("/TRIGMDAT.txt", trigm_data_line_count, 0, SDCardBuf, 'W', my_strlen(SDCardBuf)); */

}

/***********************************************************************************************************************************************************
                                                        SVK SVK DATA WRITE FUNCTION
 ************************************************************************************************************************************************************/

void WriteSvkSvkDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length)      /*Triggered Maintenance data*/
{
    uint32 lcnt = 0U;
    uint32 i;

        SDCard_SeekPipe("/tcas.txt", 0x10CUL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            lcnt = ProcessField(2U, (uint8 *)SDCardBuf, ',', '\r');
            lcnt++;
            my_sprintfint(SDCardBuf,"SVKDAT.txt: $85,Count,%u,%u!\r\n", lcnt, lcnt);
            SDCard_SeekPipe("/tcas.txt", 0x010CUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            lcnt++;
            lcnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            my_sprintf1s(SDCardBuf,"SVKDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0x010CUL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        }
/*    lcnt *= 270;*/

    for(i=0U;i<1024U;i++)
    {
        SDCardBuf[i] = '\0';
        templogbufSvkSvk[i] = '\0';
    }


  /*   CopytoSDbuf(log_data, templogbufSvkSvk, (uint16)(data_pkt_length ));*/
    /*copytoSDbuf_in_hex_format((char*)&log_data[2], (char *)templogbufSvkSvk, (uint16)((data_pkt_length)));*/

   /* my_sprintf(SDCardBuf,"$1,%s!\r\n",templogbufSvkSvk);*/

    memcpy(templogbufSvkSvk,log_data,(( data_pkt_length)+10u));

    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;


    memcpy(&SDCardBuf[3],templogbufSvkSvk,(( data_pkt_length)+10u));

    SDCard_SeekPipe("/SVKDAT.txt", svk_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 13u));

   /* SDCard_SeekPipe("/SVKDAT.txt", svk_data_line_count, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));*/

}

/********************************************************************************************************************************************************
                                                        TSRMS DATA WRITE FUNCTION
 **********************************************************************************************************************************************************/


void WriteTSRMSDatatoSDCard(uint8* log_data, uint8 EventID, uint8 data_pkt_length)
{

    uint32 lcnt = 0U;
    uint32 i;

        SDCard_SeekPipe("/tcas.txt", 0x0146UL, 0, NULL, 'R', 0U);
        ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
        if(!my_strcmp(TempDataBuf, "Count"))
        {
            lcnt = ProcessField(2U, (unsigned char *)SDCardBuf, ',', '\r');
            lcnt++;
            my_sprintfint(SDCardBuf,"TSRMSDAT.txt: $85,Count,%u,%u!\r\n", lcnt, lcnt);
            SDCard_SeekPipe("/tcas.txt", 0x0146UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));
        }
        else
        {
            lcnt++;
            lcnt = ProcessField(1U, (uint8 *)SDCardBuf, ',', '\r');
            my_sprintf1s(SDCardBuf,"TSRMSDAT.txt: $85,Count,0,0!\r\n");
            SDCard_SeekPipe("/tcas.txt", 0x0146UL, 0, SDCardBuf, 'W', my_strlen(SDCardBuf));

        }


    for(i=0U;i<1024U;i++)
    {
        SDCardBuf[i] = '\0';
        templogbufTSRMS[i] = '\0';
    }

  /*CopytoSDbuf(log_data, templogbufTSRMS, (uint16)((data_pkt_length)));*/
    /*copytoSDbuf_in_hex_format((char*)(&log_data[2]), (char *)templogbufTSRMS, (uint16)((data_pkt_length)));*/


 /* my_sprintf(SDCardBuf,"$1,%s!\r\n",templogbufTSRMS); */

    memcpy(templogbufTSRMS,log_data,(( data_pkt_length)+0u));

    SDCardBuf[0] = 0x24u;
    SDCardBuf[1] = 0x31u;
    SDCardBuf[2] = 0x2Cu;

    memcpy(&SDCardBuf[3],templogbufTSRMS,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/TSRMSDAT.txt", tsrms_data_line_count, 0, SDCardBuf, 'W', (data_pkt_length + 3u));


   /* SDCard_SeekPipe("/TSRMSDAT.txt", tsrms_data_line_count, 0, SDCardBuf, 'W', my_strlen(SDCardBuf)); */

}


void CopytoSDbuf(const uint8* cStrIN, char* cStrOUT, uint16 u8Strcnt)
{
    char TblVal[] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
    uint16_t i,j;
    uint8 temp = 0U;
    j = 0U;
    for(i=0U ;i <u8Strcnt ;i++)
    {
         temp = (cStrIN[i] >>4U)& 0x0fU;

         cStrOUT[j]= TblVal[temp];

         j++;

         temp = (cStrIN[i] & 0x0fU);

         cStrOUT[j] = TblVal[temp];

         j++;

         cStrOUT[j] = ',';

         j++;

    }
}




