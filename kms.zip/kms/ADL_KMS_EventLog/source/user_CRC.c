/*
 * user_CRC.c
 *
 *  Created on: Aug 17, 2024
 *      Author: UDAY KIRAN GEMBALI
 */

#include "MAIN.h"

uint16 MODBUS_CRC16( const uint8 *buf, uint32 len )
{
    uint16 crc = 0xFFFFu;
    uint32 i = 0;
    uint8 bit = 0;

    for( i = 0u; i < len; i++ )
    {
        crc ^= (uint16)buf[i];

        for( bit = 0u; bit < 8u; bit++ )
        {
            if( crc & 0x0001u )
            {
                crc >>= 1;
                crc ^= 0xA001u;
            }
            else
            {
                crc >>= 1;
            }
        }
    }

    return crc;
}
