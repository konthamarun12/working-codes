/*
 * USB_UART.c
 *
 *  Created on: Aug 12, 2024
 *      Author: Uday Kiran Gembali
 */


#include "MAIN.h"
#include "ff.h"
#include "diskio.h"

void delay(uint32 num)
{
    while(num)
    {
        num--;
    }
}

uint8_t read_lock=0;

uint8 u8upr_date = 0u;          /*variable to store the upper day limit*/
uint8 u8upr_mon  = 0u;          /*variable to store the upper month limit*/
uint16 u16upr_yr   = 0u;        /*variable to store the upper year limit*/
uint8 u8upr_hrs  = 0u;          /*variable to store the upper hour limit*/
uint8 u8upr_min  = 0u;          /*variable to store the upper minutes limit*/
uint8 u8upr_sec  = 0u;          /*variable to store the upper seconds limit*/

uint8 u8lwr_date = 0u;          /*variable to store the lower day limit*/
uint8 u8lwr_mon  = 0u;          /*variable to store the lower month limit*/
uint16 u16lwr_yr = 0u;          /*variable to store the lower year limit*/
uint8 u8lwr_hrs  = 0u;          /*variable to store the lower hour limit*/
uint8 u8lwr_min  = 0u;          /*variable to store the lower minutes limit*/
uint8 u8lwr_sec  = 0u;          /*variable to store the lower seconds limit*/

uint8 u8USBlink_checkpkt_rcvd = 0u;           /*Flag variable used to identify the reception of link check packet*/
uint8 u8USBdatadwnldstart_pkt_rcvd = 0u;      /*Flag variable to identify the reception of download start request packet*/
uint8 u8USBrqrmt_pkt_rcvd = 0u;
uint8 u8USBdatadwnldstop_pkt_rcvd = 0u;       /*Flag variable to identify the reception of download stop request packet*/
uint8 u8serial_number = 0u;                   /*Flag variable to store the serial number*/
uint8 u8ALL_data_packets = 0u;                /*Flag Variable to identify the downloading request of all data packets*/
volatile uint8 u8contCommun = 0u;             /*Flag Variable to identify the stop sending data packets to USB application*/

uint8 u8date = 0u;           /*variable to store the extracted day from the present extracted data packet*/
uint8 u8month = 0u;          /*variable to store the extracted month from the present extracted data packet*/
uint16 u16year = 0u;         /*variable to store the extracted year from the present extracted data packet*/
uint8 u8hrs = 0u;            /*variable to store the extracted hours from the present extracted data packet*/
uint8 u8mins = 0u;           /*variable to store the extracted minutes from the present extracted data packet*/
uint8 u8secs = 0u;           /*variable to store the extracted seconds from the present extracted data packet*/

uint8 time_range_checking(void);   /*Function to check whether present extracted data packet date and time is within the given range or not*/

usb_data_pkt_t usb_data_pkt;

uint64 usb_live_data_line_cnt = 0u;    /*Variable to store the value present position of file offset*/
uint8 USB_array[200] = {0u};           /*array to store the buffer of sending data packets as per the request*/

uint8 u8limit_not_crossed = 1u;        /*Flag variable to identify the whether the extracted data packet date and time limit is crossed or not*/



/********************************************************************************************************
              Function to validate received CRC and compare it with calculated CRC
 ********************************************************************************************************/

void validate_CRC_and_compare_rcvd_and_calc_values(const uint8 *buf, uint32 len)
{
    uint16 u16rcvdCRC = 0u;
    uint16 u16calcCRC = 0u;

    u16rcvdCRC = (((uint16)buf[(len - 4u)] << 8u) | ((uint16)(buf[(len - 3u)])));
    u16calcCRC = MODBUS_CRC16(buf,(len - 4u));

    if(u16rcvdCRC == u16calcCRC )
    {
        if(u8USBlink_checkpkt_rcvd == 1u)
        {
            get_link_check_pkt_and_send_rspns_pkt(buf);
            u8USBlink_checkpkt_rcvd = 0u;
        }
        else if(u8USBdatadwnldstart_pkt_rcvd == 1u)
        {
            get_dwnld_rqst_pkt_and_send_rspns_pkt(buf);
            usb_live_data_line_cnt = 0u;
            u8USBdatadwnldstart_pkt_rcvd = 0u;
        }
        else if(u8USBdatadwnldstop_pkt_rcvd == 1u)
        {
            get_dwnld_stop_pkt_and_send_rspns_pkt(buf);
            u8USBdatadwnldstop_pkt_rcvd = 0u;
        }
        else
        {

        }

    }
    else
    {

    }

}

/********************************************************************************************************
                            Function to send response packet to link check packet
********************************************************************************************************/

void get_link_check_pkt_and_send_rspns_pkt(uint8 *u8buffer)
{
    uint8 u8link_chk_resp_pkt[10] = {0u};
    uint16 u16CRC_val = 0u;

    if(((u8buffer[4] == 0xA3u) && (u8buffer[5] == 0x80u))) /*Checking whether we are receiving the link check request for ADL board or not*/
    {
        u8link_chk_resp_pkt[0] = 0xAAu;                /*SOF*/
        u8link_chk_resp_pkt[1] = 0xBBu;
        u8link_chk_resp_pkt[2] = 10u;                  /*Message Length*/
        u8serial_number = u8buffer[3];
        u8link_chk_resp_pkt[3] = u8serial_number;      /*Serial Number*/

        u8link_chk_resp_pkt[4] = (uint8)(ADL);         /*Interface card name*/
        u8link_chk_resp_pkt[5] = 0xD0u;                /*Actual response to link check packet*/

        u16CRC_val = MODBUS_CRC16(u8link_chk_resp_pkt,6u);     /*Calculating the CRC*/

        u8link_chk_resp_pkt[6] = (uint8)(u16CRC_val >> 8u);    /*CRC*/
        u8link_chk_resp_pkt[7] = (uint8)(u16CRC_val);
        u8link_chk_resp_pkt[8] = 0x0Du;                        /*EOF*/
        u8link_chk_resp_pkt[9] = 0x0Au;

        sciDisplayText((sciBASE_t *)UART2,u8link_chk_resp_pkt,10u);
    }
    else
    {

    }
}

/********************************************************************************************************
                            Function to send response packet to link check packet
 ********************************************************************************************************/
void get_dwnld_rqst_pkt_and_send_rspns_pkt(uint8 *u8buffer)
{
    uint8 u8dwnld_strt_resp_pkt[10] = {0u};
    uint16 u16CRC_val = 0u;



    if(((u8buffer[2] == 10u) && (u8buffer[4] == 0xA3u) && (u8buffer[5] == 0x81u)))        /*Download request to send all the data packets*/
    {
        u8ALL_data_packets = 1u;
        u8contCommun = 1u;

        u8dwnld_strt_resp_pkt[0] = 0xAAu;                /*SOF*/
        u8dwnld_strt_resp_pkt[1] = 0xBBu;
        u8dwnld_strt_resp_pkt[2] = 10u;                  /*Message Length*/
        u8serial_number = u8buffer[3];
        u8dwnld_strt_resp_pkt[3] = u8serial_number;      /*Serial Number*/

        u8dwnld_strt_resp_pkt[4] = (uint8)(ADL);         /*Interface card name*/
        u8dwnld_strt_resp_pkt[5] = 0xE0u;                /*Actual response to link check packet*/

        u16CRC_val = MODBUS_CRC16(u8dwnld_strt_resp_pkt,6u);     /*Calculating the CRC*/

        u8dwnld_strt_resp_pkt[6] = (uint8)(u16CRC_val >> 8u);    /*CRC*/
        u8dwnld_strt_resp_pkt[7] = (uint8)(u16CRC_val);
        u8dwnld_strt_resp_pkt[8] = 0x0Du;                        /*EOF*/
        u8dwnld_strt_resp_pkt[9] = 0x0Au;

        sciDisplayText((sciBASE_t *)UART2,u8dwnld_strt_resp_pkt,10u);
        u8uart2_buf_size = 0u;


    }
    else if(((u8buffer[2] == 24u) && (u8buffer[4] == 0xA3u) && (u8buffer[5] == 0x81u)))   /*Download request to send the data packets of data packets between certain date and time limits*/
    {
        u8ALL_data_packets = 0u;
        u8contCommun = 1u;

      /*  u8upr_date = u8buffer[6];
        u8upr_mon  = u8buffer[7];
        u16upr_yr  = (uint16)((uint16)(u8buffer[8] << 8u) | (uint16)(u8buffer[9]));
        u8upr_hrs  = u8buffer[10];
        u8upr_min  = u8buffer[11];
        u8upr_sec  = u8buffer[12];

        u8lwr_date = u8buffer[13];
        u8lwr_mon  = u8buffer[14];
        u16lwr_yr  = (uint16)((uint16)(u8buffer[15] << 8u) | (uint16)(u8buffer[16]));
        u8lwr_hrs  = u8buffer[17];
        u8lwr_min  = u8buffer[18];
        u8lwr_sec  = u8buffer[19];*/


        u8lwr_date = u8buffer[6];
        u8lwr_mon  = u8buffer[7];
        u16lwr_yr  = (uint16)((uint16)(u8buffer[8] << 8u) | (uint16)(u8buffer[9]));
        u8lwr_hrs  = u8buffer[10];
        u8lwr_min  = u8buffer[11];
        u8lwr_sec  = u8buffer[12];

        u8upr_date = u8buffer[13];
        u8upr_mon  = u8buffer[14];
        u16upr_yr  = (uint16)((uint16)(u8buffer[15] << 8u) | (uint16)(u8buffer[16]));
        u8upr_hrs  = u8buffer[17];
        u8upr_min  = u8buffer[18];
        u8upr_sec  = u8buffer[19];


        u8dwnld_strt_resp_pkt[0] = 0xAAu;                /*SOF*/
        u8dwnld_strt_resp_pkt[1] = 0xBBu;
        u8dwnld_strt_resp_pkt[2] = 10u;                  /*Message Length*/
        u8dwnld_strt_resp_pkt[3] = u8serial_number;      /*Serial Number*/
        u8serial_number++;
        u8dwnld_strt_resp_pkt[4] = (uint8)(ADL);         /*Interface card name*/
        u8dwnld_strt_resp_pkt[5] = 0xE0u;                /*Actual response to link check packet*/

        u16CRC_val = MODBUS_CRC16(u8dwnld_strt_resp_pkt,6u);     /*Calculating the CRC*/

        u8dwnld_strt_resp_pkt[6] = (uint8)(u16CRC_val >> 8u);    /*CRC*/
        u8dwnld_strt_resp_pkt[7] = (uint8)(u16CRC_val);
        u8dwnld_strt_resp_pkt[8] = 0x0Du;                        /*EOF*/
        u8dwnld_strt_resp_pkt[9] = 0x0Au;

        sciDisplayText((sciBASE_t *)UART2,u8dwnld_strt_resp_pkt,10u);
        u8uart2_buf_size = 0u;


    }
    else
    {

    }

}

/********************************************************************************************************
                            Function to send response packet to stop_comm packet
********************************************************************************************************/

void get_dwnld_stop_pkt_and_send_rspns_pkt(uint8 *u8buffer)
{
    uint8 u8dwnld_stop_resp_pkt[10] = {0u};
    uint16 u16CRC_val = 0u;


//    if(((u8buffer[4] == 0xA3u) && (u8buffer[5] == 0x82u))) /*Checking whether we are receiving the link check request for ADL board or not*/
//    {

       u8dwnld_stop_resp_pkt[0] = 0xAAu;                /*SOF*/
       u8dwnld_stop_resp_pkt[1] = 0xBBu;
       u8dwnld_stop_resp_pkt[2] = 10u;                  /*Message Length*/
       u8serial_number = 0x85u;
       u8dwnld_stop_resp_pkt[3] = u8serial_number;      /*Serial Number*/


       u8dwnld_stop_resp_pkt[4] = (uint8)(ADL);         /*Interface card name*/
       u8dwnld_stop_resp_pkt[5] = 0xF0u;                /*Actual response to stop request packet*/

       u16CRC_val = MODBUS_CRC16(u8dwnld_stop_resp_pkt,6u);     /*Calculating the CRC*/

       u8dwnld_stop_resp_pkt[6] = (uint8)(u16CRC_val >> 8u);    /*CRC*/
       u8dwnld_stop_resp_pkt[7] = (uint8)(u16CRC_val);
       u8dwnld_stop_resp_pkt[8] = 0x0Du;                        /*EOF*/
       u8dwnld_stop_resp_pkt[9] = 0x0Au;

       u8contCommun = 0u;

       sciDisplayText((sciBASE_t *)UART2,u8dwnld_stop_resp_pkt,10u);
//    }
//    else
//    {
//
//    }

}


/*********************************************************************************************************************************
     Function to send read the data from SD card from each file and send to USB application based on the date and time limits
**********************************************************************************************************************************/
void get_the_data_from_SD_card_from_each_file(void)
{


  /*  SDCard_SeekPipe(const char * Filename, uint64 LineCnt, int Pipe_Cnt, const char * Data,
                    char Mode, uint32 Len)   "/LIVEDAT.txt"      */


//   get_the_data_from_the_file("/CRITDAT.txt");
//    usb_live_data_line_cnt = 0u;
  /*  get_the_data_from_the_file("/LIVEDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/TRIGDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/TRIGMDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/SVKDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/TSRMSDAT.txt");
    usb_live_data_line_cnt = 0u;*/
  /*  get_the_data_from_the_file("/DataAR.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/DataAG.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/DataLR.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/DataSR.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/DataAE.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/DataTAG.txt");
    usb_live_data_line_cnt = 0u;*/



/*    get_the_data_from_the_file("/LLIVEDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/LTRIGDAT.txt");
    usb_live_data_line_cnt = 0u;
    get_the_data_from_the_file("/LTRGMDAT.txt");
    usb_live_data_line_cnt = 0u;*/
    get_the_data_from_the_file("/LCRITDAT.txt");
    usb_live_data_line_cnt = 0u;


    u8contCommun = 0u;

}

/*********************************************************************************************************************************
     Function to send the read  data from particular file and send to USB application based on the date and time limits
**********************************************************************************************************************************/


void get_the_data_from_the_file(const char * str)
{
    uint8 offset = 0u;
    uint8 u8limit_crossed = 0u;


    uint8 array[100] = {0u};

    uint8 i = 0u;
    read_lock=1u;

    usb_data_pkt.u8SOF1 = 0xAAu;                /*SOF*/
    usb_data_pkt.u8SOF2 = 0xBBu;
    usb_data_pkt.u8msg_len = 12u;               /*Message length*/
    usb_data_pkt.u8boardtype = (uint8)(ADL);    /*Interface card type*/
    usb_data_pkt.u8comm_type = 0xE0u;           /*Data packet ID*/
    usb_data_pkt.u8E0F1 = 0x0Du;                /*EOF*/
    usb_data_pkt.u8EOF2 = 0x0Au;

    SDCard_SeekPipe(str,usb_live_data_line_cnt,0u,array,'R',4u);

    if(u8ALL_data_packets == 1u)
    {

        while((u8contCommun == 1u) && (!f_eof(&sFile)))
        {
            SDCard_SeekPipe(str,usb_live_data_line_cnt,0u,array,'R',4u);              /*Reading the $1, message type, message sub type, message length*/
            usb_live_data_line_cnt = f_tell(&sFile);
           /* usb_live_data_line_cnt= usb_live_data_line_cnt-4u;                     */
            if(((array[0] == 0x24u) && (array[1]== 0x31u) && (array[2] == 0x2Cu)))     /*Validating for the start of the data packet*/
            {
                usb_data_pkt.u8msg_type = 0x02u;
                usb_data_pkt.u8msg_sub_type =0;
                usb_data_pkt.u8msg_len = array[3];

                USB_array[0] = usb_data_pkt.u8SOF1;                /*start of frame*/
                USB_array[1] = usb_data_pkt.u8SOF2;
                USB_array[2] = (usb_data_pkt.u8msg_len + 12u);     /*Message Length*/
                USB_array[3] = u8serial_number;                    /*Serial number*/
                u8serial_number++;
                USB_array[4] = usb_data_pkt.u8boardtype;           /*Interface card type*/
                USB_array[5] = usb_data_pkt.u8comm_type;           /*Packet ID*/
                USB_array[6] = usb_data_pkt.u8msg_type;            /*Message type*/
                USB_array[7] = usb_data_pkt.u8msg_sub_type;        /*Message sub type*/


                SDCard_SeekPipe(str,usb_live_data_line_cnt,0u,array,'R',(uint32)usb_data_pkt.u8msg_len);        /*Reading actual data of the packet*/
                usb_live_data_line_cnt = f_tell(&sFile);

                memcpy(&USB_array[8],array,usb_data_pkt.u8msg_len);

                usb_data_pkt.u16CRC = MODBUS_CRC16(USB_array,(uint32)(usb_data_pkt.u8msg_len + 8u));     /*Calculating the CRC*/

                offset = (usb_data_pkt.u8msg_len + 8u);

                USB_array[offset] = (uint8)(usb_data_pkt.u16CRC >> 8u);
                offset++;
                USB_array[offset] = (uint8)(usb_data_pkt.u16CRC >> 0u);
                offset++;
                USB_array[offset] = usb_data_pkt.u8E0F1;
                offset++;
                USB_array[offset] = usb_data_pkt.u8EOF2;
                offset++;

                sciDisplayText((sciBASE_t *)UART2,USB_array,(uint32)offset);

                get_dwnld_stop_pkt_and_send_rspns_pkt(u8uart2_buf);

                for(i = 0u; i < 200u; i++)
                {
                    USB_array[i] = 0u;
                }

            }
            else
            {

            }
        }
//        if()
    }
    else      /*Condition to get packets from certain range and time*/
    {

        while(((u8contCommun == 1u) && (!f_eof(&sFile) && (u8limit_not_crossed == 1u))))
         {
             SDCard_SeekPipe(str,usb_live_data_line_cnt,0u,array,'R',4u);
             usb_live_data_line_cnt = f_tell(&sFile);
             if(((array[0] == 0x24u) && (array[1]== 0x31u) && (array[2] == 0x2Cu)))     /*Validating for the start of the data packet*/
             {
                 usb_data_pkt.u8msg_type =0x02u;                /*collecting message type*/
                 usb_data_pkt.u8msg_sub_type =0u;                   /*Collecting message sub type*/
                 usb_data_pkt.u8msg_len = array[3];                 /*Collecting message length*/

                 USB_array[0] = usb_data_pkt.u8SOF1;                /*Start of frame*/
                 USB_array[1] = usb_data_pkt.u8SOF2;
                 USB_array[2] = (usb_data_pkt.u8msg_len + 12u);     /*Message length*/
                 USB_array[3] = u8serial_number;                    /*Serial number*/
                 u8serial_number++;
                 USB_array[4] = usb_data_pkt.u8boardtype;           /*Board type*/
                 USB_array[5] = usb_data_pkt.u8comm_type;           /*Message request identifier*/
                 USB_array[6] = usb_data_pkt.u8msg_type;            /*Message type*/
                 USB_array[7] = usb_data_pkt.u8msg_sub_type;        /*Message sub type*/

                 SDCard_SeekPipe(str,usb_live_data_line_cnt,0u,array,'R',(uint32)usb_data_pkt.u8msg_len);   /*Collecting the actual data of the message*/
                 usb_live_data_line_cnt = f_tell(&sFile);

                 u8date  = array[0];                                         /*Extracting the day*/
                 u8month = array[1];                                         /*Extracting the month*/
                 u16year = ((uint16)(array[2] << 8u) | (uint16)(array[3]));  /*Extracting the year*/
                 u8hrs   = array[4];                                         /*Extracting the hours*/
                 u8mins  = array[5];                                         /*Extracting the minutes*/
                 u8secs  = array[6];                                         /*Extracting the seconds*/

                 uint8 res = time_range_checking();                          /*Checking whether the given data packet is from given date and time range or not*/

                 if(res == 1u)
                 {
                      memcpy(&USB_array[8],array,usb_data_pkt.u8msg_len);

                      usb_data_pkt.u16CRC = MODBUS_CRC16(USB_array,(uint32)(usb_data_pkt.u8msg_len + 8u));     /*Calculating the CRC*/

                      offset = (usb_data_pkt.u8msg_len + 8u);

                      USB_array[offset] = (uint8)(usb_data_pkt.u16CRC >> 8u);        /*Appending the CRC*/
                      offset++;
                      USB_array[offset] = (uint8)(usb_data_pkt.u16CRC >> 0u);
                      offset++;
                      USB_array[offset] = usb_data_pkt.u8E0F1;                       /*Appending the EOF*/
                      offset++;
                      USB_array[offset] = usb_data_pkt.u8EOF2;
                      offset++;

                      sciDisplayText((sciBASE_t *)UART2,USB_array,(uint32)offset);

                      get_dwnld_stop_pkt_and_send_rspns_pkt(u8uart2_buf);

                      for(i = 0u; i < 200u; i++)
                      {
                          USB_array[i] = 0u;
                      }

                 }
                 else
                 {

                 }

             }
         }

     }
    read_lock=0u;
}

/*********************************************************************************************************************************
                   Function to check whether extracted packet date and time is in given range or not
**********************************************************************************************************************************/


uint8 time_range_checking(void)
{

    uint8 u8return = 0u;

    if(((u16year >= u16lwr_yr) && (u16year <= u16upr_yr)) &&                              /*checking whether the extracted date is within range or npt*/
            ((u8month >= u8lwr_mon) && (u8month <= u8upr_mon)) &&
                     ((u8date >= u8lwr_date) && (u8date <= u8upr_date)))

    {
          if(((u8date == u8lwr_date) && (u8hrs >= u8lwr_hrs) && (u8mins >= u8lwr_min) && (u8secs >= u8lwr_sec)))    /*start time and remaining time of same day*/
          {
              if(((u8lwr_date == u8upr_date) && (u8hrs == u8upr_hrs) && (u8mins == u8upr_min) && (u8secs == u8upr_sec)))
              {
                  u8return = 1u;              /*condition to check time limit crossed*/
                  u8limit_not_crossed = 0u;
              }
              else if(((u8lwr_date == u8upr_date) && (u8hrs <= u8upr_hrs) && (u8mins <= u8upr_min) && (u8secs <= u8upr_sec)))
              {
                  u8return = 1u;
              }
              else if(u8lwr_date != u8upr_date)
              {
                  u8return = 1u;
              }
              else
              {

              }

          }
          else if((u8date > u8lwr_date) && (u8date < u8upr_date ))    /*To cover in between days*/
          {
              u8return = 1u;
          }
          else if((u8date == u8upr_date) && (u8lwr_date != u8upr_date))                /*To cover the upper date limit*/
          {
              if(u8hrs < u8upr_hrs)
              {
                  u8return = 1u;
              }
              else if(u8hrs == u8upr_hrs)             /*To check for upper date and upper hours*/
              {
                  if(u8mins < u8upr_min)
                  {
                      u8return = 1u;
                  }
                  else if(u8mins == u8upr_min)         /*To check for upper date and upper hours and upper minutes*/
                  {
                      if(u8secs < u8upr_sec )
                      {
                          u8return = 1u;
                      }
                      else if(u8secs == u8upr_sec)    /*To check for upper date and upper hours and upper minutes and upper seconds*/
                      {
                          u8return = 1u;
                      }
                      else
                      {
                          u8return = 0u;              /*condition to check time limit crossed*/
                          u8limit_not_crossed = 0u;
                      }
                  }
                  else
                  {
                      u8return = 0u;
                  }

              }
              else
              {
                  u8return = 0u;
              }
          }
          else
          {
              u8return = 0u;
          }
    }
    else
    {
        u8return = 0u;
    }

    return u8return;

}




