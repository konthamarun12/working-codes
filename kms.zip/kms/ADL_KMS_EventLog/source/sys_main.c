/** @file sys_main.c 
*   @brief Application main file
*   @date 11-Dec-2018
*   @version 04.07.01
*
*   This file contains an empty main function,
*   which can be used for the application.
*/

/* 
* Copyright (C) 2009-2018 Texas Instruments Incorporated - www.ti.com 
* 
* 
*  Redistribution and use in source and binary forms, with or without 
*  modification, are permitted provided that the following conditions 
*  are met:
*
*    Redistributions of source code must retain the above copyright 
*    notice, this list of conditions and the following disclaimer.
*
*    Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the 
*    documentation and/or other materials provided with the   
*    distribution.
*
*    Neither the name of Texas Instruments Incorporated nor the names of
*    its contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*/


/* USER CODE BEGIN (0) */
/* USER CODE END */

/* Include Files */

#include "sys_common.h"

/* USER CODE BEGIN (1) */
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include "sci.h"
#include "rti.h"
#include "gio.h"
#include "can.h"
#include "sys_main.h"
#include "gsm.h"

#include "ti_fee.h"
#include "user_can1.h"
#include "het.h"
#include "gsm.h"

#include "MAIN.h"

/* USER CODE END */

/** @fn void main(void)
*   @brief Application main function
*   @note This function is empty by default.
*
*   This function is called after startup.
*   The user can use this function to implement the application.
*/

/* USER CODE BEGIN (2) */
void sciNotification(sciBASE_t *sci, uint32 flags);
//void sciDisplayText(sciBASE_t *sci, const uint8 *data, uint32 length);
void Delay(uint32 wait);
uint8 GSM_wait(uint8 *ch_temp);

void GSM_txData(void);
void GSM_DateTime(void);
void GSM_init();

uint8 a2i(uint8 *txt);
uint16 arry(uint8 * array);

void gioSetDirection(gioPORT_t *port, uint32 dir);
void gioSetBit(gioPORT_t *port, uint32 bit, uint32 value);

void ProcessGSMData(void);
void canMessageNotification(canBASE_t *node, uint32 messageBox);

#define UART (scilinREG)
#define UART2 (sciREG)

static uint8_t command;
static uint8_t command1;

uint8 Receive_Data[2000];
uint8 u8Recieved_Buff[2000];

/*uint8_t u8Recievebit;*/


uint32 size;
uint32 Rx_size;
/*uint8 flag;*/

uint8 u8init = 0u;
uint8 fectching = 1u;

char TempBuf[256];
uint8 DisBuf[256];
uint8 DataBuf[128];
char txData[128];
uint8 tx_packet[256];

char KeyData1[3024] = {0};
char KeyData4[700];
uint8 KeyData6[2000];
uint8 var1[5];
uint8 var = 0u;
uint16 var3;
uint16 valu = 0u;

uint8 i = 0;

uint8 rcvotp[128];
uint8 otp[4];

//uint8 ip_address[] = "\"192.168.120.138\"";
//uint8 ip_address[] = "\"183.82.122.188\"";      /* nms public ip address */
//uint8 ip_address[] = "\"185.215.195.137\"";     /* assign ip_address to the array, ublox test server */
uint8 ip_address[] = "\"112.133.205.6\"";       /* KMS ip address*/
uint8 *ptr = ip_address;

uint8 len;
uint8 u8Socket = 0;
/*uint32 32port = 7;  */                       /* ublox test server port number */
uint32 u32port = 54143u;                   /* KMS port number */
/*uint32 u32port = 55002u;*/

uint8 set;
uint32 sms;

uint16 RTI_CNT = 0;
uint8 GL_DOG_VAL = 0x00;

uint32_t gGenCntReg1;
uint32_t GenCnt1;
uint8 u8Health_status_flag = 0u;
uint32_t u32SrcLocoID = 0;

uint8_t u8KeyRequestbit = 0;
uint16_t u16KeyParseTimeout = 0;
uint16_t gKeyTimer1;
uint32_t u32canstate = 0u;

uint8_t u8canKeysendtmr = 0u;

uint8_t u8KeyReqByte = 0u;                    /* variable for asking the KMS keys */
/*uint8 u8uart2_buf_size = 0u; */
uint8_t KMStoNMS = 0u;


uint8 u8uart1_temp = 0u;                      /* UART communication variables */
uint8 u8uart1_buf[120] = {0u};
uint8 u8uart1_buf_size = 0u;

uint8 u8uart2_temp = 0u;
uint8 u8uart2_buf[120] = {0u};
uint8 u8uart2_buf_size = 0u;


struct GSM gsm;
struct DateTime date_time;
struct AutKey aut_key;
gsm_info_t GSM1_Info;
sys_mon_Info_t Sys_Mon_Info;


/*if(fectching == 0u)
{

    Init_SD_Card();
    init_SD_card_for_loco();
}
else
{
}*/



/* USER CODE END */

int main(void)
{
/* USER CODE BEGIN (3) */
    _enable_IRQ();

    sciInit();
    gioInit();
    rtiInit();
    canInit();

    spiInit();                                                                         //event log
    mibspiInit();                                                                      //event log

    ReadDipSwitchAdd();                                                                /* reading the Dip switch address */
    ReadDipSwitchConfig();                                                             /* reading the Dip switch configuration address */
    ReadSlotDetect();

      TI_Fee_Init();                                                                   /* FEE driver Initialization */

//      EEPROM_write_function();                                                       /* function to write the keys data into the EEPROM using keys received buffer */
      EEPROM_read_function();                                                          /* Reading the Keys data from EEPROM Memory */

    gioSetDirection(gioPORTB, 0xFFFFFFFFU);

    rtiEnableNotification(rtiNOTIFICATION_COMPARE0);
    rtiEnableNotification(rtiNOTIFICATION_COMPARE1);
    rtiEnableNotification(rtiNOTIFICATION_COMPARE2);
    rtiStartCounter(rtiCOUNTER_BLOCK0);

    canEnableErrorNotification(canREG1);
    canEnableErrorNotification(canREG2);

    sciEnableNotification(scilinREG, (uint32)SCI_RX_INT);
    sciReceive(scilinREG, 1u, (uint8_t*) &command);

    sciEnableNotification(UART2, (uint32) SCI_RX_INT);
    sciReceive(UART2, 1U, (uint8*) &u8uart2_temp);
    /*sciEnableNotification(sciREG, (uint32)SCI_RX_INT);
    sciReceive(sciREG, 1u, (uint8_t*) &command);
*/
//    gioSetBit(mibspiPORT1, (uint8)PIN_ENA, 0u);                      /* for enable */
//    gioSetBit(mibspiPORT5, (uint8)PIN_ENA, 0u);

//    Init_SD_Card();                                                /*Creating the SD card files */

    GSM_init();

    Sys_Mon_Info.u32ADLCRC = CheckIntCRC(0,0xfffffu);
    while(1)
    {
        CAN1Reset();
        CAN2Reset();

        u8init = 1u;
        if(((u8USBlink_checkpkt_rcvd == 1u || u8USBdatadwnldstart_pkt_rcvd == 1u || u8USBdatadwnldstop_pkt_rcvd == 1u) && (fectching == 1u)))   /*USB connection link check packet received*/
        {
            validate_CRC_and_compare_rcvd_and_calc_values(u8uart2_buf,u8uart2_buf_size);
            u8uart2_buf_size = 0u;
        }
        else
        {
        }

        if(u8contCommun == 1u)
        {
            get_the_data_from_SD_card_from_each_file();                                      /* function for fetching the data from the SD card file */
        }

        close_UDPsocket1();
/*        GSM_DateTime();   */                                                                 /* fetching the real time, date and storing into the variable */

        if((u16KeyParseTimeout == TIMEOUT_EVENT))                                            /* send keys immediately not implemented */
        {
            VPM_CAN_Received_message();
            u16KeyParseTimeout = 3u;                                                         /* setting 600 msec delay */
        }

        Check2oo2KeyReq();

/*        if((u8KeyRequestbit == SET_HIGH) || (CAN_Info.u8KeyRx == SET_HIGH) && (u8canKeysendtmr == TIMEOUT_EVENT))  */
        if((u8KeyRequestbit == SET_HIGH) || (CAN_Info.u8KeyRx == SET_HIGH))
        {
            gioSetBit(gioPORTB, 7u, 1u);                              /* indicating the Keys set data transmitting status */
            build_CANpkt1();                                          /* build and send the KMS keys set CAN packets after received the keys request */
            u8KeyRequestbit = SET_LOW;
            CAN_Info.u8KeyRx = SET_LOW;
            u8canKeysendtmr = 5u;                                     /* 5 sec timer */
            gioSetBit(gioPORTB, 7u, 0u);
        }

        if(CAN0_Info.u8GpsRxbit == SET_HIGH)
        {
            gioSetBit(gioPORTB, 7u, 1u);                              /* indicating the GPS time date packet received */
            GSM1_Info.chDate = ucGpsDatabuf[0][0];
            GSM1_Info.chMonth = ucGpsDatabuf[0][1];
            GSM1_Info.chYear  = ucGpsDatabuf[0][2] << 8u;
            GSM1_Info.chYear |= ucGpsDatabuf[0][3] << 0u;
            GSM1_Info.chHours = ucGpsDatabuf[0][4];
            GSM1_Info.chMins = ucGpsDatabuf[0][5];
            GSM1_Info.chSecs = ucGpsDatabuf[0][6];
            GSM1_Info.chYear = GSM1_Info.chYear - 2000u;
            u32SrcLocoID = ucGpsDatabuf[1][3] << 24u | ucGpsDatabuf[1][3] << 16u | ucGpsDatabuf[1][3] << 8u | ucGpsDatabuf[1][3] << 0u;
            CAN0_Info.u8GpsRxbit = SET_LOW;
            GSM1_Info.u8GPSavailable = SET_HIGH;
            GSM1_Info.u8gpstimeout = 10u;
            gioSetBit(gioPORTB, 7u, 0u);
        }

        if(GSM1_Info.u8gpstimeout == TIMEOUT_EVENT)
        {
            GSM1_Info.u8GPSavailable = SET_LOW;
        }


        if(KMStoNMS == 0u)                                                 /* checking the NMS bit is High for establishing the NMS communication */
        {
            ProcessKMSData();
        }
        else if(KMStoNMS == 1u)
        {
            Loco_to_NMS_health_pkt_send(2);
            KMStoNMS = 0u;
        }
        else{
        }

        ProcessGSMData();

/*
        if(CAN0_Info.u16CanTxSendTimeout == TIMEOUT_EVENT)
        {
            SendModuleStatus2CPUCAN();
            CAN0_Info.u16CanTxSendTimeout = 1u;
        }
*/

        if(u8Health_status_flag == TIMEOUT_EVENT)
        {
            GSM_health_status_monitor_interrupt();                             /* sending the Health status AT commands */
            GSM_health_status();                                               /* storing the health status data packet */
            u8Health_status_flag = SET_LOW;
            u8Health_status_flag = 10u;                                        /* 5 sec delay for Health packet transmission */
        }

        /*if(u8contCommun == 1u)
        {
            get_the_data_from_SD_card_from_each_file();
        }*/
    }
/* USER CODE END */


}


/* USER CODE BEGIN (4) */
void sciDisplayText(sciBASE_t *sci, const uint8 *text, uint32 length)                      /* Display the data */
{
    uint32 cout = length;
    while (cout--)
    {
        if (sci == scilinREG)
        {
            while ((scilinREG->FLR & 0x4u) == 4u);                                          /* wait until busy *///
            sciSendByte(UART, *text++);                                                    /* send out text   */
        }
        if (sci == sciREG)
        {
            while ((sciREG->FLR & 0x4u) == 4u);
            sciSendByte(sciREG, *text++);
        }
        else
        {
        }
    };
}

void sciNotification(sciBASE_t *sci, uint32 flags)                                         /* using the interrupt function received the data */
{
    if(sci == scilinREG)
    {
        sciReceive(scilinREG, 1u, (uint8_t *) &command);
        if(size > 1999u)
        {
            size = 0u;
            Clear_Buffer1();

        }
        Receive_Data[size] = command;
        size++;

        Rx_size = size;

/*        flag = 1u;*/
    }
    else if((sci == (sciBASE_t *)UART2))
    {
        if(u8uart2_buf_size == 120u)
        {
            u8uart2_buf_size = 0u;
        }
        else
        {

        }

        sciReceive((sciBASE_t *)UART2, (uint32)1u, (uint8 *)&u8uart2_temp);


        if(u8uart2_temp == 0xAAu)
        {
            u8uart2_buf_size = 0u;
        }

        u8uart2_buf[u8uart2_buf_size] = u8uart2_temp;

        u8uart2_buf_size++;

/*
        if(((u8uart2_buf[0] == 0xAAu) && (u8uart2_buf[1] == 0xBBu)))
        {
*/
            if(((u8uart2_buf[u8uart2_buf_size - 2u] == 0x0Du) && (u8uart2_buf[u8uart2_buf_size - 1u] == 0x0Au)))
            {
                if(((u8uart2_buf[0] == 0xAAu) && (u8uart2_buf[1] == 0xBBu)))    /*Checking for SOF*/
                {
                if(u8uart2_buf[5] == 0x80u)
                {
                    u8USBlink_checkpkt_rcvd = 1u;
                    /*Clr_Log_Buff();*/

                }
                else if(u8uart2_buf[5] == 0x81u)
                {
                    u8USBdatadwnldstart_pkt_rcvd = 1u;
                  /*  Clr_Log_Buff(); */

                }
                else if(u8uart2_buf[5] == 0x82u)
                {
                    u8USBdatadwnldstop_pkt_rcvd = 1u;
                    u8contCommun == 0u;
                  /*  Clr_Log_Buff();   */
                }
                else
                {

                }
             }
         }
        else
        {

        }
    }
    else
    {

    }
}


void Delay(uint32 wait)                                                                    /* Delay function */
{
    while(wait--)
    {

    };
}


uint8 GSM_wait(uint8 *ch_temp)                                                             /* this function for check the response from UDP communication */
{
    uint8 u8index;
    uint8 u8cnt;
    for(u8index = 0u;u8index <= size; u8index++)
    {
        if(Receive_Data[size - u8index] == ch_temp[0])
        {
            set = 0u;
            break;
        }
        else
        {
            set = 1u;
            u8cnt++;
        }

        if(u8cnt == 3u)
        {
            u8cnt = 0u;
            set = 0u;
            break;
        }
    }
    return set;
}

uint8 GSM_wait1(const uint8_t *ch_temp1)
{
    if(Receive_Data[size - 2u] == ch_temp1[0])
    {
        set = 0u;
    }
    else
    {
        set = 1u;
    }
    return set;
}

uint8 GSM_wait2(uint8_t *ch_temp2)                         /* not using */
{
    while(size)
    {
        if(Receive_Data[size--] == ch_temp2[0])
        {
            set = 0u;
            break;
        }
        else
        {
            set = 1u;
        }
    }
    return set;
}

uint8 a2i(uint8 *txt)                                                                      /* convert ASCII to integer conversion function */
{
    uint8 u8digit, u8index;
    uint8 u8sum = 0u;
    for(u8index = 0u;txt[u8index] != (uint8)'\0'; u8index++)
    {
        u8digit = txt[u8index] - 0x30u;
        u8sum = (u8sum * 10u) + u8digit;
    }
    return (uint8)u8sum;
}

char *strstr2(uint8_t *str, const char *substring)                                         /* search substring in main string */
{
    const char *a;
    const char *b;

    b = substring;

    if (*b == 0) {
        return (char *) str;
    }

    for ( ; *str != (uint8)0; str += 1) {
        if (*str != (uint8)*b) {
            continue;
        }

        a = (const char *)str;
        while (1) {
            if (*b == 0) {
                return (char *) str;
            }
            if (*a++ != *b++) {
                break;
            }
        }
        b = substring;
    }

    return NULL;
}

/********************************************************************/
void copystring(uint8 *str2, char *str1)                                                   /* copy string function */
{
    uint8 r;
    for(r = 0u; str1[r] != (uint8)'\0'; r++)
    {
        str2[r] = (uint8)str1[r];
    }
    str2[r] = (uint8)'\0';
}
/****************************************************************************/
/*uint16 my_strlen(uint8 * str3)
{

    uint16 u8length = 0u;
    while((str3[length] != 0x0Du) && (str[length] != '\0') && (length < max_length))
    while(str3[u8length] != (uint8)'\0')
    {
        u8length++;
    }
   return (uint16)u8length;
}*/
/*********************************************************************/
uint8 my_strncmp(const char *s, const char *t, uint8 num)                                  /* string compare function */
{
    while(num--)
    {
        if(*s != *t)
        {
            return *s - *t;
        }
        else
        {
            ++s;
            ++t;
        }
    }
    return *s;
}

/***********************************************************************/
uint16 arry(uint8 * array)                                                                  /* this function to store array as integer */
{
    uint16 u8idx;
    valu = 0u;

    for(u8idx = 0u;((u8idx <= 4u) && (array[u8idx] != 0X0Du)); ++u8idx)
    {
        valu = ((valu * 10u) + ((uint16)array[u8idx] & 0x0fu));
    }
    return (uint16)valu;
}

/**************************************************************************/
void rtiNotification(uint32 notification)
{
    RTI_CNT++;
    if(RTI_CNT > 360u)
    {
        RTI_CNT = 0u;
    }
    if(0x00 ==(RTI_CNT % 100))
    {
        gioSetBit(gioPORTB, 1u, 1u);
    }
    if(notification == rtiNOTIFICATION_COMPARE2)                                      /* 500 msec interrupt */
    {
        if(CAN0_Info.u16CanTxSendTimeout > 0)
        {
            CAN0_Info.u16CanTxSendTimeout = CAN0_Info.u16CanTxSendTimeout - 1u;
        }

        gKeyTimer1++;
        gGenCntReg1++;
    }

    if(notification == rtiNOTIFICATION_COMPARE1)                                      /* 1 sec / 1000 msec interrupt */
    {

        SendModuleStatus2CPUCAN();                                                    /* every 1 sec sending the Health packet to VPM */
        if(GSM1_Info.u8gpstimeout > 0u)
        {
            GSM1_Info.u8gpstimeout = GSM1_Info.u8gpstimeout - 1;
        }
        if(u16KeyParseTimeout > 0)
        {
            u16KeyParseTimeout--;
        }
        if(GSM1_Info.u16TCPDelayReg)
        {
            GSM1_Info.u16TCPDelayReg--;
        }
/*        if(u8canKeysendtmr > 0)
        {
            u8canKeysendtmr = u8canKeysendtmr - 1u;
        }*/

   /*     gKeyTimer1++;
        gGenCntReg1++;*/
        if(u8Health_status_flag > 0)
        {
            u8Health_status_flag--;
        }

    }
}

void ProcessGSMData(void)
{
    if(udp_data.u8ProcesPendDataBit == SET_HIGH)                           /* checking the pending data/keys */
    {
        ProcessPendingUDPData();                                           /* function call for request the remaining keys from KMS */
    }

    UDPRcvdData1();                                                        /* function call for request and receiving the UDP data */
//    GSM_DateTime();                                                      /* function call for request the time and date from GSM module */

}


void GSMTx_DataPacket_Formation(void)
{
    if((aut_key.status == 0u) && (aut_key.OTP_status != 1u))                           /* condition for identification message data packet */
    {
        GSM_txData();                                                                  /* function call for transmit the identification message */
        if((len == 0u) && (GSM_reg.Key_receive != 1u))
        {
            resend_pck();                          /* the first request message is not successful, it shall send the request for every 5 min  until it receive the message */
        }
        read_sms_otp();
    }

    else if((aut_key.OTP_status == 1u) || (u8KeyReqByte == 1u))                        /* condition for authentication key request message data packet */
    {
        GSM_txData();                                                                  /* function call for data packet transmit */
    }

    else if(GSM_reg.Key_receive == 1u)                                                 /* condition for authentication query message data packet */
    {
        rtiEnableNotification(rtiNOTIFICATION_COMPARE0);                               /* rti notification delay */
        GSM_reg.Aut_queryBit = 1u;                                                     /* enable the aut_query bit */
        GSM_txData();                                                                  /* transmit data packet send function */
    }
    else
    {
    }
}

void ProcessKMSData(void)
{
    if(gKeyTimer1 > 10)                                                          /*   10 sec delay, 5 sec delay */
    {
        GSM1_Info.TCPTxBit = 1;
        gKeyTimer1 = 0;
    }

    if(GSM1_Info.TCPTxBit)
    {
//        if(!GSM1_Info.u16TCPDelayReg)
//        {
            if(++GSM1_Info.u32TCPTxCnt > 5)
            {
                GSM1_Info.u32TCPTxCnt = 0;
                GSM1_Info.TCPTxBit = 0;
            }
            if(GSM1_Info.u8GPSavailable == SET_HIGH)                              /* checking the GPS is available or not */
            {
                GSMTx_DataPacket_Formation();                                     /* calling the KMS build packets function */
            }
//        }
    }
}

void Clr_Log_Buff(void)                                                           /* for clear the Event log UART buffer */
{
    uint8 u8idx;
    for(u8idx = 0u; u8idx < 120u; u8idx++)
    {
        u8uart2_buf[u8idx] = 0u;
    }
}

/* USER CODE END */
