/*
 * nms.c
 *
 *  Created on: Nov 18, 2024
 *      Author: USER
 */

#include "sys_common.h"
#include "sys_main.h"
#include "sci.h"
#include "gio.h"
#include "crc.h"
#include <stdio.h>

#include <string.h>
#include <stdint.h>
#include "nms.h"
#include "user_can.h"

#include "MAIN.h"

can_data_t LCAN_Data;
LOCO_TO_NMS  Loco_Health_pkt;
loco_fault_t LOCO_Fault_Msg;

void wait(uint32_t u32time);

uint8_t LOCO_Fault_buff[64] = {0};
uint8_t data_pkt_buf[256] = {0};
uint8_t u8InfoMsgData[8] = {0};
uint8_t u8caninfopktbuff[8] = {0};
uint8_t u8candatapktbuff[8] = {0};

uint8 u8len;

uint8 RX_Bit;

void Loco_to_NMS_health_pkt_send(uint8 EventType)
{

   /* uint8 LVK_buf[100][100];
   uint8 Can_pkt_count[8];*/
    uint8 disp_buf[350];
    char health_data[256];

    if(LCAN_Data.u8EventType == (uint8)LOCOHEALTHMSG)               /* checking Event Type */
    {
        uint8 l;
        uint8 u8index, u8subindex;

        Loco_Health_pkt.u16SOF = 0xBBBBu;                              /* assign header data to variable */
        Loco_Health_pkt.u8Msg_Type = 0x12u;
        Loco_Health_pkt.u16Msg_Len = 0x64u;
        Loco_Health_pkt.u16Msg_Seq = 0x15FFu;
        Loco_Health_pkt.u24Loco_Id = 0x00DD94u;
        Loco_Health_pkt.u16NMS_Id = 23167u;
        Loco_Health_pkt.u8Sys_version = 2u;
        Loco_Health_pkt.u8Day = 7u;
        Loco_Health_pkt.u8Month = 5u;
        Loco_Health_pkt.u8Year = 24u;
        Loco_Health_pkt.u8Hours = 12u;
        Loco_Health_pkt.u8Minutes = 24u;
        Loco_Health_pkt.u8Seconds = 48u;
        Loco_Health_pkt.u8Event_cnt = LCAN_Data.u8dataPktbyteCnt;                     /* Event_cnt   */
        Loco_Health_pkt.u16Event_Id = LCAN_Data.u8EventID;                            /* Event ID */

   /* Loco_Health_pkt.u8Radio2_health = 1U;
    Loco_Health_pkt.u8Radio1_input_supply = 15U;
    Loco_Health_pkt.u8Radio2_input_supply = 20U;
    Loco_Health_pkt.u8Radio1_Temp = 27U;
    Loco_Health_pkt.u8Radio2_Temp = 32U;
    Loco_Health_pkt.u8Radio1_PA_Temp = 35U;
    Loco_Health_pkt.u8Radio2_PA_Temp = 48U;
    Loco_Health_pkt.u8Radio1_PA_Supply_vtg = 11U;
    Loco_Health_pkt.u8Radio2_PA_Supply_vtg = 12U;
    Loco_Health_pkt.u8Radio1_Tx_PA_Cur = 2U;
    Loco_Health_pkt.u8Radio2_Tx_PA_Cur = 3U;
    Loco_Health_pkt.u8Radio1_Rev_Power = 0x01U;
    Loco_Health_pkt.u8Radio2_Rev_Power = 0x0FU;
    Loco_Health_pkt.u8Radio1_Forw_Power = 0x36U;
    Loco_Health_pkt.u8Radio2_Forw_Power = 0x78U;
    Loco_Health_pkt.u24Stationary_Kavach_Id = 47281U;//
    Loco_Health_pkt.u24ABS_Loc1 = 672434U;
    Loco_Health_pkt.u16Freq_Channel_Num = 368U;
    Loco_Health_pkt.u16Radio1_RSSI = 0xBDBFU;
    Loco_Health_pkt.u24ABS_Loc2 = 21734U;
    Loco_Health_pkt.u16Freq_Channel_NUM = 750U;
    Loco_Health_pkt.u16Radio2_RSSI = 0xBDBFU;//
    Loco_Health_pkt.u16Station_Reg_Pkt_Rcv_time_offset = 460U;
    Loco_Health_pkt.u8Active_GPS_Num = 3U;
    Loco_Health_pkt.u8GPS1_View_Status = 0U;
    Loco_Health_pkt.u8GPS2_View_Status = 1U;
    Loco_Health_pkt.u8GPS1_Seconds = 15U;
    Loco_Health_pkt.u8GPS2_Seconds = 32U;
    Loco_Health_pkt.u8GPS1_Satellites_in_view = 23U;
    Loco_Health_pkt.u8GPS1_CNO = 0U;
    Loco_Health_pkt.u8GPS2_Satellites_in_view = 16U;
    Loco_Health_pkt.u8GPS2_CNO = 5U;
    Loco_Health_pkt.u16GPS1_link_Status = 3U;
    Loco_Health_pkt.u16GPS2_link_Status = 1U;
    Loco_Health_pkt.u8GSM1_RSSI = 222U;
    Loco_Health_pkt.u8GSM2_RSSI = 46U;
    Loco_Health_pkt.u8Cur_running_key = 12U;
    Loco_Health_pkt.u8Remaining_Num_of_keys = 18U;
    Loco_Health_pkt.u16Session_key_checksum = 5134U;
    Loco_Health_pkt.u16DMI1_link_status = 1U;
    Loco_Health_pkt.u16DMI2_link_status = 2U;
    Loco_Health_pkt.u16RFID_Rea1_link_status = 1U;
    Loco_Health_pkt.u16RFID_Rea2_link_status = 1U;
    Loco_Health_pkt.u16Missing_Dup_rfid_tag = 812U;
    Loco_Health_pkt.u32Missing_linked_RFID_tag = 21U;
    Loco_Health_pkt.u32Computed_TLM_status = 213401U;
    Loco_Health_pkt.u8Train_Confi_change = 0U;
    Loco_Health_pkt.u8Bootup_seq_error = 0U;
    Loco_Health_pkt.u8Selected_train_formation = 4U;
    Loco_Health_pkt.u8Selected_Cab = 1U;
    Loco_Health_pkt.u8Brake_appl_reason = 3U;
    Loco_Health_pkt.u24Station_Gen_SoS = 342412U;
    Loco_Health_pkt.u24Station_Loco_Spe_SoS = 548352U;
    Loco_Health_pkt.u32Collission_Detection = 577354U;
    Loco_Health_pkt.u8Loco_self_SoS = 1U;
    Loco_Health_pkt.u8Kavach_Connection = 2U;
    Loco_Health_pkt.u8BIU_Isolated = 2U;
    Loco_Health_pkt.u8EB_Bypassed = 1U;
    Loco_Health_pkt.u8Kavach_Territory = 1U;
    Loco_Health_pkt.u8Brake_Interface_error = 1U;
    Loco_Health_pkt.u16OVK_modules_health = 34251U;
    Loco_Health_pkt.u16Conflict_Route_RFID = 713U;
    Loco_Health_pkt.u16Firm_specific_events = 1243U;*/


        data_pkt_buf[0] = ((uint8) (Loco_Health_pkt.u16SOF >> 8u));                 /* filling data, byte by byte to buffer */
        data_pkt_buf[1] = ((uint8) (Loco_Health_pkt.u16SOF >> 0u));

        data_pkt_buf[2] = Loco_Health_pkt.u8Msg_Type;

        data_pkt_buf[3] = ((uint8) (Loco_Health_pkt.u16Msg_Seq >> 8u));
        data_pkt_buf[4] = ((uint8) (Loco_Health_pkt.u16Msg_Seq >> 0u));

        data_pkt_buf[5] = ((uint8) (Loco_Health_pkt.u24Loco_Id >> 16u));
        data_pkt_buf[6] = ((uint8) (Loco_Health_pkt.u24Loco_Id >> 8u));
        data_pkt_buf[7] = ((uint8) (Loco_Health_pkt.u24Loco_Id >> 0u));

        data_pkt_buf[8] = ((uint8) (Loco_Health_pkt.u16NMS_Id >> 8u));
        data_pkt_buf[9] = ((uint8) (Loco_Health_pkt.u16NMS_Id >> 0u));

        data_pkt_buf[10] = Loco_Health_pkt.u8Sys_version;
        data_pkt_buf[11] = Loco_Health_pkt.u8Day;
        data_pkt_buf[12] = Loco_Health_pkt.u8Month;
        data_pkt_buf[13] = Loco_Health_pkt.u8Year;
        data_pkt_buf[14] = Loco_Health_pkt.u8Hours;
        data_pkt_buf[15] = Loco_Health_pkt.u8Minutes;
        data_pkt_buf[16] = Loco_Health_pkt.u8Seconds;
        data_pkt_buf[17] = Loco_Health_pkt.u8Event_cnt;
        data_pkt_buf[18] = Loco_Health_pkt.u16Event_Id;

        uint8 k = 19u;
        uint8 m = 19u;

        for(u8index = 1u;u8index < (LCAN_Data.u8EVENTCANPktCnt+1u); u8index++)                            /* receiving the all the health data based on CAN pkt length */
        {
            for(u8subindex = 0u;u8subindex < 8u; u8subindex++)
            {
                data_pkt_buf[((((u8index-1u) * 8u) + u8subindex) + k)] = LCAN_Data.u8EventLogData1[u8index][u8subindex]; /* receiving the loco health data packet and storing into the buffer */
                m++;
/*                health_data[(((u8index - 1u)*8u)+ u8subindex)] = CAN_Data.u8EventLogData1[u8index][u8subindex];    */
            }

        }

        Loco_Health_pkt.u32CRC = crc_calc(m,(uint8 *)&data_pkt_buf[2]);

/*        Loco_Health_pkt.u32CRC = 54531605u;      */

        data_pkt_buf[m++] = ((uint8) (Loco_Health_pkt.u32CRC >> 24u));               /* calculating CRC */
        data_pkt_buf[m++] = ((uint8) (Loco_Health_pkt.u32CRC >> 16u));
        data_pkt_buf[m++] = ((uint8) (Loco_Health_pkt.u32CRC >> 8u));
        data_pkt_buf[m] = ((uint8) (Loco_Health_pkt.u32CRC >> 0u));

        //CAN_Data.u8msgrxd = (uint8)HIGH;                                             /* Flag for indicating the data packet formation is complete */

        len = m;
/*        sciDisplayText(scilinREG, (uint8 *)data_pkt_buf, 39u);     */

        Transmit_LocoHealthPkt_to_NMS();                                             /* calling the function for sending data pkt buffer through UDP communication*/

        for(l = 0u;l < 250u;l++)                                                     /* clearing the buffer */
        {
            data_pkt_buf[l] = 0u;
        }
    }
    else
    {
/*        CAN_Data.u8msgrxd = (uint8)LOW;    */
    }

/**********************************************************/

/*    data_pkt_buf[19] = Loco_Health_pkt.u8Radio2_health;
    data_pkt_buf[20] = Loco_Health_pkt.u8Radio1_input_supply;
    data_pkt_buf[21] = Loco_Health_pkt.u8Radio2_input_supply;
    data_pkt_buf[22] = Loco_Health_pkt.u8Radio1_Temp;
    data_pkt_buf[23] = Loco_Health_pkt.u8Radio2_Temp;
    data_pkt_buf[24] = Loco_Health_pkt.u8Radio1_PA_Temp;
    data_pkt_buf[25] = Loco_Health_pkt.u8Radio2_PA_Temp;
    data_pkt_buf[26] = Loco_Health_pkt.u8Radio1_PA_Supply_vtg;
    data_pkt_buf[27] = Loco_Health_pkt.u8Radio2_PA_Supply_vtg;
    data_pkt_buf[28] = Loco_Health_pkt.u8Radio1_Tx_PA_Cur;
    data_pkt_buf[29] = Loco_Health_pkt.u8Radio2_Tx_PA_Cur;
    data_pkt_buf[30] = Loco_Health_pkt.u8Radio1_Rev_Power;
    data_pkt_buf[31] = Loco_Health_pkt.u8Radio2_Rev_Power;
    data_pkt_buf[32] = Loco_Health_pkt.u8Radio1_Forw_Power;
    data_pkt_buf[33] = Loco_Health_pkt.u8Radio2_Forw_Power;

    data_pkt_buf[34] = ((uint8) (Loco_Health_pkt.u24Stationary_Kavach_Id >> 16u));
    data_pkt_buf[35] = ((uint8) (Loco_Health_pkt.u24Stationary_Kavach_Id >> 8u));
    data_pkt_buf[36] = ((uint8) (Loco_Health_pkt.u24Stationary_Kavach_Id >> 0u));

    data_pkt_buf[37] = ((uint8) (Loco_Health_pkt.u24ABS_Loc1 >> 16u));
    data_pkt_buf[38] = ((uint8) (Loco_Health_pkt.u24ABS_Loc1 >> 8u));
    data_pkt_buf[39] = ((uint8) (Loco_Health_pkt.u24ABS_Loc1 >> 0u));

    data_pkt_buf[40] = ((uint8) (Loco_Health_pkt.u16Freq_Channel_NUM >> 8u));
    data_pkt_buf[41] = ((uint8) (Loco_Health_pkt.u16Freq_Channel_NUM >> 0u));

    data_pkt_buf[42] = ((uint8) (Loco_Health_pkt.u16Radio1_RSSI >> 8u));
    data_pkt_buf[43] = ((uint8) (Loco_Health_pkt.u16Radio1_RSSI >> 0u));

    data_pkt_buf[44] = ((uint8) (Loco_Health_pkt.u24ABS_Loc2 >> 16u));
    data_pkt_buf[45] = ((uint8) (Loco_Health_pkt.u24ABS_Loc2 >> 8u));
    data_pkt_buf[46] = ((uint8) (Loco_Health_pkt.u24ABS_Loc2 >> 0u));

    data_pkt_buf[47] = ((uint8) (Loco_Health_pkt.u16Freq_Channel_Num >> 8u));
    data_pkt_buf[48] = ((uint8) (Loco_Health_pkt.u16Freq_Channel_Num >> 0u));

    data_pkt_buf[49] = ((uint8) (Loco_Health_pkt.u16Radio2_RSSI >> 8u));
    data_pkt_buf[50] = ((uint8) (Loco_Health_pkt.u16Radio2_RSSI >> 0u));

    data_pkt_buf[51] = ((uint8) (Loco_Health_pkt.u16Station_Reg_Pkt_Rcv_time_offset >> 8u));
    data_pkt_buf[52] = ((uint8) (Loco_Health_pkt.u16Station_Reg_Pkt_Rcv_time_offset >> 0u));

    data_pkt_buf[53] = Loco_Health_pkt.u8Active_GPS_Num;
    data_pkt_buf[54] = Loco_Health_pkt.u8GPS1_View_Status;
    data_pkt_buf[55] = Loco_Health_pkt.u8GPS2_View_Status;
    data_pkt_buf[56] = Loco_Health_pkt.u8GPS1_Seconds;
    data_pkt_buf[57] = Loco_Health_pkt.u8GPS2_Seconds;
    data_pkt_buf[58] = Loco_Health_pkt.u8GPS1_Satellites_in_view;
    data_pkt_buf[59] = Loco_Health_pkt.u8GPS1_CNO;
    data_pkt_buf[60] = Loco_Health_pkt.u8GPS2_Satellites_in_view;
    data_pkt_buf[61] = Loco_Health_pkt.u8GPS2_CNO;

    data_pkt_buf[62] = ((uint8) (Loco_Health_pkt.u16GPS1_link_Status >> 8u));
    data_pkt_buf[63] = ((uint8) (Loco_Health_pkt.u16GPS1_link_Status >> 0u));

    data_pkt_buf[64] = ((uint8) (Loco_Health_pkt.u16GPS2_link_Status >> 8u));
    data_pkt_buf[65] = ((uint8) (Loco_Health_pkt.u16GPS2_link_Status >> 0u));

    data_pkt_buf[66] = Loco_Health_pkt.u8GSM1_RSSI;
    data_pkt_buf[67] = Loco_Health_pkt.u8GSM2_RSSI;
    data_pkt_buf[68] = Loco_Health_pkt.u8Cur_running_key;
    data_pkt_buf[69] = Loco_Health_pkt.u8Remaining_Num_of_keys;
    data_pkt_buf[70] = ((uint8) (Loco_Health_pkt.u16Session_key_checksum >> 8u));
    data_pkt_buf[71] = ((uint8) (Loco_Health_pkt.u16Session_key_checksum >> 0u));

    data_pkt_buf[72] = ((uint8) (Loco_Health_pkt.u16DMI1_link_status >> 8u));
    data_pkt_buf[73] = ((uint8) (Loco_Health_pkt.u16DMI1_link_status >> 0u));

    data_pkt_buf[74] = ((uint8) (Loco_Health_pkt.u16DMI2_link_status >> 8u));
    data_pkt_buf[75] = ((uint8) (Loco_Health_pkt.u16DMI2_link_status >> 0u));

    data_pkt_buf[76] = ((uint8) (Loco_Health_pkt.u16RFID_Rea1_link_status >> 8u));
    data_pkt_buf[77] = ((uint8) (Loco_Health_pkt.u16RFID_Rea1_link_status >> 0u));

    data_pkt_buf[78] = ((uint8) (Loco_Health_pkt.u16RFID_Rea2_link_status >> 8u));
    data_pkt_buf[79] = ((uint8) (Loco_Health_pkt.u16RFID_Rea2_link_status >> 0u));

    data_pkt_buf[80] = ((uint8) (Loco_Health_pkt.u16Missing_Dup_rfid_tag >> 8u));
    data_pkt_buf[81] = ((uint8) (Loco_Health_pkt.u16Missing_Dup_rfid_tag >> 0u));

    data_pkt_buf[82] = ((uint8) (Loco_Health_pkt.u32Computed_TLM_status >> 24u));
    data_pkt_buf[83] = ((uint8) (Loco_Health_pkt.u32Computed_TLM_status >> 16u));
    data_pkt_buf[84] = ((uint8) (Loco_Health_pkt.u32Computed_TLM_status >> 8u));
    data_pkt_buf[85] = ((uint8) (Loco_Health_pkt.u32Computed_TLM_status >> 0u));

    data_pkt_buf[86] = Loco_Health_pkt.u8Train_Confi_change;
    data_pkt_buf[87] = Loco_Health_pkt.u8Bootup_seq_error;
    data_pkt_buf[88] = Loco_Health_pkt.u8Selected_train_formation;
    data_pkt_buf[89] = Loco_Health_pkt.u8Selected_Cab;
    data_pkt_buf[90] = Loco_Health_pkt.u8Brake_appl_reason;

    data_pkt_buf[91] = ((uint8) (Loco_Health_pkt.u24Station_Gen_SoS >> 16u));
    data_pkt_buf[92] = ((uint8) (Loco_Health_pkt.u24Station_Gen_SoS >> 8u));
    data_pkt_buf[93] = ((uint8) (Loco_Health_pkt.u24Station_Gen_SoS >> 0u));

    data_pkt_buf[94] = ((uint8) (Loco_Health_pkt.u24Station_Loco_Spe_SoS >> 16u));
    data_pkt_buf[95] = ((uint8) (Loco_Health_pkt.u24Station_Loco_Spe_SoS >> 8u));
    data_pkt_buf[96] = ((uint8) (Loco_Health_pkt.u24Station_Loco_Spe_SoS >> 0u));

    data_pkt_buf[97] = ((uint8) (Loco_Health_pkt.u32Collission_Detection >> 24u));
    data_pkt_buf[98] = ((uint8) (Loco_Health_pkt.u32Collission_Detection >> 16u));
    data_pkt_buf[99] = ((uint8) (Loco_Health_pkt.u32Collission_Detection >> 8u));
    data_pkt_buf[100] = ((uint8) (Loco_Health_pkt.u32Collission_Detection >> 0u));

    data_pkt_buf[101] = Loco_Health_pkt.u8Loco_self_SoS;
    data_pkt_buf[102] = Loco_Health_pkt.u8Kavach_Connection;
    data_pkt_buf[103] = Loco_Health_pkt.u8BIU_Isolated;
    data_pkt_buf[104] = Loco_Health_pkt.u8EB_Bypassed;
    data_pkt_buf[105] = Loco_Health_pkt.u8Kavach_Territory;
    data_pkt_buf[106] = Loco_Health_pkt.u8Brake_Interface_error;

    data_pkt_buf[107] = ((uint8) (Loco_Health_pkt.u16OVK_modules_health >> 8u));
    data_pkt_buf[108] = ((uint8) (Loco_Health_pkt.u16OVK_modules_health >> 0u));

    data_pkt_buf[109] = ((uint8) (Loco_Health_pkt.u16Conflict_Route_RFID >> 8u));
    data_pkt_buf[110] = ((uint8) (Loco_Health_pkt.u16Conflict_Route_RFID >> 0u));

    data_pkt_buf[111] = ((uint8) (Loco_Health_pkt.u16Firm_specific_events >> 8u));
    data_pkt_buf[112] = ((uint8) (Loco_Health_pkt.u16Firm_specific_events >> 0u));

    sciDisplayText(scilinREG, (uint8_t *)data_pkt_buf, 112);
    sciDisplayText(sciREG, (uint8_t *)data_pkt_buf, 112u);

    Transmit_LocoHealthPkt_to_NMS();                                      */

    if(LCAN_Data.u8EventType == (uint8)LOCOFAULTMSG)
    {
        uint8 u8index, u8subindex;
        LOCO_Fault_Msg.u16SOF = 0xBBBBu;
        LOCO_Fault_Msg.u8Msg_Type = 0x13u;
        LOCO_Fault_Msg.u16Msg_Len = 0x1Eu;
        LOCO_Fault_Msg.u24Loco_Id = 0x00FFF2u;
        LOCO_Fault_Msg.u16NMS_Id = 0x24u;
        LOCO_Fault_Msg.u8Sys_version = 0x01u;
        LOCO_Fault_Msg.u8Day = LCAN_Data.u8EventLogData1[0][2];
        LOCO_Fault_Msg.u8Month = LCAN_Data.u8EventLogData1[0][1];
        LOCO_Fault_Msg.u8Year = LCAN_Data.u8EventLogData1[0][3] << 8u;
        LOCO_Fault_Msg.u8Year |= LCAN_Data.u8EventLogData1[0][4] << 0u;
        LOCO_Fault_Msg.u8Year = LOCO_Fault_Msg.u8Year - 2000u;
        LOCO_Fault_Msg.u8Hours = LCAN_Data.u8EventLogData1[0][5];
        LOCO_Fault_Msg.u8Minutes = LCAN_Data.u8EventLogData1[0][6];
        LOCO_Fault_Msg.u8Seconds = LCAN_Data.u8EventLogData1[0][7];
        LOCO_Fault_Msg.u8SubSys_type = 0x22u;
        LOCO_Fault_Msg.u8Module_ID = 12u;
        LOCO_Fault_Msg.u8Fault_Code_Type = LCAN_Data.u8EventLogData1[2][4];
        if(LCAN_Data.u8EventLogData1[2][4] == 0u)                                           /* checking the fault is recovered or not */
        {
            LOCO_Fault_Msg.u8Fault_Code_Type = 1u;
        }
        else if(LCAN_Data.u8EventLogData1[2][4] == 1u)
        {
            LOCO_Fault_Msg.u8Fault_Code_Type = 2u;
        }
        else
        {
        }

        LOCO_Fault_Msg.u16Fault_Code = ((LCAN_Data.u8EventLogData1[2][2] << 8u) | (LCAN_Data.u8EventLogData1[2][3]));
/*        LOCO_Fault_Msg.u32CRC = 0x34525A2u;   */

        data_pkt_buf[0] = (LOCO_Fault_Msg.u16SOF >> 8u);
        data_pkt_buf[1] = (LOCO_Fault_Msg.u16SOF >> 0u);
        data_pkt_buf[2] = LOCO_Fault_Msg.u8Msg_Type;
        data_pkt_buf[3] = LOCO_Fault_Msg.u16Msg_Len;
        data_pkt_buf[4] = (LOCO_Fault_Msg.u24Loco_Id >> 16u);
        data_pkt_buf[5] = (LOCO_Fault_Msg.u24Loco_Id >> 8u);
        data_pkt_buf[6] = (LOCO_Fault_Msg.u24Loco_Id >> 0u);
        data_pkt_buf[7] = (LOCO_Fault_Msg.u16NMS_Id >> 8u);
        data_pkt_buf[8] = (LOCO_Fault_Msg.u16NMS_Id >> 0u);
        data_pkt_buf[9] = LOCO_Fault_Msg.u8Sys_version;
        data_pkt_buf[10] = LOCO_Fault_Msg.u8Day;
        data_pkt_buf[11] = LOCO_Fault_Msg.u8Month;
        data_pkt_buf[12] = LOCO_Fault_Msg.u8Year;
        data_pkt_buf[13] = LOCO_Fault_Msg.u8Hours;
        data_pkt_buf[14] = LOCO_Fault_Msg.u8Minutes;
        data_pkt_buf[15] = LOCO_Fault_Msg.u8Seconds;
        data_pkt_buf[16] = LOCO_Fault_Msg.u8SubSys_type;
        data_pkt_buf[17] = LOCO_Fault_Msg.u8Module_ID;
        data_pkt_buf[18] = LOCO_Fault_Msg.u8Fault_Code_Type;
        data_pkt_buf[19] = LCAN_Data.u8EventLogData1[2][2];
        data_pkt_buf[20] = LCAN_Data.u8EventLogData1[2][3];

/*        uint8 k = 19u;  */
        uint8 m = 21u;
/*        for(u8index = 1u;u8index < (CAN_Data.u8EVENTCANPktCnt + 1u); u8index++)
        {
            for(u8subindex = 0u;u8subindex < 8u; u8subindex++)
            {
                data_pkt_buf[((((u8index - 1u) * 8u) + u8subindex) + k)] = CAN_Data.u8EventLogData1[u8index][u8subindex];
                m++;
//                health_data[(((u8index - 1u) * 8u) + u8subindex)] = CAN_Data.u8EventLogData1[u8index][u8subindex];
            }
        }*/
        LOCO_Fault_Msg.u32CRC = crc_calc(m,(uint8 *)&data_pkt_buf[2]);

        data_pkt_buf[m++] = ((uint8) (LOCO_Fault_Msg.u32CRC >> 24u));               /* calculating CRC */
        data_pkt_buf[m++] = ((uint8) (LOCO_Fault_Msg.u32CRC >> 16u));
        data_pkt_buf[m++] = ((uint8) (LOCO_Fault_Msg.u32CRC >> 8u));
        data_pkt_buf[m] = ((uint8) (LOCO_Fault_Msg.u32CRC >> 0u));

        u8len = m;

/*        sciDisplayText(sciREG, (uint8_t *)data_pkt_buf, m);  */
        Transmit_LocoHealthPkt_to_NMS();
    }
}



void ExtractCPUdata(uint8_t i)
{

/*    uint8 ucMsgData[8] = {0};
    uint8 ucInfoMsgData[8] = {0};*/

    uint8 eventID = i;

    if(eventID == (uint8)EVENT_PKT1)                                           /* info packet */
    {
//        if(CAN_Data.u8EVENTprevpktidx == 0x00u)
//        {
//            ucInfoMsgData[0] = (uint8)LOCOHEALTHMSG;                          /* Event type */
//            ucInfoMsgData[1] = 1u;                                            /* Event ID */
//            ucInfoMsgData[2] = 2u;                                            /* CAN packet Count */
//            ucInfoMsgData[3] = 1u;                                            /* current packet index */
//            ucInfoMsgData[4] = 16u;                                           /* DataByte Count */
/*            ucInfoMsgData[5] = 0u;
            ucInfoMsgData[6] = 0u;
            ucInfoMsgData[7] = 0u;
        }*/
/*
        if(CAN_Data.u8EVENTprevpktidx == 0x01u)
        {
            ucInfoMsgData[0] = (uint8)LOCOHEALTHMSG;
            ucInfoMsgData[1] = 1u;
            ucInfoMsgData[2] = 2u;
            ucInfoMsgData[3] = 2u;
            ucInfoMsgData[4] = 16u;
            ucInfoMsgData[5] = 0u;
            ucInfoMsgData[6] = 0u;
            ucInfoMsgData[7] = 0u;
        }

        if(CAN_Data.u8EVENTprevpktidx == 0x02U)
        {
            ucInfoMsgData[0] = (uint8)LOCOFAULTMSG;
            ucInfoMsgData[1] = 1U;
            ucInfoMsgData[2] = 2U;
            ucInfoMsgData[3] = 3U;
            ucInfoMsgData[4] = 16U;
            ucInfoMsgData[5] = 0U;
            ucInfoMsgData[6] = 0U;
            ucInfoMsgData[7] = 0U;
        }*/


        memcpy(LCAN_Data.u8EventLogData,ucMsgData,8u);
        LCAN_Data.U8EVENTPKTRXD1 = (uint8)EVENTPKT1;
        LCAN_Data.u8EventType    = LCAN_Data.u8EventLogData[0];           /* event type */
        LCAN_Data.u8EventID      = LCAN_Data.u8EventLogData[1];           /* event ID */
        LCAN_Data.u8EVENTCANPktCnt = LCAN_Data.u8EventLogData[2];         /* CAN packets count */
        LCAN_Data.u8EVENTcurpktidx = LCAN_Data.u8EventLogData[3];         /* Current packet Index */
        LCAN_Data.u8dataPktbyteCnt = LCAN_Data.u8EventLogData[4];         /* total data packet length */
        LCAN_Data.U8EVENTPKTRXD2   = 0U;

    }
    else if((eventID == (uint8)EVENT_PKT2) && (LCAN_Data.U8EVENTPKTRXD1 == (uint8)EVENT_PKT1))         /* data packet */
    {
        /*if(CAN_Data.u8EVENTcurpktidx == 0x01u)
        {
            ucMsgData[0] = 1u;
            ucMsgData[1] = 2u;
            ucMsgData[2] = 3u;
            ucMsgData[3] = 4u;
            ucMsgData[4] = 5u;
            ucMsgData[5] = 6u;
            ucMsgData[6] = 7u;
            ucMsgData[7] = 8u;
        }

        if(CAN_Data.u8EVENTcurpktidx == 0x02u)
        {
            ucMsgData[0] = 9u;
            ucMsgData[1] = 10u;
            ucMsgData[2] = 11u;
            ucMsgData[3] = 12u;
            ucMsgData[4] = 13u;
            ucMsgData[5] = 14u;
            ucMsgData[6] = 15u;
            ucMsgData[7] = 16u;
        }

        if(CAN_Data.u8EVENTcurpktidx == 0x03u)
        {
            ucMsgData[0] = 11u;
            ucMsgData[1] = 22u;
            ucMsgData[2] = 33u;
            ucMsgData[3] = 44u;
            ucMsgData[4] = 55u;
            ucMsgData[5] = 66u;
            ucMsgData[6] = 77u;
            ucMsgData[7] = 88u;
        }
*/
        if(LCAN_Data.u8EVENTCANPktCnt > 127u)                                       /* checking CAN pkt cnt is greater than 127 */
        {
                return;
        }

        LCAN_Data.U8EVENTPKTRXD2 = (uint8)EVENT_PKT2;

        if(LCAN_Data.u8EVENTcurpktidx  ==  (LCAN_Data.u8EVENTprevpktidx + 1u))             /* checking the info pkt receivied or not */
        {
            LCAN_Data.U8EVENTPKTRXD1 = 0u;
            memcpy(LCAN_Data.u8EventLogData1[LCAN_Data.u8EVENTcurpktidx],ucMsgData,8u);    /* copying the 8 byte of CAN data into the buffer */
            LCAN_Data.u8EVENTprevpktidx  =   LCAN_Data.u8EVENTcurpktidx ;                  /* updating the previous pkt index */

            if(LCAN_Data.u8EVENTcurpktidx == LCAN_Data.u8EVENTCANPktCnt)                   /* checking the all CAN data packets are received */
            {
                LCAN_Data.u8EVENTprevpktidx = 0u;                                         /* making the previous pkt index is zero */

                Loco_to_NMS_health_pkt_send(LCAN_Data.u8EventType);                       /* calling the data packet formation function */
            }

            LCAN_Data.u8EVENTcurpktidx = 0U;
        }
        else
        {
            LCAN_Data.u8EVENTcurpktidx = 0u;                                              /* making current and previous index is zero */
            LCAN_Data.u8EVENTprevpktidx = 0u;
        }
    }
    else
    {
    }

}

/************************************************************************************/
void close_NMSUDPsocket1(void)
{
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=4\r\n", 12u);
    wait(100u);
/*
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=5\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=6\r\n", 12u);
    wait(100u);
    sciDisplayText(scilinREG, (uint8_t *)"AT+USOCL=7\r\n", 12u);
*/
}


void Transmit_LocoHealthPkt_to_NMS(void)
{
    uint8 ip_address[] = "\"183.82.122.188\"";;       /* KMS ip address*/
//    uint8 *ptr = ip_address;

//    uint8 u8len;
    uint8 u8Socket = 4u;
    uint32 u32port = 55002u;                   /* KMS port number */

    RX_Bit = 1u;
    if(RX_Bit == (uint8)NMS)
    {
    uint8 buf_data[128];
    sciDisplayText(scilinREG, (const uint8_t *)"AT+USOCR=17\r\n",13U);         /* open the UDP socket */
    Delay(2000000U);
    if(!GSM_wait("OK"))
    {
        gioSetBit(gioPORTB, 2U, 1U);
    }
    else
    {
        gioSetBit(gioPORTB, 2U, 0U);
    }

    sprintf((char *)buf_data,"AT+USOST=%d,%s,%d,%d\r\n", u8Socket,ip_address,u32port,u8len);/* send the socket,ip address, port number and length to  one buffer */
//    sprintf((char *)buf_data, sizeof(buf_data), "AT+USOST=%d,%s,%d,%d\r\n", 4,ip_address,port,len);
    sciDisplayText(scilinREG, (uint8_t *)buf_data, 36u);

    Delay(8000000u);
    if(!GSM_wait("@"))                                                               /* waiting @ symbol for sending the data packet to UDP communication */
    {
        Delay(4000000u);
        sciDisplayText(scilinREG, (uint8_t *)data_pkt_buf, u8len);                   /* sending the data packet through UART communication */
        Delay(16000000u);
        if(!GSM_wait("+USOST"))
        {
            Delay(200000u);
            Rx_size = 0u;
            GSM_reg.UDP_TxBit = 0u;
        }
        Delay(4000000u);
        GSM_reg.UDP_TxBit = 1u;
                                                                                      /* After sending the data packet close the opened socket */
    }
    else
    {
    }

    }
    close_NMSUDPsocket1();
}


void Initialise_LVKNMS_data(void)
{
    Loco_Health_pkt.u8Radio2_health = 0u;
    Loco_Health_pkt.u8Radio1_input_supply = 0u;
    Loco_Health_pkt.u8Radio2_input_supply = 0u;
    Loco_Health_pkt.u8Radio1_Temp = 0u;
    Loco_Health_pkt.u8Radio2_Temp = 0u;
    Loco_Health_pkt.u8Radio1_PA_Temp = 0u;
    Loco_Health_pkt.u8Radio2_PA_Temp = 0u;
    Loco_Health_pkt.u8Radio1_PA_Supply_vtg = 0u;
    Loco_Health_pkt.u8Radio2_PA_Supply_vtg = 0u;
    Loco_Health_pkt.u8Radio1_Tx_PA_Cur = 0u;
    Loco_Health_pkt.u8Radio2_Tx_PA_Cur = 0u;
    Loco_Health_pkt.u8Radio1_Rev_Power = 0u;
    Loco_Health_pkt.u8Radio2_Rev_Power = 0u;
    Loco_Health_pkt.u8Radio1_Forw_Power = 0u;
    Loco_Health_pkt.u8Radio2_Forw_Power = 0u;
    Loco_Health_pkt.u24Stationary_Kavach_Id = 0u;
    Loco_Health_pkt.u24ABS_Loc1 = 0u;
    Loco_Health_pkt.u16Freq_Channel_Num = 0u;
    Loco_Health_pkt.u16Radio1_RSSI = 0u;
    Loco_Health_pkt.u24ABS_Loc2 = 0u;
    Loco_Health_pkt.u16Freq_Channel_NUM = 0u;
    Loco_Health_pkt.u16Radio2_RSSI = 0u;
    Loco_Health_pkt.u16Station_Reg_Pkt_Rcv_time_offset = 0u;
    Loco_Health_pkt.u8Active_GPS_Num = 0u;
    Loco_Health_pkt.u8GPS1_View_Status = 0u;
    Loco_Health_pkt.u8GPS2_View_Status = 0u;
    Loco_Health_pkt.u8GPS1_Seconds = 0u;
    Loco_Health_pkt.u8GPS2_Seconds = 0u;
    Loco_Health_pkt.u8GPS1_Satellites_in_view = 0u;
    Loco_Health_pkt.u8GPS1_CNO = 0u;
    Loco_Health_pkt.u8GPS2_Satellites_in_view = 0u;
    Loco_Health_pkt.u8GPS2_CNO = 0u;
    Loco_Health_pkt.u16GPS1_link_Status = 0u;
    Loco_Health_pkt.u16GPS2_link_Status = 0u;
    Loco_Health_pkt.u8GSM1_RSSI = 0u;
    Loco_Health_pkt.u8GSM2_RSSI = 0u;
    Loco_Health_pkt.u8Cur_running_key = 0u;
    Loco_Health_pkt.u8Remaining_Num_of_keys = 0u;
    Loco_Health_pkt.u16Session_key_checksum = 0u;
    Loco_Health_pkt.u16DMI1_link_status = 0u;
    Loco_Health_pkt.u16DMI2_link_status = 0u;
    Loco_Health_pkt.u16RFID_Rea1_link_status = 0u;
    Loco_Health_pkt.u16RFID_Rea2_link_status = 0u;
    Loco_Health_pkt.u16Missing_Dup_rfid_tag = 0u;
    Loco_Health_pkt.u32Missing_linked_RFID_tag = 0u;
    Loco_Health_pkt.u32Computed_TLM_status = 0u;
    Loco_Health_pkt.u8Train_Confi_change = 0u;
    Loco_Health_pkt.u8Bootup_seq_error = 0u;
    Loco_Health_pkt.u8Selected_train_formation = 0u;
    Loco_Health_pkt.u8Selected_Cab = 0u;
    Loco_Health_pkt.u8Brake_appl_reason = 0u;
    Loco_Health_pkt.u24Station_Gen_SoS = 0u;
    Loco_Health_pkt.u24Station_Loco_Spe_SoS = 0u;
    Loco_Health_pkt.u32Collission_Detection = 0u;
    Loco_Health_pkt.u8Loco_self_SoS = 0u;
    Loco_Health_pkt.u8Kavach_Connection = 0u;
    Loco_Health_pkt.u8BIU_Isolated = 0u;
    Loco_Health_pkt.u8EB_Bypassed = 0u;
    Loco_Health_pkt.u8Kavach_Territory = 0u;
    Loco_Health_pkt.u8Brake_Interface_error = 0u;
    Loco_Health_pkt.u16OVK_modules_health = 0u;
    Loco_Health_pkt.u16Conflict_Route_RFID = 0u;
    Loco_Health_pkt.u16Firm_specific_events = 0u;
}


/*void Loco_KAVACH_CANdata_process(void)
{
    uint8 Msg_buf[100] = {0,1,2,11,12,1,0,0,11,1,0,1,0,1,0,1,1,222,1,13,11,0,0,1,1,1,0,0,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1,0,1,0,0,1,1,1};


    uint16 LVKEvent_healthdata[100][100];
    uint8 Health_buffer[100];
    uint16 prev_status;
    uint8 event_id = 18U;
    uint16 u16rssi;


    if(event_id == (uint8)LOCOMSG1)
    {
        if(Msg_buf[1] == 1U)
        {
            Loco_Health_pkt.u8Radio1_health = (uint8)RADIO_OK;
        }
        else if(Msg_buf[1] == 2U)
        {
            Loco_Health_pkt.u8Radio1_health = (uint8)DIAGNOSTIC_LINK_FAIL;
        }
        else if(Msg_buf[1] == 3U)
        {
            Loco_Health_pkt.u8Radio1_health = (uint8)RADIO_FAIL;
        }
        else{}
//        Health_data[event_id][index] =  Loco_Health_pkt.u8Radio1_health;
        Health_buffer[event_id] = Loco_Health_pkt.u8Radio1_health;

    }
    else if(event_id == (uint8)LOCOMSG2)
    {
        if(Msg_buf[2] == 1U)
        {
            Loco_Health_pkt.u8Radio2_health = (uint8)RADIO_OK;
        }
        else if(Msg_buf[2] == 2U)
        {
            Loco_Health_pkt.u8Radio2_health = (uint8)DIAGNOSTIC_LINK_FAIL;
        }
        else if(Msg_buf[2] == 3U)
        {
            Loco_Health_pkt.u8Radio2_health = (uint8)RADIO_FAIL;
        }
        else{}
    }
    else if(event_id == (uint8)LOCOMSG3)
    {
        if((Msg_buf[3] >= 10U) && (Msg_buf[3] <= 30U))
        {
            Loco_Health_pkt.u8Radio1_input_supply = Msg_buf[3];
        }

    }
    else if(event_id == (uint8)LOCOMSG4)
    {
        if((Msg_buf[4] >= 10U) && (Msg_buf[4] <= 30U))
        {
            Loco_Health_pkt.u8Radio2_input_supply = Msg_buf[4];
        }
    }
    else if(event_id == (uint8)LOCOMSG5)
    {
        if((Msg_buf[5] >= -30U) && (Msg_buf[5] <= 70U))
        {
            Loco_Health_pkt.u8Radio1_Temp = Msg_buf[5];
        }
    }
    else if(event_id == (uint8)LOCOMSG6)
    {
        if((Msg_buf[6] >= -30U) && (Msg_buf[6] <= 70U))
        {
            Loco_Health_pkt.u8Radio2_Temp = Msg_buf[6];
        }
    }
    else if(event_id == (uint8)LOCOMSG7)
    {
        if((Msg_buf[7] >= 20U) && (Msg_buf[7] <= 100U))
        {
            Loco_Health_pkt.u8Radio1_PA_Temp = Msg_buf[7];
        }
    }
    else if(event_id == (uint8)LOCOMSG8)
    {
        if((Msg_buf[8] >= 20U) && (Msg_buf[8] <= 100U))
        {
            Loco_Health_pkt.u8Radio2_PA_Temp = Msg_buf[8];
        }
    }
    else if(event_id == (uint8)LOCOMSG9)
    {
        if((Msg_buf[9] >= 11U) && (Msg_buf[9] <= 13U))
        {
            Loco_Health_pkt.u8Radio1_PA_Supply_vtg = Msg_buf[9];
        }
    }
    else if(event_id == (uint8)LOCOMSG10)
    {
        if((Msg_buf[10] >= 11U) && (Msg_buf[10] <= 13U))
        {
            Loco_Health_pkt.u8Radio2_PA_Supply_vtg = Msg_buf[10];
        }
    }
    else if(event_id == (uint8)LOCOMSG11)
    {
        if((Msg_buf[11] >= 15U) && (Msg_buf[11] <= 32U))
        {
            Loco_Health_pkt.u8Radio1_Tx_PA_Cur = Msg_buf[11];
        }
    }
    else if(event_id == (uint8)LOCOMSG12)
    {
        if((Msg_buf[12] >= 15U) && (Msg_buf[12] <= 32U))
        {
            Loco_Health_pkt.u8Radio2_Tx_PA_Cur = Msg_buf[12];
        }
    }
    else if(event_id == (uint8)LOCOMSG13)
    {
        prev_status = Loco_Health_pkt.u8Radio1_Rev_Power;

        if(prev_status != Msg_buf[13])
        {
            Loco_Health_pkt.u8Radio1_Rev_Power = Msg_buf[13];
        }
    }
    else if(event_id == (uint8)LOCOMSG14)
    {
        prev_status = Loco_Health_pkt.u8Radio2_Rev_Power;

        if(prev_status != Msg_buf[14])
        {
            Loco_Health_pkt.u8Radio2_Rev_Power = Msg_buf[14];
        }
    }
    else if(event_id == (uint8)LOCOMSG15)
    {
        prev_status = Loco_Health_pkt.u8Radio1_Forw_Power;

        if(prev_status != Msg_buf[15])
        {
            Loco_Health_pkt.u8Radio1_Forw_Power = Msg_buf[15];
        }
    }
    else if(event_id == (uint8)LOCOMSG16)
    {
        prev_status = Loco_Health_pkt.u8Radio2_Forw_Power;

        if(prev_status != Msg_buf[16])
        {
            Loco_Health_pkt.u8Radio2_Forw_Power = Msg_buf[16];
        }
    }
    else if(event_id == (uint8)LOCOMSG17)
    {
        prev_status = Loco_Health_pkt.u16Radio1_RSSI;
        u16rssi = Msg_buf[17];
        u16rssi = Msg_buf[17] << 8U;
        if(u16rssi != prev_status)
        {
            Loco_Health_pkt.u16Radio1_RSSI = u16rssi;
        }
    }
    else if(event_id == (uint8)LOCOMSG18)
    {
        prev_status = Loco_Health_pkt.u16Radio2_RSSI;
        u16rssi = Msg_buf[19];
        u16rssi = Msg_buf[20] << 8U;
        if(u16rssi != prev_status)
        {
            Loco_Health_pkt.u16Radio2_RSSI = u16rssi;

        }
    }
    else if(event_id == (uint8)LOCOMSG19)
    {
        prev_status = Loco_Health_pkt.u8Active_GPS_Num;
        if(Msg_buf[21] == 0U)
        {
            Loco_Health_pkt.u8Active_GPS_Num = (uint8)NO_ACTIVE_GPS;
        }
        else if(Msg_buf[21] == 1U)
        {
            Loco_Health_pkt.u8Active_GPS_Num = (uint8)GPS1;
        }
        else if(Msg_buf[21] == 2U)
        {
            Loco_Health_pkt.u8Active_GPS_Num = (uint8)GPS2;
        }
        else if(Msg_buf[21] == 3U)
        {
            Loco_Health_pkt.u8Active_GPS_Num = (uint8)BOTH_GPS_ACTIVE;
        }
        else{}
    }
    else if(event_id == (uint8)LOCOMSG20)
    {
        prev_status = Loco_Health_pkt.u8GPS1_View_Status;
        if(Msg_buf[22] == 0U)
        {
            Loco_Health_pkt.u8GPS1_View_Status = (uint8)GPS_NO_DATA;
        }
        else if(Msg_buf[22] == 1U)
        {
            Loco_Health_pkt.u8GPS1_View_Status = (uint8)GPS_V;
        }
        else if(Msg_buf[22] == 2U)
        {
            Loco_Health_pkt.u8GPS1_View_Status = (uint8)GPS_A;
        }
        else{}
    }
    else if(event_id == (uint8)LOCOMSG21)
    {
        prev_status = Loco_Health_pkt.u8GPS2_View_Status;
        if(Msg_buf[23] == 0U)
        {
            Loco_Health_pkt.u8GPS2_View_Status = (uint8)GPS_NO_DATA;
        }
        else if(Msg_buf[23] == 1U)
        {
            Loco_Health_pkt.u8GPS2_View_Status = (uint8)GPS_V;
        }
        else if(Msg_buf[23] == 2U)
        {
            Loco_Health_pkt.u8GPS2_View_Status = (uint8)GPS_A;
        }
        else{}
    }
    else if(event_id == (uint8)LOCOMSG22)
    {
        prev_status = Loco_Health_pkt.u8GPS1_Seconds;
        if((Msg_buf[24] != prev_status) && (Msg_buf[24] == 59U))
        {
            Loco_Health_pkt.u8GPS1_Seconds = Msg_buf[24];
        }
    }
    else if(event_id == (uint8)LOCOMSG23)
    {
        prev_status = Loco_Health_pkt.u8GPS2_Seconds;
        if((Msg_buf[25] != prev_status) && (Msg_buf[25] == 59U))
        {
            Loco_Health_pkt.u8GPS2_Seconds = Msg_buf[25];
        }
    }
    else if(event_id == (uint8)LOCOMSG24)
    {
        prev_status = Loco_Health_pkt.u8GPS1_Satellites_in_view;
        if((Msg_buf[26] != prev_status))
        {
            Loco_Health_pkt.u8GPS1_Satellites_in_view = Msg_buf[26];
        }
    }
    else if(event_id == (uint8)LOCOMSG25)
    {
        Loco_Health_pkt.u8GPS1_CNO = Msg_buf[27];
    }
    else if(event_id == (uint8)LOCOMSG26)
    {
        prev_status = Loco_Health_pkt.u8GPS2_Satellites_in_view;
        if((Msg_buf[28] != prev_status))
        {
            Loco_Health_pkt.u8GPS2_Satellites_in_view = Msg_buf[28];
        }
    }
    else if(event_id == (uint8)LOCOMSG27)
    {
        Loco_Health_pkt.u8GPS2_CNO = Msg_buf[29];
    }
    else if(event_id == (uint8)LOCOMSG28)
    {
        prev_status = Loco_Health_pkt.u16GPS1_link_Status;
        uint16 value = ((Msg_buf[30]) && (Msg_buf[31] << 8U));
        if(prev_status != value)
        {
            if(value == 0U)
            {
                Loco_Health_pkt.u16GPS1_link_Status = (uint8)BOTH_GPS_PPS_FAIL;
            }
            else if(value == 1U)
            {
                Loco_Health_pkt.u16GPS1_link_Status = (uint8)GPS_FAIL_PPS_OK;
            }
            else if(value == 2U)
            {
                Loco_Health_pkt.u16GPS1_link_Status = (uint8)GPS_OK_PPS_FAIL;
            }
            else if(value == 3U)
            {
                Loco_Health_pkt.u16GPS1_link_Status = (uint8)BOTH_GPS_PPS_OK;
            }
            else{}
        }
    }
    else if(event_id == (uint8)LOCOMSG29)
    {
        prev_status = Loco_Health_pkt.u16GPS2_link_Status;
        uint16 value = ((Msg_buf[32]) && (Msg_buf[33] << 8U));
        if(prev_status != value)
        {
            if(value == 0U)
            {
                Loco_Health_pkt.u16GPS2_link_Status = (uint8)BOTH_GPS_PPS_FAIL;
            }
            else if(value == 1U)
            {
                Loco_Health_pkt.u16GPS2_link_Status = (uint8)GPS_FAIL_PPS_OK;
            }
            else if(value == 2U)
            {
                Loco_Health_pkt.u16GPS2_link_Status = (uint8)GPS_OK_PPS_FAIL;
            }
            else if(value == 3U)
            {
                Loco_Health_pkt.u16GPS2_link_Status = (uint8)BOTH_GPS_PPS_OK;
            }
            else{}
        }
    }
    else if(event_id == (uint8)LOCOMSG30)
    {
        prev_status = Loco_Health_pkt.u8GSM1_RSSI;
        if(prev_status != Msg_buf[34])
        {
            Loco_Health_pkt.u8GSM1_RSSI = Msg_buf[34];
        }
    }
    else if(event_id == (uint8)LOCOMSG31)
    {
        prev_status = Loco_Health_pkt.u8GSM2_RSSI;
        if(prev_status != Msg_buf[35])
        {
            Loco_Health_pkt.u8GSM2_RSSI = Msg_buf[35];
        }
    }
    else if(event_id == (uint8)LOCOMSG32)
    {
        prev_status = Loco_Health_pkt.u8Cur_running_key;
        if((prev_status != Msg_buf[36]) && (Msg_buf[36] <= 30U))
        {
            Loco_Health_pkt.u8Cur_running_key = Msg_buf[36];
        }
    }
    else if(event_id == (uint8)LOCOMSG33)
    {
        prev_status = Loco_Health_pkt.u8Remaining_Num_of_keys;
        if((prev_status != Msg_buf[37]) && (Msg_buf[37] <= 30U))
        {
            Loco_Health_pkt.u8Remaining_Num_of_keys = Msg_buf[38];
        }
    }
    else if(event_id == (uint8)LOCOMSG34)
    {
        prev_status = Loco_Health_pkt.u16Session_key_checksum;
        uint16 checksum = Msg_buf[38];
        checksum += Msg_buf[39] << 8U;
        if(prev_status != checksum)
        {
            Loco_Health_pkt.u16Session_key_checksum = checksum;
        }
    }
    else if(event_id == (uint8)LOCOMSG35)
    {
        prev_status = Loco_Health_pkt.u16DMI1_link_status;
        uint16 status = Msg_buf[40];
        status += Msg_buf[41] << 8U;
        if(prev_status != status)
        {
            Loco_Health_pkt.u16DMI1_link_status = status;

        }
    }
    else if(event_id == (uint8)LOCOMSG36)
    {
        prev_status = Loco_Health_pkt.u16DMI2_link_status;
        uint16 status = Msg_buf[42];
        status += Msg_buf[43] << 8U;
        if(prev_status != status)
        {
            Loco_Health_pkt.u16DMI2_link_status = status;

        }
    }
    else if(event_id == (uint8)LOCOMSG37)
    {
        prev_status = Loco_Health_pkt.u16RFID_Rea1_link_status;
        uint16 status = Msg_buf[44];
        status += Msg_buf[45] << 8U;
        if(prev_status != status)
        {
            Loco_Health_pkt.u16RFID_Rea1_link_status = status;

        }
    }
    else if(event_id == (uint8)LOCOMSG38)
    {
        prev_status = Loco_Health_pkt.u16RFID_Rea2_link_status;
        uint16 status = Msg_buf[46];
        status += Msg_buf[47] << 8U;
        if(prev_status != status)
        {
            Loco_Health_pkt.u16RFID_Rea2_link_status = status;

        }
    }
    else if(event_id == (uint8)LOCOMSG39)
    {
        Loco_Health_pkt.u16Missing_Dup_rfid_tag = ((Msg_buf[48]) || (Msg_buf[49] << 8U));
    }
    else if(event_id == (uint8)LOCOMSG40)
    {
        Loco_Health_pkt.u32Missing_linked_RFID_tag = Msg_buf[50];
        Loco_Health_pkt.u32Missing_linked_RFID_tag += Msg_buf[51] << 8U;
        Loco_Health_pkt.u32Missing_linked_RFID_tag += Msg_buf[52] << 16U;
        Loco_Health_pkt.u32Missing_linked_RFID_tag += Msg_buf[53] << 24U;
    }
    else if(event_id == (uint8)LOCOMSG41)
    {
        Loco_Health_pkt.u32Computed_TLM_status = Msg_buf[54];
        Loco_Health_pkt.u32Computed_TLM_status += Msg_buf[55] << 8U;
        Loco_Health_pkt.u32Computed_TLM_status += Msg_buf[56] << 16U;
        Loco_Health_pkt.u32Computed_TLM_status += Msg_buf[57] << 24U;
    }
    else if(event_id == (uint8)LOCOMSG42)
    {
        Loco_Health_pkt.u8Train_Confi_change = Msg_buf[58];
    }
    else if(event_id == (uint8)LOCOMSG43)
    {
        prev_status = Loco_Health_pkt.u8Bootup_seq_error;
        if(prev_status != Msg_buf[59])
        {
            if(Msg_buf[59] == 0U)
            {
                Loco_Health_pkt.u8Bootup_seq_error = (uint8)BRAKE_TEST_FAILED;
            }
            else if(Msg_buf[59] == 1U)
            {
                Loco_Health_pkt.u8Bootup_seq_error = (uint8)MR_NOT_AVAILABLE;
            }
            else{}
        }
    }

}*/


void Build_LOCO_Fault_Msg(void)
{
    LOCO_Fault_Msg.u16SOF = 0xBBBBu;
    LOCO_Fault_Msg.u8Msg_Type = 0x13u;
    LOCO_Fault_Msg.u16Msg_Len = 0x1Eu;
    LOCO_Fault_Msg.u24Loco_Id = 0x00FFF2u;
    LOCO_Fault_Msg.u16NMS_Id = 0x24u;
    LOCO_Fault_Msg.u8Sys_version = 0x01u;
    LOCO_Fault_Msg.u8Day = 0x12u;
    LOCO_Fault_Msg.u8Month = 0x0Bu;
    LOCO_Fault_Msg.u8Year = 0x18u;
    LOCO_Fault_Msg.u8Hours = 0x12u;
    LOCO_Fault_Msg.u8Minutes = 0x02u;
    LOCO_Fault_Msg.u8Seconds = 0x18u;
    LOCO_Fault_Msg.u8SubSys_type = 0x22u;
    LOCO_Fault_Msg.u8Fault_Code_Type = 0x02u;
    LOCO_Fault_Msg.u16Fault_Code = 0x74u;
    LOCO_Fault_Msg.u32CRC = 0x34525A2u;

    LOCO_Fault_buff[0] = (LOCO_Fault_Msg.u16SOF >> 8u);
    LOCO_Fault_buff[1] = (LOCO_Fault_Msg.u16SOF >> 0u);
    LOCO_Fault_buff[3] = LOCO_Fault_Msg.u8Msg_Type;
    LOCO_Fault_buff[4] = LOCO_Fault_Msg.u16Msg_Len;
    LOCO_Fault_buff[5] = (LOCO_Fault_Msg.u24Loco_Id >> 16u);
    LOCO_Fault_buff[6] = (LOCO_Fault_Msg.u24Loco_Id >> 8u);
    LOCO_Fault_buff[7] = (LOCO_Fault_Msg.u24Loco_Id >> 0u);
    LOCO_Fault_buff[8] = (LOCO_Fault_Msg.u16NMS_Id >> 8u);
    LOCO_Fault_buff[9] = (LOCO_Fault_Msg.u16NMS_Id >> 0u);
    LOCO_Fault_buff[10] = LOCO_Fault_Msg.u8Sys_version;
    LOCO_Fault_buff[11] = LOCO_Fault_Msg.u8Day;
    LOCO_Fault_buff[12] = LOCO_Fault_Msg.u8Month;
    LOCO_Fault_buff[13] = LOCO_Fault_Msg.u8Year;
    LOCO_Fault_buff[14] = LOCO_Fault_Msg.u8Hours;
    LOCO_Fault_buff[15] = LOCO_Fault_Msg.u8Minutes;
    LOCO_Fault_buff[16] = LOCO_Fault_Msg.u8Seconds;
    LOCO_Fault_buff[17] = LOCO_Fault_Msg.u8SubSys_type;
    LOCO_Fault_buff[18] = LOCO_Fault_Msg.u8Fault_Code_Type;
    LOCO_Fault_buff[19] = LOCO_Fault_Msg.u16Fault_Code;
    LOCO_Fault_buff[20] = (LOCO_Fault_Msg.u32CRC >> 24u);
    LOCO_Fault_buff[21] = (LOCO_Fault_Msg.u32CRC >> 16u);
    LOCO_Fault_buff[22] = (LOCO_Fault_Msg.u32CRC >> 8u);
    LOCO_Fault_buff[23] = (LOCO_Fault_Msg.u32CRC >> 0u);

    len = 24u;

    Transmit_LocoHealthPkt_to_NMS();

}

/***********send the buffer through CAN using information packets and data packets**********************************/

/*
void send_pkt_to_log(uint8_t event_type, uint8_t event_id, uint16_t data_pkt_length, uint8_t * log_data)
{

    u8InfoMsgData[0] = event_type;
    u8InfoMsgData[1] = event_id;

    if(data_pkt_length < 8)
    {
        u8InfoMsgData[2] = 1U;
    }
    else if((data_pkt_length % 8)  != 0)
    {
        u8InfoMsgData[2] = ((data_pkt_length / 8) + 1 );
    }
    else{
        u8InfoMsgData[2] = (data_pkt_length / 8);
    }

    u8InfoMsgData[3] = 0x00;
    u8InfoMsgData[4] = data_pkt_length;
    u8InfoMsgData[5] = 0U;
    u8InfoMsgData[6] = 0U;
    u8InfoMsgData[7] = 0U;


    uint8_t i = 1U,j = 1U;

    for(i = 0U; i < u8InfoMsgData[2] ; i++ )
    {
        u8InfoMsgData[3] = u8InfoMsgData[3] + 1U;

        ExtractCPUdata(1);

        for(j = 0U; j < 8U; j++)
        {
             if(((i * 8U) + j) < data_pkt_length)
             {
                 ucMsgData[j] = log_data[((i * 8U) + j)];
             }
             else{}

        }
        ExtractCPUdata(2);
        ucMsgData[0] = 0U; ucMsgData[1] = 0U; ucMsgData[2] = 0U; ucMsgData[4] = 0U; ucMsgData[5] = 0U; ucMsgData[6] = 0U; ucMsgData[7] = 0U;
    }

}
*/


void SendCAN_CPU2ADL(void)
{
    uint32 u32MsgID = 0u;
    u8caninfopktbuff[0] = (uint8)LOCOHEALTHMSG;                          /* Event type */
    u8caninfopktbuff[1] = 1u;                                            /* Event ID */
    u8caninfopktbuff[2] = 3u;                                            /* CAN packet Count */
    u8caninfopktbuff[3] = 1u;                                            /* current packet index */
    u8caninfopktbuff[4] = 16u;                                           /* DataByte Count */
    u8caninfopktbuff[5] = 0u;
    u8caninfopktbuff[6] = 0u;
    u8caninfopktbuff[7] = 0u;
    u32MsgID = create_can_msg_object(8);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8caninfopktbuff);
    wait(1000u);


    u8candatapktbuff[0] = 1u;
    u8candatapktbuff[1] = 2u;
    u8candatapktbuff[2] = 3u;
    u8candatapktbuff[3] = 4u;
    u8candatapktbuff[4] = 5u;
    u8candatapktbuff[5] = 6u;
    u8candatapktbuff[6] = 7u;
    u8candatapktbuff[7] = 8u;
    u32MsgID = create_can_msg_object(9);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8candatapktbuff);
    wait(1000u);


    u8caninfopktbuff[0] = (uint8)LOCOHEALTHMSG;                          /* Event type */
    u8caninfopktbuff[1] = 1u;                                            /* Event ID */
    u8caninfopktbuff[2] = 3u;                                            /* CAN packet Count */
    u8caninfopktbuff[3] = 2u;                                            /* current packet index */
    u8caninfopktbuff[4] = 16u;                                           /* DataByte Count */
    u8caninfopktbuff[5] = 0u;
    u8caninfopktbuff[6] = 0u;
    u8caninfopktbuff[7] = 0u;
    u32MsgID = create_can_msg_object(8);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8caninfopktbuff);
    wait(1000u);


    u8candatapktbuff[0] = 9u;
    u8candatapktbuff[1] = 10u;
    u8candatapktbuff[2] = 11u;
    u8candatapktbuff[3] = 12u;
    u8candatapktbuff[4] = 13u;
    u8candatapktbuff[5] = 14u;
    u8candatapktbuff[6] = 15u;
    u8candatapktbuff[7] = 16u;
    u32MsgID = create_can_msg_object(9);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8candatapktbuff);
    wait(1000u);


    u8caninfopktbuff[0] = (uint8)LOCOHEALTHMSG;                          /* Event type */
    u8caninfopktbuff[1] = 1u;                                            /* Event ID */
    u8caninfopktbuff[2] = 3u;                                            /* CAN packet Count */
    u8caninfopktbuff[3] = 3u;                                            /* current packet index */
    u8caninfopktbuff[4] = 16u;                                           /* DataByte Count */
    u8caninfopktbuff[5] = 0u;
    u8caninfopktbuff[6] = 0u;
    u8caninfopktbuff[7] = 0u;
    u32MsgID = create_can_msg_object(8);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8caninfopktbuff);
    wait(1000u);


    u8candatapktbuff[0] = 11u;
    u8candatapktbuff[1] = 22u;
    u8candatapktbuff[2] = 33u;
    u8candatapktbuff[3] = 44u;
    u8candatapktbuff[4] = 55u;
    u8candatapktbuff[5] = 66u;
    u8candatapktbuff[6] = 77u;
    u8candatapktbuff[7] = 88u;
    u32MsgID = create_can_msg_object(9);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8candatapktbuff);
    wait(1000u);

/**********************************************Fault Message ************************************************************/
    u8caninfopktbuff[0] = (uint8)LOCOFAULTMSG;;                          /* Event type */
    u8caninfopktbuff[1] = 1u;                                            /* Event ID */
    u8caninfopktbuff[2] = 2u;                                            /* CAN packet Count */
    u8caninfopktbuff[3] = 1u;                                            /* current packet index */
    u8caninfopktbuff[4] = 16u;                                           /* DataByte Count */
    u8caninfopktbuff[5] = 0u;
    u8caninfopktbuff[6] = 0u;
    u8caninfopktbuff[7] = 0u;
    u32MsgID = create_can_msg_object(8);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8caninfopktbuff);
    wait(1000u);


    u8candatapktbuff[0] = 5u;
    u8candatapktbuff[1] = 41u;
    u8candatapktbuff[2] = 37u;
    u8candatapktbuff[3] = 84u;
    u8candatapktbuff[4] = 12u;
    u8candatapktbuff[5] = 43u;
    u8candatapktbuff[6] = 8u;
    u8candatapktbuff[7] = 64u;
    u32MsgID = create_can_msg_object(9);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8candatapktbuff);
    wait(1000u);


    u8caninfopktbuff[0] = (uint8)LOCOFAULTMSG;;                          /* Event type */
    u8caninfopktbuff[1] = 1u;                                            /* Event ID */
    u8caninfopktbuff[2] = 2u;                                            /* CAN packet Count */
    u8caninfopktbuff[3] = 2u;                                            /* current packet index */
    u8caninfopktbuff[4] = 16u;                                           /* DataByte Count */
    u8caninfopktbuff[5] = 0u;
    u8caninfopktbuff[6] = 0u;
    u8caninfopktbuff[7] = 0u;
    u32MsgID = create_can_msg_object(8);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8caninfopktbuff);
    wait(1000u);


    u8candatapktbuff[0] = 21u;
    u8candatapktbuff[1] = 6u;
    u8candatapktbuff[2] = 65u;
    u8candatapktbuff[3] = 12u;
    u8candatapktbuff[4] = 4u;
    u8candatapktbuff[5] = 52u;
    u8candatapktbuff[6] = 72u;
    u8candatapktbuff[7] = 11u;
    u32MsgID = create_can_msg_object(9);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8candatapktbuff);
    wait(1000u);
}

