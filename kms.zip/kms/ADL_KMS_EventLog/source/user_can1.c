/*
 * user_can.c
 *
 *  Created on: 11-Sep-2024
 *      Author: User
 */


#include "can.h"
#include "sys_main.h"
#include "user_can1.h"
#include "gsm.h"

#include "ti_fee.h"


/*****event log ***********/
#include "MAIN.h"
#include <string.h>
#include "kavach.h"
#include "user_can.h"

uint8_t u8canbuffer[8] = {0};
uint8_t u8CANRx_Msg[8][8] = {0};
uint8_t u8CanMesg[8] = {0};
uint8_t u8CanMesg1[8] = {0};

uint8_t set1[16] ={0};
uint8_t set2[16] = {0};
uint8_t u8canTxbuff[8] = {0};
uint8_t u8Key_set_bit = 0u;

uint8_t ucMsgData[8] = {0};
char ucMsgCPU[256][8];
char ucKeyReqBuf[4][10];
char ucGpsDatabuf[4][10];

uint8 u8index = 0u;

uint32_t u32can1state = 0u;
uint32_t u32can2state = 0u;

struct UDPdata udp_data;

can_info_t CAN0_Info;
can_info_t CAN1_Info;

void delay1(void);

unsigned char KeyData9[320] = {97,1,2,3,4,5,6,7,65,65,65,65,65,65,65,65,66,66,66,66,66,66,66,66,66,66,66,66,66,66,66,66,65,65,65,65,65,65,65,65,1,2,3,4,5,6,7,8,33,33,
       33,33,33,33,33,33,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,33,33,33,33,33,33,33,33,2,3,4,5,6,7,8,9,35,35,35,35,35,35,35,35,36,36,36,36,36,36,36,36,36,
       36,36,36,36,36,36,36,35,35,35,35,35,35,35,35,3,4,5,6,7,8,9,10,37,37,37,37,37,37,37,37,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,
       37,37,37,37,37,37,37,37,4,5,6,7,8,9,10,11,39,39,39,39,39,39,39,39,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,39,39,39,39,39,39,39,39,5,6,7,8,1,2,3,4,41,41,
       41,41,41,41,41,41,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,41,41,41,41,41,41,41,41,6,7,8,9,10,11,12,13,43,43,43,43,43,43,43,43,44,44,44,44,44,44,44,44,44,
       44,44,44,44,44,44,44,43,43,43,43,43,43,43,43,1,2,3,4,5,6,7,8,45,45,45,45,45,45,45,45,46,46,46,46,46,46,46,46,46,46,46,46,46,
       46,46,46,45,45,45,45,45,45,45,45};


#define KEYSETMEM(x)   (0xF0200508 + x*40)

unsigned char read_data[1300]={0};
unsigned char u8EEPIndex ;
uint16 u8Key_size = 0u;
uint8 t = 0u;
uint8 u8Key_buff[514] = {0};

uint16 u8data1 = 0u;
uint16 u8data2 = 0u;

uint8 u8canPktindex = 0u;

uint8_t u8canidentifier = 0u;

/* structure declaration */
gcanFun CAN_Info;
gDipinfo_t DipInfo;
gKmsPkt_t KMSKeys_Info;
gsm_info_t GSM1_Info;

void myMemcpy(void *dest, const void *src, size_t n);


/*********************Event Logger Data *****************************/
uint8 data_pkt_buffer[400];

uint8 ucMsgData[8];
uint8 ucInfoMsgData[8];
char ucMsgCounter[8];
uint8 ucMsgTxBOX8[8];
uint8 ucMsgTxBOX81[8];
uint16 gCANSeqNum = 0U;

char ucMsgCPU1[8];
char ucMsgCPU2[8];
char ucMSGCPU[16][8];

uint8 sec = 0u;
uint8 min = 0u;
uint8 hrs = 0u;
uint8 day = 25u;
uint8 month = 11u;
uint16 year = 2024u;

uint8 rad_tag_buffer[100] = {0u};

uint8 u8radiotxbuff[250] = {0};

uint64 aepkt_line_count = 0u;

cpudata_info_t cpudata_info;

void ExtractCRITDat(uint8* packet);
/*Access_Auth_Packet_t loco_ag_pkt;*/
bitarray_t Radio_In_Bits;
LTCAS_STCAS_Reg_Packet_t Loco_Stn_Reg_Packet;
Access_LTCAS_Packet_t Loco_Access_Req_Packet;
Access_Auth_Packet_t loco_ag_pkt;


void ProcessTVCOMlogdata(uint8 i);
uint8 u8CanMsgIndex = 0u;
uint8 u8CANRxCnt = 0u;
void LogGPSData(void);
void LogABSData(void);
void LogACKdata(void);

static can_data_t CAN_Data;


ma_pkt MA_pkt;
static_speed_value  SSP_Value;


change_of_brake_t change_of_brake;

void BuildEventData2WriteSDcard(uint8 u8EventType, uint8 u8EventID , uint8 u8FileIndex2Store);

void WriteEventDataSDCard(uint8* log_data, uint8 u8Trigger);

/************************Event log data end ******************************/


void canMessageNotification(canBASE_t *node, uint32 messageBox)
{

    if(node == canREG1)
    {
/*        uint32_t u32MsgID = canGetID(canREG1, messageBox);  */
        if((messageBox == canMESSAGE_BOX4) || (messageBox == canMESSAGE_BOX3))
        {
            uint32_t u32MsgID = canGetID(canREG1, messageBox);                                   /* function to get the CAN msg ID based message box number */

            CAN1_Info.CAN_RxFlag = 1;
            CAN1_Info.CAN_ErrFlag = 0;
            u8canidentifier = u32MsgID & 0xFFu;                                          /* extracting the CAN ID */
            uint8_t cpu_id = (u32MsgID & 0xF0000u) >> 16u;                                      /* extracting CPU Id */
            canGetData(canREG1, messageBox, (uint8 *) ucMsgData);

            memcpy(ucMsgCPU[u8canidentifier],ucMsgData,8);

            ExtractKeysdata(u8canidentifier);
            if(u8canidentifier == 3u)
            {
                memcpy(ucKeyReqBuf[cpu_id],ucMsgData,8);
                CAN0_Info.u8keyreqmsg[cpu_id][u8canidentifier] = SET_HIGH;
            }

            if(u8canidentifier == 4u || u8canidentifier == 5u)
            {
                memcpy(ucGpsDatabuf[0],ucMsgData, 8);
                CAN0_Info.u8GpsRxbit = SET_HIGH;
            }
        }

        if(messageBox == canMESSAGE_BOX2)
        {
            uint32_t u32MsgID = canGetID(canREG1, messageBox);
            if(((u32MsgID & 0xFFFF0)== 0x18000)  || ((u32MsgID & 0xFFFF0)== 0x28000))
            {

                u8canidentifier = u32MsgID & 0xFFu;
                canGetData(canREG1, messageBox, (uint8 *) ucMsgData);
                processLogData(u8canidentifier);

            }
            else if(((u32MsgID & 0xFFFF0)== 0x38000)  || ((u32MsgID & 0xFFFF0)== 0x48000))
            {
                u8canidentifier = u32MsgID & 0xFFu;
                canGetData(canREG1, messageBox, (uint8 *) ucMsgData);
                processLogData(u8canidentifier);
            }
            else
            {

            }

         }
         if(messageBox == canMESSAGE_BOX7)
         {
             uint32_t u32MsgID = canGetID(canREG1, canMESSAGE_BOX7);
             canGetData(canREG1, canMESSAGE_BOX7, (uint8 *) ucMsgData);
             if((u32MsgID & 0xFF00)==0x3100u)
             {
                 u8canidentifier = u32MsgID & 0xFFu;

                 process_CAN_data(u8canidentifier);
             }
             else
             {
             }
         }

         if(messageBox == canMESSAGE_BOX1 )
         {
             uint32_t u32MsgID = canGetID(canREG1, canMESSAGE_BOX1);

             canGetData(canREG1, canMESSAGE_BOX1, (uint8 *) ucMsgData);
             if(((u32MsgID & 0xFF00)==0x2100) || ((u32MsgID & 0xFF00)==0x2400))
             {

                 process_gps_time();
             }
             else
             {
             }
                   /* if(((u32MsgID & 0xFF00)==0x2207) || ((u32MsgID & 0xFF00)==0x2507))
                    {
                        process_gps_abs();
                    }  */

             if((u32MsgID & 0xFF00)==0x2300u)      /*|| ((u32MsgID & 0xFF00)==0x2400)) */
             {
                 u8canidentifier =(uint8_t) (u32MsgID & 0xFFu);
                 memcpy(tsrms_pkt.u8TSRMS_tmp_buff,ucMsgData,8u);
                 process_TSRMS_data();
             }
         }

    }

    if(node == canREG2)
    {
        if((messageBox == canMESSAGE_BOX2) || (messageBox == canMESSAGE_BOX4))
        {
            uint32_t u32MsgID = canGetID(canREG1, messageBox);                                   /* function to get the CAN msg ID based message box number */

            CAN1_Info.CAN_RxFlag = 1;
            CAN1_Info.CAN_ErrFlag = 0;
            uint8_t u8canidentifier = u32MsgID & 0xFFu;                                          /* extracting the CAN ID */
            uint8_t cpu_id = (u32MsgID & 0xF0000u) >> 16u;                                       /* extracting CPU Id */
            canGetData(canREG2, messageBox, (uint8 *) ucMsgData);

            memcpy(ucMsgCPU[u8canidentifier],ucMsgData,8u);

            /*myMemcpy(u8CANRx_Msg[0], ucMsgData, 8u);
            VPM_CAN_Received_message();*/

            if(u8canidentifier == 3u)
            {
                memcpy(ucKeyReqBuf[cpu_id],ucMsgData,8u);
                CAN0_Info.u8keyreqmsg[cpu_id][u8canidentifier] = SET_HIGH;
            }

            if(u8canidentifier == 4u || u8canidentifier == 5u)
            {
                memcpy(ucGpsDatabuf[0],ucMsgData, 8u);
                CAN0_Info.u8GpsRxbit = SET_HIGH;
            }
            else
            {

            }
        }


        if ( messageBox == canMESSAGE_BOX3)
        {
             uint32_t u32MsgID = canGetID(canREG2, messageBox);
             uint8_t u8canidentifier = u32MsgID & 0xFFu;                                          /* extracting the CAN ID */
             uint8_t cpu_id = (u32MsgID & 0xF0000u) >> 16u;                                       /* extracting CPU Id */
             canGetData(canREG2, messageBox, (uint8 *) u8CanMesg);
                    /*if((u32MsgID & 0xFF00u) == 0x3200u)
                    {
                        ExtractLocoEventdata(u8canidentifier);
                    }*/

             if(((u32MsgID & 0xFF00u) == 0x3200u) && ((u8canidentifier & 0xFFu) < 27u))           /* condition for receive the data packet of Critical, triggered, triggered maint data */
             {
                 if(read_lock==0u)                                                    /* for checking the condition flag for it's reading the data from SD card */
                 {
                 ExtractLocoEventdata1(u8canidentifier);
                 }
                 else
                 {

                 }
             }

        /*            if(((u8canidentifier & 0xFFu) >= 27u) && ((u8canidentifier & 0xFFu) <= 53u))
                    {
                        gioSetBit(gioPORTB, 5u, 1u);
                        ExtractLiveEventdata(u8canidentifier);
                        wait(500u);
                        gioSetBit(gioPORTB, 5u, 0u);
                    }

                    if(((u8canidentifier & 0xFFu) >= 43u) && ((u8canidentifier & 0xFFu) <= 53u))
                    {
                        ExtractLocoEventdata(u8canidentifier);
                    }*/
                }
    }
}
/***********************************************************************************************************/

void can_pkt_transmit(void)
{
    u8canbuffer[0] = 0u;
    u8canbuffer[1] = 1u;
    u8canbuffer[2] = 0u;
    u8canbuffer[3] = 0u;
    u8canbuffer[4] = 0u;
    u8canbuffer[5] = 0u;
    u8canbuffer[6] = 0u;
    u8canbuffer[7] = 0u;

    uint32 u32MsgID = create_can_msg_object(3);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8canbuffer);
    wait(1000u);

    u8canbuffer[0] = 10u;
    u8canbuffer[1] = 11u;
    u8canbuffer[2] = 24u;
    u8canbuffer[3] = 30u;
    u8canbuffer[4] = 0u;
    u8canbuffer[5] = 0u;
    u8canbuffer[6] = 0u;
    u8canbuffer[7] = 0u;
    uint32 u32MsgID1 = create_can_msg_object(4);
    canUpdateID(canREG1, canMESSAGE_BOX5, u32MsgID1);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8*)u8canbuffer);
    wait(1000u);
}
/******************************************************************************************/
void VPM_CAN_Received_message(void)
{
    u8CANRx_Msg[0][0] = 0u;
    u8CANRx_Msg[0][1] = GSM1_Info.chDate;
    u8CANRx_Msg[0][2] = GSM1_Info.chMonth;
    u8CANRx_Msg[0][3] = GSM1_Info.chYear;
    u8CANRx_Msg[0][4] = 0u;
    u8CANRx_Msg[0][5] = 0u;
    u8CANRx_Msg[0][6] = 0u;
    u8CANRx_Msg[0][7] = 0u;

    CAN_Info.u8S_time = u8CANRx_Msg[0][0];         /* assiging received GPS time and date */
    CAN_Info.u8S_date = u8CANRx_Msg[0][1];
    CAN_Info.u8S_month = u8CANRx_Msg[0][2];
    CAN_Info.u8S_year = u8CANRx_Msg[0][3];
    CAN_Info.u8Key_set = u8CANRx_Msg[0][4];
    u8canbuffer[5] = u8CANRx_Msg[0][5];
    u8canbuffer[6] = u8CANRx_Msg[0][6];
    u8canbuffer[7] = u8CANRx_Msg[0][7];
    CAN_Info.u8KMS_Key_idx = 0u;
    Extract_KMS_key();                             /* extract KMS keys from on-chip EEPROM memory */

}
/***********************************************************************************************************/
void Key_set_can_functions(void)
{
    uint8 k;
    uint8 u8set;
    for(k = 0u;k < 32u; k++)
    {
        if((aut_key.AutKeystarthours[k] == CAN_Info.u8S_time) && (aut_key.AutKeystartdate[k] == CAN_Info.u8S_month))
        {
            if((aut_key.AutKeystartmonth[k] == CAN_Info.u8S_month) && (aut_key.AutKeystartyear[k] == CAN_Info.u8S_year))
            {
                for( u8set = 0u; u8set < 32u; set++)
                {
                    if(set < 16u)
                    {
                        set1[u8set] = CAN_Info.u8Aut_key1[k][u8set];
                    }
                    if(set >= 16u && set < 32u)
                    {
                        set2[u8set] = CAN_Info.u8Aut_key2[k][u8set];
                    }
                }
                u8Key_set_bit = 1u;
            }
        }
    }
}

/****************************************CAN Packet ID creation function************************************/
uint32 create_can_msg_object(uint8 u8CANMsg_ID)                                           /* create CAN message ID */
{
    CAN_Info.u32CAN_arbitration_value = 7u;
    CAN_Info.u32cpuID = VPMBASEID + u8CANMsg_ID + (DipInfo.u8Address * 256u);
    CAN_Info.u32CAN_arbitration_value = (((0x01u << 30u) | (0x01u << 29u) | (CAN_Info.u32cpuID & 0x1FFFFFFFu)) & 0x7FFFFFFFu);

    return CAN_Info.u32CAN_arbitration_value;
}
/***********************************************************************************************************/
void CAN_buffer_free_function(void)                                                       /* Clear the CAN buffer data */
{
    for(u8index = 0u;u8index < 8u;u8index++)
    {
        u8canTxbuff[u8index] = 0u;
    }
}
/***********************************************************************************************************/
void wait(uint32_t u32time)
{
    uint32_t u32Time = 1600u * u32time;
    while(u32Time--)
    {

    }
}

/************************************************EEPROM Functions*******************************************/

void EEPROM_write_function(void)
{
    uint16 Status;
    unsigned int BlockNumber;

    BlockNumber = 0x1u;
    TI_Fee_WriteSync(BlockNumber, (uint16_t *)&KeyData1[0]);                              /* writing KMS keys data into the EEPROM memory */
/*    TI_Fee_WriteAsync(BlockNumber, (uint8_t *)&KeyData1[0]); */
    do
    {
        TI_Fee_MainFunction();
        delay1();
        Status=TI_Fee_GetStatus(0);
    }
    while(Status!=IDLE);

//    TI_Fee_Format(0xA5A5A5A5U);                                                       /* Format the Flash bank 7 Memory data */
}
/*********************************EEPROM read function******************************************************/
void EEPROM_read_function(void)
{
    unsigned char *Read_Ptr = read_data;

    TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadAddress = (uint8 *)KEYSETMEM(0) ;                                      /* setting the starting address to the EEPORM */
    /*SAFETYMCUSW 567 S MR:17.1,17.4 <APPROVED> "Reason -  Pointer Arithmatic is necessary here."*/
    TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadAddress = TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadAddress+0;     /* Reading the address from EEPROM */

    TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadDataBuffer = Read_Ptr;                                                 /* storing the reading data from EEPROM */
    TI_Fee_oStatusWord[u8EEPIndex].Fee_StatusWordType_ST.Read = 1U;                                                      /* setting the structure variable to read the data from EEPROM memory */

    TI_Fee_GlobalVariables[u8EEPIndex].Fee_u16BlockSize = 1202u;                                                         /* total block size reading from EEPROM */

    if (TI_Fee_oStatusWord[u8EEPIndex].Fee_StatusWordType_ST.Read == 1U)                                                 /* checking the read bit to read the data from EEPROM */
    {
        while(TI_Fee_GlobalVariables[u8EEPIndex].Fee_u16BlockSize > 0U )
        {
            *TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadDataBuffer=*TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadAddress; /* reading the one one byte of data from EEPROM and storing into the RAM memory buffer */

            TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadDataBuffer++;                                                  /* incrementing the read buffer size */
            TI_Fee_GlobalVariables[u8EEPIndex].Fee_pu8ReadAddress++;                                                     /* incrementing the read data location address */
            TI_Fee_GlobalVariables[u8EEPIndex].Fee_u16BlockSize--;                                                       /* decrementing the blocksize after extracting each byte by byte */
        }
    }
    /*u8Key_size = my_strlen((uint8 *)read_data);*/
}

/********************************KMS Key extraction from EEPROM Memory *************************************/
void Extract_KMS_key(void)
{
    for(u8data1 = 0u; u8data1 < 1224; u8data1 += KEYSET_OFFSET)
    {
/*        uint8 endstartdate = 27u, enddate = 31u;  */
        CAN_Info.u8KMS_Key_idx++;
//        if((CAN_Info.u8S_time <= read_data[u8data+0u]) && ((CAN_Info.u8S_date > read_data[u8data1+1u]) && (CAN_Info.u8S_date <= read_data[u8data1+5u])) && ((CAN_Info.u8S_month >= read_data[u8data1+2u]) && (CAN_Info.u8S_month <= read_data[u8data1+6u])) && ((CAN_Info.u8S_year >= read_data[u8data1+7]) && (CAN_Info.u8S_year <= read_data[u8data1+7])))  /* with time */
        if(((((read_data[u8data1+1u] >= 27u) && (read_data[u8data1+1u] <= 31u)) || (CAN_Info.u8S_date > read_data[u8data1+1u])) && (CAN_Info.u8S_date <= read_data[u8data1+5u])) && ((CAN_Info.u8S_month >= read_data[u8data1+2u]) && (CAN_Info.u8S_month <= read_data[u8data1+6u])) && ((CAN_Info.u8S_year >= read_data[u8data1+7]) && (CAN_Info.u8S_year <= read_data[u8data1+7]))) /* checking present date is less than Key sets end date */
        {
            for(u8data2 = u8data1; u8data2 <= 1224; u8data2++)                /* extract the KMS keys using Keys data offset */
            {
                if(t < KEYSET_OFFSET)
                {
                    u8Key_buff[t] = read_data[u8data2];                       /* store the keys data into the buffer */
                    t++;
                    if(t == KEYSET_OFFSET)
                    {
                        CAN_Info.u8KeyRx = (uint8)SET_HIGH;                  /* for indicating the key stored to sending the VPM through CAN */
                        u8KeyReqByte = SET_HIGH;                             /* for asking the KMS keys if keys set is not available */
//                        build_CANpkt1();                                    /* after receiving keys set data call the build pkt function */
                        t = 0u;
                        CAN_Info.u8Key_set = CAN_Info.u8KMS_Key_idx;
                        gioSetBit(gioPORTB, 6u, 1u);
                        break;
                    }
                }
            }
        }
    }
}

/************************************************************************************/
void can_msg_send(uint8 u8CANMsg_ID)                                           /* create CAN message ID */
{
/*    DipInfo.u8Address = 7u;   */
    uint16 total_id = 0u;
    total_id = (uint16)ADLBASEID;
    if(DipInfo.u8Address == 1u)
    {
        total_id += 0x0040u;
    }
    else if(DipInfo.u8Address == 2u)
    {
        total_id += 0x0080u;
    }
    else
    {
    }

    total_id = total_id & 0xFFC0u;
    total_id = total_id | u8CANMsg_ID;                                            /* can_id is 6 bit only */


    /*CAN_Info.u32cpuID = ADLBASEID + u8CANMsg_ID + (DipInfo.u8Address * 256u);*/
    CAN_Info.u32cpuID = (uint32)total_id;
    CAN_Info.u32canMsgID = (((0x01u << 30u) | (0x01u << 29u) | (CAN_Info.u32cpuID & 0x1FFFFFFFu)) & 0x7FFFFFFFu);
    canUpdateID(canREG1, canMESSAGE_BOX5, CAN_Info.u32canMsgID);
    canTransmit(canREG1, canMESSAGE_BOX5, (uint8 *)u8canTxbuff);
}
/***********************************************************************************/
void build_CANpkt1(void)                                                       /* KMS keys CAN build function */
{
    u8canTxbuff[0] = u8Key_buff[0];
    u8canTxbuff[1] = u8Key_buff[1];
    u8canTxbuff[2] = u8Key_buff[2];
    u8canTxbuff[3] = u8Key_buff[3];
    u8canTxbuff[4] = u8Key_buff[4];
    u8canTxbuff[5] = u8Key_buff[5];
    u8canTxbuff[6] = u8Key_buff[6];
    u8canTxbuff[7] = u8Key_buff[7];
    can_msg_send(KEYDATA1);
    wait(1000u);

    u8canTxbuff[0] = u8Key_buff[8];
    u8canTxbuff[1] = u8Key_buff[9];
    u8canTxbuff[2] = u8Key_buff[10];
    u8canTxbuff[3] = u8Key_buff[11];
    u8canTxbuff[4] = u8Key_buff[12];
    u8canTxbuff[5] = u8Key_buff[13];
    u8canTxbuff[6] = u8Key_buff[14];
    u8canTxbuff[7] = u8Key_buff[15];
    can_msg_send(KEYDATA2);
    wait(1000u);


    u8canTxbuff[0] = u8Key_buff[16];
    u8canTxbuff[1] = u8Key_buff[17];
    u8canTxbuff[2] = u8Key_buff[18];
    u8canTxbuff[3] = u8Key_buff[19];
    u8canTxbuff[4] = u8Key_buff[20];
    u8canTxbuff[5] = u8Key_buff[21];
    u8canTxbuff[6] = u8Key_buff[22];
    u8canTxbuff[7] = u8Key_buff[23];
    can_msg_send(KEYDATA3);
    wait(1000u);


    u8canTxbuff[0] = u8Key_buff[24];
    u8canTxbuff[1] = u8Key_buff[25];
    u8canTxbuff[2] = u8Key_buff[26];
    u8canTxbuff[3] = u8Key_buff[27];
    u8canTxbuff[4] = u8Key_buff[28];
    u8canTxbuff[5] = u8Key_buff[29];
    u8canTxbuff[6] = u8Key_buff[30];
    u8canTxbuff[7] = u8Key_buff[31];
    can_msg_send(KEYDATA4);
    wait(1000u);


    u8canTxbuff[0] = u8Key_buff[32];
    u8canTxbuff[1] = u8Key_buff[33];
    u8canTxbuff[2] = u8Key_buff[34];
    u8canTxbuff[3] = u8Key_buff[35];
    u8canTxbuff[4] = u8Key_buff[36];
    u8canTxbuff[5] = u8Key_buff[37];
    u8canTxbuff[6] = u8Key_buff[38];
    u8canTxbuff[7] = u8Key_buff[39];
    can_msg_send(KEYDATA5);
    wait(1000u);
}
/*****************************************************************************************/
void SendModuleStatus2CPUCAN(void)
{
    u8canTxbuff[0] = DipInfo.u8Address;                              /* health status of ADL module */
    u8canTxbuff[1] = DipInfo.u8Config;
    u8canTxbuff[2] = DipInfo.u8Slot;
    u8canTxbuff[3] = Sys_Mon_Info.u32ADLCRC >> 24u;
    u8canTxbuff[4] = Sys_Mon_Info.u32ADLCRC >> 16u;
    u8canTxbuff[5] = Sys_Mon_Info.u32ADLCRC >> 8u;
    u8canTxbuff[6] = Sys_Mon_Info.u32ADLCRC >> 0u;
    u8canTxbuff[7] = 0u;
    can_msg_send(6);
    wait(1000u);

    u8canTxbuff[0] = udp_data.u32NetworkCSQ1;                        /* health status of GSM module, network signal strength  */
    u8canTxbuff[1] = udp_data.chCGREG1;                              /* network registration status */
    u8canTxbuff[2] = CAN_Info.u8Key_set;                             /* current set key index */
    u8canTxbuff[3] = 0x1Eu;                                          /* total number of Keys set */
    u8canTxbuff[4] = 1u;                                             /* SD card status indication */
    u8canTxbuff[5] = 0u;
    u8canTxbuff[6] = 0u;
    u8canTxbuff[7] = 0u;
    can_msg_send(7);
    wait(1000u);
}
/**********************VPM Communication Process***********************************/
void ExtractKeysdata(uint8_t i)
{
    if(i == (uint8_t)VALIDITY_PKT)
    {
        memcpy(CAN_Info.u8Keys_validityData,u8CanMesg,8);                               /* storing the date time packet */
        CAN_Info.u8KEYS_VALIDITYPKTRcvd = (uint8)VALIDITY_PKT;
        KMSKeys_Info.u8KMSRxdData1 = VALIDITY_PKT;
        KMSKeys_Info.u8startTime = CAN_Info.u8Keys_validityData[0];                     /* extracting the start time date and end time date */
        KMSKeys_Info.u8startDate = CAN_Info.u8Keys_validityData[1];
        KMSKeys_Info.u8startMonth = CAN_Info.u8Keys_validityData[2];
        KMSKeys_Info.u8startYear = CAN_Info.u8Keys_validityData[3];
        KMSKeys_Info.u8endTime = CAN_Info.u8Keys_validityData[4];
        KMSKeys_Info.u8endDate = CAN_Info.u8Keys_validityData[5];
        KMSKeys_Info.u8endMonth = CAN_Info.u8Keys_validityData[6];
        KMSKeys_Info.u8endYear = CAN_Info.u8Keys_validityData[7];

        CAN_Info.u8CANPktcnt = 4u;
        KMSKeys_Info.u8KMSRxdData2 = 0u;
    }
    else if((i >= 1u) && (i < 5u) || (i == KEYS_DATAPKT))                                /* checking the KMS key set packet index */
    {
        if(CAN_Info.u8CANPktcnt < (uint8_t)127)
        {
            KMSKeys_Info.u8KMSRxdData2 = (uint8_t)KEYS_DATAPKT;
            CAN_Info.u8currpktidx = i;

            if(CAN_Info.u8currpktidx == (CAN_Info.u8prevpktidx + 1u))                   /* ensuring the receiving the valid CAN packet */
            {
                KMSKeys_Info.u8KMSRxdData1 = 0u;
                memcpy(CAN_Info.u8KMS_keysData[CAN_Info.u8currpktidx],u8CanMesg,8);     /* storing the KMS key set data */
                CAN_Info.u8prevpktidx  =  CAN_Info.u8currpktidx;

                if(CAN_Info.u8currpktidx == CAN_Info.u8CANPktcnt)                       /* checking the all packets are received or not */
                {
                    CAN_Info.u8prevpktidx = 0u;
                    CAN_Info.u8KeyRx = SET_HIGH;
                    ProcessKeysSetdata();                                               /* process the received KMS keys data */
                    CAN_Info.u8KeyRx = SET_LOW;
                }

                CAN_Info.u8currpktidx = 0u;
            }
            else
            {
               CAN_Info.u8currpktidx = 0U;
               CAN_Info.u8prevpktidx = 0U;
            }
        }
    }
    else
    {
    }
}
/************************VPM Communication Process*************************************/
void ProcessKeysSetdata(void)
{
    uint8_t u8index, u8subindex;
    uint8_t k = 0u;
    /*myMemcpy(KMSKeys_Info.u8VPM_keyRcvData, CAN_Info.u8Keys_validityData, 8u);
    k = 8u;*/

    if(CAN_Info.u8KeyRx == 1u)
    {
        for(u8index = 1u; u8index <= CAN_Info.u8CANPktcnt;  u8index++)                           /*  receiving the CAN packet length of data */
        {
            for(u8subindex = 0u; u8subindex < 8u ; u8subindex++)
            {
                KMSKeys_Info.u8VPM_keyRcvData[k] = CAN_Info.u8KMS_keysData[u8index][u8subindex];    /* storing the all KMS key CAN data packet into the into buffer */
                k++;
            }
        }
    }
}
/***************************************************************************************************/

void Check2oo2KeyReq(void)
{
    uint8_t uch2oo2Error = 0;
    uint8_t u8index;
    if(CAN0_Info.u8keyreqmsg[2][3] == SET_HIGH && CAN0_Info.u8keyreqmsg[1][3] == SET_HIGH)
    {
        for(u8index = 2u; u8index < 8u; u8index++)
        {
            if(ucKeyReqBuf[0][u8index] == ucKeyReqBuf[1][u8index])
            {

            }
            else
            {
                uch2oo2Error++;
            }
        }
        if(uch2oo2Error == SET_LOW)
        {
            if(ucKeyReqBuf[1][0] == 1u || ucKeyReqBuf[2][0] == 1u)
            {
                u8KeyRequestbit = SET_HIGH;
            }
            else
            {
                u8KeyRequestbit = SET_LOW;
            }
        }
        CAN0_Info.u8keyreqmsg[0][3] = SET_LOW;
        CAN0_Info.u8keyreqmsg[1][3] = SET_LOW;
    }
}

/***********************************************************************************************/

void myMemcpy(void *dest, const void *src, size_t n)
{
    uint8 i;
    char *csrc = (char *)src;
    char *cdest = (char *)dest;
    for ( i = 0; i < n; i++)
    {
        cdest[i] = csrc[i];
    }
}


void CAN1Reset(void)
{
    u32can1state = canGetErrorLevel(canREG1);
    if(u32can1state != 0)
    {
        canREG1 ->ES = 0x00000000u;
        canInit();
    }
}

void CAN2Reset(void)
{
    u32can2state = canGetErrorLevel(canREG2);
    if(u32can2state != 0)
    {
        canREG2 ->ES = 0x00000000u;
        canInit();
    }
}

void delay1(void)
{
    unsigned int dummycnt=0x0000FFU;
    do
    {
        dummycnt--;
    }
    while(dummycnt>0);
}


/*************************************************Event logger code *******************************/

/********************************************************************************************************************************************************
                                                         EXTRACT EVENT PACKET FUNCTION
 **********************************************************************************************************************************************************/
void ExtractEventdata(uint8 i)
{

    if(i == (uint8)EVENTPKT1)
    {
        memcpy(CAN_Data.u8EventLogData,ucInfoMsgData,8U);
        CAN_Data.U8EVENTPKTRXD1   = (uint8)EVENTPKT1;
        CAN_Data.u8EventType      = CAN_Data.u8EventLogData[0];           /*event type*/
        CAN_Data.u8EventID        =  CAN_Data.u8EventLogData[1];          /*event ID*/
        CAN_Data.u8EVENTCANPktCnt = CAN_Data.u8EventLogData[2];        /*CAN packets count*/
        CAN_Data.u8EVENTcurpktidx = CAN_Data.u8EventLogData[3];        /*Current packet Index*/
        CAN_Data.u8dataPktbyteCnt = CAN_Data.u8EventLogData[4];        /* total data packet length*/
        CAN_Data.U8EVENTPKTRXD2   = 0U;

    }
    else if((i == (uint8)EVENTPKT2) && (CAN_Data.U8EVENTPKTRXD1== (uint8)EVENTPKT1))
    {
        if(CAN_Data.u8EVENTCANPktCnt <= 127U){
        CAN_Data.U8EVENTPKTRXD2 = (uint8)EVENTPKT2;

        if((CAN_Data.u8EVENTcurpktidx  ==    (CAN_Data.u8EVENTprevpktidx + 1U)))
        {

             CAN_Data.U8EVENTPKTRXD1 = 0U;
             memcpy(CAN_Data.u8EventLogData1[CAN_Data.u8EVENTcurpktidx],ucMsgData,8U);
             CAN_Data.u8EVENTprevpktidx  =   CAN_Data.u8EVENTcurpktidx ;
             if(CAN_Data.u8EVENTcurpktidx == CAN_Data.u8EVENTCANPktCnt)
             {
                 CAN_Data.u8EVENTprevpktidx = 0U;
                 ProcessEventdata(CAN_Data.u8EventType,0u);

             }
             CAN_Data.u8EVENTcurpktidx = 0U;
         }
         else
         {
             CAN_Data.u8EVENTcurpktidx = 0U;
             CAN_Data.u8EVENTprevpktidx = 0U;
         }
       }
    }
    else
    {

    }

}


/********************************************************************************************************************************************************
                                                         PROCESS EVENT PACKET FUNCTION
 **********************************************************************************************************************************************************/


void ProcessEventdata(uint8 u8EventType, uint8_t*data)
{

    CAN_Data.u8EventType  =  u8EventType;

    uint8 u8index = 0U;
    uint8 u8subindex = 0U;

     event_data_t  Triggered_Data;
     event_data_t  critical_Data;
     event_data_t  LiveEvent_Data;
     event_data_t  TrigMaint_Data;
     event_data_t  SvkToSvk_Data;
     event_data_t  TSRMS_Data;


     if(sec < 60)
     {
         sec++;
     }
     else
     {
         sec = 0u;

         if(min < 60)
         {
             min++;
         }
         else
         {
             min = 0u;

             if(hrs < 23)
             {
                 hrs++;

             }
             else
             {
                 hrs = 0u;
                 day++;

                 if(day > 30u)
                 {
                     day = 1u;
                     month++;

                     if(month > 12u)
                     {
                         month = 1u;
                     }
                 }
             }
         }
     }


/**********************************Critical data********************/

    if(CAN_Data.u8EventType  == (uint8)CRITICALDATA)
    {
      /*  CAN_Data.u8EventType      =  CAN_Data.u8EventLogData[0];
        critical_Data.u8EventID   =  CAN_Data.u8EventLogData[1];

              critical_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
              critical_Data.u8RecieveBuf[1] = critical_Data.u8EventID;
              critical_Data.u8RecieveBuf[2] = CAN_Data.u8dataPktbyteCnt;

            for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
            {
                 for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
                 {
                          critical_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];
                 }
            }    */
        critical_pkt.log_buff[0]=18u;
        critical_pkt.log_buff[1]=critical_pkt.critical_buff[0];
        critical_pkt.log_buff[2]=CRITICALDATA;
        critical_pkt.log_buff[3]=critical_pkt.critical_buff[1];
        critical_pkt.log_buff[4]=critical_pkt.critical_buff[2];
        critical_pkt.log_buff[5]=critical_pkt.critical_buff[3];
        critical_pkt.log_buff[6]=critical_pkt.critical_buff[4];
        critical_pkt.log_buff[7]=critical_pkt.critical_buff[5];
        critical_pkt.log_buff[8]=critical_pkt.critical_buff[6];
        critical_pkt.log_buff[9]=critical_pkt.critical_buff[7];
        critical_pkt.log_buff[10]=critical_pkt.critical_buff[9];
        critical_pkt.log_buff[11]=critical_pkt.critical_buff[10];
        critical_pkt.log_buff[12]=critical_pkt.critical_buff[11];
        critical_pkt.log_buff[13]=critical_pkt.critical_buff[12];
        critical_pkt.log_buff[14]=critical_pkt.critical_buff[13];
        critical_pkt.log_buff[15]=critical_pkt.critical_buff[18];
        critical_pkt.log_buff[16]=critical_pkt.critical_buff[19];
        critical_pkt.log_buff[17]=critical_pkt.critical_buff[20];
        if(critical_pkt.sub_pkt == 89u)
        {
            critical_pkt.log_buff[0]=20u;
            critical_pkt.log_buff[18]=critical_pkt.critical_buff[21];
            critical_pkt.log_buff[19]=critical_pkt.critical_buff[22];
        }


         WriteCritDatatoSDCard(&critical_pkt.log_buff[0], 0, (uint8) CAN_Data.u8EventType,critical_pkt.log_buff[0]);

    }
    else
    {
    }

/**********************************Triggered data*********************/

    if(CAN_Data.u8EventType  == (uint8)TRIGGEREDDATA)
    {
        CAN_Data.u8EventType      =  CAN_Data.u8EventLogData[0];
        Triggered_Data.u8EventID   =  CAN_Data.u8EventLogData[1];

        Triggered_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
        Triggered_Data.u8RecieveBuf[1] = Triggered_Data.u8EventID;
        Triggered_Data.u8RecieveBuf[2] = CAN_Data.u8dataPktbyteCnt;

        for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
        {
            for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
            {
                Triggered_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];

            }
        }

        WriteTrigDatatoSDCard((uint8*)Triggered_Data.u8RecieveBuf, Triggered_Data.u8EventID, (uint8)TRIGDATA,CAN_Data.u8dataPktbyteCnt);

    }else{}

/**********************************Live data***************************/

    if(CAN_Data.u8EventType == (uint8)LIVEDATA)
    {
        CAN_Data.u8EventType      =  CAN_Data.u8EventLogData[0];
        LiveEvent_Data.u8EventID   =  CAN_Data.u8EventLogData[1];

                    LiveEvent_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
                    LiveEvent_Data.u8RecieveBuf[1] = LiveEvent_Data.u8EventID;
                    LiveEvent_Data.u8RecieveBuf[2] = CAN_Data.u8dataPktbyteCnt;


            for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
            {
                    for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
                    {
                          LiveEvent_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];

                     }
            }
            WriteLiveDatatoSDCard((uint8*)LiveEvent_Data.u8RecieveBuf, LiveEvent_Data.u8EventID, (uint8)LIVDATA, CAN_Data.u8dataPktbyteCnt);

      }else{}

/********************************Triggered Maintenance data************/

    if(CAN_Data.u8EventType == (uint8)TRIGGEREDMAINT)
    {
        CAN_Data.u8EventType      =  CAN_Data.u8EventLogData[0];
        TrigMaint_Data.u8EventID   =  CAN_Data.u8EventLogData[1];

        TrigMaint_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
        TrigMaint_Data.u8RecieveBuf[1] = TrigMaint_Data.u8EventID;
        TrigMaint_Data.u8RecieveBuf[2] = CAN_Data.u8dataPktbyteCnt;


          for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
            {
                    for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
                    {
                          TrigMaint_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];

                    }
            }


        WriteTrigMaintDatatoSDCard((uint8*)TrigMaint_Data.u8RecieveBuf, (uint8)TrigMaint_Data.u8EventID, (uint8)TRIGMAINTDATA,(uint8)CAN_Data.u8dataPktbyteCnt);

    }
    else{

    }



/********************************SKV_SKV************/


    if(CAN_Data.u8EventType == (uint8)SVKTOSVKDATA)
    {
           CAN_Data.u8EventType      =  CAN_Data.u8EventLogData[0];
          SvkToSvk_Data.u8EventID   =  CAN_Data.u8EventLogData[1];


          SvkToSvk_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
          SvkToSvk_Data.u8RecieveBuf[1] = SvkToSvk_Data.u8EventID;
          SvkToSvk_Data.u8RecieveBuf[2] = (CAN_Data.u8dataPktbyteCnt + 7u);
          SvkToSvk_Data.u8RecieveBuf[3] = day;
          SvkToSvk_Data.u8RecieveBuf[4] = month;
          SvkToSvk_Data.u8RecieveBuf[5] = (uint8)((year >> 8u) & 0xFFu);
          SvkToSvk_Data.u8RecieveBuf[6] = (uint8)(year & 0xFFu);
          SvkToSvk_Data.u8RecieveBuf[7] = hrs;
          SvkToSvk_Data.u8RecieveBuf[8] = min;
          SvkToSvk_Data.u8RecieveBuf[9] = sec;

          for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
          {
              for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
              {
                  SvkToSvk_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 10U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];
              }
          }


        WriteSvkSvkDatatoSDCard((uint8*)SvkToSvk_Data.u8RecieveBuf, SvkToSvk_Data.u8EventID, (uint8)SVKSVKDATA,CAN_Data.u8dataPktbyteCnt);

    }
    else{

    }

/**********************TSRMS**********************************/


    if(CAN_Data.u8EventType == (uint8)TSRMS)
    {
       /*   CAN_Data.u8EventType   =  CAN_Data.u8EventLogData[0];
          TSRMS_Data.u8EventID   =  CAN_Data.u8EventLogData[1];



          TSRMS_Data.u8RecieveBuf[0] = CAN_Data.u8EventType;
          TSRMS_Data.u8RecieveBuf[1] = TSRMS_Data.u8EventID;
          TSRMS_Data.u8RecieveBuf[2] = (CAN_Data.u8dataPktbyteCnt + 7u);
          TSRMS_Data.u8RecieveBuf[3] = day;
          TSRMS_Data.u8RecieveBuf[4] = month;
          TSRMS_Data.u8RecieveBuf[5] = (uint8)(year >> 8u);
          TSRMS_Data.u8RecieveBuf[6] = (uint8)(year);
          TSRMS_Data.u8RecieveBuf[7] = hrs;
          TSRMS_Data.u8RecieveBuf[8] = min;
          TSRMS_Data.u8RecieveBuf[9] = sec;

          for( u8index = 1U; u8index < (CAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
          {
                for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
                {
                       TSRMS_Data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 10U)] = CAN_Data.u8EventLogData1[u8index][u8subindex];

                }
          }   */

        tsrms_pkt.TSRMS_log[0]=tsrms_pkt.u8Total_len;
        tsrms_pkt.TSRMS_log[1]=gps_pkt.hour;
        tsrms_pkt.TSRMS_log[2]=gps_pkt.minute;
        tsrms_pkt.TSRMS_log[3]=gps_pkt.seconds;
        tsrms_pkt.TSRMS_log[4]=gps_pkt.date;
        tsrms_pkt.TSRMS_log[5]=gps_pkt.month;
        tsrms_pkt.TSRMS_log[6]=gps_pkt.year_MSB;
        tsrms_pkt.TSRMS_log[7]=gps_pkt.year_LSB;

        memcpy(&tsrms_pkt.TSRMS_log[8],data,tsrms_pkt.u8Total_len);


        WriteTSRMSDatatoSDCard((uint8*)(tsrms_pkt.TSRMS_log[0]), 0u,(tsrms_pkt.u8Total_len + 8));

    }
    else{

    }

}


/*********************************************************************************************************************************
                                     Function to store radio data packets and RFID tags
 **********************************************************************************************************************************/

  void WriteSDCard(uint8* log_data,  uint8 logtype, uint16_t len, uint8 data_type)
  {

      uint8 i = 0u;

      if(sec < 60)
      {
          sec++;

      }
      else
      {
          sec = 0u;


          if(min < 60)
          {
              min++;
          }
          else
          {
              min = 0u;

              if(hrs < 23)
              {
                  hrs++;

              }
              else
              {
                  hrs = 0u;
                  day++;

                  if(day > 30u)
                  {
                      day = 1u;
                      month++;

                      if(month > 12u)
                      {
                          month = 1u;
                          year++;

                      }
                  }
              }
          }
      }

      rad_tag_buffer[0]  = gps_pkt.month;
      rad_tag_buffer[1]  = gps_pkt.date;
      rad_tag_buffer[2]  = gps_pkt.year_MSB;
      rad_tag_buffer[3]  = gps_pkt.year_LSB;
      rad_tag_buffer[4]  = gps_pkt.hour;
      rad_tag_buffer[5]  = gps_pkt.minute;
      rad_tag_buffer[6]  = gps_pkt.seconds;

      templogradioandtagbuffer[0] = 0x24u;
      templogradioandtagbuffer[1] = 0x31u;
      templogradioandtagbuffer[2] = 0x2Cu;
      templogradioandtagbuffer[3] = (uint8)data_type;
      templogradioandtagbuffer[4] = (uint8)logtype;
      len= (len + 7u);
      templogradioandtagbuffer[5] =(uint8_t) ((len & 0xFF00u)>>8u);
      templogradioandtagbuffer[6] = (uint8_t) ((len & 0xFFu)>>0u);



      if(logtype == (uint8)ARPKT)
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataAR.txt", arpkt_line_count, 0, templogradioandtagbuffer, 'W',(uint32) (len + 14u));
      }
      else if(logtype == (uint8)AGPKT)
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataAG.txt", agpkt_line_count, 0, templogradioandtagbuffer, 'W', (len + 14u));

      }
      else if(logtype == (uint8)LOCOREG)
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataLR.txt", locoreg_line_cnt, 0, templogradioandtagbuffer, 'W', (len + 14u));

      }
      else if(((logtype == NMTAG) ||(logtype == LCTAG) ||(logtype == ADJTAG) || (logtype == JUNTAG)))
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataTAG.txt", tag_dat_line_cnt, 0, templogradioandtagbuffer, 'W', (len + 14u));

      }
      else if(logtype == (uint8)STNREG)
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataSR.txt", stnreg_line_cnt, 0, templogradioandtagbuffer, 'W', (len + 14u));

      }
      else if(logtype == (uint8)AEPKT)
      {
          memcpy(&rad_tag_buffer[7],log_data,len);
          memcpy(&templogradioandtagbuffer[7],rad_tag_buffer,(len + 8u));
          SDCard_SeekPipe("/DataAE.txt", aepkt_line_count, 0, templogradioandtagbuffer, 'W', (len + 14u));

      }
      else
      {

      }

      for(i = 0u; i < 100u; i++)
      {
          rad_tag_buffer[i] = 0u;
          templogradioandtagbuffer[i] = 0u;
      }
  }




/********************************************************************************************************************************************************
                                                      FUNCTION TO SEND EVENT PACKET THROUGH CAN
 **********************************************************************************************************************************************************/

void send_pkt_to_log(uint8 event_type, uint8 event_id, uint16 data_pkt_length, uint8 * log_data)
{

    ucInfoMsgData[0] = event_type;                        /*event type*/
    ucInfoMsgData[1] = event_id;                          /*event ID*/

    if(data_pkt_length < 8U)
    {
        ucInfoMsgData[2] = 1U;
    }
    else if((data_pkt_length % 8U)  != 0U)                         /*CAN packet count*/
    {
        ucInfoMsgData[2] = (uint8)((data_pkt_length / 8U) + 1U );
    }
    else{
        ucInfoMsgData[2] = (uint8)(data_pkt_length / 8U);
    }

    ucInfoMsgData[3] = 0x00U;                                     /*current packet index*/
    ucInfoMsgData[4] = (uint8)data_pkt_length;                    /*Data packet length*/
    ucInfoMsgData[5] = 0U;
    ucInfoMsgData[6] = 0U;
    ucInfoMsgData[7] = 0U;


    uint16 i = 1U,j = 1U;

    for(i = 0U; i < ucInfoMsgData[2] ; i++ )
    {
        /*Updating current packet index*/
        ucInfoMsgData[3] = ucInfoMsgData[3] + 1U;


        ExtractEventdata(1U);

        for(j = 0U; j < 8U; j++)
        {
             if(((i * 8U) + j) < data_pkt_length)
             {

                 ucMsgData[j] = log_data[((i * 8U) + j)];
             }
             else
             {
             }

        }

        ExtractEventdata(2U);
        ucMsgData[0] = 0U; ucMsgData[1] = 0U; ucMsgData[2] = 0U; ucMsgData[4] = 0U; ucMsgData[5] = 0U; ucMsgData[6] = 0U; ucMsgData[7] = 0U;
    }

}




