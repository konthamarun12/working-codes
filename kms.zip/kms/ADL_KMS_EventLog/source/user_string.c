/*
 * user_string.c
 *
 *  Created on: Apr 23, 2024
 *      Author: HP
 */

#include "MAIN.h"

static uint8 num_arr[10] = {0U};

uint8 my_strcmp(const char *str1,const char *str2)
{
    uint8 i = 0;
    uint8 ans = 1U;
    while(str1[i] == str2[i]) {
        if((str1[i] == '\0') || (str2[i] == '\0')) {
            break;
        }
        i++;
    }
    if((str1[i] == '\0') && (str2[i] == '\0')) {
        ans = 0U;
    }
    else
    {

    }

    return ans;
}

uint32 my_strlen(const char* str3)                         /* finding string length function */
{

    uint32 length = 0U;

    while((str3[length]) != '\0')
    {
        length++;
    }
   return (uint32)length;
}

char*strstr3(const char *str, const char *substring)          /* search substring in main string */
{

    char * res = NULL;
    uint8 i = 0U, j = 0U, match = 0U, flag = 1U;

    while((str[i] != '\0') && (flag == 1U))
    {
        if(str[i] == substring[j])
        {
            while(str[j] != '\0' )
            {
                res = &str[i];
                match = i;
                if(str[i] == substring[j])
                {
                   i++;
                   j++;
                }else{}

                j++;
            }

            if(substring[j] == '\0' )
            {
                flag = 0U;
            }
            else{

                j = 0U;
                i = match;
                res = NULL;
                flag = 1U;

            }

        }else{}

        i++;
    }

    return res;

}



void my_sprintf(char * main_buf, const char* dec,const char *main_data)
{
    uint32 i = 0U, j =0U, k = 0U;

      while(dec[i] != '\0')
      {
          main_buf[k] = dec[i];

          if(dec[i] == '%')
          {
              if(dec[(i+ 1)] == 's')
              {
                  while(main_data[j] != '\0')
                  {
                     main_buf[k] = main_data[j];
                     k++;
                     j++;
                  }
              }

              i++;
              k--;
          }

          i++;
          k++;
      }

      main_buf[k] = '\0';
}


void my_sprintf1s(char * main_buf, const char* dec)
{

   uint32 i = 0U, k = 0U;

    while(dec[i] != '\0')
    {
        main_buf[k] = dec[i];
        i++;
        k++;
    }

}


void my_sprintfint(char * main_buf, const char* dec, uint32 lcnt, uint32 lcnT)
{
    uint32 i = 0U, j =0U, k = 0U;

    uint32 dig_count = 0U;

    while(dec[i] != '\0')
    {

        if(dec[i] == '%')
        {
            i++;

            if(((dec[i] == 'u') || (dec[i] == 'd')))
            {

                dig_count = numtoascii(lcnt);
                dig_count = numtoascii(lcnT);

                /*loading the ASCII NUM array of the LCNT*/

                for(j = 0U; j < dig_count; j++)
                {
                    main_buf[k] = (char)num_arr[j];
                    k++;
                }

            }else{}

        }else{}

        main_buf[k] = dec[i];

        i++;
        k++;

    }
}


uint32 numtoascii(uint32  num)
{
    uint32 i = 1U;

    uint32 number = 0U;


    number = num;

    uint32 rem = 0U;
    uint32 divi = 0U;

    uint32 dig_count = 0U;

    /*For numbers above or equal to 10 million*/

    if(number > 9999999U)
    {
        divi = 10000000U;

        for(i = 0U; i < 8U; i++)
        {


            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;


        }


        dig_count = 8U;

    }



    /*For numbers above or equal to one million */

    else if(number > 999999U)
    {
        divi = 1000000U;

        for(i = 0U; i < 7U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 7U;

    }

    /*For numbers above or equal to ten lakhs */
    else if(number > 99999U)
    {
        divi = 100000U;

        for(i = 0U; i < 6U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 6U;

    }

    /*For numbers above or equal to ten thousand */

    else if(number > 9999U)
    {
        divi = 10000U;

        for(i = 0U; i < 5U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 5U;

    }

    /*For numbers above or equal to  thousand */

    else if(number > 999U)
    {
        divi = 1000U;

        for(i = 0U; i < 4U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 4U;

    }

    /*For numbers above or equal to one hundred */

    else if(number > 99U)
    {
        divi = 100U;

        for(i = 0U; i < 3U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 3U;

    }

    /*For numbers above or equal to ten */

    else if(number > 9U)
    {
        divi = 10U;

        for(i = 0U; i < 2U; i++)
        {

            rem = number / divi;

            num_arr[i] = (uint8)rem + 0x30U;

            number = number % divi;

            divi = divi / 10U;

        }


        dig_count = 2U;

    }
    else
    {
        num_arr[i] = (uint8)number + 0x30U;

        dig_count = 1U;
    }


    return dig_count ;

}




