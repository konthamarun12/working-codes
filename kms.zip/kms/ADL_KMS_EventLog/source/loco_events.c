/*
 * loco_events.c
 *
 *  Created on: Aug 26, 2024
 *      Author: UDAY KIRAN GEMBALI
 *
 *
 */

#include "MAIN.h"

uint8  loc_day = 25u;
uint8  loc_mon = 11u;
uint16 loc_yr  = 2024u;
uint8  loc_hrs = 0u;
uint8  loc_min = 0u;
uint8  loc_sec = 0u;

uint8 loco_evnt_buf[200] = {0u};    /*Buffer to form event data packets for loco*/

uint8 Log_CAN_info_buf[8] = {0};
uint8 Log_CAN_data_buf[8] = {0};

uint8 u8message_Box6[8] = {0};

void can_msg_send(uint8 u8CANMsg_ID);


loco_live_data_t loco_live_dat;               /*LOCO live data*/
loco_trig_maint_data_t loco_trg_maint_dat;    /*LOCO triggered maintenance data*/

/******************************************************************************************************************
                                Triggered events for loco
 ********************************************************************************************************************/

updt_mov_auth_t updt_mov_auth;                                  /*Updation of movement authority*/
loco_brk_appl_t loco_brk_applied;                               /*Brake application event*/
change_of_brk_appli_t change_of_brk_application;                /*Chage in brake application*/
rmvl_of_brk_appli_t rmvl_of_brk_application;                    /*Removal of brake APPLICATION*/
mode_trans_of_kvch_t mode_trans_of_kavach;                      /*Mode transisition of kavach*/
acknmnt_by_LP_t acknmnt_by_LPilot;                              /*Acknowledgement by loco pilot*/
SPAD_t signal_passed_at_danger;                                 /*signal passed at danger*/
chang_in_TIN_t chang_in_TINumber;                               /*Change in TIN number*/
one_RFID_tg_msng_out_of_two_t one_RFID_tg_msng_out_of_two_tags; /*One of two RFID tags missing*/
both_rfid_tags_msng_t both_rfid_tags_missing;                   /*Both RFID tags missing*/
data_mismatch_btw_mn_dup_tag_t data_mismatch_btw_mn_nd_dup_tag; /*data mismatch between main and duplicate tag*/
change_in_aspct_t change_in_sig_aspect;                         /*Change in signal aspect*/
passing_of_signal_t passing_of_signall;                         /*Passing of signal*/
tx_of_emer_msg_t tx_of_emer_message;                            /*Transmission of emergency messages*/
Rx_of_emer_msg_t Rx_of_emer_message;                            /*reception of emergency messages*/
entry_into_new_stsn_t entry_into_new_station;                   /*Entry into new station area*/
freq_chan_allocation_t freq_channel_allocation;                 /*New frequency channel allocation*/

/******************************************************************************************************************
                                        Critical events of loco
********************************************************************************************************************/
auth_key_details_t authen_key_details;                          /*Authentication key details*/
TLM_meas_t TLM_measure;                                         /*Train length measurement*/
trn_cfg_chng_t trn_cfg_change;                                  /*Train configuration change event*/
boot_up_seq_err_t boot_up_seq_error;                            /*Boot up sequence error*/
cab_select_evnt_t cab_select_event;                             /*cab selection event*/
brk_appli_evnt_t brk_appli_event;                               /*Brake application event*/
collision_dtctn_t collision_detctn;                             /*Collision detection*/
loco_manual_SOS_t loco_manual_SOS_evnt;                         /*LOCO manual SOS*/
radhlt_t rad1hlt;                                               /*radio 1 health*/
radhlt_t rad2hlt;                                               /*radio 2 health*/
GSM_hlt_t GSM_health;                                           /*GSM health*/
GPS_hlt_t GPS1_hlt;                                             /*GPS1 health*/
GPS_hlt_t GPS2_hlt;                                             /*GPS2 health*/
intrfc_crds_hlt_t intrfc_crds1_hlt;                             /*Interface cards health*/
intrfc_crds_hlt_t intrfc_crds2_hlt;                             /*Interface cards health*/
EB_cnctn_stat_t EB_cnctn_stat_evnt;                             /*EB connection status event*/
kvch_cnctn_evnt_t kvch_cnctn_event;                             /*kavach connection event*/
kvch_ter_ext_ent_t kvch_ter_ext_entry;                          /*kavach territory entry or exit event*/
ETCS_exit_or_entry_t ETCS_exit_or_entry_evnt;                   /*ETCS entry or exit event*/
trn_trip_mode_entry_t trn_trip_mode_entry_evnt;                 /*Train trip mode entry event*/
ovrd_slctd_t ovrd_selected;                                     /*Over ride mode selected*/
trnout_evnt_t trnout_event;                                     /*Turnout entry event*/
TSR_event_t TSR_evnt;                                           /*TSR entry event*/
PSR_event_t PSR_evnt;                                           /*PSR entry event*/
end_of_auth_t end_of_authority;                                 /*End of authority*/
brk_test_stat_t brk_test_status;                                /*Brake test status*/
appr_rad_hole_t appr_radio_hole;                                /*Approaching radio hole*/
entry_into_post_trp_t entry_into_post_trip;                     /*Entry into post trip mode*/
entry_of_loco_into_diff_zone_t entry_of_loco_into_differ_zone;  /*Entry of loco into into differenet zone*/
grad_prof_t grad_profile;                                       /*Gradient profile packet*/
static_spd_prof_t static_spd_profile;                           /*static speed profile entry event*/

void update_loco_time_date(void)
{

    if(loc_sec < 60u)
    {
        loc_sec++;
    }
    else
    {
        loc_sec = 0u;


        if(loc_min < 60u)
        {
            loc_min++;
        }
        else
        {
            loc_min = 0u;

            if(loc_hrs < 24u)
            {
                loc_hrs++;
            }
            else
            {
                loc_hrs = 0u;

                if(loc_day < 31)
                {
                    loc_day++;
                }
                else
                {
                    loc_day = 1u;

                    if(loc_mon < 13u)
                    {
                        loc_mon++;
                    }
                    else
                    {
                        loc_mon = 1u;
                        loc_yr++;
                    }
                }
            }
        }
    }

}




/******************************************************************************************************************
                                      Function to build loco live data
********************************************************************************************************************/
void build_loco_live_data(void)
{

    uint8 i = 1u;

    update_loco_time_date();

    loco_live_dat.u8day   = loc_day;
    loco_live_dat.u8month = loc_mon;
    loco_live_dat.u16year = loc_yr;
    loco_live_dat.u8hrs   = loc_hrs;
    loco_live_dat.u8min   = loc_min;
    loco_live_dat.u8secs  = loc_sec;
    loco_live_dat.u24absloc = 12345u;
    loco_live_dat.u24loc_ID = 12345u;
    loco_live_dat.u8speed  = 28u;
    loco_live_dat.u8trndir = 1u;
    loco_live_dat.u24lastRFIDloc = 12345u;
    loco_live_dat.u16TIN = 255u;
    loco_live_dat.u8type_of_brk = 1u;
    loco_live_dat.u8speed_sen1_fault = 1u;
    loco_live_dat.u8GPS1view_not_avail_since_2hrs = 1u;
    loco_live_dat.u8GPS2view_not_avail_since_2hrs = 1u;
    loco_live_dat.u8GSM1fault = 1u;
    loco_live_dat.u8GSM2fault = 1u;
    loco_live_dat.u8Radio1_RSSI_weak = 1u;
    loco_live_dat.u8Radio2_RSSI_weak = 1u;
    loco_live_dat.u8LPOCIP1_fault = 1u;
    loco_live_dat.u8LPOCIP2_fault = 1u;
    loco_live_dat.u8RFIDrdr1fault = 1u;
    loco_live_dat.u8RFIDrdr2fault = 1u;
    loco_live_dat.u8Ssn_key_mismatch = 1u;
    loco_live_dat.u8BIU_cnctvty_fault = 1u;
    loco_live_dat.u8speedsensor2fault = 1u;
    loco_live_dat.u8CAB_input_fault = 1u;


    loco_evnt_buf[0] = loco_live_dat.u8day;
    loco_evnt_buf[1] = loco_live_dat.u8month;
    loco_evnt_buf[2] = (uint8)(loco_live_dat.u16year >> 8u);
    loco_evnt_buf[3] = (uint8)(loco_live_dat.u16year >> 0u);
    loco_evnt_buf[4] = loco_live_dat.u8hrs;
    loco_evnt_buf[5] = loco_live_dat.u8min;
    loco_evnt_buf[6] = loco_live_dat.u8secs;
    loco_evnt_buf[7] = (uint8)(loco_live_dat.u24absloc >> 16u);
    loco_evnt_buf[8] = (uint8)(loco_live_dat.u24absloc >> 8u);
    loco_evnt_buf[9] = (uint8)(loco_live_dat.u24absloc >> 0u);
    loco_evnt_buf[10]= (uint8)(loco_live_dat.u24loc_ID >> 16u);
    loco_evnt_buf[11]= (uint8)(loco_live_dat.u24loc_ID >> 8u);
    loco_evnt_buf[12]= (uint8)(loco_live_dat.u24loc_ID >> 0u);
    loco_evnt_buf[13]= loco_live_dat.u8speed;
    loco_evnt_buf[14]= loco_live_dat.u8trndir;
    loco_evnt_buf[15]= (uint8)(loco_live_dat.u24lastRFIDloc >> 16u);
    loco_evnt_buf[16]= (uint8)(loco_live_dat.u24lastRFIDloc >> 8u);
    loco_evnt_buf[17]= (uint8)(loco_live_dat.u24lastRFIDloc >> 0u);
    loco_evnt_buf[18]= (uint8)(loco_live_dat.u16TIN >> 8u);
    loco_evnt_buf[19]= (uint8)(loco_live_dat.u16TIN >> 0u);
    loco_evnt_buf[20]= loco_live_dat.u8type_of_brk;
    loco_evnt_buf[21]= loco_live_dat.u8speed_sen1_fault;
    loco_evnt_buf[22]= loco_live_dat.u8GPS1view_not_avail_since_2hrs;
    loco_evnt_buf[23]= loco_live_dat.u8GPS2view_not_avail_since_2hrs;
    loco_evnt_buf[24]= loco_live_dat.u8GSM1fault;
    loco_evnt_buf[25]= loco_live_dat.u8GSM2fault;
    loco_evnt_buf[26]= loco_live_dat.u8Radio1_RSSI_weak;
    loco_evnt_buf[27]= loco_live_dat.u8Radio2_RSSI_weak;
    loco_evnt_buf[28]= loco_live_dat.u8LPOCIP1_fault;
    loco_evnt_buf[29]= loco_live_dat.u8LPOCIP2_fault;
    loco_evnt_buf[30]= loco_live_dat.u8RFIDrdr1fault;
    loco_evnt_buf[31]= loco_live_dat.u8RFIDrdr2fault;
    loco_evnt_buf[32]= loco_live_dat.u8Ssn_key_mismatch;
    loco_evnt_buf[33]= loco_live_dat.u8BIU_cnctvty_fault;
    loco_evnt_buf[34]= loco_live_dat.u8speedsensor2fault;
    loco_evnt_buf[35]= loco_live_dat.u8CAB_input_fault;

   /* send_loco_evnt_pkt_to_log(uint8 event_type, uint8 event_id, uint16 data_pkt_length, uint8 * log_data) */

    Log_CAN_data_buf[0] = LOCO_LIVE_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 5u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 36u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_LIVE_DATA;                      /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 5u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 36u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = loco_evnt_buf[13];
    Log_CAN_data_buf[6] = loco_evnt_buf[14];
    Log_CAN_data_buf[7] = loco_evnt_buf[15];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_LIVE_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 5u;
    Log_CAN_data_buf[3] = 3u;
    Log_CAN_data_buf[4] = 36u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[16];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[17];
    Log_CAN_data_buf[2] = loco_evnt_buf[18];
    Log_CAN_data_buf[3] = loco_evnt_buf[19];
    Log_CAN_data_buf[4] = loco_evnt_buf[20];
    Log_CAN_data_buf[5] = loco_evnt_buf[21];
    Log_CAN_data_buf[6] = loco_evnt_buf[22];
    Log_CAN_data_buf[7] = loco_evnt_buf[23];
    can_msg_send(2u);
    wait(1000u);


    Log_CAN_data_buf[0] = LOCO_LIVE_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 5u;
    Log_CAN_data_buf[3] = 4u;
    Log_CAN_data_buf[4] = 36u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[24];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[25];
    Log_CAN_data_buf[2] = loco_evnt_buf[26];
    Log_CAN_data_buf[3] = loco_evnt_buf[27];
    Log_CAN_data_buf[4] = loco_evnt_buf[28];
    Log_CAN_data_buf[5] = loco_evnt_buf[29];
    Log_CAN_data_buf[6] = loco_evnt_buf[30];
    Log_CAN_data_buf[7] = loco_evnt_buf[31];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_LIVE_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 5u;
    Log_CAN_data_buf[3] = 5u;
    Log_CAN_data_buf[4] = 36u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[32];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[33];
    Log_CAN_data_buf[2] = loco_evnt_buf[34];
    Log_CAN_data_buf[3] = loco_evnt_buf[35];
    Log_CAN_data_buf[4] = loco_evnt_buf[36];
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_LIVE_DATA, 1u, 36u, loco_evnt_buf );

    for(i = 0u; i < 36u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/******************************************************************************************************************
                                      Function to build loco live data
********************************************************************************************************************/
void build_loco_trig_maint_data(void)
{
   /* loco_trig_maint_data_t loco_trg_maint_dat;*/

    uint8 i = 1u;

    update_loco_time_date();

    loco_trg_maint_dat.u8day   = loc_day;
    loco_trg_maint_dat.u8month = loc_mon;
    loco_trg_maint_dat.u16year = loc_yr;
    loco_trg_maint_dat.u8hrs   = loc_hrs;
    loco_trg_maint_dat.u8min   = loc_min;
    loco_trg_maint_dat.u8secs  = loc_sec;
    loco_trg_maint_dat.u24absloc = 12345u;
    loco_trg_maint_dat.u8rad1active = 1u;
    loco_trg_maint_dat.u8rad2active = 1u;
    loco_trg_maint_dat.u8rad1health = 1u;
    loco_trg_maint_dat.u8rad2health = 1u;
    loco_trg_maint_dat.u8rad1inputsupply = 1u;
    loco_trg_maint_dat.u8rad2inputsupply = 20u;
    loco_trg_maint_dat.u8rad1temp = 20u;
    loco_trg_maint_dat.u8rad2temp = 20u;
    loco_trg_maint_dat.u8rad1PAtemp = 25u;
    loco_trg_maint_dat.u8rad2PAtemp = 25u;
    loco_trg_maint_dat.u8rad1PAsupply = 30u;
    loco_trg_maint_dat.u8rad2PAsupply = 30u;
    loco_trg_maint_dat.u8rad1_tx_PA_current = 1u;
    loco_trg_maint_dat.u8rad2_tx_PA_current = 1u;
    loco_trg_maint_dat.u16rad1RSSI = 35u;
    loco_trg_maint_dat.u16rad2RSSI = 35u;
    loco_trg_maint_dat.u8rad1Revpwr = 27u;
    loco_trg_maint_dat.u8rad2Revpwr = 27u;
    loco_trg_maint_dat.u8rad1Fwdpwr = 28u;
    loco_trg_maint_dat.u8rad2Fwdpwr = 28u;
    loco_trg_maint_dat.u8GPS1status = 1u;
    loco_trg_maint_dat.u8GPS2status = 1u;
    loco_trg_maint_dat.u8GPS1secs = 23u;
    loco_trg_maint_dat.u8GPS2secs = 23u;
    loco_trg_maint_dat.u8GSM1rssi = 24u;
    loco_trg_maint_dat.u8GSM2rssi = 24u;
    loco_trg_maint_dat.u8LPOCIP1stat = 1u;
    loco_trg_maint_dat.u8LPOCIP2stat = 1u;
    loco_trg_maint_dat.u8RFIDrdr1stat = 1u;
    loco_trg_maint_dat.u8RFIDrdr2stat = 1u;
    loco_trg_maint_dat.u16dup_missing_RFID_tag = 1u;
    loco_trg_maint_dat.u8biuconnectivity = 1u;
    loco_trg_maint_dat.u8rstrt_of_kavach = 1u;
    loco_trg_maint_dat.u8MBT = 1u;
    loco_trg_maint_dat.u8readalltags = 2u;
    loco_trg_maint_dat.u8mode_transition = 1u;
    loco_trg_maint_dat.u8present_mode = 1u;
    loco_trg_maint_dat.u16TLM = 258u;


    loco_evnt_buf[0]  = loco_trg_maint_dat.u8day;
    loco_evnt_buf[1]  = loco_trg_maint_dat.u8month;
    loco_evnt_buf[2]  = (uint8)(loco_trg_maint_dat.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(loco_trg_maint_dat.u16year >> 0u);
    loco_evnt_buf[4]  = loco_trg_maint_dat.u8hrs;
    loco_evnt_buf[5]  = loco_trg_maint_dat.u8min;
    loco_evnt_buf[6]  = loco_trg_maint_dat.u8secs;
    loco_evnt_buf[7]  = (uint8)(loco_trg_maint_dat.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(loco_trg_maint_dat.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(loco_trg_maint_dat.u24absloc >> 0u);
    loco_evnt_buf[10] = loco_trg_maint_dat.u8rad1active ;
    loco_evnt_buf[11] = loco_trg_maint_dat.u8rad2active ;
    loco_evnt_buf[12] = loco_trg_maint_dat.u8rad1health;
    loco_evnt_buf[13] = loco_trg_maint_dat.u8rad2health;
    loco_evnt_buf[14] = loco_trg_maint_dat.u8rad1inputsupply;
    loco_evnt_buf[15] = loco_trg_maint_dat.u8rad2inputsupply;
    loco_evnt_buf[16] = loco_trg_maint_dat.u8rad1temp;
    loco_evnt_buf[17] = loco_trg_maint_dat.u8rad2temp;
    loco_evnt_buf[18] = loco_trg_maint_dat.u8rad1PAtemp;
    loco_evnt_buf[19] = loco_trg_maint_dat.u8rad2PAtemp;
    loco_evnt_buf[20] = loco_trg_maint_dat.u8rad1PAsupply;
    loco_evnt_buf[21] = loco_trg_maint_dat.u8rad2PAsupply;
    loco_evnt_buf[22] = loco_trg_maint_dat.u8rad1_tx_PA_current;
    loco_evnt_buf[23] =  loco_trg_maint_dat.u8rad2_tx_PA_current;
    loco_evnt_buf[24] = (uint8)(loco_trg_maint_dat.u16rad1RSSI >> 8u);
    loco_evnt_buf[25] = (uint8)(loco_trg_maint_dat.u16rad1RSSI >> 0u);
    loco_evnt_buf[26] = (uint8)(loco_trg_maint_dat.u16rad2RSSI >> 8u);
    loco_evnt_buf[27] = (uint8)(loco_trg_maint_dat.u16rad2RSSI >> 0u);
    loco_evnt_buf[28] = loco_trg_maint_dat.u8rad1Revpwr;
    loco_evnt_buf[29] = loco_trg_maint_dat.u8rad2Revpwr;
    loco_evnt_buf[30] = loco_trg_maint_dat.u8rad1Fwdpwr;
    loco_evnt_buf[31] = loco_trg_maint_dat.u8rad2Fwdpwr;
    loco_evnt_buf[32] = loco_trg_maint_dat.u8GPS1status;
    loco_evnt_buf[33] = loco_trg_maint_dat.u8GPS2status;
    loco_evnt_buf[34] = loco_trg_maint_dat.u8GPS1secs;
    loco_evnt_buf[35] = loco_trg_maint_dat.u8GPS2secs;
    loco_evnt_buf[36] = loco_trg_maint_dat.u8GSM1rssi;
    loco_evnt_buf[37] = loco_trg_maint_dat.u8GSM2rssi;
    loco_evnt_buf[38] = loco_trg_maint_dat.u8LPOCIP1stat;
    loco_evnt_buf[39] = loco_trg_maint_dat.u8LPOCIP2stat;
    loco_evnt_buf[40] = loco_trg_maint_dat.u8RFIDrdr1stat;
    loco_evnt_buf[41] = loco_trg_maint_dat.u8RFIDrdr2stat;
    loco_evnt_buf[42] = (uint8)(loco_trg_maint_dat.u16dup_missing_RFID_tag >> 8u);
    loco_evnt_buf[43] = (uint8)(loco_trg_maint_dat.u16dup_missing_RFID_tag >> 0u);
    loco_evnt_buf[44] = loco_trg_maint_dat.u8biuconnectivity;
    loco_evnt_buf[45] = loco_trg_maint_dat.u8rstrt_of_kavach;
    loco_evnt_buf[46] = loco_trg_maint_dat.u8MBT;
    loco_evnt_buf[47] = loco_trg_maint_dat.u8readalltags;
    loco_evnt_buf[48] = loco_trg_maint_dat.u8mode_transition;
    loco_evnt_buf[49] = loco_trg_maint_dat.u8present_mode;
    loco_evnt_buf[50] = (uint8)(loco_trg_maint_dat.u16TLM >> 8u);
    loco_evnt_buf[51] = (uint8)(loco_trg_maint_dat.u16TLM >> 0u);


    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = loco_evnt_buf[13];
    Log_CAN_data_buf[6] = loco_evnt_buf[14];
    Log_CAN_data_buf[7] = loco_evnt_buf[15];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 3u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[16];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[17];
    Log_CAN_data_buf[2] = loco_evnt_buf[18];
    Log_CAN_data_buf[3] = loco_evnt_buf[19];
    Log_CAN_data_buf[4] = loco_evnt_buf[20];
    Log_CAN_data_buf[5] = loco_evnt_buf[21];
    Log_CAN_data_buf[6] = loco_evnt_buf[22];
    Log_CAN_data_buf[7] = loco_evnt_buf[23];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 4u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[24];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[25];
    Log_CAN_data_buf[2] = loco_evnt_buf[26];
    Log_CAN_data_buf[3] = loco_evnt_buf[27];
    Log_CAN_data_buf[4] = loco_evnt_buf[28];
    Log_CAN_data_buf[5] = loco_evnt_buf[29];
    Log_CAN_data_buf[6] = loco_evnt_buf[30];
    Log_CAN_data_buf[7] = loco_evnt_buf[31];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 5u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[32];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[33];
    Log_CAN_data_buf[2] = loco_evnt_buf[34];
    Log_CAN_data_buf[3] = loco_evnt_buf[35];
    Log_CAN_data_buf[4] = loco_evnt_buf[36];
    Log_CAN_data_buf[5] = loco_evnt_buf[37];
    Log_CAN_data_buf[6] = loco_evnt_buf[38];
    Log_CAN_data_buf[7] = loco_evnt_buf[39];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 6u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[40];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[41];
    Log_CAN_data_buf[2] = loco_evnt_buf[42];
    Log_CAN_data_buf[3] = loco_evnt_buf[43];
    Log_CAN_data_buf[4] = loco_evnt_buf[44];
    Log_CAN_data_buf[5] = loco_evnt_buf[45];
    Log_CAN_data_buf[6] = loco_evnt_buf[46];
    Log_CAN_data_buf[7] = loco_evnt_buf[47];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_MAINT_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 7u;
    Log_CAN_data_buf[3] = 7u;
    Log_CAN_data_buf[4] = 52u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[48];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[49];
    Log_CAN_data_buf[2] = loco_evnt_buf[50];
    Log_CAN_data_buf[3] = loco_evnt_buf[51];
    Log_CAN_data_buf[4] = loco_evnt_buf[52];
    Log_CAN_data_buf[5] = loco_evnt_buf[53];
    Log_CAN_data_buf[6] = loco_evnt_buf[54];
    Log_CAN_data_buf[7] = loco_evnt_buf[55];
    can_msg_send(2u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_MAINT_DATA, 1u, 51u, loco_evnt_buf );

    for(i = 0u; i < 52u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                            LOCO TRIGGERED  DATA
                                 Update of movement authority (Sub message ID 1)
*****************************************************************************************************************/

void build_updt_mov_auth(void)
{
    uint8 i = 1u;

    update_loco_time_date();

    updt_mov_auth.u8day   = loc_day;
    updt_mov_auth.u8month = loc_mon;
    updt_mov_auth.u16year = loc_yr;
    updt_mov_auth.u8hrs   = loc_hrs;
    updt_mov_auth.u8min   = loc_min;
    updt_mov_auth.u8secs  = loc_sec;
    updt_mov_auth.u24absloc = 12345u;
    updt_mov_auth.u8authority_type = 2U;
    updt_mov_auth.u8authorized_spd = 29U;
    updt_mov_auth.u16newMA = 1234U;

    loco_evnt_buf[0]  = updt_mov_auth.u8day;
    loco_evnt_buf[1]  = updt_mov_auth.u8month;
    loco_evnt_buf[2]  = (uint8)(updt_mov_auth.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(updt_mov_auth.u16year >> 0u);
    loco_evnt_buf[4]  = updt_mov_auth.u8hrs;
    loco_evnt_buf[5]  = updt_mov_auth.u8min;
    loco_evnt_buf[6]  = updt_mov_auth.u8secs;
    loco_evnt_buf[7]  = (uint8)(updt_mov_auth.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(updt_mov_auth.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(updt_mov_auth.u24absloc >> 0u);
    loco_evnt_buf[10] = updt_mov_auth.u8authority_type;
    loco_evnt_buf[11] = updt_mov_auth.u8authorized_spd;
    loco_evnt_buf[12] = (uint8)(updt_mov_auth.u16newMA >> 8u);
    loco_evnt_buf[13] = (uint8)(updt_mov_auth.u16newMA >> 0u);


    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 14u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 14u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = loco_evnt_buf[13];
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 1u, 14u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                 Brake application (Sub message ID 2)
 *****************************************************************************************************************/
void build_loco_brk_applied(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    loco_brk_applied.u8day   = loc_day;
    loco_brk_applied.u8month = loc_mon;
    loco_brk_applied.u16year = loc_yr;
    loco_brk_applied.u8hrs   = loc_hrs;
    loco_brk_applied.u8min   = loc_min;
    loco_brk_applied.u8secs  = loc_sec;
    loco_brk_applied.u24absloc = 12345u;
    loco_brk_applied.u8prsnt_spd = 25u;
    loco_brk_applied.u8applied_rsn = 2u;
    loco_brk_applied.u8brk_type_applied = 1u;

    loco_evnt_buf[0]  = loco_brk_applied.u8day;
    loco_evnt_buf[1]  = loco_brk_applied.u8month;
    loco_evnt_buf[2]  = (uint8)(loco_brk_applied.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(loco_brk_applied.u16year >> 0u);
    loco_evnt_buf[4]  = loco_brk_applied.u8hrs;
    loco_evnt_buf[5]  = loco_brk_applied.u8min;
    loco_evnt_buf[6]  = loco_brk_applied.u8secs;
    loco_evnt_buf[7]  = (uint8)(loco_brk_applied.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(loco_brk_applied.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(loco_brk_applied.u24absloc >> 0u);
    loco_evnt_buf[10] = loco_brk_applied.u8prsnt_spd;
    loco_evnt_buf[11] = loco_brk_applied.u8applied_rsn;
    loco_evnt_buf[12] = loco_brk_applied.u8brk_type_applied;

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 13u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 13u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 2u, 13u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                             change of Brake application (Sub message ID 3)
 *****************************************************************************************************************/
void build_change_of_brk_application_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    change_of_brk_application.u8day   = loc_day;
    change_of_brk_application.u8month = loc_mon;
    change_of_brk_application.u16year = loc_yr;
    change_of_brk_application.u8hrs   = loc_hrs;
    change_of_brk_application.u8min   = loc_min;
    change_of_brk_application.u8secs  = loc_sec;
    change_of_brk_application.u24absloc = 12345u;
    change_of_brk_application.u8new_brk_applied = 1u;
    change_of_brk_application.u8prev_brk_applied = 2u;

    loco_evnt_buf[0]  = change_of_brk_application.u8day;
    loco_evnt_buf[1]  = change_of_brk_application.u8month;
    loco_evnt_buf[2]  = (uint8)(change_of_brk_application.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(change_of_brk_application.u16year >> 0u);
    loco_evnt_buf[4]  = change_of_brk_application.u8hrs;
    loco_evnt_buf[5]  = change_of_brk_application.u8min;
    loco_evnt_buf[6]  = change_of_brk_application.u8secs;
    loco_evnt_buf[7]  = (uint8)(change_of_brk_application.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(change_of_brk_application.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(change_of_brk_application.u24absloc >> 0u);
    loco_evnt_buf[10] = change_of_brk_application.u8new_brk_applied;
    loco_evnt_buf[11] = change_of_brk_application.u8prev_brk_applied;

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = 0u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 3u, 12u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                             removal of Brake application (Sub message ID 4)
 *****************************************************************************************************************/
void build_rmvl_of_brk_application_packet(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    rmvl_of_brk_application.u8day   = loc_day;
    rmvl_of_brk_application.u8month = loc_mon;
    rmvl_of_brk_application.u16year = loc_yr;
    rmvl_of_brk_application.u8hrs   = loc_hrs;
    rmvl_of_brk_application.u8min   = loc_min;
    rmvl_of_brk_application.u8secs  = loc_sec;
    rmvl_of_brk_application.u24absloc = 12345u;
    rmvl_of_brk_application.u8type_of_brake_releived = 1u;

    loco_evnt_buf[0]  = rmvl_of_brk_application.u8day;
    loco_evnt_buf[1]  = rmvl_of_brk_application.u8month;
    loco_evnt_buf[2]  = (uint8)(rmvl_of_brk_application.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(rmvl_of_brk_application.u16year >> 0u);
    loco_evnt_buf[4]  = rmvl_of_brk_application.u8hrs;
    loco_evnt_buf[5]  = rmvl_of_brk_application.u8min;
    loco_evnt_buf[6]  = rmvl_of_brk_application.u8secs;
    loco_evnt_buf[7]  = (uint8)(rmvl_of_brk_application.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(rmvl_of_brk_application.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(rmvl_of_brk_application.u24absloc >> 0u);
    loco_evnt_buf[10] = rmvl_of_brk_application.u8type_of_brake_releived;

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = 1u;
        Log_CAN_data_buf[2] = 2u;
        Log_CAN_data_buf[3] = 1u;
        Log_CAN_data_buf[4] = 11u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(1u);
        wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[1];
        Log_CAN_data_buf[2] = loco_evnt_buf[2];
        Log_CAN_data_buf[3] = loco_evnt_buf[3];
        Log_CAN_data_buf[4] = loco_evnt_buf[4];
        Log_CAN_data_buf[5] = loco_evnt_buf[5];
        Log_CAN_data_buf[6] = loco_evnt_buf[6];
        Log_CAN_data_buf[7] = loco_evnt_buf[7];
        can_msg_send(2u);
        wait(1000u);

        Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = 1u;
        Log_CAN_data_buf[2] = 2u;
        Log_CAN_data_buf[3] = 2u;
        Log_CAN_data_buf[4] = 11u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(1u);
        wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[9];
        Log_CAN_data_buf[2] = loco_evnt_buf[10];
        Log_CAN_data_buf[3] = 0u;
        Log_CAN_data_buf[4] = 0u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(2u);
        wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 4u, 11u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                             Mode transition of kavach (Sub message ID 5)
 *****************************************************************************************************************/
void build_mode_trans_of_kavach_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/


    mode_trans_of_kavach.u8day   = loc_day;
    mode_trans_of_kavach.u8month = loc_mon;
    mode_trans_of_kavach.u16year = loc_yr;
    mode_trans_of_kavach.u8hrs   = loc_hrs;
    mode_trans_of_kavach.u8min   = loc_min;
    mode_trans_of_kavach.u8secs  = loc_sec;
    mode_trans_of_kavach.u24absloc = 12345u;
    mode_trans_of_kavach.u8prev_mode = 1u;
    mode_trans_of_kavach.u8prsnt_mode = 2u;

    loco_evnt_buf[0]  = mode_trans_of_kavach.u8day;
    loco_evnt_buf[1]  = mode_trans_of_kavach.u8month;
    loco_evnt_buf[2]  = (uint8)(mode_trans_of_kavach.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(mode_trans_of_kavach.u16year >> 0u);
    loco_evnt_buf[4]  = mode_trans_of_kavach.u8hrs;
    loco_evnt_buf[5]  = mode_trans_of_kavach.u8min;
    loco_evnt_buf[6]  = mode_trans_of_kavach.u8secs;
    loco_evnt_buf[7]  = (uint8)(mode_trans_of_kavach.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(mode_trans_of_kavach.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(mode_trans_of_kavach.u24absloc >> 0u);
    loco_evnt_buf[10] = mode_trans_of_kavach.u8prev_mode;
    loco_evnt_buf[11] = mode_trans_of_kavach.u8prsnt_mode;

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[1];
        Log_CAN_data_buf[2] = loco_evnt_buf[2];
        Log_CAN_data_buf[3] = loco_evnt_buf[3];
        Log_CAN_data_buf[4] = loco_evnt_buf[4];
        Log_CAN_data_buf[5] = loco_evnt_buf[5];
        Log_CAN_data_buf[6] = loco_evnt_buf[6];
        Log_CAN_data_buf[7] = loco_evnt_buf[7];
        can_msg_send(2u);
        wait(1000u);

        Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = 1u;
        Log_CAN_data_buf[2] = 2u;
        Log_CAN_data_buf[3] = 2u;
        Log_CAN_data_buf[4] = 12u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(1u);
        wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[9];
        Log_CAN_data_buf[2] = loco_evnt_buf[10];
        Log_CAN_data_buf[3] = loco_evnt_buf[11];
        Log_CAN_data_buf[4] = 0u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(2u);
        wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 5u, 12u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                             Mode transition of kavach (Sub message ID 6)
 *****************************************************************************************************************/
void build_acknmnt_by_LPilot_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/


    acknmnt_by_LPilot.u8day   = loc_day;
    acknmnt_by_LPilot.u8month = loc_mon;
    acknmnt_by_LPilot.u16year = loc_yr;
    acknmnt_by_LPilot.u8hrs   = loc_hrs;
    acknmnt_by_LPilot.u8min   = loc_min;
    acknmnt_by_LPilot.u8secs  = loc_sec;
    acknmnt_by_LPilot.u24absloc = 12345u;
    acknmnt_by_LPilot.u8ackRsn = 1u;

    loco_evnt_buf[0]  = acknmnt_by_LPilot.u8day;
    loco_evnt_buf[1]  = acknmnt_by_LPilot.u8month;
    loco_evnt_buf[2]  = (uint8)(acknmnt_by_LPilot.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(acknmnt_by_LPilot.u16year >> 0u);
    loco_evnt_buf[4]  = acknmnt_by_LPilot.u8hrs;
    loco_evnt_buf[5]  = acknmnt_by_LPilot.u8min;
    loco_evnt_buf[6]  = acknmnt_by_LPilot.u8secs;
    loco_evnt_buf[7]  = (uint8)(acknmnt_by_LPilot.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(acknmnt_by_LPilot.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(acknmnt_by_LPilot.u24absloc >> 0u);
    loco_evnt_buf[10] = acknmnt_by_LPilot.u8ackRsn;


    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = 1u;
        Log_CAN_data_buf[2] = 2u;
        Log_CAN_data_buf[3] = 1u;
        Log_CAN_data_buf[4] = 11u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(1u);
        wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[1];
        Log_CAN_data_buf[2] = loco_evnt_buf[2];
        Log_CAN_data_buf[3] = loco_evnt_buf[3];
        Log_CAN_data_buf[4] = loco_evnt_buf[4];
        Log_CAN_data_buf[5] = loco_evnt_buf[5];
        Log_CAN_data_buf[6] = loco_evnt_buf[6];
        Log_CAN_data_buf[7] = loco_evnt_buf[7];
        can_msg_send(2u);
        wait(1000u);

        Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = 1u;
        Log_CAN_data_buf[2] = 2u;
        Log_CAN_data_buf[3] = 2u;
        Log_CAN_data_buf[4] = 11u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(1u);
        wait(1000u);

        Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
        Log_CAN_data_buf[1] = loco_evnt_buf[9];
        Log_CAN_data_buf[2] = loco_evnt_buf[10];
        Log_CAN_data_buf[3] = 0u;
        Log_CAN_data_buf[4] = 0u;
        Log_CAN_data_buf[5] = 0u;
        Log_CAN_data_buf[6] = 0u;
        Log_CAN_data_buf[7] = 0u;
        can_msg_send(2u);
        wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 6u, 11u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/*****************************************************************************************************************
                                     SPAD (Sub message ID 7)
 *****************************************************************************************************************/
void build_signal_passed_at_danger_pkt(void)
{

    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    signal_passed_at_danger.u8day   = loc_day;
    signal_passed_at_danger.u8month = loc_mon;
    signal_passed_at_danger.u16year = loc_yr;
    signal_passed_at_danger.u8hrs   = loc_hrs;
    signal_passed_at_danger.u8min   = loc_min;
    signal_passed_at_danger.u8secs  = loc_sec;
    signal_passed_at_danger.u24absloc = 12345u;
    signal_passed_at_danger.u8spd = 25u;
    signal_passed_at_danger.ref_RFID_tag = 123u;

    loco_evnt_buf[0]  = signal_passed_at_danger.u8day;
    loco_evnt_buf[1]  = signal_passed_at_danger.u8month;
    loco_evnt_buf[2]  = (uint8)(signal_passed_at_danger.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(signal_passed_at_danger.u16year >> 0u);
    loco_evnt_buf[4]  = signal_passed_at_danger.u8hrs;
    loco_evnt_buf[5]  = signal_passed_at_danger.u8min;
    loco_evnt_buf[6]  = signal_passed_at_danger.u8secs;
    loco_evnt_buf[7]  = (uint8)(signal_passed_at_danger.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(signal_passed_at_danger.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(signal_passed_at_danger.u24absloc >> 0u);
    loco_evnt_buf[10] = signal_passed_at_danger.u8spd;
    loco_evnt_buf[11] = (uint8)(signal_passed_at_danger.ref_RFID_tag >> 8u);
    loco_evnt_buf[12] = (uint8)(signal_passed_at_danger.ref_RFID_tag >> 0u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 13u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 13u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 7u, 13u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                     Change in TIN (Sub message ID 8)
 *****************************************************************************************************************/
void build_chang_in_TINumber_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    chang_in_TINumber.u8day   = loc_day;
    chang_in_TINumber.u8month = loc_mon;
    chang_in_TINumber.u16year = loc_yr;
    chang_in_TINumber.u8hrs   = loc_hrs;
    chang_in_TINumber.u8min   = loc_min;
    chang_in_TINumber.u8secs  = loc_sec;
    chang_in_TINumber.u24absloc = 12345u;
    chang_in_TINumber.u16prev_TIN = 120u;
    chang_in_TINumber.u16pres_TIN = 121u;

    loco_evnt_buf[0]  = chang_in_TINumber.u8day;
    loco_evnt_buf[1]  = chang_in_TINumber.u8month;
    loco_evnt_buf[2]  = (uint8)(chang_in_TINumber.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(chang_in_TINumber.u16year >> 0u);
    loco_evnt_buf[4]  = chang_in_TINumber.u8hrs;
    loco_evnt_buf[5]  = chang_in_TINumber.u8min;
    loco_evnt_buf[6]  = chang_in_TINumber.u8secs;
    loco_evnt_buf[7]  = (uint8)(chang_in_TINumber.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(chang_in_TINumber.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(chang_in_TINumber.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(chang_in_TINumber.u16prev_TIN >> 8u);
    loco_evnt_buf[11] = (uint8)(chang_in_TINumber.u16prev_TIN >> 0u);
    loco_evnt_buf[12] = (uint8)(chang_in_TINumber.u16pres_TIN >> 8u);
    loco_evnt_buf[13] = (uint8)(chang_in_TINumber.u16pres_TIN >> 0u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 14u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 14u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = loco_evnt_buf[13];
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);
//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 8u, 14u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                     One RFID tag missing out of two (Sub message ID 9)
 *****************************************************************************************************************/
void build_one_RFID_tg_msng_out_of_two_tags_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    one_RFID_tg_msng_out_of_two_tags.u8day   = loc_day;
    one_RFID_tg_msng_out_of_two_tags.u8month = loc_mon;
    one_RFID_tg_msng_out_of_two_tags.u16year = loc_yr;
    one_RFID_tg_msng_out_of_two_tags.u8hrs   = loc_hrs;
    one_RFID_tg_msng_out_of_two_tags.u8min   = loc_min;
    one_RFID_tg_msng_out_of_two_tags.u8secs  = loc_sec;
    one_RFID_tg_msng_out_of_two_tags.u24absloc = 12345u;
    one_RFID_tg_msng_out_of_two_tags.u16RFID_tag = 122u;
    one_RFID_tg_msng_out_of_two_tags.u8tag_type = 0u;

    loco_evnt_buf[0]  = one_RFID_tg_msng_out_of_two_tags.u8day;
    loco_evnt_buf[1]  = one_RFID_tg_msng_out_of_two_tags.u8month;
    loco_evnt_buf[2]  = (uint8)(one_RFID_tg_msng_out_of_two_tags.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(one_RFID_tg_msng_out_of_two_tags.u16year >> 0u);
    loco_evnt_buf[4]  = one_RFID_tg_msng_out_of_two_tags.u8hrs;
    loco_evnt_buf[5]  = one_RFID_tg_msng_out_of_two_tags.u8min;
    loco_evnt_buf[6]  = one_RFID_tg_msng_out_of_two_tags.u8secs;
    loco_evnt_buf[7]  = (uint8)(one_RFID_tg_msng_out_of_two_tags.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(one_RFID_tg_msng_out_of_two_tags.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(one_RFID_tg_msng_out_of_two_tags.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(one_RFID_tg_msng_out_of_two_tags.u16RFID_tag >> 8u);
    loco_evnt_buf[11] = (uint8)(one_RFID_tg_msng_out_of_two_tags.u16RFID_tag >> 0u);
    loco_evnt_buf[12] = one_RFID_tg_msng_out_of_two_tags.u8tag_type;

    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 9u, 13u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                     Both RFID tags missing (Sub message ID 10)
 *****************************************************************************************************************/
void build_both_rfid_tags_missing_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    both_rfid_tags_missing.u8day   = loc_day;
    both_rfid_tags_missing.u8month = loc_mon;
    both_rfid_tags_missing.u16year = loc_yr;
    both_rfid_tags_missing.u8hrs   = loc_hrs;
    both_rfid_tags_missing.u8min   = loc_min;
    both_rfid_tags_missing.u8secs  = loc_sec;
    both_rfid_tags_missing.u24absloc = 12345u;
    both_rfid_tags_missing.u16RFID_tag = 125u;

    loco_evnt_buf[0]  = both_rfid_tags_missing.u8day;
    loco_evnt_buf[1]  = both_rfid_tags_missing.u8month;
    loco_evnt_buf[2]  = (uint8)(both_rfid_tags_missing.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(both_rfid_tags_missing.u16year >> 0u);
    loco_evnt_buf[4]  = both_rfid_tags_missing.u8hrs;
    loco_evnt_buf[5]  = both_rfid_tags_missing.u8min;
    loco_evnt_buf[6]  = both_rfid_tags_missing.u8secs;
    loco_evnt_buf[7]  = (uint8)(both_rfid_tags_missing.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(both_rfid_tags_missing.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(both_rfid_tags_missing.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(both_rfid_tags_missing.u16RFID_tag >> 8u);
    loco_evnt_buf[11] = (uint8)(both_rfid_tags_missing.u16RFID_tag >> 0u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = 0u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 10u, 12u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                    data mismatch between main duplicate RFID tag (Sub message ID 11)
 *****************************************************************************************************************/
void build_data_mismatch_btw_mn_nd_dup_tag_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    data_mismatch_btw_mn_nd_dup_tag.u8day   = loc_day;
    data_mismatch_btw_mn_nd_dup_tag.u8month = loc_mon;
    data_mismatch_btw_mn_nd_dup_tag.u16year = loc_yr;
    data_mismatch_btw_mn_nd_dup_tag.u8hrs   = loc_hrs;
    data_mismatch_btw_mn_nd_dup_tag.u8min   = loc_min;
    data_mismatch_btw_mn_nd_dup_tag.u8secs  = loc_sec;
    data_mismatch_btw_mn_nd_dup_tag.u24absloc = 12345u;
    data_mismatch_btw_mn_nd_dup_tag.u16RFID_tag = 125u;

    loco_evnt_buf[0]  = data_mismatch_btw_mn_nd_dup_tag.u8day;
    loco_evnt_buf[1]  = data_mismatch_btw_mn_nd_dup_tag.u8month;
    loco_evnt_buf[2]  = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u16year >> 0u);
    loco_evnt_buf[4]  = data_mismatch_btw_mn_nd_dup_tag.u8hrs;
    loco_evnt_buf[5]  = data_mismatch_btw_mn_nd_dup_tag.u8min;
    loco_evnt_buf[6]  = data_mismatch_btw_mn_nd_dup_tag.u8secs;
    loco_evnt_buf[7]  = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u16RFID_tag >> 8u);
    loco_evnt_buf[11] = (uint8)(data_mismatch_btw_mn_nd_dup_tag.u16RFID_tag >> 0u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 12u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = 0u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 11u, 12u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                    Change in signal aspect (Sub message ID 12)
 *****************************************************************************************************************/
void build_change_in_sig_aspect(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    change_in_sig_aspect.u8day   = loc_day;
    change_in_sig_aspect.u8month = loc_mon;
    change_in_sig_aspect.u16year = loc_yr;
    change_in_sig_aspect.u8hrs   = loc_hrs;
    change_in_sig_aspect.u8min   = loc_min;
    change_in_sig_aspect.u8secs  = loc_sec;
    change_in_sig_aspect.u24absloc = 12345u;
    change_in_sig_aspect.u8trn_sec_type = 1u;
    change_in_sig_aspect.u16ref_RFID_tag = 125u;
    change_in_sig_aspect.u8sig_type = 1u;
    change_in_sig_aspect.u8prev_sig_aspect = 1u;
    change_in_sig_aspect.u8pres_sig_aspect = 2u;

    loco_evnt_buf[0]  = change_in_sig_aspect.u8day;
    loco_evnt_buf[1]  = change_in_sig_aspect.u8month;
    loco_evnt_buf[2]  = (uint8)(change_in_sig_aspect.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(change_in_sig_aspect.u16year >> 0u);
    loco_evnt_buf[4]  = change_in_sig_aspect.u8hrs;
    loco_evnt_buf[5]  = change_in_sig_aspect.u8min;
    loco_evnt_buf[6]  = change_in_sig_aspect.u8secs;
    loco_evnt_buf[7]  = (uint8)(change_in_sig_aspect.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(change_in_sig_aspect.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(change_in_sig_aspect.u24absloc >> 0u);
    loco_evnt_buf[10] = change_in_sig_aspect.u8trn_sec_type;
    loco_evnt_buf[11] = (uint8)(change_in_sig_aspect.u16ref_RFID_tag >> 8u);
    loco_evnt_buf[12] = (uint8)(change_in_sig_aspect.u16ref_RFID_tag >> 0u);
    loco_evnt_buf[13] = change_in_sig_aspect.u8sig_type;
    loco_evnt_buf[14] = change_in_sig_aspect.u8prev_sig_aspect;
    loco_evnt_buf[15] = change_in_sig_aspect.u8pres_sig_aspect;

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 1u;
    Log_CAN_data_buf[4] = 16u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[0];                       /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[1];
    Log_CAN_data_buf[2] = loco_evnt_buf[2];
    Log_CAN_data_buf[3] = loco_evnt_buf[3];
    Log_CAN_data_buf[4] = loco_evnt_buf[4];
    Log_CAN_data_buf[5] = loco_evnt_buf[5];
    Log_CAN_data_buf[6] = loco_evnt_buf[6];
    Log_CAN_data_buf[7] = loco_evnt_buf[7];
    can_msg_send(2u);
    wait(1000u);

    Log_CAN_data_buf[0] = LOCO_TRIG_DATA;                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = 1u;
    Log_CAN_data_buf[2] = 2u;
    Log_CAN_data_buf[3] = 2u;
    Log_CAN_data_buf[4] = 16u;
    Log_CAN_data_buf[5] = 0u;
    Log_CAN_data_buf[6] = 0u;
    Log_CAN_data_buf[7] = 0u;
    can_msg_send(1u);
    wait(1000u);

    Log_CAN_data_buf[0] = loco_evnt_buf[8];                     /* newly added for CAN communication */
    Log_CAN_data_buf[1] = loco_evnt_buf[9];
    Log_CAN_data_buf[2] = loco_evnt_buf[10];
    Log_CAN_data_buf[3] = loco_evnt_buf[11];
    Log_CAN_data_buf[4] = loco_evnt_buf[12];
    Log_CAN_data_buf[5] = loco_evnt_buf[13];
    Log_CAN_data_buf[6] = loco_evnt_buf[14];
    Log_CAN_data_buf[7] = loco_evnt_buf[15];
    can_msg_send(2u);
    wait(1000u);

//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 12u, 16u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                    Passing of signal (Sub message ID 13)
 *****************************************************************************************************************/
void build_passing_of_signall_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    passing_of_signall.u8day   = loc_day;
    passing_of_signall.u8month = loc_mon;
    passing_of_signall.u16year = loc_yr;
    passing_of_signall.u8hrs   = loc_hrs;
    passing_of_signall.u8min   = loc_min;
    passing_of_signall.u8secs  = loc_sec;
    passing_of_signall.u24absloc = 12345u;
    passing_of_signall.u8trn_sec_type = 1u;
    passing_of_signall.u16ref_RFID_tag= 1u;
    passing_of_signall.u8sig_aspect = 1u;

    loco_evnt_buf[0]  = passing_of_signall.u8day;
    loco_evnt_buf[1]  = passing_of_signall.u8month;
    loco_evnt_buf[2]  = (uint8)(passing_of_signall.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(passing_of_signall.u16year >> 0u);
    loco_evnt_buf[4]  = passing_of_signall.u8hrs;
    loco_evnt_buf[5]  = passing_of_signall.u8min;
    loco_evnt_buf[6]  = passing_of_signall.u8secs;
    loco_evnt_buf[7]  = (uint8)(passing_of_signall.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(passing_of_signall.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(passing_of_signall.u24absloc >> 0u);
    loco_evnt_buf[10] = passing_of_signall.u8trn_sec_type;
    loco_evnt_buf[11] = (uint8)(passing_of_signall.u16ref_RFID_tag >> 8u);
    loco_evnt_buf[12] = (uint8)(passing_of_signall.u16ref_RFID_tag >> 0u);
    loco_evnt_buf[13] = passing_of_signall.u8sig_aspect;


//    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 13u, 14u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   Transmission of emergency messages (Sub message ID 14)
 *****************************************************************************************************************/
void build_tx_of_emer_message_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    tx_of_emer_message.u8day   = loc_day;
    tx_of_emer_message.u8month = loc_mon;
    tx_of_emer_message.u16year = loc_yr;
    tx_of_emer_message.u8hrs   = loc_hrs;
    tx_of_emer_message.u8min   = loc_min;
    tx_of_emer_message.u8secs  = loc_sec;
    tx_of_emer_message.u24absloc = 12345u;
    tx_of_emer_message.u8txRsn = 1u;

    loco_evnt_buf[0]  = tx_of_emer_message.u8day;
    loco_evnt_buf[1]  = tx_of_emer_message.u8month;
    loco_evnt_buf[2]  = (uint8)(tx_of_emer_message.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(tx_of_emer_message.u16year >> 0u);
    loco_evnt_buf[4]  = tx_of_emer_message.u8hrs;
    loco_evnt_buf[5]  = tx_of_emer_message.u8min;
    loco_evnt_buf[6]  = tx_of_emer_message.u8secs;
    loco_evnt_buf[7]  = (uint8)(tx_of_emer_message.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(tx_of_emer_message.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(tx_of_emer_message.u24absloc >> 0u);
    loco_evnt_buf[10] = tx_of_emer_message.u8txRsn;

    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 14u, 11u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   Reception of emergency messages (Sub message ID 15)
 *****************************************************************************************************************/
void build_Rx_of_emer_message_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    Rx_of_emer_message.u8day   = loc_day;
    Rx_of_emer_message.u8month = loc_mon;
    Rx_of_emer_message.u16year = loc_yr;
    Rx_of_emer_message.u8hrs   = loc_hrs;
    Rx_of_emer_message.u8min   = loc_min;
    Rx_of_emer_message.u8secs  = loc_sec;
    Rx_of_emer_message.u24absloc = 12345u;
    Rx_of_emer_message.u8sender = 1u;
    Rx_of_emer_message.u24stnorlocoID = 1345u;
    Rx_of_emer_message.u8RxRsn = 1u;

    loco_evnt_buf[0]  = Rx_of_emer_message.u8day;
    loco_evnt_buf[1]  = Rx_of_emer_message.u8month;
    loco_evnt_buf[2]  = (uint8)(Rx_of_emer_message.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(Rx_of_emer_message.u16year >> 0u);
    loco_evnt_buf[4]  = Rx_of_emer_message.u8hrs;
    loco_evnt_buf[5]  = Rx_of_emer_message.u8min;
    loco_evnt_buf[6]  = Rx_of_emer_message.u8secs;
    loco_evnt_buf[7]  = (uint8)(Rx_of_emer_message.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(Rx_of_emer_message.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(Rx_of_emer_message.u24absloc >> 0u);
    loco_evnt_buf[10] = Rx_of_emer_message.u8sender;
    loco_evnt_buf[11] = (uint8)(Rx_of_emer_message.u24stnorlocoID >> 16u);
    loco_evnt_buf[12] = (uint8)(Rx_of_emer_message.u24stnorlocoID >> 8u);
    loco_evnt_buf[13] = (uint8)(Rx_of_emer_message.u24stnorlocoID >> 0u);
    loco_evnt_buf[14] = Rx_of_emer_message.u8RxRsn;

    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 15u, 15u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   Entry into new station area (Sub message ID 16)
 *****************************************************************************************************************/
void build_entry_into_new_station_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    entry_into_new_station.u8day   = loc_day;
    entry_into_new_station.u8month = loc_mon;
    entry_into_new_station.u16year = loc_yr;
    entry_into_new_station.u8hrs   = loc_hrs;
    entry_into_new_station.u8min   = loc_min;
    entry_into_new_station.u8secs  = loc_sec;
    entry_into_new_station.u24absloc = 12345u;
    entry_into_new_station.u16stnID = 12345u;

    loco_evnt_buf[0]  = entry_into_new_station.u8day;
    loco_evnt_buf[1]  = entry_into_new_station.u8month;
    loco_evnt_buf[2]  = (uint8)(entry_into_new_station.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(entry_into_new_station.u16year >> 0u);
    loco_evnt_buf[4]  = entry_into_new_station.u8hrs;
    loco_evnt_buf[5]  = entry_into_new_station.u8min;
    loco_evnt_buf[6]  = entry_into_new_station.u8secs;
    loco_evnt_buf[7]  = (uint8)(entry_into_new_station.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(entry_into_new_station.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(entry_into_new_station.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(entry_into_new_station.u16stnID >> 8u);
    loco_evnt_buf[11] = (uint8)(entry_into_new_station.u16stnID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 16u, 12u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   Frequency channel allocation (Sub message ID 17)
 *****************************************************************************************************************/
void build_freq_channel_allocation_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    freq_channel_allocation.u8day   = loc_day;
    freq_channel_allocation.u8month = loc_mon;
    freq_channel_allocation.u16year = loc_yr;
    freq_channel_allocation.u8hrs   = loc_hrs;
    freq_channel_allocation.u8min   = loc_min;
    freq_channel_allocation.u8secs  = loc_sec;
    freq_channel_allocation.u24absloc = 12345u;
    freq_channel_allocation.u16new_stn_ID = 1234u;
    freq_channel_allocation.u16uplink_freq = 2000u;
    freq_channel_allocation.u16downlink_freq = 1900u;

    loco_evnt_buf[0]  = freq_channel_allocation.u8day;
    loco_evnt_buf[1]  = freq_channel_allocation.u8month;
    loco_evnt_buf[2]  = (uint8)(freq_channel_allocation.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(freq_channel_allocation.u16year >> 0u);
    loco_evnt_buf[4]  = freq_channel_allocation.u8hrs;
    loco_evnt_buf[5]  = freq_channel_allocation.u8min;
    loco_evnt_buf[6]  = freq_channel_allocation.u8secs;
    loco_evnt_buf[7]  = (uint8)(freq_channel_allocation.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(freq_channel_allocation.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(freq_channel_allocation.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(freq_channel_allocation.u16new_stn_ID >> 8u);
    loco_evnt_buf[11] = (uint8)(freq_channel_allocation.u16new_stn_ID >> 0u);
    loco_evnt_buf[12] = (uint8)(freq_channel_allocation.u16uplink_freq >> 8u);
    loco_evnt_buf[13] = (uint8)(freq_channel_allocation.u16uplink_freq >> 0u);
    loco_evnt_buf[14] = (uint8)(freq_channel_allocation.u16downlink_freq >> 8u);
    loco_evnt_buf[15] = (uint8)(freq_channel_allocation.u16downlink_freq >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_TRIG_DATA, 17u, 16u, loco_evnt_buf );

    for(i = 0u; i < 20u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                          CRITICAL DATA:9A
                             Auhentication key details . Event ID : 01
 *****************************************************************************************************************/
void build_authen_key_details_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    authen_key_details.u8day   = loc_day;
    authen_key_details.u8month = loc_mon;
    authen_key_details.u16year = loc_yr;
    authen_key_details.u8hrs   = loc_hrs;
    authen_key_details.u8min   = loc_min;
    authen_key_details.u8secs  = loc_sec;
    authen_key_details.u24absloc = 12345u;
    authen_key_details.u8current_running_key[0] = 0xA5u;
    authen_key_details.u8current_running_key[1] = 0xA5u;
    authen_key_details.u8current_running_key[2] = 0xA5u;
    authen_key_details.u8current_running_key[3] = 0xA5u;
    authen_key_details.u8current_running_key[4] = 0xA5u;
    authen_key_details.u8current_running_key[5] = 0xA5u;
    authen_key_details.u8current_running_key[6] = 0xA5u;
    authen_key_details.u8current_running_key[7] = 0xA5u;
    authen_key_details.u8current_running_key[8] = 0xA5u;
    authen_key_details.u8current_running_key[9] = 0xA5u;
    authen_key_details.u8current_running_key[10] = 0xA5u;
    authen_key_details.u8current_running_key[11] = 0xA5u;
    authen_key_details.u8current_running_key[12] = 0xA5u;
    authen_key_details.u8current_running_key[13] = 0xA5u;
    authen_key_details.u8current_running_key[14] = 0xA5u;
    authen_key_details.u8current_running_key[15] = 0xA5u;
    authen_key_details.u8key_mem_loc = 1u;
    authen_key_details.u16stn_ID = 12345u;
    authen_key_details.u8rem_keys = 125u;

    loco_evnt_buf[0]  = authen_key_details.u8day;
    loco_evnt_buf[1]  = authen_key_details.u8month;
    loco_evnt_buf[2]  = (uint8)(authen_key_details.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(authen_key_details.u16year >> 0u);
    loco_evnt_buf[4]  = authen_key_details.u8hrs;
    loco_evnt_buf[5]  = authen_key_details.u8min;
    loco_evnt_buf[6]  = authen_key_details.u8secs;
    loco_evnt_buf[7]  = (uint8)(authen_key_details.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(authen_key_details.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(authen_key_details.u24absloc >> 0u);
    loco_evnt_buf[10] = authen_key_details.u8current_running_key[0];
    loco_evnt_buf[11] = authen_key_details.u8current_running_key[1];
    loco_evnt_buf[12] = authen_key_details.u8current_running_key[2];
    loco_evnt_buf[13] = authen_key_details.u8current_running_key[3];
    loco_evnt_buf[14] = authen_key_details.u8current_running_key[4];
    loco_evnt_buf[15] = authen_key_details.u8current_running_key[5];
    loco_evnt_buf[16] = authen_key_details.u8current_running_key[6];
    loco_evnt_buf[17] = authen_key_details.u8current_running_key[7];
    loco_evnt_buf[18] = authen_key_details.u8current_running_key[8];
    loco_evnt_buf[19] = authen_key_details.u8current_running_key[9];
    loco_evnt_buf[20] = authen_key_details.u8current_running_key[10];
    loco_evnt_buf[21] = authen_key_details.u8current_running_key[11];
    loco_evnt_buf[22] = authen_key_details.u8current_running_key[12];
    loco_evnt_buf[23] = authen_key_details.u8current_running_key[13];
    loco_evnt_buf[24] = authen_key_details.u8current_running_key[14];
    loco_evnt_buf[25] = authen_key_details.u8current_running_key[15];
    loco_evnt_buf[26] = authen_key_details.u8key_mem_loc;
    loco_evnt_buf[27] = (uint8)(authen_key_details.u16stn_ID >> 8u);
    loco_evnt_buf[28] = (uint8)(authen_key_details.u16stn_ID >> 0u);
    loco_evnt_buf[29] = authen_key_details.u8rem_keys;


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 1u, 30u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Train Length measurement, event Id : 02
 *****************************************************************************************************************/
void build_TLM_measure_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    TLM_measure.u8day   = loc_day;
    TLM_measure.u8month = loc_mon;
    TLM_measure.u16year = loc_yr;
    TLM_measure.u8hrs   = loc_hrs;
    TLM_measure.u8min   = loc_min;
    TLM_measure.u8secs  = loc_sec;
    TLM_measure.u24absloc = 12345u;
    TLM_measure.u16TLM = 1250u;

    loco_evnt_buf[0]  = TLM_measure.u8day;
    loco_evnt_buf[1]  = TLM_measure.u8month;
    loco_evnt_buf[2]  = (uint8)(TLM_measure.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(TLM_measure.u16year >> 0u);
    loco_evnt_buf[4]  = TLM_measure.u8hrs;
    loco_evnt_buf[5]  = TLM_measure.u8min;
    loco_evnt_buf[6]  = TLM_measure.u8secs;
    loco_evnt_buf[7]  = (uint8)(TLM_measure.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(TLM_measure.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(TLM_measure.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(TLM_measure.u16TLM >> 8u);
    loco_evnt_buf[11] = (uint8)(TLM_measure.u16TLM >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 2u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}
/*****************************************************************************************************************
                                   event name : Train configuration change event, event Id : 03
 *****************************************************************************************************************/
void build_trn_cfg_chng_event(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    trn_cfg_change.u8day   = loc_day;
    trn_cfg_change.u8month = loc_mon;
    trn_cfg_change.u16year = loc_yr;
    trn_cfg_change.u8hrs   = loc_hrs;
    trn_cfg_change.u8min   = loc_min;
    trn_cfg_change.u8secs  = loc_sec;
    trn_cfg_change.u24absloc = 12345u;
    trn_cfg_change.u8trn_cfg_chng = 1u;

    loco_evnt_buf[0]  = trn_cfg_change.u8day;
    loco_evnt_buf[1]  = trn_cfg_change.u8month;
    loco_evnt_buf[2]  = (uint8)(trn_cfg_change.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(trn_cfg_change.u16year >> 0u);
    loco_evnt_buf[4]  = trn_cfg_change.u8hrs;
    loco_evnt_buf[5]  = trn_cfg_change.u8min;
    loco_evnt_buf[6]  = trn_cfg_change.u8secs;
    loco_evnt_buf[7]  = (uint8)(trn_cfg_change.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(trn_cfg_change.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(trn_cfg_change.u24absloc >> 0u);
    loco_evnt_buf[10] = trn_cfg_change.u8trn_cfg_chng;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 3u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }


}

/*****************************************************************************************************************
                                   event name : Bootup sequenceerror event, event Id : 04
 *****************************************************************************************************************/
void build_boot_up_seq_error_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    boot_up_seq_error.u8day   = loc_day;
    boot_up_seq_error.u8month = loc_mon;
    boot_up_seq_error.u16year = loc_yr;
    boot_up_seq_error.u8hrs   = loc_hrs;
    boot_up_seq_error.u8min   = loc_min;
    boot_up_seq_error.u8secs  = loc_sec;
    boot_up_seq_error.u24absloc = 12345u;
    boot_up_seq_error.u8err_type = 1u;

    loco_evnt_buf[0]  = boot_up_seq_error.u8day;
    loco_evnt_buf[1]  = boot_up_seq_error.u8month;
    loco_evnt_buf[2]  = (uint8)(boot_up_seq_error.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(boot_up_seq_error.u16year >> 0u);
    loco_evnt_buf[4]  = boot_up_seq_error.u8hrs;
    loco_evnt_buf[5]  = boot_up_seq_error.u8min;
    loco_evnt_buf[6]  = boot_up_seq_error.u8secs;
    loco_evnt_buf[7]  = (uint8)(boot_up_seq_error.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(boot_up_seq_error.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(boot_up_seq_error.u24absloc >> 0u);
    loco_evnt_buf[10] = boot_up_seq_error.u8err_type;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 4u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :cab selection event, event Id : 05
 *****************************************************************************************************************/
void build_cab_select_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    cab_select_event.u8day   = loc_day;
    cab_select_event.u8month = loc_mon;
    cab_select_event.u16year = loc_yr;
    cab_select_event.u8hrs   = loc_hrs;
    cab_select_event.u8min   = loc_min;
    cab_select_event.u8secs  = loc_sec;
    cab_select_event.u24absloc = 12345u;
    cab_select_event.u8cab_slctd = 1u;

    loco_evnt_buf[0]  = cab_select_event.u8day;
    loco_evnt_buf[1]  = cab_select_event.u8month;
    loco_evnt_buf[2]  = (uint8)(cab_select_event.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(cab_select_event.u16year >> 0u);
    loco_evnt_buf[4]  = cab_select_event.u8hrs;
    loco_evnt_buf[5]  = cab_select_event.u8min;
    loco_evnt_buf[6]  = cab_select_event.u8secs;
    loco_evnt_buf[7]  = (uint8)(cab_select_event.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(cab_select_event.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(cab_select_event.u24absloc >> 0u);
    loco_evnt_buf[10] = cab_select_event.u8cab_slctd;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 5u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Brake application event, event Id : 06
 *****************************************************************************************************************/
void build_brk_appli_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    brk_appli_event.u8day   = loc_day;
    brk_appli_event.u8month = loc_mon;
    brk_appli_event.u16year = loc_yr;
    brk_appli_event.u8hrs   = loc_hrs;
    brk_appli_event.u8min   = loc_min;
    brk_appli_event.u8secs  = loc_sec;
    brk_appli_event.u24absloc = 12345u;
    brk_appli_event.u8brk_appli_rsn = 1u;
    brk_appli_event.u8speed = 25u;
    brk_appli_event.u8brk_type_applied = 1u;

    loco_evnt_buf[0]  = brk_appli_event.u8day;
    loco_evnt_buf[1]  = brk_appli_event.u8month;
    loco_evnt_buf[2]  = (uint8)(brk_appli_event.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(brk_appli_event.u16year >> 0u);
    loco_evnt_buf[4]  = brk_appli_event.u8hrs;
    loco_evnt_buf[5]  = brk_appli_event.u8min;
    loco_evnt_buf[6]  = brk_appli_event.u8secs;
    loco_evnt_buf[7]  = (uint8)(brk_appli_event.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(brk_appli_event.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(brk_appli_event.u24absloc >> 0u);
    loco_evnt_buf[10] = brk_appli_event.u8brk_appli_rsn;
    loco_evnt_buf[11] = brk_appli_event.u8speed;
    loco_evnt_buf[12] = brk_appli_event.u8brk_type_applied;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 6u, 13u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : collision detection, event Id : 07
 *****************************************************************************************************************/
void build_collision_detctn_ent_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    collision_detctn.u8day   = loc_day;
    collision_detctn.u8month = loc_mon;
    collision_detctn.u16year = loc_yr;
    collision_detctn.u8hrs   = loc_hrs;
    collision_detctn.u8min   = loc_min;
    collision_detctn.u8secs  = loc_sec;
    collision_detctn.u24absloc = 12345u;
    collision_detctn.u8colsn_type = 1u;

    loco_evnt_buf[0]  = collision_detctn.u8day;
    loco_evnt_buf[1]  = collision_detctn.u8month;
    loco_evnt_buf[2]  = (uint8)(collision_detctn.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(collision_detctn.u16year >> 0u);
    loco_evnt_buf[4]  = collision_detctn.u8hrs;
    loco_evnt_buf[5]  = collision_detctn.u8min;
    loco_evnt_buf[6]  = collision_detctn.u8secs;
    loco_evnt_buf[7]  = (uint8)(collision_detctn.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(collision_detctn.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(collision_detctn.u24absloc >> 0u);
    loco_evnt_buf[10] = collision_detctn.u8colsn_type;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 7u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Loco Manual SOS, event Id : 08
 *****************************************************************************************************************/
void build_loco_manual_SOS_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    loco_manual_SOS_evnt.u8day   = loc_day;
    loco_manual_SOS_evnt.u8month = loc_mon;
    loco_manual_SOS_evnt.u16year = loc_yr;
    loco_manual_SOS_evnt.u8hrs   = loc_hrs;
    loco_manual_SOS_evnt.u8min   = loc_min;
    loco_manual_SOS_evnt.u8secs  = loc_sec;
    loco_manual_SOS_evnt.u24absloc = 12345u;
    loco_manual_SOS_evnt.u8loco_self_sos = 1u;

    loco_evnt_buf[0]  = loco_manual_SOS_evnt.u8day;
    loco_evnt_buf[1]  = loco_manual_SOS_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(loco_manual_SOS_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(loco_manual_SOS_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = loco_manual_SOS_evnt.u8hrs;
    loco_evnt_buf[5]  = loco_manual_SOS_evnt.u8min;
    loco_evnt_buf[6]  = loco_manual_SOS_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(loco_manual_SOS_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(loco_manual_SOS_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(loco_manual_SOS_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = loco_manual_SOS_evnt.u8loco_self_sos;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 8u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : radio 1  health, event Id : 09
 *****************************************************************************************************************/
void build_rad1hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    rad1hlt.u8day   = loc_day;
    rad1hlt.u8month = loc_mon;
    rad1hlt.u16year = loc_yr;
    rad1hlt.u8hrs   = loc_hrs;
    rad1hlt.u8min   = loc_min;
    rad1hlt.u8secs  = loc_sec;
    rad1hlt.u24absloc = 12345u;
    rad1hlt.u8hlt = 1u;
    rad1hlt.u8Ipsupply = 12u;
    rad1hlt.u8temp = 30u;
    rad1hlt.u8PA_temp = 35u;
    rad1hlt.u8PA_suply_volt = 12u;
    rad1hlt.u8TxPAcrnt = 1u;
    rad1hlt.u8revPwr = 10u;
    rad1hlt.u8fwdPwr = 12u;
    rad1hlt.u16RSSI = 234u;
    rad1hlt.u8RxpktCnt = 134u;

    loco_evnt_buf[0]  = rad1hlt.u8day;
    loco_evnt_buf[1]  = rad1hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(rad1hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(rad1hlt.u16year >> 0u);
    loco_evnt_buf[4]  = rad1hlt.u8hrs;
    loco_evnt_buf[5]  = rad1hlt.u8min;
    loco_evnt_buf[6]  = rad1hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(rad1hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(rad1hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(rad1hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = rad1hlt.u8hlt;
    loco_evnt_buf[11] = rad1hlt.u8Ipsupply;
    loco_evnt_buf[12] = rad1hlt.u8temp;
    loco_evnt_buf[13] = rad1hlt.u8PA_temp;
    loco_evnt_buf[14] = rad1hlt.u8PA_suply_volt;
    loco_evnt_buf[15] = rad1hlt.u8TxPAcrnt;
    loco_evnt_buf[16] = rad1hlt.u8revPwr;
    loco_evnt_buf[17] = rad1hlt.u8fwdPwr;
    loco_evnt_buf[18] = (uint8)(rad1hlt.u16RSSI >> 8u);
    loco_evnt_buf[19] = (uint8)(rad1hlt.u16RSSI >> 0u);
    loco_evnt_buf[20] = rad1hlt.u8RxpktCnt;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 9u, 21u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : radio 2 health, event Id : 10
 *****************************************************************************************************************/
void build_rad2hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    rad2hlt.u8day   = loc_day;
    rad2hlt.u8month = loc_mon;
    rad2hlt.u16year = loc_yr;
    rad2hlt.u8hrs   = loc_hrs;
    rad2hlt.u8min   = loc_min;
    rad2hlt.u8secs  = loc_sec;
    rad2hlt.u24absloc = 12345u;
    rad2hlt.u8hlt = 1u;
    rad2hlt.u8Ipsupply = 12u;
    rad2hlt.u8temp = 30u;
    rad2hlt.u8PA_temp = 35u;
    rad2hlt.u8PA_suply_volt = 12u;
    rad2hlt.u8TxPAcrnt = 1u;
    rad2hlt.u8revPwr = 10u;
    rad2hlt.u8fwdPwr = 12u;
    rad2hlt.u16RSSI = 234u;
    rad2hlt.u8RxpktCnt = 134u;

    loco_evnt_buf[0]  = rad2hlt.u8day;
    loco_evnt_buf[1]  = rad2hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(rad2hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(rad2hlt.u16year >> 0u);
    loco_evnt_buf[4]  = rad2hlt.u8hrs;
    loco_evnt_buf[5]  = rad2hlt.u8min;
    loco_evnt_buf[6]  = rad2hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(rad2hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(rad2hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(rad2hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = rad2hlt.u8hlt;
    loco_evnt_buf[11] = rad2hlt.u8Ipsupply;
    loco_evnt_buf[12] = rad2hlt.u8temp;
    loco_evnt_buf[13] = rad2hlt.u8PA_temp;
    loco_evnt_buf[14] = rad2hlt.u8PA_suply_volt;
    loco_evnt_buf[15] = rad2hlt.u8TxPAcrnt;
    loco_evnt_buf[16] = rad2hlt.u8revPwr;
    loco_evnt_buf[17] = rad2hlt.u8fwdPwr;
    loco_evnt_buf[18] = (uint8)(rad2hlt.u16RSSI >> 8u);
    loco_evnt_buf[19] = (uint8)(rad2hlt.u16RSSI >> 0u);
    loco_evnt_buf[20] = rad2hlt.u8RxpktCnt;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 10u, 21u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : GSM health event , event Id : 11
 *****************************************************************************************************************/
void build_GSM_hlt_event(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    GSM_health.u8day   = loc_day;
    GSM_health.u8month = loc_mon;
    GSM_health.u16year = loc_yr;
    GSM_health.u8hrs   = loc_hrs;
    GSM_health.u8min   = loc_min;
    GSM_health.u8secs  = loc_sec;
    GSM_health.u24absloc = 12345u;
    GSM_health.u8GSM1RSSI = 12u;
    GSM_health.u8GSM2RSSI = 11u;

    loco_evnt_buf[0]  = GSM_health.u8day;
    loco_evnt_buf[1]  = GSM_health.u8month;
    loco_evnt_buf[2]  = (uint8)(GSM_health.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(GSM_health.u16year >> 0u);
    loco_evnt_buf[4]  = GSM_health.u8hrs;
    loco_evnt_buf[5]  = GSM_health.u8min;
    loco_evnt_buf[6]  = GSM_health.u8secs;
    loco_evnt_buf[7]  = (uint8)(GSM_health.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(GSM_health.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(GSM_health.u24absloc >> 0u);
    loco_evnt_buf[10] = GSM_health.u8GSM1RSSI;
    loco_evnt_buf[11] = GSM_health.u8GSM2RSSI;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 11u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/*****************************************************************************************************************
                                   event name : GPS 1 health event , event Id : 12
*****************************************************************************************************************/
void build_GPS1_hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    GPS1_hlt.u8day   = loc_day;
    GPS1_hlt.u8month = loc_mon;
    GPS1_hlt.u16year = loc_yr;
    GPS1_hlt.u8hrs   = loc_hrs;
    GPS1_hlt.u8min   = loc_min;
    GPS1_hlt.u8secs  = loc_sec;
    GPS1_hlt.u24absloc = 12345u;
    GPS1_hlt.u8actv_GPS_num = 1u;
    GPS1_hlt.u8view = 1u;
    GPS1_hlt.u8sec = 12u;
    GPS1_hlt.u8satellite_in_vw = 1u;
    GPS1_hlt.u8CNO = 12u;

    loco_evnt_buf[0]  = GPS1_hlt.u8day;
    loco_evnt_buf[1]  = GPS1_hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(GPS1_hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(GPS1_hlt.u16year >> 0u);
    loco_evnt_buf[4]  = GPS1_hlt.u8hrs;
    loco_evnt_buf[5]  = GPS1_hlt.u8min;
    loco_evnt_buf[6]  = GPS1_hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(GPS1_hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(GPS1_hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(GPS1_hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = GPS1_hlt.u8actv_GPS_num;
    loco_evnt_buf[11] = GPS1_hlt.u8view;
    loco_evnt_buf[12] = GPS1_hlt.u8sec;
    loco_evnt_buf[13] = GPS1_hlt.u8satellite_in_vw;
    loco_evnt_buf[14] = GPS1_hlt.u8CNO;


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 12u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : GPS 2 health event , event Id : 13
*****************************************************************************************************************/
void bulid_GPS2_hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    GPS2_hlt.u8day   = loc_day;
    GPS2_hlt.u8month = loc_mon;
    GPS2_hlt.u16year = loc_yr;
    GPS2_hlt.u8hrs   = loc_hrs;
    GPS2_hlt.u8min   = loc_min;
    GPS2_hlt.u8secs  = loc_sec;
    GPS2_hlt.u24absloc = 12345u;
    GPS2_hlt.u8actv_GPS_num = 1u;
    GPS2_hlt.u8view = 1u;
    GPS2_hlt.u8sec = 12u;
    GPS2_hlt.u8satellite_in_vw = 1u;
    GPS2_hlt.u8CNO = 12u;

    loco_evnt_buf[0]  = GPS2_hlt.u8day;
    loco_evnt_buf[1]  = GPS2_hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(GPS2_hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(GPS2_hlt.u16year >> 0u);
    loco_evnt_buf[4]  = GPS2_hlt.u8hrs;
    loco_evnt_buf[5]  = GPS2_hlt.u8min;
    loco_evnt_buf[6]  = GPS2_hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(GPS2_hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(GPS2_hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(GPS2_hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = GPS2_hlt.u8actv_GPS_num;
    loco_evnt_buf[11] = GPS2_hlt.u8view;
    loco_evnt_buf[12] = GPS2_hlt.u8sec;
    loco_evnt_buf[13] = GPS2_hlt.u8satellite_in_vw;
    loco_evnt_buf[14] = GPS2_hlt.u8CNO;


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 13u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Interface cards 1 , event Id : 14
 *****************************************************************************************************************/
void build_intrfc_crds1_hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    intrfc_crds1_hlt.u8day   = loc_day;
    intrfc_crds1_hlt.u8month = loc_mon;
    intrfc_crds1_hlt.u16year = loc_yr;
    intrfc_crds1_hlt.u8hrs   = loc_hrs;
    intrfc_crds1_hlt.u8min   = loc_min;
    intrfc_crds1_hlt.u8secs  = loc_sec;
    intrfc_crds1_hlt.u24absloc = 12345u;
    intrfc_crds1_hlt.u8VPMhlt = 1u;
    intrfc_crds1_hlt.u8VIChlt = 1u;
    intrfc_crds1_hlt.u8VIMhlt = 1u;
    intrfc_crds1_hlt.u8VOMhlt = 1u;
    intrfc_crds1_hlt.u8ADLhlt = 1u;

    loco_evnt_buf[0]  = intrfc_crds1_hlt.u8day;
    loco_evnt_buf[1]  = intrfc_crds1_hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(intrfc_crds1_hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(intrfc_crds1_hlt.u16year >> 0u);
    loco_evnt_buf[4]  = intrfc_crds1_hlt.u8hrs;
    loco_evnt_buf[5]  = intrfc_crds1_hlt.u8min;
    loco_evnt_buf[6]  = intrfc_crds1_hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(intrfc_crds1_hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(intrfc_crds1_hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(intrfc_crds1_hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = intrfc_crds1_hlt.u8VPMhlt;
    loco_evnt_buf[11] = intrfc_crds1_hlt.u8VIChlt;
    loco_evnt_buf[12] = intrfc_crds1_hlt.u8VIMhlt;
    loco_evnt_buf[13] = intrfc_crds1_hlt.u8VOMhlt;
    loco_evnt_buf[14] = intrfc_crds1_hlt.u8ADLhlt;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 14u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Interface cards 2 , event Id : 15
 *****************************************************************************************************************/
void build_intrfc_crds2_hlt_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    intrfc_crds2_hlt.u8day   = loc_day;
    intrfc_crds2_hlt.u8month = loc_mon;
    intrfc_crds2_hlt.u16year = loc_yr;
    intrfc_crds2_hlt.u8hrs   = loc_hrs;
    intrfc_crds2_hlt.u8min   = loc_min;
    intrfc_crds2_hlt.u8secs  = loc_sec;
    intrfc_crds2_hlt.u24absloc = 12345u;
    intrfc_crds2_hlt.u8VPMhlt = 1u;
    intrfc_crds2_hlt.u8VIChlt = 1u;
    intrfc_crds2_hlt.u8VIMhlt = 1u;
    intrfc_crds2_hlt.u8VOMhlt = 1u;
    intrfc_crds2_hlt.u8ADLhlt = 1u;

    loco_evnt_buf[0]  = intrfc_crds2_hlt.u8day;
    loco_evnt_buf[1]  = intrfc_crds2_hlt.u8month;
    loco_evnt_buf[2]  = (uint8)(intrfc_crds2_hlt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(intrfc_crds2_hlt.u16year >> 0u);
    loco_evnt_buf[4]  = intrfc_crds2_hlt.u8hrs;
    loco_evnt_buf[5]  = intrfc_crds2_hlt.u8min;
    loco_evnt_buf[6]  = intrfc_crds2_hlt.u8secs;
    loco_evnt_buf[7]  = (uint8)(intrfc_crds2_hlt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(intrfc_crds2_hlt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(intrfc_crds2_hlt.u24absloc >> 0u);
    loco_evnt_buf[10] = intrfc_crds2_hlt.u8VPMhlt;
    loco_evnt_buf[11] = intrfc_crds2_hlt.u8VIChlt;
    loco_evnt_buf[12] = intrfc_crds2_hlt.u8VIMhlt;
    loco_evnt_buf[13] = intrfc_crds2_hlt.u8VOMhlt;
    loco_evnt_buf[14] = intrfc_crds2_hlt.u8ADLhlt;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 15u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : EB connection status event , event Id : 16
 *****************************************************************************************************************/
void build_EB_cnctn_stat_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    EB_cnctn_stat_evnt.u8day   = loc_day;
    EB_cnctn_stat_evnt.u8month = loc_mon;
    EB_cnctn_stat_evnt.u16year = loc_yr;
    EB_cnctn_stat_evnt.u8hrs   = loc_hrs;
    EB_cnctn_stat_evnt.u8min   = loc_min;
    EB_cnctn_stat_evnt.u8secs  = loc_sec;
    EB_cnctn_stat_evnt.u24absloc = 12345u;
    EB_cnctn_stat_evnt.u8EBcnctn = 1u;

    loco_evnt_buf[0]  = EB_cnctn_stat_evnt.u8day;
    loco_evnt_buf[1]  = EB_cnctn_stat_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(EB_cnctn_stat_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(EB_cnctn_stat_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = EB_cnctn_stat_evnt.u8hrs;
    loco_evnt_buf[5]  = EB_cnctn_stat_evnt.u8min;
    loco_evnt_buf[6]  = EB_cnctn_stat_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(EB_cnctn_stat_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(EB_cnctn_stat_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(EB_cnctn_stat_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = EB_cnctn_stat_evnt.u8EBcnctn;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 16u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : kavach connection status event , event Id : 17
 *****************************************************************************************************************/
void build_kvch_cnctn_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    kvch_cnctn_event.u8day   = loc_day;
    kvch_cnctn_event.u8month = loc_mon;
    kvch_cnctn_event.u16year = loc_yr;
    kvch_cnctn_event.u8hrs   = loc_hrs;
    kvch_cnctn_event.u8min   = loc_min;
    kvch_cnctn_event.u8secs  = loc_sec;
    kvch_cnctn_event.u24absloc = 12345u;
    kvch_cnctn_event.u8KVCHcnctn = 1u;

    loco_evnt_buf[0]  = kvch_cnctn_event.u8day;
    loco_evnt_buf[1]  = kvch_cnctn_event.u8month;
    loco_evnt_buf[2]  = (uint8)(kvch_cnctn_event.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(kvch_cnctn_event.u16year >> 0u);
    loco_evnt_buf[4]  = kvch_cnctn_event.u8hrs;
    loco_evnt_buf[5]  = kvch_cnctn_event.u8min;
    loco_evnt_buf[6]  = kvch_cnctn_event.u8secs;
    loco_evnt_buf[7]  = (uint8)(kvch_cnctn_event.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(kvch_cnctn_event.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(kvch_cnctn_event.u24absloc >> 0u);
    loco_evnt_buf[10] = kvch_cnctn_event.u8KVCHcnctn;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 17u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : kavach territory exit or entry event , event Id : 18
 *****************************************************************************************************************/
void build_kvch_ter_ext_entry_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    kvch_ter_ext_entry.u8day   = loc_day;
    kvch_ter_ext_entry.u8month = loc_mon;
    kvch_ter_ext_entry.u16year = loc_yr;
    kvch_ter_ext_entry.u8hrs   = loc_hrs;
    kvch_ter_ext_entry.u8min   = loc_min;
    kvch_ter_ext_entry.u8secs  = loc_sec;
    kvch_ter_ext_entry.u24absloc = 12345u;
    kvch_ter_ext_entry.u8kvch_ext_ent = 1u;
    kvch_ter_ext_entry.u16stnIBSID = 12345u;

    loco_evnt_buf[0]  = kvch_ter_ext_entry.u8day;
    loco_evnt_buf[1]  = kvch_ter_ext_entry.u8month;
    loco_evnt_buf[2]  = (uint8)(kvch_ter_ext_entry.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(kvch_ter_ext_entry.u16year >> 0u);
    loco_evnt_buf[4]  = kvch_ter_ext_entry.u8hrs;
    loco_evnt_buf[5]  = kvch_ter_ext_entry.u8min;
    loco_evnt_buf[6]  = kvch_ter_ext_entry.u8secs;
    loco_evnt_buf[7]  = (uint8)(kvch_ter_ext_entry.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(kvch_ter_ext_entry.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(kvch_ter_ext_entry.u24absloc >> 0u);
    loco_evnt_buf[10] = kvch_ter_ext_entry.u8kvch_ext_ent;
    loco_evnt_buf[11] = (uint8)(kvch_ter_ext_entry.u16stnIBSID >> 8u);
    loco_evnt_buf[12] = (uint8)(kvch_ter_ext_entry.u16stnIBSID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 18u, 13u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : ETCS  exit or entry event , event Id : 19u
 *****************************************************************************************************************/
void build_ETCS_exit_or_entry_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    ETCS_exit_or_entry_evnt.u8day   = loc_day;
    ETCS_exit_or_entry_evnt.u8month = loc_mon;
    ETCS_exit_or_entry_evnt.u16year = loc_yr;
    ETCS_exit_or_entry_evnt.u8hrs   = loc_hrs;
    ETCS_exit_or_entry_evnt.u8min   = loc_min;
    ETCS_exit_or_entry_evnt.u8secs  = loc_sec;
    ETCS_exit_or_entry_evnt.u24absloc = 12345u;
    ETCS_exit_or_entry_evnt.u8ETCS_ext_ent = 1u;
    ETCS_exit_or_entry_evnt.u16etcsID = 1234u;

    loco_evnt_buf[0]  = ETCS_exit_or_entry_evnt.u8day;
    loco_evnt_buf[1]  = ETCS_exit_or_entry_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(ETCS_exit_or_entry_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(ETCS_exit_or_entry_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = ETCS_exit_or_entry_evnt.u8hrs;
    loco_evnt_buf[5]  = ETCS_exit_or_entry_evnt.u8min;
    loco_evnt_buf[6]  = ETCS_exit_or_entry_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(ETCS_exit_or_entry_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(ETCS_exit_or_entry_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(ETCS_exit_or_entry_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = ETCS_exit_or_entry_evnt.u8ETCS_ext_ent;
    loco_evnt_buf[11] = (uint8)(ETCS_exit_or_entry_evnt.u16etcsID >> 8u);
    loco_evnt_buf[12] = (uint8)(ETCS_exit_or_entry_evnt.u16etcsID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 19u, 13u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : train trip mode , event Id : 20
 *****************************************************************************************************************/
void build_trn_trip_mode_entry_evnt_pkkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    trn_trip_mode_entry_evnt.u8day   = loc_day;
    trn_trip_mode_entry_evnt.u8month = loc_mon;
    trn_trip_mode_entry_evnt.u16year = loc_yr;
    trn_trip_mode_entry_evnt.u8hrs   = loc_hrs;
    trn_trip_mode_entry_evnt.u8min   = loc_min;
    trn_trip_mode_entry_evnt.u8secs  = loc_sec;
    trn_trip_mode_entry_evnt.u24absloc = 12345u;
    trn_trip_mode_entry_evnt.u16refRFID = 12345u;

    loco_evnt_buf[0]  = trn_trip_mode_entry_evnt.u8day;
    loco_evnt_buf[1]  = trn_trip_mode_entry_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(trn_trip_mode_entry_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(trn_trip_mode_entry_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = trn_trip_mode_entry_evnt.u8hrs;
    loco_evnt_buf[5]  = trn_trip_mode_entry_evnt.u8min;
    loco_evnt_buf[6]  = trn_trip_mode_entry_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(trn_trip_mode_entry_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(trn_trip_mode_entry_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(trn_trip_mode_entry_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(trn_trip_mode_entry_evnt.u16refRFID >> 8u);
    loco_evnt_buf[11] = (uint8)(trn_trip_mode_entry_evnt.u16refRFID >> 0u);


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 20u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name : Over ride selected , event Id : 21
 *****************************************************************************************************************/
void build_ovrd_selected_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    ovrd_selected.u8day   = loc_day;
    ovrd_selected.u8month = loc_mon;
    ovrd_selected.u16year = loc_yr;
    ovrd_selected.u8hrs   = loc_hrs;
    ovrd_selected.u8min   = loc_min;
    ovrd_selected.u8secs  = loc_sec;
    ovrd_selected.u24absloc = 12345u;
    ovrd_selected.u16refRFID = 12345u;

    loco_evnt_buf[0]  = ovrd_selected.u8day;
    loco_evnt_buf[1]  = ovrd_selected.u8month;
    loco_evnt_buf[2]  = (uint8)(ovrd_selected.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(ovrd_selected.u16year >> 0u);
    loco_evnt_buf[4]  = ovrd_selected.u8hrs;
    loco_evnt_buf[5]  = ovrd_selected.u8min;
    loco_evnt_buf[6]  = ovrd_selected.u8secs;
    loco_evnt_buf[7]  = (uint8)(ovrd_selected.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(ovrd_selected.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(ovrd_selected.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(ovrd_selected.u16refRFID >> 8u);
    loco_evnt_buf[11] = (uint8)(ovrd_selected.u16refRFID >> 0u);


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 21u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :Turnout event  , event Id : 22
 *****************************************************************************************************************/
void build_trnout_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    trnout_event.u8day   = loc_day;
    trnout_event.u8month = loc_mon;
    trnout_event.u16year = loc_yr;
    trnout_event.u8hrs   = loc_hrs;
    trnout_event.u8min   = loc_min;
    trnout_event.u8secs  = loc_sec;
    trnout_event.u24absloc = 12345u;
    trnout_event.u8trnout_spd = 12u;
    trnout_event.u16trnout_dist = 150u;
    trnout_event.u16ref_RFID = 123u;

    loco_evnt_buf[0]  = trnout_event.u8day;
    loco_evnt_buf[1]  = trnout_event.u8month;
    loco_evnt_buf[2]  = (uint8)(trnout_event.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(trnout_event.u16year >> 0u);
    loco_evnt_buf[4]  = trnout_event.u8hrs;
    loco_evnt_buf[5]  = trnout_event.u8min;
    loco_evnt_buf[6]  = trnout_event.u8secs;
    loco_evnt_buf[7]  = (uint8)(trnout_event.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(trnout_event.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(trnout_event.u24absloc >> 0u);
    loco_evnt_buf[10] = trnout_event.u8trnout_spd;
    loco_evnt_buf[11] = (uint8)(trnout_event.u16trnout_dist >> 8u);
    loco_evnt_buf[12] = (uint8)(trnout_event.u16trnout_dist >> 0u);
    loco_evnt_buf[13] = (uint8)(trnout_event.u16ref_RFID >> 8u);
    loco_evnt_buf[14] = (uint8)(trnout_event.u16ref_RFID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 22u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :TSR event  , event Id : 23
 *****************************************************************************************************************/
void build_TSR_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    TSR_evnt.u8day   = loc_day;
    TSR_evnt.u8month = loc_mon;
    TSR_evnt.u16year = loc_yr;
    TSR_evnt.u8hrs   = loc_hrs;
    TSR_evnt.u8min   = loc_min;
    TSR_evnt.u8secs  = loc_sec;
    TSR_evnt.u24absloc = 12345u;
    TSR_evnt.u8TSR_spd = 12u;
    TSR_evnt.u16TSR_dist = 150u;
    TSR_evnt.u16ref_RFID = 123u;

    loco_evnt_buf[0]  = TSR_evnt.u8day;
    loco_evnt_buf[1]  = TSR_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(TSR_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(TSR_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = TSR_evnt.u8hrs;
    loco_evnt_buf[5]  = TSR_evnt.u8min;
    loco_evnt_buf[6]  = TSR_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(TSR_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(TSR_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(TSR_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = TSR_evnt.u8TSR_spd;
    loco_evnt_buf[11] = (uint8)(TSR_evnt.u16TSR_dist >> 8u);
    loco_evnt_buf[12] = (uint8)(TSR_evnt.u16TSR_dist >> 0u);
    loco_evnt_buf[13] = (uint8)(TSR_evnt.u16ref_RFID >> 8u);
    loco_evnt_buf[14] = (uint8)(TSR_evnt.u16ref_RFID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 23u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :PSR event  , event Id : 24
 *****************************************************************************************************************/
void build_PSR_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    PSR_evnt.u8day   = loc_day;
    PSR_evnt.u8month = loc_mon;
    PSR_evnt.u16year = loc_yr;
    PSR_evnt.u8hrs   = loc_hrs;
    PSR_evnt.u8min   = loc_min;
    PSR_evnt.u8secs  = loc_sec;
    PSR_evnt.u24absloc = 12345u;
    PSR_evnt.u8PSR = 12u;
    PSR_evnt.u16PSr_dist= 150u;
    PSR_evnt.refRFID = 123u;

    loco_evnt_buf[0]  = PSR_evnt.u8day;
    loco_evnt_buf[1]  = PSR_evnt.u8month;
    loco_evnt_buf[2]  = (uint8)(PSR_evnt.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(PSR_evnt.u16year >> 0u);
    loco_evnt_buf[4]  = PSR_evnt.u8hrs;
    loco_evnt_buf[5]  = PSR_evnt.u8min;
    loco_evnt_buf[6]  = PSR_evnt.u8secs;
    loco_evnt_buf[7]  = (uint8)(PSR_evnt.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(PSR_evnt.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(PSR_evnt.u24absloc >> 0u);
    loco_evnt_buf[10] = PSR_evnt.u8PSR;
    loco_evnt_buf[11] = (uint8)(PSR_evnt.u16PSr_dist >> 8u);
    loco_evnt_buf[12] = (uint8)(PSR_evnt.u16PSr_dist >> 0u);
    loco_evnt_buf[13] = (uint8)(PSR_evnt.refRFID >> 8u);
    loco_evnt_buf[14] = (uint8)(PSR_evnt.refRFID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 24u, 15u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :End of authority  , event Id : 25
 *****************************************************************************************************************/
void build_end_of_auth_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    end_of_authority.u8day   = loc_day;
    end_of_authority.u8month = loc_mon;
    end_of_authority.u16year = loc_yr;
    end_of_authority.u8hrs   = loc_hrs;
    end_of_authority.u8min   = loc_min;
    end_of_authority.u8secs  = loc_sec;
    end_of_authority.u24absloc = 12345u;
    end_of_authority.u16refRFID = 12345u;

    loco_evnt_buf[0]  = end_of_authority.u8day;
    loco_evnt_buf[1]  = end_of_authority.u8month;
    loco_evnt_buf[2]  = (uint8)(end_of_authority.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(end_of_authority.u16year >> 0u);
    loco_evnt_buf[4]  = end_of_authority.u8hrs;
    loco_evnt_buf[5]  = end_of_authority.u8min;
    loco_evnt_buf[6]  = end_of_authority.u8secs;
    loco_evnt_buf[7]  = (uint8)(end_of_authority.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(end_of_authority.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(end_of_authority.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(end_of_authority.u16refRFID >> 8u);
    loco_evnt_buf[11] = (uint8)(end_of_authority.u16refRFID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 25u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/*****************************************************************************************************************
                                   event name :Brake test status  , event Id : 26
 *****************************************************************************************************************/
void build_brk_test_stat_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    brk_test_status.u8day   = loc_day;
    brk_test_status.u8month = loc_mon;
    brk_test_status.u16year = loc_yr;
    brk_test_status.u8hrs   = loc_hrs;
    brk_test_status.u8min   = loc_min;
    brk_test_status.u8secs  = loc_sec;
    brk_test_status.u24absloc = 12345u;
    brk_test_status.u8brk_test_stat = 1u;

    loco_evnt_buf[0]  = brk_test_status.u8day;
    loco_evnt_buf[1]  = brk_test_status.u8month;
    loco_evnt_buf[2]  = (uint8)(brk_test_status.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(brk_test_status.u16year >> 0u);
    loco_evnt_buf[4]  = brk_test_status.u8hrs;
    loco_evnt_buf[5]  = brk_test_status.u8min;
    loco_evnt_buf[6]  = brk_test_status.u8secs;
    loco_evnt_buf[7]  = (uint8)(brk_test_status.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(brk_test_status.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(brk_test_status.u24absloc >> 0u);
    loco_evnt_buf[10] = brk_test_status.u8brk_test_stat;


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 26u, 11u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :Approaching radio hole  , event Id : 27
 *****************************************************************************************************************/
void build_appr_rad_hole_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    appr_radio_hole.u8day   = loc_day;
    appr_radio_hole.u8month = loc_mon;
    appr_radio_hole.u16year = loc_yr;
    appr_radio_hole.u8hrs   = loc_hrs;
    appr_radio_hole.u8min   = loc_min;
    appr_radio_hole.u8secs  = loc_sec;
    appr_radio_hole.u24absloc = 12345u;
    appr_radio_hole.u16ref_RFID = 12345u;
    appr_radio_hole.u16dist = 1234u;

    loco_evnt_buf[0]  = appr_radio_hole.u8day;
    loco_evnt_buf[1]  = appr_radio_hole.u8month;
    loco_evnt_buf[2]  = (uint8)(appr_radio_hole.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(appr_radio_hole.u16year >> 0u);
    loco_evnt_buf[4]  = appr_radio_hole.u8hrs;
    loco_evnt_buf[5]  = appr_radio_hole.u8min;
    loco_evnt_buf[6]  = appr_radio_hole.u8secs;
    loco_evnt_buf[7]  = (uint8)(appr_radio_hole.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(appr_radio_hole.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(appr_radio_hole.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(appr_radio_hole.u16ref_RFID >> 8u);
    loco_evnt_buf[11] = (uint8)(appr_radio_hole.u16ref_RFID >> 0u);
    loco_evnt_buf[12] = (uint8)(appr_radio_hole.u16dist >> 8u);
    loco_evnt_buf[13] = (uint8)(appr_radio_hole.u16dist >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 27u, 14u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :Entry into post trip mode  , event Id : 28
 *****************************************************************************************************************/
void build_entry_into_post_trp_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    entry_into_post_trip.u8day   = loc_day;
    entry_into_post_trip.u8month = loc_mon;
    entry_into_post_trip.u16year = loc_yr;
    entry_into_post_trip.u8hrs   = loc_hrs;
    entry_into_post_trip.u8min   = loc_min;
    entry_into_post_trip.u8secs  = loc_sec;
    entry_into_post_trip.u24absloc = 12345u;
    entry_into_post_trip.u16ref_RFID = 750u;

    loco_evnt_buf[0]  = entry_into_post_trip.u8day;
    loco_evnt_buf[1]  = entry_into_post_trip.u8month;
    loco_evnt_buf[2]  = (uint8)(entry_into_post_trip.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(entry_into_post_trip.u16year >> 0u);
    loco_evnt_buf[4]  = entry_into_post_trip.u8hrs;
    loco_evnt_buf[5]  = entry_into_post_trip.u8min;
    loco_evnt_buf[6]  = entry_into_post_trip.u8secs;
    loco_evnt_buf[7]  = (uint8)(entry_into_post_trip.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(entry_into_post_trip.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(entry_into_post_trip.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(entry_into_post_trip.u16ref_RFID >> 8u);
    loco_evnt_buf[11] = (uint8)(entry_into_post_trip.u16ref_RFID >> 0u);

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 28u, 12u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }

}

/*****************************************************************************************************************
                                   event name :Entry of loco into different zone  , event Id : 29
 *****************************************************************************************************************/
void build_entry_of_loco_into_differ_zone_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    entry_of_loco_into_differ_zone.u8day   = loc_day;
    entry_of_loco_into_differ_zone.u8month = loc_mon;
    entry_of_loco_into_differ_zone.u16year = loc_yr;
    entry_of_loco_into_differ_zone.u8hrs   = loc_hrs;
    entry_of_loco_into_differ_zone.u8min   = loc_min;
    entry_of_loco_into_differ_zone.u8secs  = loc_sec;
    entry_of_loco_into_differ_zone.u24absloc = 12345u;
    entry_of_loco_into_differ_zone.u16ref_RFID = 750u;
    entry_of_loco_into_differ_zone.u8zone_type = 1u;

    loco_evnt_buf[0]  = entry_of_loco_into_differ_zone.u8day;
    loco_evnt_buf[1]  = entry_of_loco_into_differ_zone.u8month;
    loco_evnt_buf[2]  = (uint8)(entry_of_loco_into_differ_zone.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(entry_of_loco_into_differ_zone.u16year >> 0u);
    loco_evnt_buf[4]  = entry_of_loco_into_differ_zone.u8hrs;
    loco_evnt_buf[5]  = entry_of_loco_into_differ_zone.u8min;
    loco_evnt_buf[6]  = entry_of_loco_into_differ_zone.u8secs;
    loco_evnt_buf[7]  = (uint8)(entry_of_loco_into_differ_zone.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(entry_of_loco_into_differ_zone.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(entry_of_loco_into_differ_zone.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(entry_of_loco_into_differ_zone.u16ref_RFID >> 8u);
    loco_evnt_buf[11] = (uint8)(entry_of_loco_into_differ_zone.u16ref_RFID >> 0u);
    loco_evnt_buf[12] = entry_of_loco_into_differ_zone.u8zone_type;


    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 29u, 13u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/*****************************************************************************************************************
                                   event name :Gradient profile ; event ID : 30
 *****************************************************************************************************************/
void build_grad_profile_event_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    grad_profile.u8day   = loc_day;
    grad_profile.u8month = loc_mon;
    grad_profile.u16year = loc_yr;
    grad_profile.u8hrs   = loc_hrs;
    grad_profile.u8min   = loc_min;
    grad_profile.u8secs  = loc_sec;
    grad_profile.u24absloc = 12345u;
    grad_profile.u16refRFID = 123u;
    grad_profile.u8auth_speed = 12u;
    grad_profile.u8grad_type = 1u;

    loco_evnt_buf[0]  = grad_profile.u8day;
    loco_evnt_buf[1]  = grad_profile.u8month;
    loco_evnt_buf[2]  = (uint8)(grad_profile.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(grad_profile.u16year >> 0u);
    loco_evnt_buf[4]  = grad_profile.u8hrs;
    loco_evnt_buf[5]  = grad_profile.u8min;
    loco_evnt_buf[6]  = grad_profile.u8secs;
    loco_evnt_buf[7]  = (uint8)(grad_profile.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(grad_profile.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(grad_profile.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(grad_profile.u16refRFID >> 8u);
    loco_evnt_buf[11] = (uint8)(grad_profile.u16refRFID >> 8u);
    loco_evnt_buf[12] = grad_profile.u8auth_speed;
    loco_evnt_buf[13] = grad_profile.u8grad_type;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 30u, 14u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/*****************************************************************************************************************
                                   event name : static speed profile ; event ID : 31
 *****************************************************************************************************************/
void build_static_spd_prof_evnt_pkt(void)
{
    uint8 i = 1u;

    update_loco_time_date();            /*Updating date and time*/

    static_spd_profile.u8day   = loc_day;
    static_spd_profile.u8month = loc_mon;
    static_spd_profile.u16year = loc_yr;
    static_spd_profile.u8hrs   = loc_hrs;
    static_spd_profile.u8min   = loc_min;
    static_spd_profile.u8secs  = loc_sec;
    static_spd_profile.u24absloc = 12345u;
    static_spd_profile.u16refRFID = 123u;
    static_spd_profile.u8auth_speed = 25u;

    loco_evnt_buf[0]  = static_spd_profile.u8day;
    loco_evnt_buf[1]  = static_spd_profile.u8month;
    loco_evnt_buf[2]  = (uint8)(static_spd_profile.u16year >> 8u);
    loco_evnt_buf[3]  = (uint8)(static_spd_profile.u16year >> 0u);
    loco_evnt_buf[4]  = static_spd_profile.u8hrs;
    loco_evnt_buf[5]  = static_spd_profile.u8min;
    loco_evnt_buf[6]  = static_spd_profile.u8secs;
    loco_evnt_buf[7]  = (uint8)(static_spd_profile.u24absloc >> 16u);
    loco_evnt_buf[8]  = (uint8)(static_spd_profile.u24absloc >> 8u);
    loco_evnt_buf[9]  = (uint8)(static_spd_profile.u24absloc >> 0u);
    loco_evnt_buf[10] = (uint8)(static_spd_profile.u16refRFID >> 8u);
    loco_evnt_buf[11] = (uint8)(static_spd_profile.u16refRFID >> 0u);
    loco_evnt_buf[12] = static_spd_profile.u8auth_speed;

    send_loco_evnt_pkt_to_log(LOCO_CRITICAL_DATA, 31u, 13u, loco_evnt_buf );

    for(i = 0u; i < 40u; i++)
    {
        loco_evnt_buf[i] = 0u;
    }
}

/**************************************CAN Packet Build function*************************************/
void Build_LiveData_event(void)
{

    uint32 u32Framenumber = 123467u;
    uint8 u8GPSDate = 4u;
    uint8 u8GPSMonth = 12u;
    uint16 u16GPSYear = 2024u;
    uint16 u16MA = 680u;
    uint32 u32SSP_available_Dist = 2341u;
    uint8 u32mrsp = 25u;
    uint16 u16EOA_dist = 450u;
    uint16 u16SSP_EOA_Dist = 220u;
    uint32 u32DistfrmTag = 738u;
    uint32 u32Abs_Location = 1123u;
    uint16 u16Base_rfidTag = 245u;
    uint16 u16mabaseTag = 170u;
    uint8 u8Currmode = 3u;
    uint8 u8Prevmode = 2u;
    uint8 u8Ack_cause = 0u;
    uint8 u8SR_Transition_cause = 0u;
    uint8 u8Brake = 1u;
    uint8 u8SoS_Data = 5u;
    uint8 u8CollisionData_state = 0u;
    uint8 u8Radio_state = 1u;
    uint16 u16CollisionTarget_Dist = 772u;
    uint8 isARMandatory = 1u;
    uint8 isRegMandatory = 1u;
    uint8 Tagstate = 1u;
    uint8 TagSubState = 1u;
    uint8 DetectedInSRmode = 0u;
    uint8 u8Trackstate = 1u;
    uint8 u8LastfoundTagIdx = 1u;
    uint8 u8LastmissedTagIdx = 0u;
    uint8 u8ConsecutiveMissedTagCount = 1u;
    uint8 u8LastTLproID = 20u;
    uint16 u16MissedTagDist = 282u;
    uint16 u16ComputeDistance = 120u;
    uint8 eTagstate = 1u;
    uint16 u16NextPSRDist = 345u;
    uint16 u16NextApproachingSpeed = 35u;
    uint8 u16SectionSpeedlinmit = 30u;
    uint8 u16NxtTsrSpeed = 10u;
    uint16 u16TSR_Dist = 112u;
    uint16 u16TsrSpeedLimit = 60u;
    uint8 u8SSPMA_Avail = 0u;
    uint8 MA_Override_Dist = 240u;
    uint8 isSFTag_Crossed = 0u;
    uint8 u8MA_standalone_packet = 2u;
    uint8 u8Speed_final = 60u;
    uint8 u8NZ_permitted_speed = 0u;
    uint8 u8Override = 0u;
    uint8 u8Direction = 1u;
    uint8 u8TLM_State = 0u;
    uint32 u32TempstartLoc = 4321u;
    uint8 u8spervision_type = 2u;


    u8message_Box6[0] = (u32Framenumber >> 24) & 0xff;
    u8message_Box6[1] = (u32Framenumber >> 16)& 0xff;
    u8message_Box6[2] = (u32Framenumber >> 8) & 0xff;
    u8message_Box6[3] = (u32Framenumber >> 0) & 0xff;
    u8message_Box6[4] = u8GPSDate;
    u8message_Box6[5] = u8GPSMonth;
    u8message_Box6[6] = (u16GPSYear >> 8);
    u8message_Box6[7] = (u16GPSYear >> 0);
    can_msg_send(27);
    wait(1000u);

    u8message_Box6[0] = 0x00u;
    u8message_Box6[1] = (u16MA >> 8);
    u8message_Box6[2] = (u16MA >> 0);
    u8message_Box6[3] = (u32SSP_available_Dist >> 24u) & 0xffu;
    u8message_Box6[4] = (u32SSP_available_Dist >> 16u) & 0xffu;
    u8message_Box6[5] = (u32SSP_available_Dist >> 8u) & 0xffu;
    u8message_Box6[6] = (u32SSP_available_Dist >> 0u) & 0xffu;
    u8message_Box6[7] = u32mrsp;
    can_msg_send(28);
    wait(1000u);

    u8message_Box6[0] = (u16EOA_dist >> 8u);
    u8message_Box6[1] = (u16EOA_dist >> 0u);
    u8message_Box6[2] = (u16SSP_EOA_Dist >> 8u);
    u8message_Box6[3] = (u16SSP_EOA_Dist >> 0u);
    u8message_Box6[4] = (u32DistfrmTag >> 24u) & 0xffu;
    u8message_Box6[5] = (u32DistfrmTag >> 16u) & 0xffu;
    u8message_Box6[6] = (u32DistfrmTag >> 8u) & 0xffu;
    u8message_Box6[7] = (u32DistfrmTag >> 0u) & 0xffu;
    can_msg_send(29);
    wait(1000u);

    u8message_Box6[0] = (u32Abs_Location >> 24u) & 0xffu;
    u8message_Box6[1] = (u32Abs_Location >> 16u) & 0xffu;
    u8message_Box6[2] = (u32Abs_Location >> 8u) & 0xffu;
    u8message_Box6[3] = (u32Abs_Location >> 0u) & 0xffu;
    u8message_Box6[4] = (u16Base_rfidTag >> 8u) & 0xffu;
    u8message_Box6[5] = (u16Base_rfidTag >> 0u) & 0xffu;
    u8message_Box6[6] = (u16mabaseTag >> 8u) & 0xffu;
    u8message_Box6[7] = (u16mabaseTag >> 0u) & 0xffu;
    can_msg_send(30);
    wait(1000u);

    u8message_Box6[0] = u8Currmode;
    u8message_Box6[1] = u8Prevmode;
    u8message_Box6[2] = u8Ack_cause;
    u8message_Box6[3] = u8SR_Transition_cause;
    u8message_Box6[4] = u8Brake;
    u8message_Box6[5] = u8SoS_Data;
    u8message_Box6[6] = u8CollisionData_state;
    u8message_Box6[7] = u8Radio_state;
    can_msg_send(31);
    wait(1000u);

    u8message_Box6[0] = (u16CollisionTarget_Dist >> 8u ) & 0xffu;
    u8message_Box6[1] = (u16CollisionTarget_Dist >> 0u) & 0xffu;
    u8message_Box6[2] = isARMandatory;
    u8message_Box6[3] = isRegMandatory;
    u8message_Box6[4] = Tagstate;
    u8message_Box6[5] = TagSubState;
    u8message_Box6[6] = DetectedInSRmode;
    u8message_Box6[7] = u8Trackstate;
    can_msg_send(32);
    wait(1000u);

    u8message_Box6[0] = u8LastfoundTagIdx;
    u8message_Box6[1] = u8LastmissedTagIdx;
    u8message_Box6[2] = u8ConsecutiveMissedTagCount;
    u8message_Box6[3] = u8LastTLproID;
    u8message_Box6[4] = (u16MissedTagDist >> 8u) & 0xffu;
    u8message_Box6[5] = (u16MissedTagDist >> 0u) & 0xffu;
    u8message_Box6[6] = (u16ComputeDistance >> 8u) & 0xffu;
    u8message_Box6[7] = (u16ComputeDistance >> 0u) & 0xffu;
    can_msg_send(33);
    wait(1000u);


    u8message_Box6[0] = eTagstate;
    u8message_Box6[1] = eTagstate;
    u8message_Box6[2] = eTagstate;
    u8message_Box6[3] = eTagstate;
    u8message_Box6[4] = eTagstate;
    u8message_Box6[5] = eTagstate;
    u8message_Box6[6] = eTagstate;
    u8message_Box6[7] = eTagstate;
    can_msg_send(34);
    wait(1000u);


    u8message_Box6[0] = (u16NextPSRDist >> 8u) & 0xffu;
    u8message_Box6[1] = (u16NextPSRDist >> 0u) & 0xffu;
    u8message_Box6[2] = (u16NextApproachingSpeed >> 8u) & 0xffu;
    u8message_Box6[3] = (u16NextApproachingSpeed >> 0u) & 0xffu;
    u8message_Box6[4] = u16SectionSpeedlinmit;
    u8message_Box6[5] = u16NxtTsrSpeed;
    u8message_Box6[6] = (u16TSR_Dist >> 8u) & 0xffu;
    u8message_Box6[7] = (u16TSR_Dist >> 0u) & 0xffu;
    can_msg_send(35);
    wait(1000u);


    u8message_Box6[0] = (u16TsrSpeedLimit >> 8u) & 0xffu;
    u8message_Box6[1] = (u16TsrSpeedLimit >> 0u) & 0xffu;
    u8message_Box6[2] = u8SSPMA_Avail;
    u8message_Box6[3] = MA_Override_Dist;
    u8message_Box6[4] = isSFTag_Crossed;
    u8message_Box6[5] = u8MA_standalone_packet;
    u8message_Box6[6] = u8Speed_final;
    u8message_Box6[7] = u8NZ_permitted_speed;
    can_msg_send(36);
    wait(1000u);


    u8message_Box6[0] = u8Override;
    u8message_Box6[1] = u8Direction;
    u8message_Box6[2] = u8TLM_State;
    u8message_Box6[3] = (u32TempstartLoc >> 24u) & 0xffu;
    u8message_Box6[4] = (u32TempstartLoc >> 16u) & 0xffu;
    u8message_Box6[5] = (u32TempstartLoc >> 8u) & 0xffu;
    u8message_Box6[6] = (u32TempstartLoc >> 0u) & 0xffu;
    u8message_Box6[7] = u8spervision_type;
    can_msg_send(37);
    wait(1000u);

}


void Build_Critical_Event_Data(void)
{
    uint8 Event_ID = 2u;
    uint8 u8GPS_Month = 12u;
    uint8 u8GPS_Date = 4u;
    uint16 u16GPS_Year = 2024u;
    uint8 u8Hours = 10u;
    uint8 u8Minutes = 22u;
    uint8 u8Seconds = 46u;

    uint32 u32Abs_Loc = 2324u;
    uint32 u32Train_ID = 65522u;
    uint32 u32Abs_Location = 3424u;
    uint32 u32Source_loco_ID = 34242u;
    uint16 u16Collission_Target_Distance;

    uint8 u8BrakeTestResult = 1u;
    uint8 u8MBT_state = 2u;
    uint8 u8BIU_Auto_Test_Mode = 1u;
    uint8 u8Brake = 0u;
    uint8 u8BrakeCause = 10u;

    uint16 u16Emergency_status;
    uint8 u8Ack_Cause;


    u8message_Box6[0] = Event_ID;
    u8message_Box6[1] = u8GPS_Month;
    u8message_Box6[2] = u8GPS_Date;
    u8message_Box6[3] = (u16GPS_Year >> 8u);
    u8message_Box6[4] = (u16GPS_Year >> 0u);
    u8message_Box6[5] = u8Hours;
    u8message_Box6[6] = u8Minutes;
    u8message_Box6[7] = u8Seconds;
    can_msg_send(17);
    wait(1000u);


    u8message_Box6[0] = Event_ID;
    u8message_Box6[1] = (u32Abs_Loc >> 24u);
    u8message_Box6[2] = (u32Abs_Loc >> 16u);
    u8message_Box6[3] = (u32Abs_Loc >> 8u);
    u8message_Box6[4] = (u32Abs_Loc >> 0u);
    u8message_Box6[5] = 0u;
    u8message_Box6[6] = 0u;
    u8message_Box6[7] = 0u;
    can_msg_send(18);
    wait(1000u);

    /*u8message_Box6[0] = 83;
    u8message_Box6[1] = (u32Train_ID >> 24u);
    u8message_Box6[2] = (u32Train_ID >> 16u);
    u8message_Box6[3] = (u32Train_ID >> 8u);
    u8message_Box6[4] = (u32Train_ID >> 0u);
    u8message_Box6[5] = (u32Abs_Location >> 24u);
    u8message_Box6[6] = (u32Abs_Location >> 16u);
    u8message_Box6[7] = (u32Abs_Location >> 8u);
    can_msg_send(19);
    wait(1000u);

    u8message_Box6[0] = 83;
    u8message_Box6[1] = (u32Train_ID >> 24u);
    u8message_Box6[2] = (u32Train_ID >> 16u);
    u8message_Box6[3] = (u32Train_ID >> 8u);
    u8message_Box6[4] = (u32Train_ID >> 0u);
    u8message_Box6[5] = (u32Abs_Location >> 24u);
    u8message_Box6[6] = (u32Abs_Location >> 16u);
    u8message_Box6[7] = (u32Abs_Location >> 8u);
    can_msg_send(20);
    wait(1000u);*/

    u8message_Box6[0] = 2u;
    u8message_Box6[1] = 56u;
    u8message_Box6[2] = u8BrakeTestResult;
    u8message_Box6[3] = u8MBT_state;
    u8message_Box6[4] = u8BIU_Auto_Test_Mode;
    u8message_Box6[5] = u8Brake;
    u8message_Box6[6] = u8BrakeCause;
    u8message_Box6[7] = 0u;
    can_msg_send(20);
    wait(1000u);

    u8message_Box6[0] = 2u;
    u8message_Box6[1] = 75u;
    u8message_Box6[2] = (u16Emergency_status >> 8u);
    u8message_Box6[3] = (u16Emergency_status >> 0u);
    u8message_Box6[4] = u8Ack_Cause;
    u8message_Box6[5] = 0u;
    u8message_Box6[6] = 0u;
    u8message_Box6[7] = 0u;
    can_msg_send(20);
    wait(1000u);

}
