/*
 * loco_SD_card.c
 *
 *  Created on: Aug 27, 2024
 *      Author: HP
 */

#include "MAIN.h"
#include "sys_main.h"

uint8 ucLocoInfoMsgData[8] = {0u};
uint8 ucLocoMsgData[8] = {0u};

uint8 u8locolivedatalogbuf[200] = {0u};
uint8 u8locotrigmaintdatabuf[200] = {0u};
uint8 u8locotrigdatabuf[200] = {0u};
uint8 u8lococritdatabuf[200] = {0u};
uint8 u8locoSDcardbuf[200] = {0u};

uint64 locolivedatalinecnt = 0ul;
uint64 locotrigdatalinecnt = 0ul;
uint64 locotrigmaintdatalinecnt = 0ul;
uint64 lococritdatalinecnt = 0ul;

uint8 u8Event_cnt = 0u;
uint8 u8Event_type = 0u;
uint8 livepktcnt = 0u;

static can_data_t LCAN_Data;

/*********************************************************************************************************************
                               Function to create required files to log the loco event data
 **********************************************************************************************************************/

void init_SD_card_for_loco(void)
{
    SDCard_CreateFile("/LTRIGDAT.txt", "$TCAS data log!\r\n");

    SDCard_CreateFile("/LCRITDAT.txt", "$TCAS data log!\r\n");

    SDCard_CreateFile("/LLIVEDAT.txt", "$TCAS data log!\r\n");

    SDCard_CreateFile("/LTRGMDAT.txt", "$TCAS data log!\r\n");

}

/*********************************************************************************************************************
                               Function to send the event data packet through CAN to ADL
 **********************************************************************************************************************/
void send_loco_evnt_pkt_to_log(uint8 event_type, uint8 event_id, uint16 data_pkt_length, uint8 * log_data)
{

    ucLocoInfoMsgData[0] = event_type;                        /*event type*/
    ucLocoInfoMsgData[1] = event_id;                          /*event ID*/

    if(data_pkt_length < 8U)
    {
        ucLocoInfoMsgData[2] = 1U;
    }
    else if((data_pkt_length % 8U)  != 0U)                         /*CAN packet count*/
    {
        ucLocoInfoMsgData[2] = (uint8)((data_pkt_length / 8U) + 1U );
    }
    else{
        ucLocoInfoMsgData[2] = (uint8)(data_pkt_length / 8U);
    }

    ucLocoInfoMsgData[3] = 0x00U;                                     /*current packet index*/
    ucLocoInfoMsgData[4] = (uint8)data_pkt_length;                    /*Data packet length*/
    ucLocoInfoMsgData[5] = 0U;
    ucLocoInfoMsgData[6] = 0U;
    ucLocoInfoMsgData[7] = 0U;


    uint16 i = 1U,j = 1U;

    for(i = 0U; i < ucLocoInfoMsgData[2] ; i++ )
    {
        /*Updating current packet index*/
        ucLocoInfoMsgData[3] = ucLocoInfoMsgData[3] + 1U;

        ExtractLocoEventdata(1U);

        for(j = 0U; j < 8U; j++)
        {
            if(((i * 8U) + j) < data_pkt_length)
            {
                ucLocoMsgData[j] = log_data[((i * 8U) + j)];
            }
            else
            {
            }
        }

        ExtractLocoEventdata(2U);
        ucLocoMsgData[0] = 0U; ucLocoMsgData[1] = 0U; ucLocoMsgData[2] = 0U; ucLocoMsgData[4] = 0U; ucLocoMsgData[5] = 0U; ucLocoMsgData[6] = 0U; ucLocoMsgData[7] = 0U;
    }

}

/*********************************************************************************************************************
                               Function to extract the event data that has come through can protocol
 **********************************************************************************************************************/


/*
void ExtractLocoEventdata(uint8 i)
{

    if(i == (uint8)EVENTPKT1)
    {

        memcpy(LCAN_Data.u8EventLogData,ucMsgData,8u);
        LCAN_Data.U8EVENTPKTRXD1   = (uint8)EVENTPKT1;
        LCAN_Data.u8EventType      = LCAN_Data.u8EventLogData[0];           event type
        LCAN_Data.u8EventID        = LCAN_Data.u8EventLogData[1];           event ID
        LCAN_Data.u8EVENTCANPktCnt = LCAN_Data.u8EventLogData[2];           CAN packets count
        LCAN_Data.u8EVENTcurpktidx = LCAN_Data.u8EventLogData[3];           Current packet Index
        LCAN_Data.u8dataPktbyteCnt = LCAN_Data.u8EventLogData[4];            total data packet length
        LCAN_Data.U8EVENTPKTRXD2   = 0U;

    }
    else if((i == (uint8)EVENTPKT2) && (LCAN_Data.U8EVENTPKTRXD1== (uint8)EVENTPKT1))
    {
        if(LCAN_Data.u8EVENTCANPktCnt <= 127u)
        {
            LCAN_Data.U8EVENTPKTRXD2 = (uint8)EVENTPKT2;

            if((LCAN_Data.u8EVENTcurpktidx  == (LCAN_Data.u8EVENTprevpktidx + 1u)))
            {
                LCAN_Data.U8EVENTPKTRXD1 = 0u;
                memcpy(LCAN_Data.u8EventLogData1[LCAN_Data.u8EVENTcurpktidx],ucMsgData,8u);
                LCAN_Data.u8EVENTprevpktidx  =   LCAN_Data.u8EVENTcurpktidx ;

                if(LCAN_Data.u8EVENTcurpktidx == LCAN_Data.u8EVENTCANPktCnt)
                {
                     LCAN_Data.u8EVENTprevpktidx = 0u;

                     ProcessLocoEventdata(LCAN_Data.u8EventType);

                }

                LCAN_Data.u8EVENTcurpktidx = 0u;
            }
            else
            {
                LCAN_Data.u8EVENTcurpktidx = 0u;
                LCAN_Data.u8EVENTprevpktidx = 0u;
            }

        }
    }
    else
    {

    }
}
*/


/*
void ExtractLiveEventdata(uint8 i)
{

    if((i >= 27u) && (i <= 53u))
    {
        livepktcnt++;
        memcpy(LCAN_Data.u8EventLogData1[livepktcnt],u8CanMesg,8u);
        if( i == 53u)
        {
            gioSetBit(gioPORTB, 6u, 1u);
            u8Event_type = 0x93u;
            ProcessLocoEventdata(u8Event_type);
            livepktcnt = 0u;
            wait(500u);
            gioSetBit(gioPORTB, 6u, 0u);
        }
    }
}
*/


void ExtractLocoEventdata1(uint8 i)
{
    if((i == DATETIME_PKT) || (i == ABSLOC_PKT) || (i == DATA_PKT))
    {
        if(i == DATETIME_PKT)
        {
            memcpy(LCAN_Data.u8EventLogData1[0],u8CanMesg,8u);
            LCAN_Data.u8EVENTprevpktidx = DATETIME_PKT;
/*            u8Event_cnt++;  */
        }
        if((i == ABSLOC_PKT) && (LCAN_Data.u8EVENTprevpktidx == DATETIME_PKT))
        {
            memcpy(LCAN_Data.u8EventLogData1[1],u8CanMesg,8u);
            LCAN_Data.u8EVENTprevpktidx = ABSLOC_PKT;
/*            u8Event_cnt++;  */
        }
        if((i == DATA_PKT) && (LCAN_Data.u8EVENTprevpktidx == ABSLOC_PKT))
        {
            memcpy(LCAN_Data.u8EventLogData1[2],u8CanMesg,8u);
            LCAN_Data.u8EVENTprevpktidx = DATA_PKT;
/*            u8Event_cnt++;   */
        }

        if(((i == DATA_PKT) && (LCAN_Data.u8EVENTprevpktidx == DATA_PKT)))
        {
            LCAN_Data.u8EventType = LCAN_Data.u8EventLogData1[0][0];
            LCAN_Data.u8EventType = 0x02u;
            ProcessLocoEventdata(LCAN_Data.u8EventType);
            LCAN_Data.u8EVENTprevpktidx = SET_LOW;
            u8Event_cnt = 0u;
            KMStoNMS = 1u;
//            Loco_to_NMS_health_pkt_send();                                                    /* calling the NMS build packet function */
        }
    }
}



void ExtractLiveEventdata(uint8 i)
{

    if((i >= 27u) && (i <= 53u))
    {
        livepktcnt++;
        memcpy(LCAN_Data.u8EventLogData1[livepktcnt],u8CanMesg,8u);
        if( i == 53u)
        {
            u8Event_type = 0x93u;
            ProcessLocoEventdata(u8Event_type);
            livepktcnt = 0u;
        }

    }
}


void ExtractLocoEventdata(uint8 i)
{
    if(i > 0u)
    {
        memcpy(LCAN_Data.u8EventLogData1[u8Event_cnt],u8CanMesg,8u);

        u8Event_cnt++;

        if(u8Event_cnt == 3u)
        {
            u8Event_type = LCAN_Data.u8EventLogData1[2][1];
            ProcessLocoEventdata(u8Event_type);
            u8Event_cnt = 0u;
        }

    }
    else if((i == (uint8)EVENTPKT2) && (LCAN_Data.U8EVENTPKTRXD1== (uint8)EVENTPKT1))
    {
        if(LCAN_Data.u8EVENTCANPktCnt <= 127u)
        {
            LCAN_Data.U8EVENTPKTRXD2 = (uint8)EVENTPKT2;

            if((LCAN_Data.u8EVENTcurpktidx  == (LCAN_Data.u8EVENTprevpktidx + 1u)))
            {
                LCAN_Data.U8EVENTPKTRXD1 = 0u;
                memcpy(LCAN_Data.u8EventLogData1[LCAN_Data.u8EVENTcurpktidx],ucMsgData,8u);
                LCAN_Data.u8EVENTprevpktidx  =   LCAN_Data.u8EVENTcurpktidx ;

                if(LCAN_Data.u8EVENTcurpktidx == LCAN_Data.u8EVENTCANPktCnt)
                {
                     LCAN_Data.u8EVENTprevpktidx = 0u;

                     ProcessLocoEventdata(LCAN_Data.u8EventType);

                }

                LCAN_Data.u8EVENTcurpktidx = 0u;
            }
            else
            {
                LCAN_Data.u8EVENTcurpktidx = 0u;
                LCAN_Data.u8EVENTprevpktidx = 0u;
            }
        }
    }
    else
    {

    }
}

/*********************************************************************************************************************
                       Function to process the event data that has been received through CAN protocol
 **********************************************************************************************************************/


void ProcessLocoEventdata(uint8 u8EventType)
{

    LCAN_Data.u8EventType  =  u8EventType;

    uint8 u8index = 0U;
    uint8 u8subindex = 0U;

    loco_event_data_t loco_live_data;
    loco_event_data_t loco_trig_data;
    loco_event_data_t loco_trig_maint_data;
    loco_event_data_t loco_crit_data;

    /******************************************************************************************************************
                                     LOCO TRIGGERED DATA
     ******************************************************************************************************************/

    /*******************************************************ex********************************************************/
    if(LCAN_Data.u8EventType == CRITICAL_DATA)
    {
        /*uint8 u8Data = 0u;*/

        loco_crit_data.u8RecieveBuf[0] = LCAN_Data.u8EventLogData1[0][0];
        loco_crit_data.u8RecieveBuf[1] = LCAN_Data.u8EventType;
        loco_crit_data.u8RecieveBuf[2] = LCAN_Data.u8EventLogData1[0][1];
        loco_crit_data.u8RecieveBuf[3] = LCAN_Data.u8EventLogData1[0][2];
        loco_crit_data.u8RecieveBuf[4] = LCAN_Data.u8EventLogData1[0][3];
        loco_crit_data.u8RecieveBuf[5] = LCAN_Data.u8EventLogData1[0][4];
        loco_crit_data.u8RecieveBuf[6] = LCAN_Data.u8EventLogData1[0][5];
        loco_crit_data.u8RecieveBuf[7] = LCAN_Data.u8EventLogData1[0][6];
        loco_crit_data.u8RecieveBuf[8] = LCAN_Data.u8EventLogData1[0][7];
        loco_crit_data.u8RecieveBuf[9] = LCAN_Data.u8EventLogData1[1][4];
        loco_crit_data.u8RecieveBuf[10] = LCAN_Data.u8EventLogData1[1][5];
        loco_crit_data.u8RecieveBuf[11] = LCAN_Data.u8EventLogData1[1][6];
        loco_crit_data.u8RecieveBuf[12] = LCAN_Data.u8EventLogData1[1][1];
        loco_crit_data.u8RecieveBuf[13] = LCAN_Data.u8EventLogData1[1][2];
        loco_crit_data.u8RecieveBuf[14] = LCAN_Data.u8EventLogData1[1][3];

        loco_crit_data.u8RecieveBuf[15] = LCAN_Data.u8EventLogData1[2][2];
        /*u8Data = LCAN_Data.u8EventLogData1[2][3];
        loco_crit_data.u8RecieveBuf[16] = u8Data + 0x30u;*/
        loco_crit_data.u8RecieveBuf[16] = LCAN_Data.u8EventLogData1[2][3];
        loco_crit_data.u8RecieveBuf[17] = LCAN_Data.u8EventLogData1[2][4];
        WriteLocoCritDatatoSDCard((uint8*)loco_crit_data.u8RecieveBuf, loco_crit_data.u8EventID,  18u);

    }

/*********************Live data *************************************/
    if(LCAN_Data.u8EventType == (uint8)LOCO_LIVE_DATA)
    {
        for( u8index = 1u; u8index < 27;  u8index++)
        {
            for( u8subindex = 0u; u8subindex < 8u; u8subindex++)
            {
                loco_live_data.u8RecieveBuf[((((u8index - 1u) * 8u) + u8subindex ) + 3u)] = LCAN_Data.u8EventLogData1[u8index][u8subindex];
            }
        }
        WriteLocoLiveDatatoSDCard((uint8*)loco_live_data.u8RecieveBuf, loco_live_data.u8EventID, 186u);
    }
/************************************************************ex_end****************************************************/
/**************************************************************************************/
    if(LCAN_Data.u8EventType == (uint8)LOCO_TRIG_DATA)
    {
        LCAN_Data.u8EventType      =  LCAN_Data.u8EventLogData[0];
        loco_trig_data.u8EventID   =  LCAN_Data.u8EventLogData[1];

        loco_trig_data.u8RecieveBuf[0] = LCAN_Data.u8EventType;
        loco_trig_data.u8RecieveBuf[1] = loco_trig_data.u8EventID;
        loco_trig_data.u8RecieveBuf[2] = LCAN_Data.u8dataPktbyteCnt;

        for( u8index = 1u; u8index < (LCAN_Data.u8EVENTCANPktCnt + 1u);  u8index++)
        {
            for( u8subindex = 0u; u8subindex < 8u ; u8subindex++)
            {
                loco_trig_data.u8RecieveBuf[((((u8index - 1u) * 8u) + u8subindex ) + 3u)] = LCAN_Data.u8EventLogData1[u8index][u8subindex];

            }
        }
        WriteLocoTrigDatatoSDCard((uint8*)loco_trig_data.u8RecieveBuf, loco_trig_data.u8EventID,  LCAN_Data.u8dataPktbyteCnt);

    }
    else
    {
    }

    /******************************************************************************************************************
                                     LOCO LIVE DATA
     ******************************************************************************************************************/

    if(LCAN_Data.u8EventType == (uint8)LOCO_LIVE_DATA)
    {
        LCAN_Data.u8EventType      =  LCAN_Data.u8EventLogData[0];
        loco_live_data.u8EventID   =  LCAN_Data.u8EventLogData[1];

        loco_live_data.u8RecieveBuf[0] = LCAN_Data.u8EventType;
        loco_live_data.u8RecieveBuf[1] = loco_live_data.u8EventID;
        loco_live_data.u8RecieveBuf[2] = LCAN_Data.u8dataPktbyteCnt;

        for( u8index = 1u; u8index < (LCAN_Data.u8EVENTCANPktCnt + 1u);  u8index++)
        {
            for( u8subindex = 0u; u8subindex < 8u; u8subindex++)
            {
                loco_live_data.u8RecieveBuf[((((u8index - 1u) * 8u) + u8subindex ) + 3u)] = LCAN_Data.u8EventLogData1[u8index][u8subindex];
            }
        }
        WriteLocoLiveDatatoSDCard((uint8*)loco_live_data.u8RecieveBuf, loco_live_data.u8EventID,  LCAN_Data.u8dataPktbyteCnt);
    }
    else
    {
    }

    /******************************************************************************************************************
                                     LOCO TRIGGERED MAINTENANCE DATA
     ******************************************************************************************************************/

    if(LCAN_Data.u8EventType == (uint8)LOCO_TRIG_MAINT_DATA)
    {
        LCAN_Data.u8EventType      =  LCAN_Data.u8EventLogData[0];
        loco_crit_data.u8EventID   =  LCAN_Data.u8EventLogData[1];

        loco_trig_maint_data.u8RecieveBuf[0] = LCAN_Data.u8EventType;
        loco_trig_maint_data.u8RecieveBuf[1] = loco_trig_maint_data.u8EventID;
        loco_trig_maint_data.u8RecieveBuf[2] = LCAN_Data.u8dataPktbyteCnt;


        for( u8index = 1U; u8index < (LCAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
        {
            for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
            {
                loco_trig_maint_data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = LCAN_Data.u8EventLogData1[u8index][u8subindex];
            }
        }
        WriteLocoTrigmaintDatatoSDCard((uint8*)loco_trig_maint_data.u8RecieveBuf, loco_trig_maint_data.u8EventID,  LCAN_Data.u8dataPktbyteCnt);
    }
    else
    {
    }

    /******************************************************************************************************************
                                     LOCO CRITICAL DATA
     ******************************************************************************************************************/


    if(LCAN_Data.u8EventType == (uint8)LOCO_CRITICAL_DATA)
    {
        LCAN_Data.u8EventType            =  LCAN_Data.u8EventLogData[0];
        loco_crit_data.u8EventID   =  LCAN_Data.u8EventLogData[1];

        loco_crit_data.u8RecieveBuf[0] = LCAN_Data.u8EventType;
        loco_crit_data.u8RecieveBuf[1] = loco_crit_data.u8EventID;
        loco_crit_data.u8RecieveBuf[2] = LCAN_Data.u8dataPktbyteCnt;

        for( u8index = 1U; u8index < (LCAN_Data.u8EVENTCANPktCnt + 1U);  u8index++)
        {
            for( u8subindex = 0U; u8subindex < 8U ; u8subindex++)
            {
                loco_crit_data.u8RecieveBuf[((((u8index - 1U) * 8U) + u8subindex ) + 3U)] = LCAN_Data.u8EventLogData1[u8index][u8subindex];

            }
        }
        WriteLocoCritDatatoSDCard((uint8*)loco_crit_data.u8RecieveBuf, loco_crit_data.u8EventID,  LCAN_Data.u8dataPktbyteCnt);
    }
    else
    {
    }

}

/*****************************************************************************************************************************
                                Function to write  loco live data into SD card
 ******************************************************************************************************************************/

void WriteLocoLiveDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length)
{

    uint8 i = 1u;

    memcpy(u8locolivedatalogbuf,log_data,(( data_pkt_length)+3u));

    u8locoSDcardbuf[0] = 0x24u;
    u8locoSDcardbuf[1] = 0x31u;
    u8locoSDcardbuf[2] = 0x2Cu;

    memcpy(&u8locoSDcardbuf[3],u8locolivedatalogbuf,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/LLIVEDAT.txt", locolivedatalinecnt, 0, u8locoSDcardbuf, 'W', (data_pkt_length + 6u));

    for(i = 0u; i < 200u; i++)
    {
        u8locoSDcardbuf[i] = 0u;
        u8locolivedatalogbuf[i] = 0u;
    }

}

/*****************************************************************************************************************************
                                Function to write loco Trig maintenance data into SD card
******************************************************************************************************************************/


void WriteLocoTrigmaintDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length)
{
    uint8 i = 1u;

    memcpy(u8locotrigmaintdatabuf,log_data,(( data_pkt_length)+3u));

    u8locoSDcardbuf[0] = 0x24u;
    u8locoSDcardbuf[1] = 0x31u;
    u8locoSDcardbuf[2] = 0x2Cu;

    memcpy(&u8locoSDcardbuf[3],u8locotrigmaintdatabuf,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/LTRGMDAT.txt", locotrigmaintdatalinecnt, 0, u8locoSDcardbuf, 'W', (data_pkt_length + 6u));

    for(i = 0u; i < 200u; i++)
    {
        u8locoSDcardbuf[i] = 0u;
        u8locotrigmaintdatabuf[i] = 0u;
    }

}

/*****************************************************************************************************************************
                                Function to write  loco Triggered data into SD card
 ******************************************************************************************************************************/


void WriteLocoTrigDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length)
{
    uint8 i = 1u;

    memcpy(u8locotrigdatabuf,log_data,(( data_pkt_length)+3u));

    u8locoSDcardbuf[0] = 0x24u;
    u8locoSDcardbuf[1] = 0x31u;
    u8locoSDcardbuf[2] = 0x2Cu;

    memcpy(&u8locoSDcardbuf[3],u8locotrigdatabuf,(( data_pkt_length)+3u));

    SDCard_SeekPipe("/LTRIGDAT.txt", locotrigdatalinecnt, 0, u8locoSDcardbuf, 'W', (data_pkt_length + 6u));

    for(i = 0u; i < 200u; i++)
    {
        u8locoSDcardbuf[i] = 0u;
        u8locotrigdatabuf[i] = 0u;
    }

}

/*****************************************************************************************************************************
                                Function to write  loco critical data into SD card
******************************************************************************************************************************/


void WriteLocoCritDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length)
{
    uint8 i = 1u;

    memcpy(u8lococritdatabuf,log_data,(( data_pkt_length)+0u));

    u8locoSDcardbuf[0] = 0x24u;
    u8locoSDcardbuf[1] = 0x31u;
    u8locoSDcardbuf[2] = 0x2Cu;
    u8locoSDcardbuf[3] = 18u;


    memcpy(&u8locoSDcardbuf[4],u8lococritdatabuf,(( data_pkt_length)+4u));

    SDCard_SeekPipe("/LCRITDAT.txt", lococritdatalinecnt, 0, u8locoSDcardbuf, 'W', (data_pkt_length + 4u));

    for(i = 0u; i < 200u; i++)
    {
        u8locoSDcardbuf[i] = 0u;
        u8lococritdatabuf[i] = 0u;
    }

}



/*********************************************dummy data packet*******************************************/

void BuildExtLiveData(void)
{
  uint32_t u32FrameNumber = 123456u;
  ucMsgTxBOX8[0] = (u32FrameNumber >> 24u);
  ucMsgTxBOX8[1] = (u32FrameNumber >> 16u);
  ucMsgTxBOX8[2] = (u32FrameNumber >> 8u);
  ucMsgTxBOX8[3] = (u32FrameNumber >> 0u);
  ucMsgTxBOX8[4] = 7u;
  ucMsgTxBOX8[5] = 12u;
  ucMsgTxBOX8[6] = 0x07u;
  ucMsgTxBOX8[7] = 0xE8u;
  can_msg_send(EXT_DIAGNOSTIC1);
  wait(1000u);


  uint32 u32SSPAvailableDist = 123456u;
  ucMsgTxBOX8[0] = 1u;
  ucMsgTxBOX8[1] = 0x01u;
  ucMsgTxBOX8[2] = 0x18u;
  ucMsgTxBOX8[3] = (u32SSPAvailableDist >> 24u);
  ucMsgTxBOX8[4] = (u32SSPAvailableDist >> 16u);
  ucMsgTxBOX8[5] = (u32SSPAvailableDist >> 8u);
  ucMsgTxBOX8[6] = (u32SSPAvailableDist >> 0u);
  ucMsgTxBOX8[7] = 25u;
  can_msg_send(EXT_DIAGNOSTIC2);
  wait(1000u);


  uint16_t u16DistancefromTag = 550u;
  uint16_t u32EOADist = 234u;
  uint16_t u32EOA1Dist = 743u;
  uint16_t u16CurTag=668u;
  ucMsgTxBOX8[0] = (u32EOADist >> 8u);
  ucMsgTxBOX8[1] = (u32EOADist >> 0u);
  ucMsgTxBOX8[2] = (u32EOA1Dist >> 8u);
  ucMsgTxBOX8[3] = (u32EOA1Dist >> 0u);
  ucMsgTxBOX8[4] = (u16DistancefromTag >> 8u);
  ucMsgTxBOX8[5] = (u16DistancefromTag >> 0u);
  ucMsgTxBOX8[6] = (u16CurTag >> 8u);
  ucMsgTxBOX8[7] = (u16CurTag >> 0u);
  can_msg_send(EXT_DIAGNOSTIC3);
  wait(1000u);



  uint32_t u32ABSLoc = 5375731u;
  uint16_t u16BaseRefRFIDTag = 535u;
  uint16_t u16mabasetag = 6741u;
  ucMsgTxBOX8[0] = (u32ABSLoc >> 24u);
  ucMsgTxBOX8[1] = (u32ABSLoc >> 16u);
  ucMsgTxBOX8[2] = (u32ABSLoc >> 8u);
  ucMsgTxBOX8[3] = (u32ABSLoc >> 0u);
  ucMsgTxBOX8[4] = (u16BaseRefRFIDTag >> 8u);
  ucMsgTxBOX8[5] = (u16BaseRefRFIDTag >> 0u);
  ucMsgTxBOX8[6] = (u16mabasetag >> 8u);
  ucMsgTxBOX8[7] = (u16mabasetag >> 0u);
  can_msg_send(EXT_DIAGNOSTIC4);
  wait(1000u);


  uint8_t u8SoSData = 6u;
  ucMsgTxBOX8[0] =  4u;
  ucMsgTxBOX8[1] =  3u;
  ucMsgTxBOX8[2] =  0u;
  ucMsgTxBOX8[3] =  0u;
  ucMsgTxBOX8[4] =  0u;
  ucMsgTxBOX8[5] =  u8SoSData;
  ucMsgTxBOX8[6] =  1u;
  ucMsgTxBOX8[7] =  2u;
  can_msg_send(EXT_DIAGNOSTIC5);
  wait(1000u);



  uint16_t u16CollisionTargetDist = 354u;
  ucMsgTxBOX8[0] =  (u16CollisionTargetDist >> 8u);
  ucMsgTxBOX8[1] =  (u16CollisionTargetDist >> 0u);
  ucMsgTxBOX8[2] =  1u;
  ucMsgTxBOX8[3] =  0u;
  ucMsgTxBOX8[4] =  0u;
  ucMsgTxBOX8[5] =  0u;
  ucMsgTxBOX8[6] =  1u;
  ucMsgTxBOX8[7] =  0u;
  can_msg_send(EXT_DIAGNOSTIC6);
  wait(1000u);



  uint16_t u16MissedTagDistance = 345u;
  uint16_t u16ComputeDistance = 452u;
  ucMsgTxBOX8[0] =  4u;
  ucMsgTxBOX8[1] =  2u;
  ucMsgTxBOX8[2] =  1u;
  ucMsgTxBOX8[3] =  35u;
  ucMsgTxBOX8[4] =  ((u16MissedTagDistance >> 8u));
  ucMsgTxBOX8[5] =  ((u16MissedTagDistance >> 0u));
  ucMsgTxBOX8[6] =  ((u16ComputeDistance >> 8u));
  ucMsgTxBOX8[7] =  ((u16ComputeDistance >> 0u));
  can_msg_send(EXT_DIAGNOSTIC7);
  wait(1000u);


  uint8_t u8index = 0;
  for(u8index = 0u; u8index < 8u; u8index++)
  {
    ucMsgTxBOX8[u8index] =  1u;
  }
  can_msg_send(EXT_DIAGNOSTIC8);
  wait(1000u);


  uint16_t u16NextPSRDist = 453u;
  uint16_t u16NextApproachingSpeed = 235u;
  uint16_t u16tsrdist = 352u;
  ucMsgTxBOX8[0] =  (u16NextPSRDist >> 8u);
  ucMsgTxBOX8[1] =  (u16NextPSRDist >> 0u);
  ucMsgTxBOX8[2] =  (u16NextApproachingSpeed >> 8u);
  ucMsgTxBOX8[3] =  (u16NextApproachingSpeed >> 0u);
  ucMsgTxBOX8[4] =  35u;
  ucMsgTxBOX8[5] =  40u;
  ucMsgTxBOX8[6] =  (u16tsrdist >> 8u);
  ucMsgTxBOX8[7] =  (u16tsrdist >> 0u);
  can_msg_send(EXT_DIAGNOSTIC9);
  wait(1000u);


  uint16_t u16tsrspeedlimit = 463u;
  ucMsgTxBOX8[0] =  (u16tsrspeedlimit >> 8u);
  ucMsgTxBOX8[1] =  (u16tsrspeedlimit >> 0u);
  ucMsgTxBOX8[2] =  1u;
  ucMsgTxBOX8[3] =  2u;
  ucMsgTxBOX8[4] =  0u;
  ucMsgTxBOX8[5] =  1u;
/*  ucMsgTxBOX8[2] =  error_2oo2[TVCOMBOARD1].u8packettype;
  ucMsgTxBOX8[3] =  error_2oo2[TVCOMBOARD1].u8packetoffset;
  ucMsgTxBOX8[4] =  error_2oo2[TVCOMBOARD1].u8byteoffset;
  ucMsgTxBOX8[5] =  error_2oo2[TVCOMBOARD2].u8packettype;*/
  ucMsgTxBOX8[6] = 0u;
  ucMsgTxBOX8[7] = 0u;
  can_msg_send(EXT_DIAGNOSTIC10);
  wait(1000u);


  uint32_t tempstartloc = 34546u;
  uint32_t tempendloc = 7553u;

  ucMsgTxBOX8[0] =  1u;
  ucMsgTxBOX8[1] =  1u;
  ucMsgTxBOX8[2] =  0u;
  ucMsgTxBOX8[3] =  (tempstartloc >> 24u);
  ucMsgTxBOX8[4] =  (tempstartloc >> 16u);
  ucMsgTxBOX8[5] =  (tempstartloc >> 8u);
  ucMsgTxBOX8[6] =  (tempstartloc >> 0u);
  ucMsgTxBOX8[7] =  1u;
  can_msg_send(EXT_DIAGNOSTIC11);
  wait(1000u);



  uint8_t fVp_WithOverlap_kmph = 120u;
  uint8_t fVsbi_WithOverlap_kmph = 45u;
  uint8_t fVw_WithOverlap_kmph = 34u;
  uint8_t fVebi_WithOverlap_kmph = 67u;
  ucMsgTxBOX8[0] =  (tempendloc >> 24u);
  ucMsgTxBOX8[1] =  (tempendloc >> 16u);
  ucMsgTxBOX8[2] =  (tempendloc >> 8u);
  ucMsgTxBOX8[3] =  (tempendloc >> 0u);
  ucMsgTxBOX8[4] =  fVp_WithOverlap_kmph;
  ucMsgTxBOX8[5] =  fVw_WithOverlap_kmph;
  ucMsgTxBOX8[6] =  fVsbi_WithOverlap_kmph;
  ucMsgTxBOX8[7] =  fVebi_WithOverlap_kmph;
  can_msg_send(EXT_DIAGNOSTIC12);
  wait(1000u);

}
//*******************************************************************************************
void BuildCriticalLiveData(void)
{
    uint32_t u32FrameNumber = 2345u;

    ucMsgTxBOX8[0] = (u32FrameNumber >> 24) & 0xff;
    ucMsgTxBOX8[1] = (u32FrameNumber >> 16) & 0xff;
    ucMsgTxBOX8[2] = (u32FrameNumber >> 8) & 0xff;
    ucMsgTxBOX8[3] = (u32FrameNumber >> 0) & 0xff;
    ucMsgTxBOX8[4] = 12u;
    ucMsgTxBOX8[5] = 12u;
    ucMsgTxBOX8[6] = 0x07u;
    ucMsgTxBOX8[7] = 0xE8u;
    can_msg_send(EXT_CRITICAL1);
    wait(1000u);


    ucMsgTxBOX8[0] = 4u;
    ucMsgTxBOX8[1] = 7u;
    ucMsgTxBOX8[2] = 5u;
    ucMsgTxBOX8[3] = 2u;
    ucMsgTxBOX8[4] = 2u;
    ucMsgTxBOX8[5] = 0u;
    ucMsgTxBOX8[6] = 0u;
    ucMsgTxBOX8[7] = 1u;
    can_msg_send(EXT_CRITICAL2);
    wait(1000u);

    ucMsgTxBOX8[0] = 1u;
    ucMsgTxBOX8[1] = 1u;
    ucMsgTxBOX8[2] = 1u;
    ucMsgTxBOX8[3] = 0u;
    ucMsgTxBOX8[4] = 0u;
    ucMsgTxBOX8[5] = 0u;
    ucMsgTxBOX8[6] = 0u;
    ucMsgTxBOX8[7] = 0u;
    can_msg_send(EXT_CRITICAL3);
    wait(1000u);

    ucMsgTxBOX8[0] =  0u;
    ucMsgTxBOX8[1] =  0u;
    ucMsgTxBOX8[2] =  0u;
    ucMsgTxBOX8[3] =  0u;
    ucMsgTxBOX8[4] =  1u;
    ucMsgTxBOX8[5] =  0u;
    ucMsgTxBOX8[6] =  0u;
    ucMsgTxBOX8[7] =  0u;
    can_msg_send(EXT_CRITICAL4);
    wait(1000u);


    ucMsgTxBOX8[0] =  1u;
    ucMsgTxBOX8[1] =  0u;
    ucMsgTxBOX8[2] =  1;
    ucMsgTxBOX8[3] =  1u;
    ucMsgTxBOX8[4] =  0u;
    ucMsgTxBOX8[5] =  0u;
    ucMsgTxBOX8[6] =  0u;
    ucMsgTxBOX8[7] =  0u;
    can_msg_send(EXT_CRITICAL5);
    wait(1000u);


    uint16_t i16Radio_RSSI = 128u;
    ucMsgTxBOX8[0] =  i16Radio_RSSI >> 8;
    ucMsgTxBOX8[1] =  i16Radio_RSSI >> 0;
    ucMsgTxBOX8[2] =  12u;
    ucMsgTxBOX8[3] =  1u;
    ucMsgTxBOX8[4] =  0u;
    ucMsgTxBOX8[5] =  1u;
    ucMsgTxBOX8[6] =  1u;
    ucMsgTxBOX8[7] =  0u;
    can_msg_send(EXT_CRITICAL6);
    wait(1000u);


    ucMsgTxBOX8[0] =  i16Radio_RSSI >> 8;
    ucMsgTxBOX8[1] =  i16Radio_RSSI >> 0;
    ucMsgTxBOX8[2] =  18u;
    ucMsgTxBOX8[3] =  0;
    ucMsgTxBOX8[4] =  0;
    ucMsgTxBOX8[5] =  0;
    ucMsgTxBOX8[6] =  0;
    ucMsgTxBOX8[7] =  0;
    can_msg_send(EXT_CRITICAL7);
    wait(1000u);


    uint8_t u8keyindex = 0u;
    for(u8keyindex = 0u ; u8keyindex < 8u ; u8keyindex++)
    {
        ucMsgTxBOX8[u8keyindex] = 1u;
    }
    can_msg_send(EXT_CRITICAL8);
    wait(1000u);


    for(u8keyindex = 0u ; u8keyindex < 8u ; u8keyindex++)
    {
        ucMsgTxBOX8[u8keyindex] = 2u;
    }
    can_msg_send(EXT_CRITICAL9);
    wait(1000u);


    for(u8keyindex = 0u ; u8keyindex < 8u ; u8keyindex++)
    {
        ucMsgTxBOX8[u8keyindex] = 3u;
    }
    can_msg_send(EXT_CRITICAL10);
    wait(1000u);

    for(u8keyindex = 0u ; u8keyindex < 8u ; u8keyindex++)
    {
        ucMsgTxBOX8[u8keyindex] = 4u;
    }
    can_msg_send(EXT_CRITICAL11);
    wait(1000u);

}




