/*
 * atf_test.c
 *
 *  Created on: Jul 19, 2024
 *  Author: UDAY KIRAN
 */

#include "MAIN.h"

/*uint8 u8uart1_temp = 0u;
uint8 u8uart1_buf[120] = {0u};
uint8 u8uart1_buf_size = 0u;

uint8 u8uart2_temp = 0u;
uint8 u8uart2_buf[120] = {0u};
uint8 u8uart2_buf_size = 0u;*/



 /********************************************************************************************************
                                          UART Interrupt Handler
  ********************************************************************************************************/
/*
 void sciNotification(sciBASE_t *sci, uint32 flags)
 {
     if(sci == scilinREG)
     {
             sciReceive(scilinREG, 1u, (uint8_t *) &command);
             if(size > 1999u)
             {
                 size = 0u;
                 Clear_Buffer1();

             }
             Receive_Data[size] = command;
             size++;

             Rx_size = size;

             flag = 1u;
         }
     else if((sci == (sciBASE_t *)UART2))
     {
         if(u8uart2_buf_size == 120u)
         {
             u8uart2_buf_size = 0u;
         }
         else
         {

         }

         sciReceive((sciBASE_t *)UART2, (uint32)1u, (uint8 *)&u8uart2_temp);

         u8uart2_buf[u8uart2_buf_size] = u8uart2_temp;

         u8uart2_buf_size++;


         if (((u8uart2_buf[u8uart2_buf_size - 2u] == 0x0Du) && (u8uart2_buf[u8uart2_buf_size - 1u] == 0x0Au)))
         {
             if (u8uart2_buf[0] == '$')
             {
                 ScilinRxd = (bool) SET_HIGH;
             }

             if(((u8uart2_buf[0] == 0xAAu) && (u8uart2_buf[1] == 0xCCu)))
             {
                 ATP.isTestDataRxd = (bool) SET_HIGH;
                 memcpy(ATP.u8ATPTestData, u8uart2_buf, u8uart2_buf_size);
                 u8uart2_buf_size = 0u;
             }
             else
             {

             }
         }
         else
         {

         }



         if(((u8uart2_buf[0] == 0xAAu) && (u8uart2_buf[1] == 0xBBu)))
         {
             if(((u8uart2_buf[u8uart2_buf_size - 2u] == 0x0Du) && (u8uart2_buf[u8uart2_buf_size - 1u] == 0x0Au)))
             {
//                 if(((u8uart2_buf[0] == 0xAAu) && (u8uart2_buf[1] == 0xBBu)))
//                 {
                  if(u8uart2_buf[5] == 0x80u)
                  {
                      u8USBlink_checkpkt_rcvd = 1u;

                  }
                  else if(u8uart2_buf[5] == 0x81u)
                  {
                      u8USBdatadwnldstart_pkt_rcvd = 1u;

                  }
                  else if(u8uart2_buf[5] == 0x82u)
                  {
                      u8USBdatadwnldstop_pkt_rcvd = 1u;
                      u8contCommun == 0u;

                  }
                  else
                  {

                  }
             }
         }
         else
         {

         }
     }
     else
     {

     }
 }


  void sciDisplayText(sciBASE_t *sci, uint8 *text,uint32 length)
  {
      while(length--)
      {
          while ((UART2->FLR & 0x4) == 4);
          sciSendByte(UART2,*text++);
      };
  }
*/


