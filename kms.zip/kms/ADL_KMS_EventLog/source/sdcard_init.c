/*-----------------------------------------------------------------------*/
/* MMC/SDC (in SPI mode) control module  (C)ChaN, 2007                   */
/*-----------------------------------------------------------------------*/
/* Only rcvr_spi(), xmit_spi(), disk_timerproc() and some macros         */
/* are platform dependent.                                               */
/*-----------------------------------------------------------------------*/

/*
 * This file was modified from a sample available from the FatFs
 * web site. It was modified to work with an TMS570LC1227 development
 * board.
 */

#include "MAIN.h"
#include "diskio.h"
#include "ff.h"

FATFS g_sFatFs1;

spiDAT1_t dataconfig1_t;

uint8 flag = 0u;

#define DETECTED         (0u)
#define NOT_DETECTED     (1u)


/* Definitions for MMC/SDC command */
#define CMD0     (0x40U+0U)     /* GO_IDLE_STATE      */
#define CMD1     (0x40U+1U)     /* SEND_OP_COND       */
#define CMD8     (0x40U+8U)     /* SEND_IF_COND       */
#define CMD9     (0x40U+9U)     /* SEND_CSD           */
#define CMD10    (0x40U+10U)    /* SEND_CID           */
#define CMD12    (0x40U+12U)    /* STOP_TRANSMISSION  */
#define CMD16    (0x40U+16U)    /* SET_BLOCKLEN       */
#define CMD17    (0x40U+17U)    /* READ_SINGLE_BLOCK  */
#define CMD18    (0x40U+18U)    /* READ_MULTIPLE_BLOCK*/
#define CMD23    (0x40U+23U)    /* SET_BLOCK_COUNT */
#define CMD24    (0x40U+24U)    /* WRITE_BLOCK */
#define CMD25    (0x40U+25U)    /* WRITE_MULTIPLE_BLOCK */
#define CMD41    (0x40U+41U)    /* SEND_OP_COND (ACMD) */
#define CMD55    (0x40U+55U)    /* APP_CMD */
#define CMD58    (0x40U+58U)    /* READ_OCR */

/* Peripheral definitions for DK-TM4C123G board */
/* SSI port */
static
BYTE rcvr_spi (void);

static
void rcvr_spi_m (BYTE *dst);

static
BYTE wait_ready (void);



static
int chk_power(void);        /* Socket power state: 0=off, 1=on */


static
BOOL rcvr_datablock (
    BYTE *buff,            /* Data buffer to store received data */
    UINT btr            /* Byte count (must be even number) */
);


static
BOOL xmit_datablock (
    const BYTE *buff,    /* 512 byte data block to be transmitted */
    BYTE token            /* Data/Stop token */
);


static
BYTE send_cmd (
    BYTE cmd,        /* Command byte */
    DWORD arg        /* Argument */
);


static
BYTE send_cmd12 (void);

/*spiDAT1_t dataconfig1_t;

dataconfig1_t.CS_HOLD = FALSE;
dataconfig1_t.WDEL    = TRUE;
dataconfig1_t.DFSEL   = SPI_FMT_0;
dataconfig1_t.CSNR    = 0xFE;*/


/* asserts the CS pin to the card */
void SELECT(void)
{

    uint32 PORT = 0xFFFFFF00U;


    xmit_spi(0xFFu);

    PORT = 0x01010E00U;
    spiSetFunctional(SDCARD_REG, PORT);




    /*Lowing the respective pin*/
    gioSetBit(SDCARD_PORT,(uint32)SPI_PIN_CS0 ,0U);
    /*gioSetPort(spiPORT2,0U);*/

//    xmit_spi(0xFFu);


}

/* de-asserts the CS pin to the card */

void DESELECT(void)
{
    uint32 PORT = 0U;

    /*MAking SPI CS pin as GPIO pin*/

//    xmit_spi(0xFFu);

    PORT = 0x01010E00U;
    spiSetFunctional(SDCARD_REG, PORT);

    /*high ing the respective pin*/
    gioSetBit(SDCARD_PORT,(uint32)SPI_PIN_CS0 ,1U);


    xmit_spi(0xFFu);


}


/*--------------------------------------------------------------------------

   Module Private Functions

---------------------------------------------------------------------------*/

static volatile
DSTATUS Stat = STA_NOINIT;    /* Disk status */

static volatile
BYTE Timer1, Timer2;    /* 100Hz decrement timer */

static
BYTE CardType;            /* b0:MMC, b1:SDC, b2:Block addressing */

static
BYTE PowerFlag = 0;     /* indicates if "power" is on */

/*-----------------------------------------------------------------------*/
/* Transmit a byte to MMC via SPI  (Platform dependent)                  */
/*-----------------------------------------------------------------------*/


void xmit_spi(BYTE Data)
{
    uint16 Receive_Data = 0U;
    uint16 DATA = (uint16)(Data);


   spiTransmitAndReceiveData(SDCARD_REG, &dataconfig1_t, 1U, &DATA, &Receive_Data);
   /* spiSendAndGetData(spiREG2, &dataconfig1_t, 1U, &DATA, &Receive_Data);*/


}



/*-----------------------------------------------------------------------*/
/* Receive a byte from MMC via SPI  (Platform dependent)                 */
/*-----------------------------------------------------------------------*/

static
BYTE rcvr_spi (void)
{
    uint16 Receive_Data = 0U;
    uint16 dummy_data = 0xFFU;



    spiTransmitAndReceiveData(SDCARD_REG, &dataconfig1_t, 1U, &dummy_data, &Receive_Data);
   /* spiTransmitData((spiBASE_t*) spiREG2, (spiDAT1_t *)&dataconfig1_t, 1u, (uint16 *) &dummy_data);
    spiReceiveData((spiBASE_t*) spiREG2, (spiDAT1_t *)&dataconfig1_t, 1u, (uint16 *) &Receive_Data);*/

    /*spiSendAndGetData(spiREG2, &dataconfig1_t, 1U, &dummy_data, &Receive_Data);*/

    return (BYTE)Receive_Data;


}


static
void rcvr_spi_m (BYTE *dst)
{
    *dst = rcvr_spi();
}

/*-----------------------------------------------------------------------*/
/* Wait for card ready                                                   */
/*-----------------------------------------------------------------------*/

static
BYTE wait_ready (void)
{
    BYTE res;


    Timer2 = 50U;    /* Wait for ready in timeout of 500ms */
    rcvr_spi();
    do{
        res = rcvr_spi();
//        res = 0xFFu;

    }while ((res != 0xFFU) && Timer2);

    return res;
}

/*-----------------------------------------------------------------------*/
/* Send 80 or so clock transitions with CS and DI held high. This is     */
/* required after card power up to get it into SPI mode                  */
/*-----------------------------------------------------------------------*/

void send_initial_clock_train(void)
{
    unsigned int i;

    /* Ensure CS is held high. */
    DESELECT();

    /* Switch the SSI TX line to a GPIO and drive it high too. */




    uint32 PORT =  0x01000A00U;

    spiSetFunctional(SDCARD_REG, PORT);

    gioSetBit(SDCARD_PORT,(uint32)SPI_PIN_SIMO ,1U);


   /* spiREG2->PC2 &=  0xFF00FFFFU;
      spiREG2->PC2 |=  0x00010000U;*/



    /* Send 10 bytes over the SSI. This causes the clock to wiggle the */
    /* required number of times. */

    for(i = 0U ; i < 10U ; i++)
    {
        xmit_spi(0xFFU);
    }

    /*Reverting back the functionality of SIMO to SPI*/



    PORT =  0x01010E00U;

    spiSetFunctional(SDCARD_REG, PORT);


}


/*-----------------------------------------------------------------------*/
/* Power Control  (Platform dependent)                                   */
/*-----------------------------------------------------------------------*/
/* When the target system does not support socket power control, there   */
/* is nothing to do in these functions and chk_power always returns 1.   */


void power_on (void)
{
    /* Set DI and CS high and apply more than 74 pulses to SCLK for the card */
    /* to be able to accept a native command. */


 /*   spiREG2->GCR0 = 0u;

    uint8 wait = 255;

    while(wait)
    {
        wait--;
    }


    spiREG2->GCR0 = 1u;*/

  /* spiREG2->GCR0 = 1U; */


    uint32 val = SDCARD_REG->GCR1;

    val = 0xFFFFFEFF;

    SDCARD_REG->GCR1 = SDCARD_REG->GCR1 & val;

    dataconfig1_t.CS_HOLD = FALSE;
    dataconfig1_t.WDEL    = TRUE;
    dataconfig1_t.DFSEL   = SPI_FMT_0;
    dataconfig1_t.CSNR    = SPI_CS_0;


    spiInit();


    /*Making CS pin as GPIO and remaining pins as SPI pins*/

    uint32 PORT = 0U;

    PORT = 0x01010E00U;
    spiSetFunctional(SDCARD_REG, PORT);


    /*PORT = spiREG2->PC1;*/


  /*  uint32 pull_up = 0U;
      pull_up = spiREG2->PC8 & 0xFFFFFFFFU;

     spiREG2->PC8 &= 0x0000FFFFU;
     spiREG2->PC8 |= 0x01010F00U;

     pull_up = spiREG2->PC8 & 0xFFFFFFFFU;*/





    /*Setting SPI clock frequency for 400 KHz*/

    SDCARD_REG->FMT0 = (SDCARD_REG->FMT0 & 0xFFFF00FFU);
    SDCARD_REG->FMT0 = ((SDCARD_REG->FMT0 | 0x0000FF00U));




    send_initial_clock_train();




    PowerFlag = 1U;
}


void set_max_speed(void)                                         /* this is to write the data into the SD card*/
{
    /*Disabling the SPI*/
    /*spiREG2->GCR0 = 0U;*/
   /* spiREG2->GCR1 = spiREG2->GCR1 & 0x00FFFFFFU;*/

    /*MAKing the SPI clock frequency to the half of original clock frequency*/
    SDCARD_REG->FMT0  = (SDCARD_REG->FMT0 & 0xFFFF00FFU);
    SDCARD_REG->FMT0 |= 0x00000A00U;

    /*Enabling the SPI again*/
    /* spiREG2->GCR0 = 1U;*/
    /* spiREG2->GCR1 = spiREG2->GCR1 & 0x01FFFFFFU;*/
}



static
void power_off (void)
{
    PowerFlag = 0U;
}

static
int chk_power(void)        /* Socket power state: 0=off, 1=on */
{
    return (int)PowerFlag;
}



/*-----------------------------------------------------------------------*/
/* Receive a data packet from MMC                                        */
/*-----------------------------------------------------------------------*/

static
BOOL rcvr_datablock (
    BYTE *buff,            /* Data buffer to store received data */
    UINT btr            /* Byte count (must be even number) */
)
{
    BYTE token;


    Timer1 = 100;
    do {                            /* Wait for data packet in timeout of 100ms */
        token = rcvr_spi();
    } while ((token == 0xFF) && Timer1);
    if(token != 0xFE) return FALSE;    /* If not valid data token, retutn with error */

    do {                            /* Receive the data block into buffer */
        rcvr_spi_m(buff++);
        rcvr_spi_m(buff++);
    } while (btr -= 2);
    rcvr_spi();                        /* Discard CRC */
    rcvr_spi();

    return TRUE;                    /* Return with success */
}



/*-----------------------------------------------------------------------*/
/*                    Send a data packet to MMC                          */
/*-----------------------------------------------------------------------*/

#if _READONLY == 0
static
BOOL xmit_datablock (
    const BYTE *buff,    /* 512 byte data block to be transmitted */
    BYTE token            /* Data/Stop token */
)
{
    BYTE resp, wc;


    if (wait_ready() != 0xFF) return FALSE;

    xmit_spi(token);                    /* Xmit data token */
    if (token != 0xFD) {    /* Is data token */
        wc = 0;
        do {                            /* Xmit the 512 byte data block to MMC */
            xmit_spi(*buff++);
            xmit_spi(*buff++);
        } while (--wc);
        xmit_spi(0xFF);                    /* CRC (Dummy) */
        xmit_spi(0xFF);
        resp = rcvr_spi();                /* Reveive data response */
        if ((resp & 0x1F) != 0x05)        /* If not accepted, return with error */
            return FALSE;
    }

    return TRUE;
}
#endif /* _READONLY */




/*-----------------------------------------------------------------------*/
/*                      Send a command packet to MMC                     */
/*-----------------------------------------------------------------------*/





static
BYTE send_cmd (
    BYTE cmd,        /* Command byte */
    DWORD arg        /* Argument */
)
{
    BYTE n, res;



 /*   uint32 val = SDCARD_REG->GCR1;

    val = 0xFFFFFEFF;

    SDCARD_REG->GCR1 = SDCARD_REG->GCR1 & val;*/



    if (wait_ready() != 0xFFU)
    {
        res = 0xFFU;
    }
    else
    {

    /* Send command packet */
    xmit_spi(cmd);                      /* Command */
    xmit_spi((BYTE)(arg >> 24));        /* Argument[31..24] */
    xmit_spi((BYTE)(arg >> 16));        /* Argument[23..16] */
    xmit_spi((BYTE)(arg >> 8));         /* Argument[15..8]  */
    xmit_spi((BYTE)arg);                /* Argument[7..0]   */
    n = 0xffU;


    if (cmd == CMD0){
        n = 0x95U;            /* CRC for CMD0(0) */
    }else{}
    if (cmd == CMD8){
        n = 0x87U;            /* CRC for CMD8(0x1AA) */
    }else{}
    xmit_spi(n);

    /* Receive command response */
    if (cmd == CMD12){
        rcvr_spi();        /* Skip a stuff byte when stop reading */
    }else{}
    n = 10U;                                /* Wait for a valid response in timeout of 10 attempts */
    do{
        res = rcvr_spi();

       /* if(res != 0xFFu)
        {
            break;
        }
        else
        {

        }*/

    }
     while ((res & 0x80U) && --n);

    }



    return res;            /* Return with the response value */


}

/*-----------------------------------------------------------------------*
 * Send the special command used to terminate a multi-sector read.
 *
 * This is the only command which can be sent while the SDCard is sending
 * data. The SDCard spec indicates that the data transfer will stop 2 bytes
 * after the 6 byte CMD12 command is sent and that the card will then send
 * 0xFF for between 2 and 6 more bytes before the R1 response byte.  This
 * response will be followed by another 0xFF byte.  In testing, however, it
 * seems that some cards don't send the 2 to 6 0xFF bytes between the end of
 * data transmission and the response code.  This function, therefore, merely
 * reads 10 bytes and, if the last one read is 0xFF, returns the value of the
 * latest non-0xFF byte as the response code.
 *
 *-----------------------------------------------------------------------*/

static
BYTE send_cmd12 (void)
{
    BYTE n, res, val;

    /*        For CMD12, we don't wait for the card to be idle before we send
     *        the new command.
     */

    /* Send command packet - the argument for CMD12 is ignored. */
    xmit_spi(CMD12);
    xmit_spi(0U);
    xmit_spi(0U);
    xmit_spi(0U);
    xmit_spi(0U);
    xmit_spi(0U);

    /* Read up to 10 bytes from the card, remembering the value read if it's
       not 0xFF */
    for(n = 0U; n < 10U; n++)
    {
        val = rcvr_spi();
        if(val != 0xFFU)
        {
            res = val;
        }else{}
    }

    return res;            /* Return with the response value */
}

/*--------------------------------------------------------------------------

   Public Functions

---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*/
/* Initialize Disk Drive                                                 */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
    BYTE drv        /* Physical drive nmuber (0) */
)
{
    BYTE n, ty, ocr[4] = {0U};


    DSTATUS result = 1U;
    uint8 ret = 1U;



        if (drv)
        {
             result = (DSTATUS)STA_NOINIT;
             ret = 0U;
        }else{}

        if (Stat & (DSTATUS)STA_NODISK)
        {
            result = Stat;
            ret = 0U;
        }else{}



   /*     uint32 card = 0u;

        card = gioGetBit(SDCARD_PORT,(uint32)SPI_PIN_ENA);

        if(card == (uint32)NOT_DETECTED)
        {
            ret = 0u;  /*No card is there in the socket
        }
        else if(card == (uint32)DETECTED)
        {
            ret = 1u;  /*card is there in the socket
        }
        else
        {

        }*/


    if(ret == 1U){


    power_on();                            /* Force socket power on */


/*    uint32 u32wait = 3333334u;

    while(u32wait--)
    {

    }*/



    send_initial_clock_train();            /* Ensure the card is in SPI mode */

    SELECT();                /* CS = L */
    ty = 0U;


    uint8 res = 0u;

    res = send_cmd(CMD0, 0x00U);

/*    while(res != 0x01u)
    {

        res = send_cmd(CMD0, 0x00U);
    }*/



    if (res == 0x01U) {            /* Enter Idle state */
        Timer1 = 100U;                        /* Initialization timeout of 1000 msec */
        if (send_cmd(CMD8, 0x1AAU) == 1U) {    /* SDC Ver2+ */
            for (n = 0U; n < 4U; n++)
            {
                ocr[n] = rcvr_spi();
            }
            if (((ocr[2] == 0x01U) && (ocr[3] == 0xAAU))) {    /* The card can work at vdd range of 2.7-3.6V */
                do {
                    if ((send_cmd(CMD55, 0U) <= 1U) && (send_cmd(CMD41, (1UL << 30U)) == 0U))
                    {
                        break;    /* ACMD41 with HCS bit */
                    }else{}
                } while (Timer1);
                if ((Timer1) && (send_cmd(CMD58, 0U) == 0U)) {    /* Check CCS bit */
                    for (n = 0U; n < 4U; n++)
                    {
                        ocr[n] = rcvr_spi();
                    }
                    ty = (ocr[0] & 0x40U) ? 6U : 2U;
                }else{}
            }else{}
        } else {                            /* SDC Ver1 or MMC */
            ty = (((send_cmd(CMD55, 0) <= 1U) && (send_cmd(CMD41, 0U) <= 1)) ? 2U : 1U);    /* SDC : MMC */
            do {
                if (ty == 2U) {
                    if ((send_cmd(CMD55, 0U) <= 1) && (send_cmd(CMD41, 0U) == 0U)){
                        break;    /* ACMD41 */
                    }else{}
                } else {
                    if (send_cmd(CMD1, 0U) == 0U){
                        break;                                /* CMD1 */
                    }else{}
                }
            } while (Timer1);
            if ((!Timer1) ||( send_cmd(CMD16, 512U)) != 0U)    /* Select R/W block length */
            {
                ty = 0U;
            }else{}

        }
    }
     CardType = ty;
    DESELECT();            /* CS = H */
    rcvr_spi();            /* Idle (Release DO) */

    if (ty) {            /* Initialization succeded */
        Stat &= (DSTATUS)(~STA_NOINIT);        /* Clear STA_NOINIT */
        set_max_speed();
    } else {            /* Initialization failed */
        power_off();
    }

    result = Stat;
    }else{}

//    f_mount(0U, &g_sFatFs1);
    return result;
}



/*-----------------------------------------------------------------------*/
/*                      Get Disk Status                                  */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
    BYTE drv        /* Physical drive nmuber (0) */
)
{
    DSTATUS result = 0U;
    if (drv){
        result = (DSTATUS)STA_NOINIT;        /* Supports only single drive */
    }else{
      result = Stat;
    }

    return result;
}



/*-----------------------------------------------------------------------*/
/*                       Read Sector(s)                                  */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
    BYTE drv,            /* Physical drive nmuber (0) */
    BYTE *buff,            /* Pointer to the data buffer to store read data */
    DWORD sector,        /* Start sector number (LBA) */
    BYTE count            /* Sector count (1..255) */
)
{
    if (drv || !count) return RES_PARERR;
    if (Stat & STA_NOINIT) return RES_NOTRDY;

    if (!(CardType & 4)) sector *= 512;    /* Convert to byte address if needed */

    SELECT();            /* CS = L */

    if (count == 1) {    /* Single block read */
        if ((send_cmd(CMD17, sector) == 0)    /* READ_SINGLE_BLOCK */
            && rcvr_datablock(buff, 512))
            count = 0;
    }
    else {                /* Multiple block read */
        if (send_cmd(CMD18, sector) == 0) {    /* READ_MULTIPLE_BLOCK */
            do {
                if (!rcvr_datablock(buff, 512)) break;
                buff += 512;
            } while (--count);
            send_cmd12();                /* STOP_TRANSMISSION */
        }
    }

    DESELECT();            /* CS = H */
    rcvr_spi();            /* Idle (Release DO) */

    return count ? RES_ERROR : RES_OK;
}



/*-----------------------------------------------------------------------
 Write Sector(s)
/*-----------------------------------------------------------------------*/

#if _READONLY == 0
DRESULT disk_write (
    BYTE drv,            /* Physical drive nmuber (0) */
    const BYTE *buff,    /* Pointer to the data to be written */
    DWORD sector,        /* Start sector number (LBA) */
    BYTE count            /* Sector count (1..255) */
)
{
    if (drv || !count) return RES_PARERR;
    if (Stat & STA_NOINIT) return RES_NOTRDY;
    if (Stat & STA_PROTECT) return RES_WRPRT;

    if (!(CardType & 4)) sector *= 512;    /* Convert to byte address if needed */

    SELECT();            /* CS = L */

    if (count == 1) {    /* Single block write */
        if ((send_cmd(CMD24, sector) == 0)    /* WRITE_BLOCK */
            && xmit_datablock(buff, 0xFE))
            count = 0;
    }
    else {                /* Multiple block write */
        if (CardType & 2) {
            send_cmd(CMD55, 0); send_cmd(CMD23, count);    /* ACMD23 */
        }
        if (send_cmd(CMD25, sector) == 0) {    /* WRITE_MULTIPLE_BLOCK */
            do {
                if (!xmit_datablock(buff, 0xFC)) break;
                buff += 512;
            } while (--count);
            if (!xmit_datablock(0, 0xFD))    /* STOP_TRAN token */
                count = 1;
        }
    }

    DESELECT();            /* CS = H */
    rcvr_spi();            /* Idle (Release DO) */

    return count ? RES_ERROR : RES_OK;
}
#endif /* _READONLY */



/*-----------------------------------------------------------------------*/
/*                      Miscellaneous Functions                          */
/*-----------------------------------------------------------------------*/
/*DRESULT disk_ioctl (BYTE pdrv, BYTE cmd, void* buff)*/
DRESULT disk_ioctl (
    BYTE drv,        /* Physical drive nmuber (0) */
    BYTE ctrl,        /* Control code */
    void *buff        /* Buffer to send/receive control data */
)
{
    DRESULT res;
    BYTE n, csd[16], *ptr = buff;
    WORD csize;


    if (drv) return RES_PARERR;

    res = RES_ERROR;

    if (ctrl == CTRL_POWER) {
        switch (*ptr) {
        case 0:        /* Sub control code == 0 (POWER_OFF) */
            if (chk_power())
                power_off();        /* Power off */
            res = RES_OK;
            break;
        case 1:        /* Sub control code == 1 (POWER_ON) */
            power_on();                /* Power on */
            res = RES_OK;
            break;
        case 2:        /* Sub control code == 2 (POWER_GET) */
            *(ptr+1) = (BYTE)chk_power();
            res = RES_OK;
            break;
        default :
            res = RES_PARERR;
        }
    }
    else {
        if (Stat & STA_NOINIT) return RES_NOTRDY;

        SELECT();        /* CS = L */

        switch (ctrl) {
        case GET_SECTOR_COUNT :    /* Get number of sectors on the disk (DWORD) */
            if ((send_cmd(CMD9, 0) == 0) && rcvr_datablock(csd, 16)) {
                if ((csd[0] >> 6) == 1) {    /* SDC ver 2.00 */
                    csize = csd[9] + ((WORD)csd[8] << 8) + 1;
                    *(DWORD*)buff = (DWORD)csize << 10;
                } else {                    /* MMC or SDC ver 1.XX */
                    n = (csd[5] & 15) + ((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2;
                    csize = (csd[8] >> 6) + ((WORD)csd[7] << 2) + ((WORD)(csd[6] & 3) << 10) + 1;
                    *(DWORD*)buff = (DWORD)csize << (n - 9);
                }
                res = RES_OK;
            }
            break;

        case GET_SECTOR_SIZE :    /* Get sectors on the disk (WORD) */
            *(WORD*)buff = 512;
            res = RES_OK;
            break;

        case CTRL_SYNC :    /* Make sure that data has been written */
            if (wait_ready() == 0xFF)
                res = RES_OK;
            break;

        case MMC_GET_CSD :    /* Receive CSD as a data block (16 bytes) */
            if (send_cmd(CMD9, 0) == 0        /* READ_CSD */
                && rcvr_datablock(ptr, 16))
                res = RES_OK;
            break;

        case MMC_GET_CID :    /* Receive CID as a data block (16 bytes) */
            if (send_cmd(CMD10, 0) == 0        /* READ_CID */
                && rcvr_datablock(ptr, 16))
                res = RES_OK;
            break;

        case MMC_GET_OCR :    /* Receive OCR as an R3 resp (4 bytes) */
            if (send_cmd(CMD58, 0) == 0) {    /* READ_OCR */
                for (n = 0; n < 4; n++)
                    *ptr++ = rcvr_spi();
                res = RES_OK;
            }

//        case MMC_GET_TYPE :    /* Get card type flags (1 byte) */
//            *ptr = CardType;
//            res = RES_OK;
//            break;

        default:
            res = RES_PARERR;
        }

        DESELECT();            /* CS = H */
        rcvr_spi();            /* Idle (Release DO) */
    }

    return res;
}


/*-----------------------------------------------------------------------*/
/* Device Timer Interrupt Procedure  (Platform dependent)                */
/*-----------------------------------------------------------------------*/
/* This function must be called in period of 10ms                        */


/*
void rtiNotification(uint32 notification)
{

    BYTE n;


    n = Timer1;
    if (n){

        n = (n - 1U);

        Timer1 = n;

    }else{}

    n = Timer2;

    if (n){

        n = (n - 1U);

        Timer2 = n;

    }else{}


}
*/

/*---------------------------------------------------------*/
/*      User Provided Timer Function for FatFs module      */
/*---------------------------------------------------------*/
/* This is a real time clock service to be called from     */
/* FatFs module. Any valid time must be returned even if   */
/* the system does not support a real time clock.          */

DWORD get_fattime (void)
{

    return  ((2024UL-1980UL) << 25)    /* Year = 2007*/
            | (12UL << 21)              /* Month = June*/
            | (20UL << 16)              /* Day = 5 */
            | (11U << 11)              /* Hour = 11 */
            | (42U << 5)               /* Min = 38 */
            | (22U >> 1)                /* Sec = 0 */
            ;

}
