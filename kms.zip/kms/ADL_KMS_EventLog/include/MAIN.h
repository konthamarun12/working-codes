/*
 * MAIN.h
 *
 *  Created on: Apr 23, 2024
 *      Author: HP
 */

#ifndef INCLUDE_MAIN_H_
#define INCLUDE_MAIN_H_

#include "sys_common.h"
#include "system.h"
#include "sys_core.h"
#include "stdlib.h"
#include "stdbool.h"
#include "esm.h"


#include "sci.h"
#include "gio.h"
#include "rti.h"
#include "can.h"
#include "spi.h"
#include "het.h"
#include "mibspi.h"
#include "integer.h"



#include "tcas.h"
#include "USB_UART.h"
#include "user_CRC.h"
#include "loco_events.h"
#include "radio.h"
#include "atf.h"
#include "ADL_can.h"
#include "kavach.h"
//#include "parallel.h"
//#include "oled.h"
#include "user_can.h"
#include "user_can1.h"

#define SDCARD_REG  (spiREG3)
#define SDCARD_PORT (spiPORT3)

#define UART1 (scilinREG)
#define UART2 (sciREG)

extern uint8 u8uart1_temp;
extern uint8 u8uart1_buf[120];
extern uint8 u8uart1_buf_size;

extern uint8 u8uart2_temp;
extern uint8 u8uart2_buf[120];
extern uint8 u8uart2_buf_size;

extern uint8 u8can1_data[8];
extern uint8 u8can2_data[8];

extern uint32 u32tmr_cnt;


extern void ATF_test_function(void);
extern boolean CAN_checking_function(uint8 *rcvd_arr, uint8 *tX_arr);
extern uint8 u8can1_test_data[8];
extern uint8 u8can2_test_data[8];
extern void sciDisplayText(sciBASE_t *sci, const uint8 *text,uint32 length);

extern uint8 u8init;
extern uint8 fectching;



extern void SELECT(void);
extern void DESELECT(void);
extern void xmit_spi(uint8 Data);
extern void send_initial_clock_train(void);
extern void power_on (void);
extern void set_max_speed(void);                                         /* this for write the data to the SD card*/
extern void power_off (void);

#endif /* INCLUDE_MAIN_H_ */
