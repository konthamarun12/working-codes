/*
 * nms.h
 *
 *  Created on: Nov 18, 2024
 *      Author: USER
 */

#ifndef INCLUDE_NMS_H_
#define INCLUDE_NMS_H_


#include "sci.h"
#include "sys_main.h"
#include "can.h"


extern uint8 Can_pkt_cnt[8];


extern uint8 RX_Bit;

#define EVENT_PKT1          8
#define EVENT_PKT2          9

#define LOCOHEALTHMSG       3
#define LOCOFAULTMSG        2

#define HIGH                1
#define LOW                 0

#define NMS                 1                         /* type 1*/
#define KMS                 0                         /* type 2*/


/**************Event Id's******************************/

#define LOCOMSG1    1     /* radio1 health */
#define LOCOMSG2    2     /* radio2 health */
#define LOCOMSG3    3     /* radio1 inpu`t supply */
#define LOCOMSG4    4     /* radio2 input supply */
#define LOCOMSG5    5     /* radio1 temperature */
#define LOCOMSG6    6     /* radio2 temperature */
#define LOCOMSG7    7     /* radio1 PA temperature */
#define LOCOMSG8    8     /* radio2 PA temperature */
#define LOCOMSG9    9     /* radio1 PA supply vtg */
#define LOCOMSG10   10    /* radio2 PA supply vtg */
#define LOCOMSG11   11    /* radio1 TX PA current */
#define LOCOMSG12   12    /* radio2 TX PA current */
#define LOCOMSG13   13    /* radio1 reverse power */
#define LOCOMSG14   14    /* radio2 reverse power */
#define LOCOMSG15   15    /* radio1 forward power */
#define LOCOMSG16   16    /* radio2 forward power */
#define LOCOMSG17   17    /* station kavach ID */
#define LOCOMSG18   18    /* Absolute location1 */
#define LOCOMSG19   19    /* Frequency channel number */
#define LOCOMSG20   20    /* radio1 rssi */
#define LOCOMSG21   21    /* Absolute location2 */
#define LOCOMSG22   22    /* Frequency channel number */
#define LOCOMSG23   23    /* radio2 rssi */
#define LOCOMSG24   24    /* stationary regular packet received time offset */
#define LOCOMSG25   25    /* Active GPS number */
#define LOCOMSG26   26    /* GPS-1 view status */
#define LOCOMSG27   27    /* GPS-2 view status */
#define LOCOMSG28   28    /* GPS-1 seconds */
#define LOCOMSG29   29    /* GPS-2 seconds */
#define LOCOMSG30   30    /* GPS-1 satellites in view */
#define LOCOMSG31   31    /* GPS-1 CNO */
#define LOCOMSG32   32    /* GPS-2 satellites in view */
#define LOCOMSG33   33    /* GPS-2 CNO */
#define LOCOMSG34   34    /* GPS-1 link status */
#define LOCOMSG35   35    /* GPS-2 link status */
#define LOCOMSG36   36    /* GSM-1 rssi */
#define LOCOMSG37   37    /* GSM-2 rssi */
#define LOCOMSG38   38    /* current running key */
#define LOCOMSG39   39    /* remaining number of keys */
#define LOCOMSG40   40    /* session key checksum */
#define LOCOMSG41   41    /* DMI-1 link status */
#define LOCOMSG42   42    /* DMI-2 link status */
#define LOCOMSG43   43    /* Duplicate missing RFID tag */
#define LOCOMSG44   44    /* missed linked RFID tag */
#define LOCOMSG45   45    /* computed TLM status */
#define LOCOMSG46   46    /* train configuration change status */
#define LOCOMSG47   47    /* bootup sequence error */
#define LOCOMSG48   48    /* selected train formation */
#define LOCOMSG49   49    /* selected cab */
#define LOCOMSG50   50    /* Brake application reason */
#define LOCOMSG51   51    /* Station generated SOS */
#define LOCOMSG52   52    /* station generated specific SOS */
#define LOCOMSG53   53
#define LOCOMSG54   54
#define LOCOMSG55   55
#define LOCOMSG56   56
#define LOCOMSG57   57
#define LOCOMSG58   58
#define LOCOMSG59   59
#define LOCOMSG60   60


/*******************Macros for health packet data **************************/

#define RADIO_OK    1
#define DIAGNOSTIC_LINK_FAIL  2
#define RADIO_FAIL  2

#define NO_ACTIVE_GPS     0
#define GPS1              1
#define GPS2              2
#define BOTH_GPS_ACTIVE   3

#define GPS_NO_DATA  0
#define GPS_V        1
#define GPS_A        2

#define BOTH_GPS_PPS_FAIL  0
#define GPS_FAIL_PPS_OK    1
#define GPS_OK_PPS_FAIL    2
#define BOTH_GPS_PPS_OK    3

#define BRAKE_TEST_FAILED  0
#define MR_NOT_AVAILABLE   1

#define LIGHT_ENGINE                 1
#define LIGHT_ENGINE_MULTI           2
#define PASSENGER_TRAIN_3_7_COACH    3
#define PASSENGER_TRAIN_8_13_COACH   4
#define PASSENGER_TRAIN_14_20_COACH  5
#define PASSENGER_TRAIN_21_27_COACH  6
#define GOODS_59BOXN_EMPTY    7
#define GOODS_59BOXN_HALF     8
#define GOODS_59BOXN_FULL     9
#define GOODS_42BCN_EMPTY     10
#define GOODS_42BCN_HALF      11
#define GOODS_42BCN_FULL      12
#define LIGHT_ENGINE_WAP5     13
#define WAP5_8LHB_COACHES     14
#define LIGHT_ENGINE_WAP7     15

#define NO_CAB_SELECTED       0
#define CAB1_SELECTED         1
#define CAB2_SELECTED         2
#define BOTHCAB_SELECTED      3

#define NOT_USED              0
#define REVERSE_MOV_DATECTED  1
#define UNUSUAL_STOPPAGE_DETECTED  2
#define OVERSPEED             3
#define ROLLBACK_DETECTED     4
#define MBT_SELECTED          5
#define NO_LP_ACK             6
#define MA_SHORTENED          7
#define HEADON_COLLISION_DETECTED   8
#define REAREND_COLLISION_DETECTED  9
#define LOCO_SPEC_SOS_RCVD     10
#define STN_GEN_SOS_RCVD       11

#define MANUAL_SOS_RCVD         1
#define MANUAL_SOS_END          2
#define UNUSUAL_STOPPAGE_START  3
#define UNUSUAL_STOPPAGE_END    4
#define HEAD_ON_COLLISION_DET   5
#define HEAD_ON_COLLISION_END   6
#define REAR_END_COLLISION_DET  7
#define REAR_END_COLLISION_END  8
#define TRAIN_PARTING_DET       9
#define TRAIN_PARTING_END       10

#define MANUAL_SOS      1
#define MANUAL_SOS_END  2
#define UNUSUAL_STOPPAGE_START  3
#define UNUSUAL_STOPPAGE_END    4

#define KAVACH_ISOLATED         1
#define KAVACH_CONNECTED        2

#define BIU_ISOLATED            1
#define BIU_CONNECTED           2

#define EB_CONNECTED            1
#define EB_BYPASSED             2

#define KAVACH_ENTRY            1
#define KAVACH_EXIT             2
#define ETCS_ENTRY              3
#define ETCE_EXIT               4


typedef struct                                                       /* Loco health packet message */
{
    uint16 u16SOF;
    uint8 u8Msg_Type;
    uint16 u16Msg_Len;
    uint16 u16Msg_Seq;
    uint32 u24Loco_Id;
    uint16 u16NMS_Id;
    uint8 u8Sys_version;
    uint8 u8Day;
    uint8 u8Month;
    uint8 u8Year;
    uint8 u8Hours;
    uint8 u8Minutes;
    uint8 u8Seconds;
    uint8 u8Event_cnt;
    uint16 u16Event_Id;
    uint8 u8Event_data;
    uint32 u32CRC;

    uint8 u8Radio2_health;
    uint8 u8Radio1_health;
    uint8 u8Radio1_input_supply;
    uint8 u8Radio2_input_supply;
    uint8 u8Radio1_Temp;
    uint8 u8Radio2_Temp;
    uint8 u8Radio1_PA_Temp;
    uint8 u8Radio2_PA_Temp;
    uint8 u8Radio1_PA_Supply_vtg;
    uint8 u8Radio2_PA_Supply_vtg;
    uint8 u8Radio1_Tx_PA_Cur;
    uint8 u8Radio2_Tx_PA_Cur;
    uint8 u8Radio1_Rev_Power;
    uint8 u8Radio2_Rev_Power;
    uint8 u8Radio1_Forw_Power;
    uint8 u8Radio2_Forw_Power;
    uint32 u24Stationary_Kavach_Id;
    uint32 u24ABS_Loc1;
    uint16 u16Freq_Channel_Num;
    uint16 u16Radio1_RSSI;
    uint32 u24ABS_Loc2;
    uint16 u16Freq_Channel_NUM;
    uint16 u16Radio2_RSSI;
    uint16 u16Station_Reg_Pkt_Rcv_time_offset;
    uint8 u8Active_GPS_Num;
    uint8 u8GPS1_View_Status;
    uint8 u8GPS2_View_Status;
    uint8 u8GPS1_Seconds;
    uint8 u8GPS2_Seconds;
    uint8 u8GPS1_Satellites_in_view;
    uint8 u8GPS1_CNO;
    uint8 u8GPS2_Satellites_in_view;
    uint8 u8GPS2_CNO;
    uint16 u16GPS1_link_Status;
    uint16 u16GPS2_link_Status;
    uint8 u8GSM1_RSSI;
    uint8 u8GSM2_RSSI;
    uint8 u8Cur_running_key;
    uint8 u8Remaining_Num_of_keys;
    uint16 u16Session_key_checksum;
    uint16 u16DMI1_link_status;
    uint16 u16DMI2_link_status;
    uint16 u16RFID_Rea1_link_status;
    uint16 u16RFID_Rea2_link_status;
    uint16 u16Missing_Dup_rfid_tag;
    uint32 u32Missing_linked_RFID_tag;
    uint32 u32Computed_TLM_status;
    uint8 u8Train_Confi_change;
    uint8 u8Bootup_seq_error;
    uint8 u8Selected_train_formation;
    uint8 u8Selected_Cab;
    uint8 u8Brake_appl_reason;
    uint32 u24Station_Gen_SoS;
    uint32 u24Station_Loco_Spe_SoS;
    uint32 u32Collission_Detection;
    uint8 u8Loco_self_SoS;
    uint8 u8Kavach_Connection;
    uint8 u8BIU_Isolated;
    uint8 u8EB_Bypassed;
    uint8 u8Kavach_Territory;
    uint8 u8Brake_Interface_error;
    uint16 u16OVK_modules_health;
    uint16 u16Conflict_Route_RFID;
    uint8 Reserved;
    uint16 u16Firm_specific_events;
    uint8 Spec_value;

}LOCO_TO_NMS;
extern LOCO_TO_NMS  Loco_Health_pkt;


typedef struct                                                   /* NMS acknowledge message */
{
    uint16 u16SOF;
    uint8 u8Msg_Type;
    uint16 u16Msg_Len;
    uint16 u16Msg_seq;
    uint16 u16NMS_Sys_Id;
    uint32 u24Kavach_Sub_Sys_Id;
    uint8 u8Kavach_Sub_sys_type;
    uint32 u32CRC;
}NMS_Res_Pkt;
extern NMS_Res_Pkt  NMS_ack_msg;


/*
typedef struct
{
    uint8_t u8EventType;
    uint8_t u8EventID;
    uint8_t u8dataPktbyteCnt;
    uint8_t u8curpktidx;
    uint8_t u8PrevCanIdentifier;
    uint8_t u8prevpktidx;
    uint8_t u8logmsgrxd;
    uint8_t u8EventLogData[14];
    uint8_t u8EventLogData1[8][8];
    uint8_t U8EVENTPKTRXD1;
    uint8_t u8EVENTCANPktCnt;
    uint8_t u8EVENTcurpktidx;
    uint8_t U8EVENTPKTRXD2;
    uint8_t u8EVENTprevpktidx;
    uint8_t u8Regrxbuf[100];
    uint8_t u8msgrxd;

}can_data_t;
extern can_data_t CAN_Data;
*/

typedef struct                                                   /* Loco Fault message */
{
    uint16_t u16SOF;
    uint8_t u8Msg_Type;
    uint16_t u16Msg_Len;
    uint16_t u16Msg_Seq;
    uint32_t u24Loco_Id;
    uint16_t u16NMS_Id;
    uint8_t u8Sys_version;
    uint8_t u8Day;
    uint8_t u8Month;
    uint8_t u8Year;
    uint8_t u8Hours;
    uint8_t u8Minutes;
    uint8_t u8Seconds;
    uint8_t u8SubSys_type;
    uint8_t u8Fault_Codes;
    uint8_t u8Module_ID;
    uint8_t u8Fault_Code_Type;
    uint16_t u16Fault_Code;
    uint32_t u32CRC;
    uint8_t Loco_fault_buff[64];
}loco_fault_t;
extern loco_fault_t LOCO_Fault_Msg;


typedef struct                                                 /* loco RSSI message */
{
    uint16_t u16SOF;
    uint8_t u8Msg_Type;
    uint16_t u16Msg_Len;
    uint16_t u16Msg_Seq;
    uint32_t u24Loco_Id;
    uint16_t u16NMS_Id;
    uint8_t u8Sys_version;
    uint8_t u8Day;
    uint8_t u8Month;
    uint8_t u8Year;
    uint8_t u8Hours;
    uint8_t u8Minutes;
    uint8_t u8Seconds;
    uint16_t u16STN_ID;
    uint8_t u8Radio1_rssi_cnt;
    uint16_t u16Ref_RFID_tag1;
    uint32_t u24Abs_Ref_RFID_tag1;
    uint16_t u16RSSI1;
    uint8_t u8Radio2_rssi_cnt;
    uint16_t u16Ref_RFID_tag2;
    uint32_t u24Abs_Ref_RFID_tag2;
    uint16_t u16RSSI2;
    uint32_t u32CRC;
}loco_rssi_t;
extern loco_rssi_t LOCO_RSSI_MSG;

extern void Transmit_LocoHealthPkt_to_NMS(void);

extern void Loco_to_NMS_health_pkt_send(uint8 EventType);

extern void UDP_transmit_sciDisplayText(sciBASE_t *sci, const uint8 *text, uint32 length);

extern void canReceiveMessages(canBASE_t *node, uint32 messageBox, uint8 MsgType);

/*extern uint32 canIsRxMessageArrived(canBASE_t *node, uint32 messageBox);*/

/*extern uint32 canGetData(canBASE_t *node, uint32 messageBox, uint8 * const data);*/

extern void Initialise_LVKNMS_data(void);

extern void Loco_KAVACH_CANdata_process(void);

extern void ExtractCPUdata(uint8_t i);

/*extern int my_sprintf(char *buffer, size_t buffer_size, const char *format, ...); */

extern void close_NMSUDPsocket1(void);
extern void SendCAN_CPU2ADL(void);

extern void Build_LOCO_Fault_Msg(void);


#endif /* INCLUDE_NMS_H_ */
