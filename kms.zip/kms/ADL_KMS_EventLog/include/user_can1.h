/*
 * user_can.h
 *
 *  Created on: 11-Sep-2024
 *      Author: User
 */

//#include "MAIN.h"

//#ifndef INCLUDE_USER_CAN_H_
//#define INCLUDE_USER_CAN_H_

//#include "MAIN.h"

//#define ADLBASEID  (0x3700)
//#define VPMBASEID  (0x13000)
//#define VPM_BASEID  (0x3700)
//
//#define SET_HIGH  1
//#define SET_LOW   0
//
//#define VALIDITY_PKT 0
//#define KEYS_DATAPKT 1
//
//#define KEYSET_OFFSET  (40)
//
//
//#define KEYDATA1                            (1u)
//#define KEYDATA2                            (2u)
//#define KEYDATA3                            (3u)
//#define KEYDATA4                            (4u)
//#define KEYDATA5                            (5u)
//
//
//typedef struct
//{
//    uint8 u8S_time;
//    uint8 u8S_date;
//    uint8 u8S_month;
//    uint8 u8S_year;
//
//    uint8 u8Aut_key1[32][16];
//    uint8 u8Aut_key2[32][16];
//
//    uint32 u32cpuID;
//    uint32 u32canMsgID;
//    uint8 u8Offset;
//    uint8 u8ATPTestTxd[255];
//    uint8 u8Address;
//    uint8 u8canTxbuff[8];
//
//    uint32 u32CAN_arbitration_value;
//    uint32 u32canMsg_id;
//
//    uint8 u8Key_set;
//    uint8 u8KeyRx;
//
//    uint8 CanRX_Msg;
//    uint8 u8Keys_validityData[8];
//    uint8 u8KMS_keysData[8][8];
//    uint8 u8KEYS_VALIDITYPKTRcvd;
//
//    uint8 u8CANPktcnt;
//    uint8 u8currpktidx;
//    uint8 u8prevpktidx;
//
//    uint8 u8KMS_Key_idx;
//}gcanFun;
//extern gcanFun CAN_Info;
//
//typedef struct
//{
//    uint8_t u8Address;
//    uint8_t u8Config;
//    uint8_t u8Slot;
//}gDipinfo_t;
//
//extern gDipinfo_t Dip_Info;
//
//
//typedef struct
//{
//    uint8_t u8startTime;
//    uint8_t u8startDate;
//    uint8_t u8startMonth;
//    uint8_t u8startYear;
//    uint8_t u8endTime;
//    uint8_t u8endDate;
//    uint8_t u8endMonth;
//    uint8_t u8endYear;
//
//    uint8_t u8KMSRxdData1;
//    uint8_t u8KMSRxdData2;
//
//    uint8_t u8VPM_keyRcvData[255];
//}gKmsPkt_t;
//
//extern gKmsPkt_t KMSKeys_Info;
//
//
//typedef struct
//{
//    uint8_t CAN_Status;
//    uint8_t CAN_ErrFlag;
//    uint8_t CAN_MsgCount;
//    uint8_t CAN_MsgObjSent;
//    bool    CAN_RxFlag;
//    uint8_t CAN_CANFlags1;
//    uint8_t CAN_CANFlags2;
//    uint8_t u8CanPacketRxd;
//    uint8_t u8CANTxBox[8];
//    uint8_t u8CANRxBox[8];
//    uint8_t u8keyreqmsg[4][10];
//    uint8_t u8GpsRxbit;
//    uint16_t u16CanTxSendTimeout;
//    uint16_t u16CANResetTmr;
//}can_info_t;
//
//typedef struct{
//    uint8_t u8GSM1State;
//    uint8_t u8GSM2State;
//    uint8_t u8GSM1Retries;
//    uint8_t u8GSM2Retries;
//    uint16_t u8GSM1TmeOut;
//    uint16_t u8GSM2TmeOut;
//    uint32_t u32ADLCRC;
//}sys_mon_Info_t;
//
//extern sys_mon_Info_t Sys_Mon_Info;
//
//extern char ucGpsDatabuf[4][10];
//extern can_info_t CAN0_Info;
//extern can_info_t CAN1_Info;
//
//extern unsigned char ucMsgData[8];
//extern char ucMsgCPU[256][8];
//
//
//extern uint32 create_can_msg_object(uint8 u8CANMsg_ID);
//extern void CAN_buffer_free_function(void);
//extern void wait(uint32_t u32time);
//extern void VPM_CAN_Received_message(void);
//extern void Key_set_can_functions(void);
//
//extern void EEPROM_write_function(void);
//extern void EEPROM_read_function(void);
//extern void Extract_KMS_key(void);
//
//extern void can_msg_send(uint8 u8CANMsg_ID);
//extern void build_CANpkt1(void);
//extern void can_pkt_transmit(void);
//
//extern void ExtractKeysdata(uint8_t i);
//extern void ProcessKeysSetdata(void);
//extern void myMemcpy(void *dest, const void *src, size_t n);
//
//extern void CAN1Reset(void);
//extern void CAN2Reset(void);
//
//extern void Check2oo2KeyReq(void);

//#endif /* INCLUDE_USER_CAN_H_ */
