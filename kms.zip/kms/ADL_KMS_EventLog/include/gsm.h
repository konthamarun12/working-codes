/*
 * gsm.h
 *
 *  Created on: Oct 23, 2024
 *      Author: USER
 */

#ifndef INCLUDE_GSM_H_
#define INCLUDE_GSM_H_

#include "sys_main.h"
#include "sci.h"
#include "gio.h"

//typedef struct
//{
//    uint16_t GSMRcvBuf[2000];
//    uint16_t RcvDataSize;
//    uint8_t GSMRxBit;
//
//};

typedef struct
{
    char  chDate;
    char  chMonth;
    uint16_t    chYear;
    char    chSecs;
    char    chMins;
    char    chHours;
    uint64_t u64Key1;
    uint64_t u64Key2;
    uint8_t  u8GPSavailable;
    uint8_t  u8gpstimeout;

    uint32_t  u32TCPRxCnt;
    uint32_t  u32TCPTxCnt;
    uint16_t  u16TCPDelayReg;
    char      chTCPBuf[2048];
    volatile bool   TCPRxBit;
    bool      TCPTxBit;
}gsm_info_t;

extern gsm_info_t GSM1_Info;
extern gsm_info_t GSM2_Info;

extern void close_UDPsocket(void);
//extern uint32 crc_calc(uint32 cnt, uint8* buf);

#endif /* INCLUDE_GSM_H_ */
