/*
 * atf.h
 *
 *  Created on: 01-Aug-2024
 *      Author: User
 */

#ifndef INCLUDE_ATF_H_
#define INCLUDE_ATF_H_

/*********************************************
       RADIO packet
 *********************************************/
#define INFO_PKT       0x01u
//#define DATA_PKT       0X02u
//#define RADIO_PKT      0X01u
#define DATE_PKT       0X01u
#define ABS_PKT        0x02u
#define ERROR_PKT      0x03u
#define PDI_MESS       0x0201u
#define PDI_ACK_MESS   0x0202u
#define TSR_INFO_MESS  0x0203u
#define GET_TSR_MESS   0x0204u
#define SK_ACK_MESS    0x0205u
#define DATA_INT_MESS  0x0206u
#define ACK_MESS       0x0207u

typedef struct
{


 uint8_t u8AR[50];
 uint8_t u8AG[50];
 uint8_t u8STL[700];
 uint8_t u8LTS[50];
 uint8_t u8AE[50];
 uint8_t radio_log[100];
 uint8_t u8Info[50];
 uint8_t u8pkt_type;
 uint8_t u8sub_pkt_type;
 uint8_t u8Total_pkt;
 uint8_t u8Current_pkt;
 uint16_t u16Total_byte;
 uint8_t u8pre_command;
 uint16_t u16AR_pkt_count;
 uint16_t u16AG_pkt_count;
 uint16_t u16STL_pkt_count;
 uint16_t u16LTS_pkt_count;
 uint16_t u16AE_pkt_count;

}RADIO_PKT_t;


typedef struct
{
    uint8_t date;
    uint8_t month;
    uint8_t hour;
    uint8_t minute;
    uint8_t seconds;
    uint8_t year_MSB;
    uint8_t year_LSB;
    uint8_t gps_buff[20];
}GPS_PKT_t;

extern GPS_PKT_t gps_pkt;
extern RADIO_PKT_t radio_pkt;
extern void RADIO_CAN_pkt(void);
extern void my_MemCpy(uint8_t * dest, uint8_t * src, uint8 len,uint8_t can_ID);
extern void creating_buff(void);
typedef struct
{
    uint8_t critical_buff[100];
    uint8_t pre_command;
    uint8_t event_type;
    uint8_t log_buff[100];
    uint8_t sub_pkt;
}CRITICAL_PKT_t;
extern CRITICAL_PKT_t critical_pkt;


typedef struct
{
    uint8_t u8TSRMS_tmp_buff[20];
    uint8_t u8TSRMS_buff[200];
    uint8_t u8TSRMS_pkt_type;
    uint8_t u8Total_len;
    uint8_t u8Total_pkt;
    uint8_t u8current_pkt;
    uint16_t u16message_type;
    uint8_t pre_command;
    uint8_t PDI_mes[20];
    uint8_t PDI_ACK_mes[30];
    uint8_t TSR_info[100];
    uint8_t GET_TSR_mes[20];
    uint8_t SK_ACK[100];
    uint8_t DATA_INT_mes[20];
    uint8_t ACK_mes[50];
    uint8_t event_type;
    uint8_t TSRMS_log[200];
}TSRMS_PKT_t;

extern TSRMS_PKT_t tsrms_pkt;

/*********************************************/


#include "sci.h"

extern bool ScilinRxd;

extern uint8_t Init_Flag;
extern uint8 u8GSMBuff[50];
extern uint8_t Init_Flag;

typedef struct
{
    bool isSendTxd;
    bool isTestDataRxd;
    bool isCANTestDataRxd1;
    bool isCANTestDataRxd2;
    bool isCAN1Tx;
    bool isCAN2Tx;

    bool isTestDataRxd1;
    bool isTestSCI1;
    bool isTestSCI2;
    bool isTestCAN1;
    bool isTestCAN2;
    bool isTestIP;
    bool isTestI2C;
    bool isTestDIP1;
    bool isTestDIP2;
    bool isSlotDete;
    bool isTestRS4851;
    bool isTestRS4852;
    bool isTestRS4853;
    bool isTestSLED;
    bool ATPdatabuff[256];

    bool isTestGSMEn;
    bool isTestSIMdetect;
    bool isTestSDEn;
    bool isTestSPI;
    bool isUSBTestData;
    bool isCANTestData;

    uint8_t u8SciTest1;
    uint8_t u8ScITest2;
    uint8_t u8CAN1Test;
    uint8_t u8CAN2Test;
    uint32_t u32InputTest;
    uint8_t u8I2CTest;
    uint8_t u8DIP1Test;
    uint8_t u8DIP2Test;
    uint8_t u8SlotTest;
    uint8_t u8ParallelTest;
    uint8_t u8RS4851Test;
    uint8_t u8RS4852Test;
    uint8_t u8RS4853Test;
    uint8_t u8SLEDTest;
    uint8_t u8ATPTestData[255];
    uint8_t u8ATPTestTxd[255];

    uint8_t u8GSMInit;
    uint8_t u8SIMDetect;
    uint8_t u8SDcard_Detect;
    uint8_t u8SPITest;
    uint8_t u8CAN1RxBuf[64];
    uint8_t u8SignalStength;

}gATPTest_;

extern gATPTest_ ATP;


 /*extern void sciDisplayText(sciBASE_t *sci, uint8 *text, uint32 length);
extern void InitPeripherals(void);  */
extern void InitEMIF(void);
extern void TestCanComm(void);
extern void ReadDipSwitchAdd(void);
extern void ReadDipSwitchConfig(void);
extern void ReadSlotDetect(void);
extern void Update_IPStatus(void);
extern void ProcessSciRxdData(void);
extern uint32_t Bit2Byte(bool *datainbits, uint16_t u16Spos, uint8_t u8Offset);
extern void BuildATPRespons(void);
extern void InitDataport(void);

extern uint8 GSM_wait(uint8 *ch_temp);
extern void GSM_init(void);
extern void Status_LED_function(void);
extern void controller_test_function(void);
extern void GSM_siganl_strength(void);
extern void GSM_SIM_Detection(void);
extern void process_CAN_data(uint8_t u8canidentifier);

#endif /* INCLUDE_ATF_H_ */
