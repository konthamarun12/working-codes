/*
 * ADL_can.h
 *
 *  Created on: Aug 30, 2024
 *      Author: HP
 */

#ifndef INCLUDE_ADL_CAN_H_
#define INCLUDE_ADL_CAN_H_

#define VPMBASEID  (0x13000)
//#define ADLBASEID  (0x5000)

extern uint8_t u8canTxbuff[8];
extern uint8_t canFlag, canFlag1;
extern uint8 u8CANRx_Msg[8][8];
extern uint8 u8MCU2_CANTx;

extern uint8_t u8CanMesg[8];

//typedef struct
//{
//    uint32 u32cpuID;
//    uint32 u32canMsgID;
//    uint8 u8Offset;
//    uint8 u8ATPTestTxd[255];
//    uint8 u8Address;
//    uint8 u8canTxbuff[8];
//
//    uint32 u32CAN_arbitration_value;
//    uint32 u32canMsg_id;
//
//}gcanFun;
//
//extern gcanFun CAN_Info;


/*extern void vim_canpacketSend(void);
extern void can_build_packet(void);*/
extern uint32 create_can_msg_object(uint8 u8CANMsg_Num);
extern void ADL_input_can_data_pkt(void);
extern void ADL_can_data_pkt(void);
extern void ADL_can1_data_pkt(void);
extern void ADL_health_data_packet(void);

extern void ADL_CAN_Pkt_Transmit(void);
extern void CAN_buffer_free_function(void);
extern void CAN_Data_separation(void);

extern void Build_LiveData_event(void);
extern void Build_Critical_Event_Data(void);

#endif /* INCLUDE_ADL_CAN_H_ */
