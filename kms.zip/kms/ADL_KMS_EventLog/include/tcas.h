/*
 * tcas.h
 *
 *  Created on: Apr 23, 2024
 *      Author: HP
 */





#ifndef INCLUDE_TCAS_H_
#define INCLUDE_TCAS_H_

extern uint64 live_data_line_count;
extern uint64 crit_data_line_count;
extern uint64 trig_data_line_count;
extern uint64 trigm_data_line_count;
extern uint64 svk_data_line_count;
extern uint64 tsrms_data_line_count;
extern uint64 tcas_data_line_count;
extern uint64 agpkt_line_count;
extern uint64 arpkt_line_count;
extern uint64 aepkt_line_count;
extern uint64 locoreg_line_cnt;
extern uint64 stnreg_line_cnt;
extern uint64 tag_dat_line_cnt;


extern char templogbufcrit[512];
extern char templogbuftrig[512];
extern uint32 tempbuftrig[512];
extern uint8 templogbufLive[512];
extern char templogbufTrigMain[512];
extern char templogbufSvkSvk[512];
extern char templogbufTSRMS[512];
extern char templogbufKMS[512];
extern uint8 templogradioandtagbuffer[512];


extern char SDCardBuf[1024];

extern uint16 astohex(const unsigned char *p);




#define ARPACKET1           1
#define ARPACKET2           2
#define ARPACKET3           3
#define ARPACKET4           4


#define AGPACKET1           9
#define AGPACKET2           10
#define AGPACKET3           11
#define AGPACKET4           12

#define LocoRegPACKET1      5
#define LocoRegPACKET2      6
#define LocoRegPACKET3      7
#define LocoRegPACKET4      8

#define StnRegPACKET1       15
#define StnRegPACKET2       16

#define GPSPACKET           17

#define ABSPACKET           18

#define ACKPACKET           19

#define NORMALTAGDATA1      20
#define NORMALTAGDATA2      21

#define LCTAGDATA1          22
#define LCTAGDATA2          23

#define ADJTAGDATA1         24
#define ADJTAGDATA2         25

#define JUNTAGDATA1         26
#define JUNTAGDATA2         27

#define RadioInfo1            28
#define RadioInfo2            29
#define RadioInfo3            30
#define RadioInfo4            31
#define RadioInfo5            32
#define GPSGSMInfo            33
#define KeysInfo              34
#define RFIDInfo              35
#define TLMInfo               36
#define TrainInfo             37
#define CollisionDet          38
#define SOSMsgs1              39
#define SOSMsgs2              40
#define SPADKavachInfo        41
#define BrakeCollisionInfo    42
#define SoSInfo               43
#define KAVACHInfo            44
#define ModuleHealth1         45
#define ModuleHealth2         46
#define ModuleHealth3         47
#define ModuleHealth4         48
#define DMImsgTT              49


/***********************critical data macros*************************************/

#define EXT_DIAGNOSTIC1     (27)
#define EXT_DIAGNOSTIC2     (28)
#define EXT_DIAGNOSTIC3     (29)
#define EXT_DIAGNOSTIC4     (30)
#define EXT_DIAGNOSTIC5     (31)
#define EXT_DIAGNOSTIC6     (32)
#define EXT_DIAGNOSTIC7     (33)
#define EXT_DIAGNOSTIC8     (34)
#define EXT_DIAGNOSTIC9     (35)
#define EXT_DIAGNOSTIC10    (36)
#define EXT_DIAGNOSTIC11    (37)
#define EXT_DIAGNOSTIC12    (38)
#define EXT_DIAGNOSTIC13    (39)
#define EXT_DIAGNOSTIC14    (40)
#define EXT_DIAGNOSTIC15    (41)
#define EXT_DIAGNOSTIC16    (42)


#define EXT_CRITICAL1       (43)
#define EXT_CRITICAL2       (44)
#define EXT_CRITICAL3       (45)
#define EXT_CRITICAL4       (46)
#define EXT_CRITICAL5       (47)
#define EXT_CRITICAL6       (48)
#define EXT_CRITICAL7       (49)
#define EXT_CRITICAL8       (50)
#define EXT_CRITICAL9       (51)
#define EXT_CRITICAL10      (52)
#define EXT_CRITICAL11      (53)




/***********************************************************************/
#define TRIGGEREDDATA   (0xA0u)     /*for finding out the type of events*/
#define CRITICALDATA    (0x02u)
#define LIVEDATA        (0xA1u)
#define TRIGGEREDMAINT  (0xA2u)
#define SVKTOSVKDATA    (0xA5u)
#define TSRMS           (0x06u)
#define RADIODATA       (0xD1u)
#define RFIDDATA        (0x94u)

#define CHANGEOFBRAKE1      29
#define CHANGEOFBRAKE2      29

/*#define NORMALBRAKE           2
#define SERVICEBRAKE      2
#define EMERGENCYBRAKE    3*/

#define EVENTPKT1           1
#define EVENTPKT2           2


/**************Macros for events*****************************/

#define TRIGGERED_DATA    1
#define CRITICAL_DATA     2
#define LIVE_DATA         3
#define TRIGGERED_MAINT_DATA  4

/************************************************************/

typedef struct
{
  uint8 s4_pkttype;
  uint8 s7_pktlen;
  uint32 s17_framenum;
  uint16 s16_stnid;
  uint8 s3_stn_ver;
  uint32 s23_stn_abs;
  uint32 s20_destlocoid;
  uint16  s12_allotedUplinkFreq;
  uint16  s12_allotedDnlinkFreq;
  uint8  s7_alottedtdmaslot;
  uint16 s16_stnrandnum;
  uint16 s7_stntdmaslot;
  uint32 s32_MAC_CODE;
  uint32 s32_CRC;

}Access_Auth_Packet_t;

extern Access_Auth_Packet_t loco_ag_pkt;

typedef struct
{
    bool radiobits[1024];
    bool radiobitsAR[500];
    bool radiobitsAG[500];
    bool bradioLEBits[8192];
    bool bradioTxBits[256];
}bitarray_t;

extern bitarray_t Radio_In_Bits;

typedef struct
{
    uint8 s4_pkttype;
    uint8 s7_pktlen;
    uint32 s17_framenum;
    uint32 s17_framenumprev;
    uint32 s20_source_locoid;
    uint8 s3_source_locover;
    uint32 s23_abs_loc;
    uint16 s9_lDoubtover;
    uint16 s9_lDoubtunder;
    uint8 s2_trainintegrity;
    uint16 s11_trainlen;
    uint16 s9_trainspeed;
    uint8 s2_movement_dir;
    uint8 s3_emergency_status;
    uint8 s4_locomode;
    uint16 s10_last_rfidtag;
    uint8 s1_main_dup_tag;
    uint8 s3_TaglinkInfo;
    uint16 s9_tin;
    uint8 s3_brake_applied;
    uint8 s2_newma_reply;
    uint8 s4_last_refprofid;
    bool s1_sigov;
    uint8 s4_info_ack;
    uint8 s3_spare;
    uint8 s6_loco_health;

    uint32 s32_mac_code;
    uint32 s32_crc;

}LTCAS_STCAS_Reg_Packet_t;
extern LTCAS_STCAS_Reg_Packet_t Loco_Stn_Reg_Packet;

typedef struct
{
    uint8 s4_PKT_TYPE;
    uint8 s7_PKT_LENGTH;
    uint32 s17_FRAME_NUM;
    uint32 s20_SOURCE_LOCO_ID;
    uint8  s3_Source_Loco_Ver;
    uint32 s23_ABS_LOCO_LOC;
    uint16 s11_TRAIN_LENGTH;
    uint8 s8_TRAIN_SPEED;
    uint8 s2_MOVEMENT_DIR;
    uint8 s3_EMERGENCY_STATUS;
    uint8 s4_LOCO_MODE;
    uint16 s10_LAST_RFID_TAG;
    uint16 s16_ApprStnID;
    uint8 s7_TIN;
    uint32 s21_GpsLong;
    uint32 s20_GpsLat;
    uint16 s16_LOCO_RAND_NUM_RL;
    uint32 s32_CRC;
}Access_LTCAS_Packet_t;
extern Access_LTCAS_Packet_t Loco_Access_Req_Packet;

extern void build_Loco_Reg_pkt(void);
extern void build_AR_pkt(void);
extern void build_AG_pkt(void);
extern void build_Stn_Reg_pkt(void);
extern void build_AE_pkt(void);
extern void write_tag_data(void);

typedef struct
{
    uint8  u8GpsHours;
    uint8  u8GpsMins;
    uint8  u8GpsSecs;
    uint8  u8DateTimeConfirm;
    uint8  u8GpsDate;
    uint8  u8GpsMonth;
    uint16 u16GpsYear1;
    uint16 u16GpsYear2;
    uint8  u8GpsStat;
    uint8  u8GpsNS;
    uint8  u8GpsEW;
    uint32  u8GpsSpeed;
    double    GpsCog;
    uint32 u32GpsLatitude;
    uint32 u32GpsLongitude;
    uint8 u8EvenPPS;
    uint8 u8SyncPPS;
    bool        IsSlotBit;
    uint8 TDMISlots;
    uint8 u8PPSCnt;
    uint8 u8GPSSync;
    uint8 u8SATViewCnt;
    uint8 u8PPSBit;
    uint8 u8TDMIRiseEdge[70];
    uint8 u8SlotTxCnt[70];
    uint16 u16SlotValidTmr;
    uint8 u8GNSSFixType;
    uint8 u8GNSSFixFlags;
    uint8 u8NoSatalite;
    uint16 u16TimerbitsCtr;
    uint16 u16TimerbitsCtrX;
    uint8 u8FrameState;
}gps_info_t;


typedef struct
{
uint8 u8HOCDetrcvd;
uint8 u8TrigDetrcvd;
uint8 u8CritDetrcvd;
uint8 u8LiveDetrcvd;
uint8 u8Changeofbrakercvd;
uint8 u8RadioInforcvd;
uint8 KavachFreqRadiorcvd;
uint8 GPSGSMrcvd;
uint8 KeysRFIDTrainrcvd;
uint8 BrakeCollisionrcvd;
uint8 Keysrcvd;
uint8 RFIDInforcvd;
uint8 TLMrcvd;
uint8 TrainInforcvd;
uint8 Collisionrcvd;
uint8 SOSMsgrcvd;
uint8 SPADKavachrcvd;
uint8 ModuleHealhrcvd;
uint8 DMImsgTTrcvd;
}cpudata_info_t;
extern cpudata_info_t cpudata_info;

typedef struct
{
    uint8 u8EventType;
    uint8 u8EventID;
    uint8 u8dataPktbyteCnt;
    uint8 u8curpktidx;
    uint8 u8PrevCanIdentifier;
    uint8 u8prevpktidx;
    uint8 u8logmsgrxd;
    uint8 u8EventLogData[14];
    uint8 u8EventLogData1[30][8];
    uint8 U8EVENTPKTRXD1;
    uint8 u8EVENTCANPktCnt;
    uint8 u8EVENTcurpktidx;
    uint8 U8EVENTPKTRXD2;
    uint8 u8EVENTprevpktidx;
    uint8 u8Regrxbuf[100];
    uint8 u8msgrxd;

}can_data_t;

extern can_data_t CAN_Data;

typedef struct
{
    uint8 u8EventID;
    uint8 u8RecieveBuf[255];
    uint8  u8SdCardWriteBuf[255];
    uint8  u8SdCardWriteReady;

}event_data_t;

typedef struct
{
    uint8 u8EventID;
    uint8 u8Nobrake[3];
    uint8 u8Normalbrake[3];
    uint8 u8Serivcebrake[3];
    uint8 u8Emergencybrake[3];

}change_of_brake_t;

/*structure for SPAD packet*/
typedef struct
{
     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;

     uint32 u32loco_id;
     uint32 u32abs_loc;
     uint8 signal_aspect;

}SPAD_packet_t;




typedef struct
{
    uint8 u8Day;
    uint8 u8Month;
    uint16 u16Year;
    uint8 u8seconds;
    uint8 u8minutes;
    uint8 u8hours;
    uint32 u32LocoID;
    uint32 u32ABS_Loc;
    uint8 Emergencystatus;
}lvk_emergency_msg;


typedef struct
{
    uint8 u8Day;
    uint8 u8Month;
    uint16 u16Year;
    uint8 u8seconds;
    uint8 u8minutes;
    uint8 u8hours;
    uint16 u16stationID;
    uint8 u8Emergencystatus;
}svk_emergency_msg;


typedef struct
{
    uint8 u8Day;
    uint8 u8Month;
    uint16 u16Year;
    uint8 u8seconds;
    uint8 u8minutes;
    uint8 u8hours;
    uint8 u8Relayeventcnt;
    uint8 u8Relaystatus;
}change_in_signalling_status;


typedef struct
{
    uint8 u8Day;
    uint8 u8Month;
    uint16 u16Year;
    uint8 u8seconds;
    uint8 u8minutes;
    uint8 u8hours;
    uint32 u32LocoID;
    uint32 u32ABS_location;
    uint8 u8mode;

}entry_of_new_train;


typedef struct
{
    uint8 u8Day;
    uint8 u8Month;
    uint16 u16Year;
    uint8 u8seconds;
    uint8 u8minutes;
    uint8 u8hours;
    uint8 u8RelayEventcnt;
    uint8 u8Prevstatus;
    uint8 u8Presentstatus;
}interlocking_status_t ;


/*structure to store live data*/

typedef struct
{
     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint8 u8loco_pkts_rcvd;
     uint8 fld_inputs_cnt;
     uint8 u8signal_inputs[50];
     uint8 u8signal_info_pkts_sent;
     uint8 u8track_profile_sent;
     uint8 u8stn_emerg_msg;
     uint8 u8GPS1_view;
     uint8 u8GPS2_view;
     uint8 u8GSM1_fault;
     uint8 u8GSM2_fault;
     uint8 u8Radio1RSSI;
     uint8 u8Radio2RSSI;
     uint8 u8session_key_mismatch;
     uint8 u8RIU_connectivity;
     uint8 u8SMOCIP_com1;
     uint8 u8SMOCIP_com2;
     uint8 u8signalling_input_fault;


}live_data_t;



/*structure for triggered maintaintenace data*/

typedef struct
{

    uint8 u8day;
    uint8 u8month;
    uint16 u16year;
    uint8 u8hours;
    uint8 u8minutes;
    uint8 u8seconds;
    uint16 u16station_id;
    uint32 abs_loc;
    uint8 u8radio1active;
    uint8 u8radio2active;
    uint8 u8radio1Health;
    uint8 u8radio2Health;
    uint8 u8radio1_ip_supply;
    uint8 u8radio2_ip_supply;
    uint8 u8radio1temp;
    uint8 u8radio2temp;
    uint8 u8radio1PAtemp;
    uint8 u8radio2PAtemp;
    uint8 u8radio1PAsupply;
    uint8 u8radio2PAsupply;
    uint8 u8radio1TXcurr;
    uint8 u8radio2TXcurr;
    uint8 u8radio1RSSI;
    uint8 u8radio2RSSI;
    uint8 u8radio1Revpower;
    uint8 u8radio2Revpower;
    uint8 u8radio1Forwpower;
    uint8 u8radio2Forwpower;
    uint8 u8SMOCIPcom1stat;
    uint8 u8SMOCIPcom2stat;
    uint8 u8RIUconnectivity;
    uint8 u8restartOfKavach;

}trig_maint_t;


/*station kavach - station kavach data packets*/

typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint32 u32MAC;
}train_handover_cancelletaion_msg_t;



typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint8  u8tlm_status;
    uint32 u32tlm_frame;
    uint8 u8tlm_offset;
    uint32 u32MAC;


}trn_len_info_pkt_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint8 u8tlm_info;
    uint32 u32MAC;
}trn_len_ack_pkt_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint16 u8tslRouteID;
    uint32 u32MAC;

}TSL_rqst_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint8 u8tslRouterqstRply;
    uint32 u32MAC;

}TSL_auth_t;



typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
  uint32 u32MAC;
}fld_ele_stat_rqst_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint16 u16fld_ele_len;
    uint8 u8field[10];
  uint32 u32MAC;

}fld_ele_stat_t;



typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint8 u8PDI_ver_primary;
    uint16 u16random_number;

}cmd_pdi_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint8 u8PDI_ver_check;
  uint8 u8PDI_ver_secondary ;
    uint16 u16sec_random_number;
    uint32 u32MAC;
}msg_PDI_t;



typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint32 u32MAC;

}Hrt_beat_msg_t;



typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint8 u8MA_frm_BorderRFID;
    uint16 dist_to_border_tag_location;
    uint8 u8loco_to_stn_reg_pkt[21];
    uint32 u32MAC;

}trn_handover_rqst_msg_t;




typedef struct
{
    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint32 u32okv_ID;
    uint32 u32MAC;

}trn_taken_ovr_msg_t;




typedef struct
{

    uint8 u8specific_protocol;
    uint16 u16message_type;
    uint8 u8sender_ID[20];
    uint8 u8recvr_ID[20];
    uint16 u16message_length;
    uint32 u32frame_num;
    uint16 u16mesg_seq;
    uint16 u16Border_RFID;
    uint8 u8Ref_prof_ID;
    uint32 u32okv_ID;

    uint32 u32MAC;



}train_RRI_info_t;



/***********************TSRMS STN KAVACH MESSAGES**************************************/

typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16Messagetype;
    uint16 u16senderId;
    uint16 u16receiverId;
    uint16 u16Messagelength;
    uint8 u8senderPDIversion;
    uint16 u16TSRMSRndNum;
}tsrms_to_SKavach;



typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16Messagetype;
    uint16 u16senderId;
    uint16 u16receiverId;
    uint16 u16Messagelength;
    uint8 u8resultofPDIVerCheck;
    uint8 u8PDIVerofKavach;
    uint16 u16SKavachRndNum;
    uint32 u32MAC;
}tsrms_to_SKAVACH;



typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16MessageType;
    uint16 u16senderTsrmsId;
    uint16 u16receiverStnId;
    uint16 u16Messagelength;
    uint32 u32FrameNum;
    uint16 u16TAN;
    uint8 u8tsrActivationDay;
    uint8 u8tsrActivationMonth;
    uint8 u8tsrActivationYear;
    uint8 u8tsrActivationHour;
    uint8 u8tsrActivationMinutes;
    uint8 u8tsrActivationSeconds;
    uint8 u8TSRcnt;
    uint8 u8TSRIdentity;
    uint8 u8TSRType_Continous;
    uint8 u8TSRType_Intermittent;
    uint8 u8ActiveTsrStartDay;
    uint8 u8ActiveTsrStartMonth;
    uint8 u8ActiveTsrStartYear;
    uint8 u8ActiveTsrStartHour;
    uint8 u8ActiveTsrStartMinutes;
    uint8 u8ActiveTsrStartSeconds;
    uint8 u8ActiveTsrEndDay;
    uint8 u8ActiveTsrEndMonth;
    uint8 u8ActiveTsrEndYear;
    uint8 u8ActiveTsrEndHour;
    uint8 u8ActiveTsrEndMinutes;
    uint8 u8ActiveTsrEndSeconds;
    uint16 u16TSRRoute1ID;
    uint16 u16TSRRoute2ID;
    uint16 u16TSRRoute3ID;
    uint16 u16TSRRoute4ID;
    uint16 u16TSRRoute5ID;
    uint8 u8TSRdirection;
    uint16 u16TsrStartingDist;
    uint16 u16TSRLength;
    uint8 u8TSRAplicableTrainClass;
    uint8 u8universal_TSR_speed;
    uint8 u8TSRClassAtrains;
    uint8 u8TSRClassBtrains;
    uint8 u8TSRclassCtrains;
    uint8 u8Whistlecode;
    uint32 u32MAC;
}All_tsr_info_msg;


typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16MessageType;
    uint16 u16senderstnId;
    uint16 u16receiverTsrmsId;
    uint16 u16Messagelength;
    uint32 u32FrameNum;
    uint16 u16TAN;
}svk_to_tsrms_info_msg;



typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16MessageType;
    uint16 u16senderStnId;
    uint16 u16receiverTsrmsId;
    uint16 u16Messagelength;
    uint32 u32FrameNum;
    uint16 u16TAN;
    uint8 u8tsrActivationDay;
    uint8 u8tsrActivationMonth;
    uint8 u8tsrActivationYear;
    uint8 u8tsrActivationHour;
    uint8 u8tsrActivationMinutes;
    uint8 u8tsrActivationSeconds;
    uint8 u8TSRcnt;
    uint8 u8TSRIdentity;
    uint8 u8TSRType_Continous;
    uint8 u8TSRType_Intermittent;
    uint8 u8ActiveTsrStartDay;
    uint8 u8ActiveTsrStartMonth;
    uint8 u8ActiveTsrStartYear;
    uint8 u8ActiveTsrStartHour;
    uint8 u8ActiveTsrStartMinutes;
    uint8 u8ActiveTsrStartSeconds;
    uint8 u8ActiveTsrEndDay;
    uint8 u8ActiveTsrEndMonth;
    uint8 u8ActiveTsrEndYear;
    uint8 u8ActiveTsrEndHour;
    uint8 u8ActiveTsrEndMinutes;
    uint8 u8ActiveTsrEndSeconds;
    uint16 u16TSRRoute1ID;
    uint16 u16TSRRoute2ID;
    uint16 u16TSRRoute3ID;
    uint16 u16TSRRoute4ID;
    uint16 u16TSRRoute5ID;
    uint8 u8TSRdirection;
    uint16 u16TsrStartingDist;
    uint16 u16TSRLength;
    uint8 u8TSRAplicableTrainClass;
    uint8 u8universal_TSR_speed;
    uint8 u8TSRClassAtrains;
    uint8 u8TSRClassBtrains;
    uint8 u8TSRclassCtrains;
    uint8 u8Whistlecode;
    uint32 u32MAC;
}svk_to_tsr_data;


typedef struct
{
    uint8 u8Protocoltype;
    uint16 u16MessageType;
    uint16 u16senderTsrmsId;
    uint16 u16receiverstnId;
    uint16 u16Messagelength;
    uint32 u32FrameNum;
    uint16 u16TAN;
}Tsr_Data_integrity_test_msg;



typedef struct
{

    uint8 u8Protocoltype;
    uint16 u16MessageType;
    uint16 u16senderstnId;
    uint16 u16receiveTsrmsId;
    uint16 u16Messagelength;
    uint32 u32FrameNum;
    uint16 u16TAN;
    uint8 u8tsrActivationDay;
    uint8 u8tsrActivationMonth;
    uint8 u8tsrActivationYear;
    uint8 u8tsrActivationHour;
    uint8 u8tsrActivationMinutes;
    uint8 u8tsrActivationSeconds;
    uint8 u8TSRcnt;
    uint8 u8TSRIdentity;
    uint32 u32MAC;

}svk_ack_msg;



/***********************CRITICAL DATA STRUCTURES******************************/
typedef  struct
{



     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint16 u16station_id;
     uint8 u8radio1_health;
     uint8 u8radio1ipsupply;
     uint8 u8radio1Temp;
     uint8 u8radio1PATemp;
     uint8 u8radio1PAsplyVol;
   uint8 u8radio1TxPACurr;
     uint8 radio1RevPow;
     uint8 radio1ForPow;
     uint16 radio1RSSI;
     uint8 Radio1RxPktCnt;


} radio1_t;

typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint16 u16stationid;
     uint8 u8radio2_health;
     uint8 u8radio2ipsupply;
     uint8 u8radio2Temp;
     uint8 u8radio2PATemp;
     uint8 u8radio2PAsplyVol;
     uint8 u8radio2TxPACurr;
     uint8 radio2RevPow;
     uint8 radio2ForPow;
     uint16 radio2RSSI;
     uint8 Radio2RxPktCnt;

} radio2_t;

typedef struct
{
     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint16 u16stationid;
     uint8 GSM1RSSI;
     uint8 GSM2RSSI;

}GSM_t;



typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
   uint32 u32locoID;
     uint32 u32abs_loc;
   uint16   u16Miss_tag;
     uint16   u16Invalid_tag;

} RFID_t;

typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;

     uint32 u32locoID;
     uint32 u32abs_loc;

     uint16  u16uplink_Freq_cha_num;
     uint16  u16downlink_Freq_cha_num;

     uint8  u8Alloc_slot_newLOCO;

} freq_chan_t;

typedef struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;


     uint16 u16station_id;
     uint32 u32abs_loc;


     uint8  Current_key;
     uint8  Remain_key;
} key_t;

typedef  struct
{


     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;

     uint16 u16station_id;
     uint32 u32abs_loc;


     uint8  u8Active_Gps1;
     uint8  u8Active_Gps2;
     uint8  u8Both_Gps;
     uint8  u8No_Gps;
     uint8  u8Both_RSSI;
     uint8  u8Both_View;
     uint8  u8Both_second;

     uint8  u8GSM1RSSI;
     uint8  u8GSM2RSSI;

} Gps_and_GSM_status_t;

typedef  struct
{
     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;

   uint32 u32locoID;
     uint32 u32abs_loc;


     uint8  u8Wrong_Tag;
     uint8  u8Coll_det;
     uint8  u8Shut_limit;
     uint8  u8Invalid_pos;
     uint8  u8Sig_conf;

} SOSdet_t;

typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;

     uint32 u32locoID;
     uint32 u32abs_loc;

     uint8  u8Unknown_dir_SR;
     uint8  u8Out_of_STN;
     uint8  u8IS_NL_mode;
     uint8  u8auth_failure;
     uint8  u8Com_time_out;

} Exit_t;

typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint32 u32locoID;
     uint32 u32abs_loc;
     uint8  u8sos_Ack;
     uint8  u8Trip_Ack;
     uint8  u8Post_Ack;
     uint8  u8OS_SR_Ack;
     uint8  u8OVD_SR_Ack;
     uint8  u8Unusual_stop_Ack;
     uint8  u8Loco_sos_Ack;
     uint8  u8LS_SR_Ack;
     uint8  u8Radio_Dai_Fail;

} Ack_t;

typedef  struct
{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint16 u16station_id;
     uint32 u32abs_loc;
     uint8 u8GTCPU1_health;
     uint8 u8GTCPU2_health;
     uint8 u8GTVCOM1_health;
     uint8 u8GTVCOM2_health;
     uint8 u8GTMVI1_health;
     uint8 u8GTMVI2_health;
     uint8 u8GTIN1_health;
     uint8 u8GTIN2_health;
     uint8 u8GTIN3_health;
     uint8 u8GTIN4_health;


} module_t;



typedef struct{

     uint8 u8day;
     uint8 u8month;
     uint16 u16year;
     uint8 u8hours;
     uint8 u8minutes;
     uint8 u8seconds;
     uint16 u16stationID;
     uint8 active_GPS_Number;
     uint8 GPS_view;
     uint8 GPS_sec;
     uint8 GPS_satellite_in_view;
     uint8 GPS_CNO;

}GPS_t;


extern uint8 data_pkt_buffer[400];
extern char TempDataBuf[100];
extern char TempDataBuf1[100];

/*Critical data logging functions*/
extern void critdat_Radio1_health(void);
extern void critdat_Radio2_health(void);
extern void critdat_RFID_Tag(void);
extern void critdat_freqchan_alloc(void);
extern void critdat_keys_details(void);
extern void critdat_SOS_Detection(void);
extern void critdat_train_exit_from_station(void);
extern void critdat_loco_ack_data(void);
extern void critdat_module_status(void);
extern void critdat_GSM_status(void);
extern void critdat_GPS1_status(void);
extern void critdat_GPS2_status(void);



/****************Access Authority Packet ***************************************************************/

#define AAPKT_PKT_TYPE                                  4U
#define AAPKT_PKT_LEN                                   7U
#define AAPKT_PFRAME_NUM                                17U
#define AAPKT_SSTN_ILC_IBS_ID                           16U
#define AAPKT_SSTN_ILC_IBS_VER                          3U
#define AAPKT_SSTN_ILC_IBS_LOC                          23U
#define AAPKT_DEST_LOCO_ID                              20U
#define AAPKT_ALLOTED_UPLINK_FREQ                       12U
#define AAPKT_ALLOTED_DNLINK_FREQ                       12U
#define AAPKT_ALLOTED_TDMA_TSLOT                        7U
#define AAP_STN_RND_NUM_RS                              16U
#define AAPKT_STN_TDMA                                  7U
#define AAPKT_MAC_CODE                                  32U
#define AAPKT_CRC                                       32U

/*Access Request Packet:**********************************************************************/
#define ARPKT_PKT_TYPE                                  4U
#define ARPKT_PKT_LEN                                   7U
#define ARPKT_FRAM_NUM                                  17U
#define ARPKT_SOURCE_LOCO_ID                            20U
#define ARPKT_SOURCE_LOCO_VER                           3U
#define ARPKT_ABS_LOCO_LOC                              23U
#define ARPKT_TRAIN_LEN                                 11U
#define ARPKT_TRAIN_SPEED                               9U
#define ARPKT_MOVEMNT_DIR                               2U
#define ARPKT_EMG_STATUS                                3U
#define ARPKT_LOCO_MODE                                 4U
#define ARPKT_APRCH_STNID                               16U
#define ARPKT_LAST_RFID_TAG                             10U
#define ARPKT_TIN                                       9U
#define ARPKT_LONGITUDE                                 21U
#define ARPKT_LATITUDE                                  20U
#define ARPKT_LOCO_RND_NUM_RL                           16U
#define ARPKT_PADDING_BIT                               5U
#define ARPKT_CRC                                       32U

/*Station to Loco Regular Packet*******************************************************/
#define SL_HED_PKT_TYPE                                 4U
#define SL_HED_PKT_LEN                                  10U
#define SL_HED_FRM_NUM                                  17U
#define SL_HED_SSTN_ILC_IBS_ID                          16U
#define SL_HED_SSTN_ILC__IBS_VER                        3U
#define SL_HED_DEST_LCNT                                4U
#define SL_HED_ER_FZR                                   2U
#define SL_HED_DEST_LOCOID                              20U
#define SL_HED_REF_PROFID                               4U
#define SL_HED_LREF_RFID                                10U
#define SL_HED_DIST_PKT_STRT                            15U
#define SL_HED_PKT_DIR                                  2U
#define SL_HED_PADING                                   3U


/*Loco to Station Regular Packet:**********************************************/

#define LS_PKT_TYPE                                     4U
#define LS_PKT_LEN                                      7U
#define LS_FRAME_NUM                                    17U
#define LS_SOURCE_LOCO_ID                               20U
#define LS_SOURCE_LOCO_VER                              3U
#define LS_ABS_LOCO_LOC                                 23U
#define LS_L_DOUBTOVER                                  9U
#define LS_L_DOUBTUNDER                                 9U
#define LS_TRAIN_INT                                    2U
#define LS_TRAIN_LEN                                    11U
#define LS_TRAIN_SPEED                                  9U
#define LS_MOVEMNT_DIR                                  2U
#define LS_EMG_STATUS                                   3U
#define LS_LOCO_MODE                                    4U
#define LS_LAST_RFID_TAG                                10U
#define LS_MAINDUP_TAG                                  1U
#define LS_TAG_LINK_INFO                                3U
#define LS_TIN                                          9u
#define LS_BRAKE_APPLIED                                3U
#define LS_NEWMA_REPLY                                  2u
#define LS_LAST_REF_PROFID                              4U
#define LS_SIG_OV                                       1U
#define LS_INFO_ACK                                     4U
#define LS_SPARE                                        3U
#define LS_LOCO_HEALTH_STATUS                           6U
#define LS_MAC_CODE                                     32U
#define LS_PACK_CRC                                     32U


#define BIU_EVENT_TYPE                                  8U
#define BIU_ISOIP                                       8U
#define BIU_ISO_CMD                                     8U


/*typedef union
{
    uint16 Word;
    struct
    {
            uint8   Lo;
            uint8   Hi;
        } Byte ;
} wordtype_t;*/



#define FRAME_HEADER1                                   (0U)
#define FRAME_HEADER2                                   (1U)
#define END_EACH_FRAME1                                 (2U)
#define TARGET_DISTANCE_HI                              (3U)
#define TARGET_DISTANCE_LOW                             (4U)
#define END_EACH_FRAME2                                 (5U)

#define TYPE_TARGET                                     (6U)
#define END_EACH_FRAME3                                 (7U)
#define CURR_SPEED                                      (8U)
#define END_EACH_FRAME4                                 (9U)
#define PERMIT_SPEED                                    (10U)

#define END_EACH_FRAME5                                 (11U)
#define LOCO_ID_LOW                                     (12U)
#define LOCO_ID_HI                                      (13U)
#define END_EACH_FRAME6                                 (14U)
#define NEXT_LOW_SPEED                                  (15U)

#define END_EACH_FRAME7                                 (16U)
#define BRAKE_CMD                                       (17U)
#define END_EACH_FRAME8                                 (18U)
#define ABS_LOC_LOW                                     (19U)
#define ABS_LOC_MID                                     (20U)

#define ABS_LOC_HI                                      (21U)
#define END_EACH_FRAME9                                 (22U)
#define MODE_OPERATION                                  (23U)
#define END_EACH_FRAME10                                (24U)
#define MOVING_AUTHORITY                                (25U)

#define END_EACH_FRAME11                                (26U)
#define CUR_SIGNAL_ASPECT                               (27U)
#define END_EACH_FRAME12                                (28U)
#define ADD_PROVISION                                   (29U)
#define END_EACH_FRAME13                                (30U)

#define DIST_CURRENT_SIGNAL_LOW                         (31U)
#define DIST_CURRENT_SIGNAL_HI                          (32U)
#define END_EACH_FRAME14                                (33U)
#define CUR_SIGNAL_TYPE_LOW                             (34U)
#define CUR_SIGNAL_TYPE_HI                              (35U)

#define END_EACH_FRAME15                                (36U)
#define DECELERATION_CONST                              (37U)
#define END_EACH_FRAME16                                (38U)
#define TRAIN_LENGTH_LOW                                (39U)
#define TRAIN_LENGTH_HI                                 (40U)

#define END_EACH_FRAME17                                (41U)
#define LTCAS_SYSTEM_STSTUS                             (42U)
#define END_EACH_FRAME18                                (43U)
#define SoS_STATUS                                      (44U)
#define END_EACH_FRAME19                                (45U)

#define RADIO_SIG_STRENGTH                              (46U)
#define END_EACH_FRAME20                                (47U)
#define RFID_ID_LOW                                     (48U)
#define RFID_ID_HI                                      (49U)
#define DIRECTION                                       (50U)

#define DISTANCE_LOW                                    (51U)
#define DISTANCE_HI                                     (52U)
#define END_EACH_FRAME21                                (53U)
#define TAG_DETECTION_STATUS                            (54U)
#define END_EACH_FRAME22                                (55U)
#define CRC_LOW                                         (56U)
#define CRC_HI                                          (57U)

#define END_EACH_FRAME                0x7cU

/*******************************************modes*******************************************/
#define FRAME_HEADER1                                   (0U)
#define FRAME_HEADER2                                   (1U)
#define END_EACH_FRAME1                                 (2U)
#define TARGET_DISTANCE_HI                              (3U)
#define TARGET_DISTANCE_LOW                             (4U)
#define END_EACH_FRAME2                                 (5U)

#define TYPE_TARGET                                     (6U)
#define END_EACH_FRAME3                                 (7U)
#define CURR_SPEED                                      (8U)
#define END_EACH_FRAME4                                 (9U)
#define PERMIT_SPEED                                    (10U)

#define END_EACH_FRAME5                                 (11U)
#define LOCO_ID_LOW                                     (12U)
#define LOCO_ID_HI                                      (13U)

/***************************************Logging*****************************************************/
#define STNREG           1U
#define LOCOREG          2U
#define ARPKT            3U
#define AGPKT            4U
#define AEPKT            5u
#define GPSPKT           5U
#define ABSPKT           6U
#define ACKPKT           7U
#define NMTAG            7U
#define LCTAG            8U
#define ADJTAG           9U
#define JUNTAG           10U

#define TRIGDATA         12U
#define CRITDATA         13U
#define LIVDATA          14U
#define TRIGMAINTDATA    15U
#define SVKSVKDATA       16U


extern uint8 TMVI_Slot_ID;
extern uint8 TMVI_Add_ID;
extern uint8 TMVI_Config_ID;
/*extern dip_switch_info_t DIP_Switch_Info;*/

extern uint8 gcTemp;
extern unsigned long g_ulFlags;
extern uint8 gcDIBuf[8];
extern volatile unsigned long g_bErrFlag;
extern volatile unsigned long g_bMsgObj3Sent;
extern volatile unsigned long g_bRXFlag1;
extern volatile unsigned long g_bRXFlag2;
extern volatile unsigned long g_ulMsgCount;
extern volatile unsigned long g_bErrFlagC2;
extern volatile unsigned long g_ulMsgCountC2;
extern volatile unsigned long g_bMsgObj8SentC2;
extern unsigned long ulStatusC2;
extern volatile unsigned long g_bCANFlags1C2;
extern volatile unsigned long g_bCANFlags2C2;
extern volatile unsigned long g_bRXFlag1C2;
extern volatile unsigned long g_bRXFlag2C2;
extern uint8    gSMOCIPRdy;
extern unsigned long ulStatus;
extern volatile unsigned long g_bMsgObj8Sent;
extern uint8 ucMsgData[8];
extern char ucMsgCounter[8];
extern uint8 ucMsgTxBOX8[8];
extern uint8 ucMsgTxBOX81[8];
extern char TempDataBuf[100];
extern uint8 SDWriteRdy;
extern uint32 CopyBitsRx (bool *datainbits , uint16 startpos , uint8 offset);
extern uint8 u8ARPacketrcvd;
extern uint8 u8AGPacketrcvd;
extern uint8 u8LocoRegPacketrcvd;
extern uint8 u8StnRegPacketrcvd;
extern void CheckCAN1Lost(void);
extern void ProcessEventdata(uint8 u8EventType, uint8_t* data);

extern char ucMsgCPU1[8];
extern char ucMsgCPU2[8];
extern char ucMsgCPU[256][8];
extern unsigned long gnRec1Count;
extern unsigned char gcRec1Buf[1000];
extern unsigned char gcRx1Bit;

extern unsigned long gnRec0Count;
extern unsigned char gcRec0Buf[1000];
extern unsigned char gcRx0Bit;

extern unsigned short gsDly0Reg;
extern unsigned short gsDly1Reg;
extern double gTemperture;

extern uint16 gsDly5Reg;
extern uint16 gnRec5Count;
extern char gcRec5Buf[1500];
extern uint8 gcRx5Bit;
extern uint8 gT5Rdy,gcRx5Dly;

extern char ucARRadioData[10][8];
extern char ucAGRadioData[10][8];
extern char ucLocoRegData[10][8];
extern char ucStnRegData[150][8];
extern char ucGPSData[10];
extern uint16 u16Writetmr;

extern uint8 u8CanMsgIndex;
extern uint8 u8CANRxCnt;

extern uint8 Log_CAN_data_buf[8];
extern uint8 u8message_Box6[8];
/***************************************************************************/
extern void init_io(void);
extern void Can0_ObjSet(void);
extern void Can1_ObjSet(void);
extern void Initialise_CAN0(void);
extern void Initialise_CAN1(void);

extern void SendCANtoRF(void);
extern void ProcessDMICAN(void);
extern void SendCANtoRS422(void);
extern void ProcessRFCAN(void);
extern void SendCANtoDMI1(void);
extern void ProcessRFID(void);
extern uint8 hex_decode(uint8 _data1, uint8 _data2);
extern void ProcessStatData(void);
extern void SendCANtoBIU(void);
extern void SendCANtoCount(void);
extern void SendCANtoDMI2(void);
extern void SendCANtoDMI3(void);
extern void ProcessSignalData(void);
extern void CheckCollision(void);
extern void ExtractTVCOMdata(void);
extern void ExtractARPacket(uint8* packet);
extern void ExtractAGPacket(uint8* packet);
extern void ExtractLocoRegPacket(uint8* packet);
extern void ExtractStnRegPacket(uint8* packet);
extern void WriteTVCOMdataforlogging(void);
extern void ExtractEventdata(uint8 i);
extern void ExtractTSRMSdata(void);


extern void CheckCAN0Lost(void);
void sendCAN2CPU(uint8 _CANaddr);
extern void sendCAN0Test(void);
extern void sendCAN1Test(void);
void readInputsFPGA(void);
uint8 Read_FPGA(uint8 Address);
void Write_FPGA(uint8 Address, uint8 Data);
void FPGARst(void);

void setTMP101(void);
uint16 ReadTMP101(void);
void setINA226(void);
void readINA226(void);
void i2cRead(uint8 _addr, uint8 _cnt);
void i2cWrite(uint8 _addr, uint8 _data);
void i2c_Stop(void);
void i2c_Restart(void);
void i2c_SendByte(uint8 _buf);

void ProcessGPS(void);
void ProcessGPRMC(void);
uint32 ProcessGPSField(uint8 index);
uint32 ProcessField(uint8 index, const uint8 *pucBuffer, char _val, char _end);
uint32 ProcessData(uint8 index);
uint32 ProcessFieldSD(uint8 index, const uint8 *pucBuffer, char _val, char _end);

void UART5Send(const uint8 *pucBuffer, unsigned long ulCount);
uint32 calculateLRC(const uint8 *pucBuffer, uint8 _len);
void decodeRFID(uint8 _rxCount);

void    Read_Slot_Detect_Dip_Switch(void);
void    Read_Config_Dip_Switch(void);
void    Read_Add_Dip_Switch(void);

extern void Init_SD_Card(void);
extern void CheckSDCard(void);
extern void SDCard_SeekPipe(const char * Filename, uint64 LineCnt, int Pipe_Cnt,const char * Data, char Mode, uint32 Len);         /*, unsigned long ReadCount*/
extern void USBSDCard_SeekPipe(const char * Filename, uint64 LineCnt, int Pipe_Cnt,const char * Data, char Mode, uint32 Len);
extern void SDCard_CreateFile(const char *Filename,const char * Code);
extern unsigned long Get_MemoryStatus(void);
extern void SDCard_WriteFile(char * Filename, char * Code);



extern void Build_SM_OCIP_Transmit_Message(void);
extern uint8 ExtractMode(uint8 _mode);
extern void GPS_BB_COM_Send(const unsigned char *pucBuffer, unsigned long ulCount);
extern void Test_Function(void);
extern void WriteSDCard(uint8* log_data,  uint8 logtype, uint16_t len, uint8 data_type);
extern void WriteLiveDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length);
extern void WriteCritDatatoSDCard(uint8* log_data , uint8 u8EventID, uint8 logtype,uint8 data_pkt_length);
extern void WriteTrigDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length);
extern void WriteTrigMaintDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length);
extern void WritedirectpktDatatoSDCard(uint8* log_data , uint8 EventID, uint8 event_Type, uint8 data_pkt_length);

extern void WriteSvkSvkDatatoSDCard(uint8* log_data , uint8 EventID, uint8 logtype, uint8 data_pkt_length);
extern void WriteKMSCONSTLENDatatoSDCard(uint8* log_data , uint8 EventID, uint16 BYTE_OFFSET);
extern void WriteKMSVARLENDatatoSDCard(uint8* log_data , uint8 EventID, uint16 BYTE_OFFSET);
extern void WriteTSRMSDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length);

extern void build_svk_svk_trn_handover_canc_pkt(void);
extern void build_svk_svk_trn_len_info_pkt(void);
extern void build_svk_svk_trn_len_ack_pkt(void);
extern void build_svk_svk_TSL_rqst_msg(void);
extern void build_svk_svk_TSL_auth_msg(void);
extern void build_svk_svk_fld_ele_stat_rqst_msg(void);
extern void build_svk_svk_fld_ele_stat_msg(void);
extern void build_svk_svk_cmd_pdi_msg(void);
extern void build_svk_svk_msg_PDI_msg(void);
extern void build_svk_svk_Hrt_beat_msg(void);
extern void build_svk_svk_trn_handover_rqst_msg(void);
extern void build_svk_svk_trn_taken_ovr_msg(void);
extern void build_svk_svk_train_RRI_info_msg(uint8 * data_pkt, uint8 pkt_len);

extern void build_trig_new_train_entry_data(void);
extern void build_trig_interlocking_status_data(void);
extern void build_trig_lvk_emegency_status_data(void);
extern void build_trig_svk_emegency_status_data(void);
extern void build_trig_siganlling_change_status_data(void);

extern void build_Tsr_Cmd_PDI_ver_check_data(void);
extern void build_Tsr_Msg_PDI_ver_check_data(void);
extern void build_all_Tsr_info_msg(void);
extern void get_Stn_Tsr_info_msg(void);
extern void Stn_Tsr_data_msg(void);
extern void Tsr_data_integrity_test_msg(void);
extern void Stn_ack_msg(void);

extern void build_SPAD_event(void);

extern void build_live_data(void);

extern void build_triggered_maint_data(void);

extern void GPS_details(void);

extern void send_pkt_to_log(uint8 event_type, uint8 event_id, uint16 data_pkt_length , uint8 *log_data);


extern void ReadSDCard(void);
extern void ClearSDCard(void);
/*extern int my_strcmp(char* str1, const char *str2);*/
extern uint8 my_strcmp(const char *str1,const char *str2);
extern uint32 my_strlen(const char* str3);
char*strstr3(const char *str, const char *substring);
extern void my_sprintf(char * main_buf, const char* dec,const char *main_data);
extern void my_sprintf1s(char * main_buf, const char* dec);
extern void my_sprintfint(char * main_buf, const char* dec, uint32 lcnt, uint32 lcnT);
extern uint32 numtoascii(uint32  num);

extern uint8 flag;



#endif /* INCLUDE_TCAS_H_ */
