/*
 * kavach.h
 *
 *  Created on: 01-Aug-2024
 *      Author: User
 */

#ifndef INCLUDE_KAVACH_H_
#define INCLUDE_KAVACH_H_


#include "sys_common.h"

//#define SET_LOW         (0u)
//#define SET_HIGH        (1u)
#define ENABLE          (0xFFFFFFFFu)
#define DISABLE         (0x00000000u)

#define EMIFPORT        (hetPORT1)

extern uint8_t u8canidentifier;

/******************MACROs for Loco Fault messages for Event logging*********************/
#define DATETIME_PKT    (17u)
#define ABSLOC_PKT      (18u)
#define DATA_PKT        (19u)


#define RADIO_INFOPKT    (1u)
#define RADIO_DATAPKT    (2u)
#define RADIO_PKT        (1u)

//typedef struct
//{
//    uint8_t u8Address;
//    uint8_t u8Config;
//    uint8_t u8Slot;
//}gDipinfo_t;

 typedef struct
 {

 }gInputData;

//extern gDipinfo_t DipInfo;
extern gInputData IPData;



/***************************Structures for radio packets svk-svk(5)*****************/

typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_MA;
    uint8 b4frame_offset;
    uint8 b4dest_loco_sos;
    uint8 b2train_sel_type;
    uint32 b17cur_sig_info;
    uint8 b6cur_sig_aspect;
    uint8 b6nxt_sig_aspect;
    uint16 b15appr_sig_dist;
    uint8 b2aut_type;
    uint8 b6authorized_speed;
    uint16 b16MA_wrt_sig;
    uint8 b1req_shorten_MA;
    uint8 b16new_MA;
    uint8 b1TRN_len_info_sts;
    uint8 b1TRN_len_info_type;
    uint32 b17ref_frame_num_tlm;
    uint8 b8ref_offset_int_tlm;
    uint8 b1next_stn_comm;
    uint16 b16appr_stn_ILC_IBS_ID;
}ma_pkt;
extern ma_pkt MA_pkt;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_ssp;
    uint8 b5LM_speed_inof_cnt;
    uint16 b15LM_static_speed_dist;
    uint8 b1LM_static_speed_class;
    uint32 b6LM_static_speed_value;
}static_speed_value;
extern static_speed_value  SSP_Value;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_GRAD;
    uint8 b5LM_grad_info_cnt;
    uint16 u15LM_gradient_dist;
    uint8 b1LM_GDIR;
    uint32 b5LM_Gradient_value;

}gradient_prof;
extern gradient_prof  Grad_Prof;

typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_LC;
    uint8 b5LM_LC_info_cnt;
    uint16 b15LM_LC_dist;
    uint8 b10LM_LC_ID_numeric;
    uint32 b3LM_LC_ID_alpha_suffix;
    uint8 b1LM_LC_manning_type;
    uint8 b3LM_LC_class;
    uint16 b1LM_LC_auto_whistling_enable;
    uint8 b2LM_LC_Auto_whistling_type;
}Lc_gate_prof;
extern Lc_gate_prof  LC_Gate_Prof;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_TSP;
    uint8 b5TO_speed;
    uint16 b15Diff_dist_TO;
    uint16 b12TO_speed_rel_dist;
}turnout_speed_prof;
extern turnout_speed_prof TO_Speed_Prof;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_TLI;
    uint8 b4dist_dup_tag;
    uint8 b6route_rfid_cnt;
    uint16 b11dist_nxt_rfid;
    uint16 b10nxt_rfid_tag_id;
    uint8 b1dup_tag_dir;
    uint8 b1ABS_loc_reset;
    uint16 b15start_dist_TO_loc_reset;
    uint8 b2adj_loco_dir;
    uint32 b23ABS_loc_correction;
    uint8 b3adj_line_cnt;
    uint16 b9Line_TIN;
}tag_linking_info;
extern tag_linking_info Tag_Link_Info;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_TC;
    uint8 b4track_cond_cnt;
    uint8 b4track_cond_type;
    uint16 b15start_dist_trackcond;
    uint16 b15len_trackcond;
}track_cond_data;
extern track_cond_data  Track_Cond_Data;


typedef struct
{
    uint8 b4sub_pkt_type;
    uint8 b7sub_pkt_len_TC;
    uint8 b2tsr_status;
    uint8 b5tsr_info_cnt;
    uint8 btsr_id;
    uint16 b15tsr_dist;
    uint16 b15tsr_len;
    uint8 b1tsr_class;
    uint8 b6tsr_universal_speed;
    uint8 b6tsr_classA_speed;
    uint8 b6tsr_classB_speed;
    uint8 b6tsr_classC_speed;
    uint8 b2tsr_whistle;
}temp_speed_restrictions_prof;
extern temp_speed_restrictions_prof  TSR_Prof;

extern void wait(uint32_t u32time);



extern void build_MA_packet(void);
extern void BuildExtLiveData(void);
extern void BuildCriticalLiveData(void);
extern void ExtractLiveEventdata(uint8 i);

extern void ExtractLocoEventdata1(uint8 i);

/***************Event Logging **************************/
extern void processLogData(uint8_t u8canidentifier);
extern void process_TSRMS_data();
extern void process_gps_time(void);


#endif /* INCLUDE_KAVACH_H_ */
