/*
 * sys_main.h
 *
 *  Created on: 11-Oct-2023
 *      Author: HP 840 G3
 */

#ifndef INCLUDE_SYS_MAIN_H_
#define INCLUDE_SYS_MAIN_H_

#include "sci.h"
#include "gio.h"
#include <string.h>
#include "MAIN.h"

#define UART (scilinREG)
#define UART2 (sciREG)


static uint8_t command;

#define MAX_DATA_RECEIVE_COUNT (2000u)


#define KEYRCVD       1
#define OTPRCVD       1
#define KEYNOTRCVD    0
#define OTPNOTRCVD    0

#define TIMEOUT_EVENT 0

extern uint8 Receive_Data[2000];
extern uint32 size;
extern uint32 Rx_size;
extern uint8 flag;
extern uint8 tx_packet[256];

extern char TempBuf[256];
extern uint8 DataBuf[128];
extern char txData[128];
extern uint8 set;
extern uint32 sms;
extern uint8 DisBuf[256];

extern char KeyData1[3024];
extern char KeyData4[700];
extern uint8 KeyData6[2000];
extern uint8 transmit1[1023];
extern uint8 transmit2[60];
extern uint8 transmit3[20];
extern uint8 transmit4[23];
extern uint8 var1[5];
extern uint8 var;
extern uint16 var3;
extern uint16 valu;

extern uint8 i;

extern uint8 ip_address[17];
extern uint8 *ptr;
extern uint8 len;
extern uint8 u8Socket;
extern uint32 u32port;

extern uint8 rcvotp[128];
extern uint8 otp[4];

extern uint16 RTI_CNT;
extern uint8  GL_DOG_VAL;

extern uint8_t u8KeyRequestbit;
extern uint16_t gKeyTimer1;

extern uint8_t u8KeyReqByte;

extern uint8_t KMStoNMS;

extern struct GSM gsm;
extern struct DateTime date_time;
extern struct AutKey aut_key;
extern struct UDPdata udp_data;

extern uint32_t gGenCntReg1,GenCnt1;

struct GSM
{
    uint16 SOF[2];
    uint8 Msg_type;
    uint16 Msg_length[2];
    uint8 Date[3];
    uint8 Time[3];
    uint8 Kavach_unit_type;
    uint8 Kavach_unit_ID[3];
    uint8 SIM_ID;
    uint8 Ack_status;
    uint32 OTP[4];
    uint32 Key_set_unique_ID[4];
    uint8 No_of_key_sets;
    uint32 start_time[4];
    uint32 end_time[4];
    uint8 key_set;
    uint32 crc[4];
    uint8 u8GSM_Rxbit;
};
struct GSM gsm;

struct DateTime
{
    uint8_t year;
    uint8_t month;
    uint8_t date;
    uint8_t hours;
    uint8_t minutes;
    uint8_t seconds;
    uint64_t key1;
    uint64_t key2;
};
struct DateTime date_time;

struct AutKey
{
    uint8_t AutKeystartyear[128];
    uint8_t AutKeystartmonth[128];
    uint8_t AutKeystartdate[128];
    uint8_t AutKeystarthours[128];
    uint8_t AutKeyendyear[128];
    uint8_t AutKeyendmonth[128];
    uint8_t AutKeyenddate[128];
    uint8_t AutKeyendhours[128];
    uint32_t AutKey1[30];
    uint32_t AutKey2[30];
    uint8_t UDPBuf[128];
    uint8_t UDPlen;
    uint8 OTPreg[15];
    uint16_t OTP_status;
    uint8_t status;
    uint16_t Msglen;
    uint16_t key_setcnt;
};
struct AutKey aut_key;

struct GSMreg
{
    uint8_t GSM_TxBit;
    uint8_t GSM_RxBit;
    uint8_t UDP_TxBit;
    uint8_t UDP_RxBit;
    uint8_t Rx_cnt;
    uint8_t Tx_cnt;
    uint8_t OTP_receive;
    uint8_t Key_receive;
    uint8_t UDP_closeBit;
    uint8_t Aut_queryBit;
};
struct GSMreg GSM_reg;

struct UDPdata
{
    uint8 IP_Address[0];
    uint8 socket[1];
    uint8 Port[6];
    uint8 leng[2];
    uint16 u16UDPRcvDataCnt;
    uint8 u8ProcesPendDataBit;
    uint32 u32NetworkCSQ1;
    uint8 chCGREG1;
};
struct UDPdata udp_data;

extern struct UDPdata udp_data;

extern void sciNotification(sciBASE_t *sci, uint32 flags);
extern void sciDisplayText(sciBASE_t *sci, const uint8 *data, uint32 length);
extern void Delay(uint32 wait);
extern uint8 GSM_wait(uint8 *ch_temp);
extern uint8 GSM_wait1(uint8_t const *ch_temp1);

extern void GSM_txData(void);
extern uint8 a2i(uint8 *txt);
extern void GSM_init(void);

extern void Close_socket(void);
extern void SendSMS(void);
extern void NewMsg_Notification(void);
extern void Process_GSMRcv(void);
extern void Read_SMS(uint8 data);
extern void resend_pck(void);

extern void GSM_DateTime(void);
extern void Delete_SMS(uint8 otp_data);

extern char *strstr1(uint8_t *str1, const char *str2);
extern void copystring(uint8 *str1, char *str2);
extern uint8 my_strncmp(const char *s1, const char *t, uint8 num);
extern uint8 Data_Buffer(uint8_t *buffer);
extern void transmit_udp(void);
extern uint16 arry(uint8 * array);

extern void Data_separation(void);
extern char* my_strncpy(char* dest, const char* src, uint8 n);

extern void Ide_Ack_Msg(void);
extern void Aut_key_Msg(void);
extern void Aut_status_Msg(void);

//extern uint16 my_strlen(uint8 * str3);
extern void cal_rcvdata(void);
extern char *strstr2(uint8_t *str, const char *substring);

extern uint32 crc_calc1(uint8 cnt, uint8 crc, uint8 *buf);
extern uint32_t crc32(const void *ptr, uint16_t len1);                      /* 45 functions */
extern uint32 crc_calc(uint32 cnt, uint8* buf);
extern uint32 crc32( const void *buf, uint16_t size);

extern uint32_t CheckIntCRC(uint32_t start_addr, uint32_t end_addr);

extern void Clear_Buffer(uint8_t * u8buffer);
extern void Clear_Buffer1(void);
extern void close_UDPsocket(void);
extern void close_UDPsocket1(void);

extern void GSM_UDP_init(void);
extern void read_sms_otp(void);

extern void UDPRcvdData(void);
extern void UDPRcvdData1(void);

extern void ProcessPendingUDPData();

extern void GSM_health_status_monitor_interrupt(void);
extern void GSM_health_status(void);

extern void ReadDipSwitchAdd(void);
extern void ReadDipSwitchConfig(void);
extern void ReadSlotDetect(void);

extern void SendModuleStatus2CPUCAN(void);
extern void ProcessKMSData(void);
extern void GSMTx_DataPacket_Formation(void);

extern void Loco_to_NMS_health_pkt_send(uint8 EventType);

extern void Clr_Log_Buff(void);

#endif /* INCLUDE_SYS_MAIN_H_ */
