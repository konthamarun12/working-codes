/*
 * user_CRC.h
 *
 *  Created on: Aug 17, 2024
 *      Author: HP
 */

#ifndef INCLUDE_USER_CRC_H_
#define INCLUDE_USER_CRC_H_


extern uint16 MODBUS_CRC16( const uint8 *buf, uint32 len );



#endif /* INCLUDE_USER_CRC_H_ */
