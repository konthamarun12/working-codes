/*
 * radio.h
 *
 *  Created on: Aug 29, 2024
 *      Author: HP
 */

#ifndef INCLUDE_RADIO_H_
#define INCLUDE_RADIO_H_


typedef struct additional_emergency_packet
{

    uint32 PKT_TYPE                   :4;
    uint32 PKT_LENGTH                 :7;
    uint32 FRAME_NUM                  :17;
    uint32 SOURCE_STN_ILC_IBS_ID      :16;
    uint32 SOURCE_STN_ILC_IBS_VERSION :3;
    uint32 STN_ILC_IBS_LOC            :23;
    uint32 GEN_SOS_CALL               :1;
    uint32 PADDING_BITS               :1;
    uint32 PKT_CRC                    :32;

}epkt_t;

/****************************************************************************************************************/
/*******************************************ACCESS AUTHORITY PACKET**********************************************/
typedef struct access_authority_packet
{
    uint32 PKT_TYPE                    :4;
    uint32 PKT_LENGTH                  :7;
    uint32 FRAME_NUM                   :17;
    uint32 SOURCE_STN_ILC_IBS_ID       :16;
    uint32 SOURCE_STN_ILC_IBS_VERSION  :3;
    uint32 STN_ILC_IBS_LOC             :23;
    uint32 DEST_LOCO_ID                :20;
    uint32 ALLOTED_UP_LINK_FREQ        :12;
    uint32 ALLOTED_DOWN_LINK_FREQ      :12;
    uint32 ALLOTED_TDMA_TIME_SLOT      :7;
    uint32 STN_RND_NUM_RS              :16;
    uint32 STN_TDMA                    :7;
    uint32 MAC_CODE                    :32;
    uint32 PKT_CRC                     :32;


}aapkt_t;



/****************************************************************************************************************/
/******************************************ACCESS REQUEST PACKET*************************************************/
typedef struct access_request_packet
{
    uint32 PKT_TYPE            :4;
    uint32 PKT_LENGTH          :7;
    uint32 FRAME_NUM           :17;
    uint32 SOURCE_LOCO_ID      :20;
    uint32 SOURCE_LOCO_VERSION :3;
    uint32 ABS_LOCO_LOC        :23;
    uint32 TRAIN_LENGTH        :11;
    uint32 TRAIN_SPEED         :9;
    uint32 MOVEMENT_DIR        :2;
    uint32 EMERGENCY_STATUS    :3;
    uint32 LOCO_MODE           :4;
    uint32 APPR_STN_ID         :16;
    uint32 LAST_RFID_TAG       :10;
    uint32 TIN                 :9;
    uint32 LONGITUDE           :21;
    uint32 LATITUDE            :20;
    uint32 LOCO_RND_NUM_RL     :16;
    uint32 PADDING_BITS        :5;
    uint32 PKT_CRC             :32;

}arpkt_t;

/*uint32 retrieving_data_from_arpkt(uint8* a_array,uint32 a_size);*/
void fill_and_send_the_access_request_packet_buffer(sciBASE_t* REGISTER);




/****************************************************************************************************************/
/********************************************onboard to station packet*******************************************/
typedef struct onboard_to_station_regular_pkt
{
    uint32 PKT_TYPE              :4;
    uint32 PKT_LENGTH            :7;
    uint32 FRAME_NUM             :17;
    uint32 SOURCE_LOCO_ID        :20;
    uint32 SOURCE_LOCO_VERSION   :3;
    uint32 ABS_LOCO_LOC          :23;
    uint32 I_DOUBTOVER           :9;
    uint32 I_DOUBTUNDER          :9;
    uint32 TRAIN_INT             :2;
    uint32 TRAIN_LENGTH          :11;
    uint32 TRAIN_SPEED           :9;
    uint32 MOVEMENT_DIR          :2;
    uint32 EMERGENCY_STATUS      :3;
    uint32 LOCO_MODE             :4;
    uint32 LAST_RFID_TAG         :10;
    uint32 TAG_DUP               :1;
    uint32 TAG_LINK_INFO         :3;
    uint32 TIN                   :9;
    uint32 BRAKE_APPLIED         :3;
    uint32 NEW_MA_REPLY          :2;
    uint32 LAST_REF_PROFILE_NUM  :4;
    uint32 SIG_OV                :1;
    uint32 INFO_ACK              :4;
    uint32 SPARE                 :2;
    uint32 LOCO_HEALTH_STATUS    :24;
    uint32 PADDING_BITS          :6;
    uint32 MAC_CODE              :32;
    uint32 PKT_CRC               :32;

}otspkt_t;

/************************************************************Station to onboard Packet**************************************/
/***************************************************************************************************************************/

typedef struct TSR_profile_packet
{
    uint32 SUB_PKT_TYPE        :4;
    uint32 SUB_PKT_LENGTH      :7;
    uint32 TSR_STATUS          :2;
    uint32 TSR_INFO_CNT        :5;
    uint32 TSR_ID              :8;
    uint32 TSR_DISTANCE        :15;
    uint32 TSR_LENGTH          :15;
    uint32 TSR_CLASS           :1;
    uint32 TSR_UNIVERSAL_SPEED :6;
    uint32 TSR_CLASSA_SPEED    :6;
    uint32 TSR_CLASSB_SPEED    :6;
    uint32 TSR_CLASSC_SPEED    :6;
    uint32 TSR_WHISTLE         :2;
    uint32 PADDING_BITS        :5;


}tsrpkt_t;

typedef struct track_condition_packet
{
    uint32 SUB_PKT_TYPE               :4;
    uint32 SUB_PKT_LENGTH             :7;
    uint32 TRACK_COND_CNT             :4;
    uint32 TRACK_COND_TYPE            :4;
    uint32 START_DIST_TRACKCOND       :15;
    uint32 LENGTH_TRACKCOND           :15;
    uint32 PADDING_BITS               :7;

}tcpkt_t;

typedef struct tag_linking_information_packet
{
    uint32 SUB_PKT_TYPE           :4;
    uint32 SUB_PKT_LENGTH         :7;
    uint32 DIST_DUP_TAG           :4;
    uint32 ROUTE_RFID_CNT         :6;
    uint32 DIST_NXT_RFID          :11;
    uint32 NXT_RFID_TAG_ID        :10;
    uint32 DUP_TAG_DIR            :1;
    uint32 BS_LOC_RESET           :1;
    uint32 START_DIST_TO_LOC_RESET:15;
    uint32 ADJ_LOCO_DIR           :2;
    uint32 ABS_LOCO_CORRECTION    :23;
    uint32 ADJ_LINE_CNT           :3;
    uint32 LINE_TIN               :9;


}tlpkt_t;


typedef struct turnout_speed_profile_packet
{
    uint32 SUB_PKT_TYPE           :4;
    uint32 SUB_PKT_LENGTH         :7;
    uint32 TO_CNT                 :2;
    uint32 TO_SPEED               :5;
    uint32 DIFF_DIST_TO           :15;
    uint32 TO_SPEED_REL_DIST      :12;
    uint32 PADDING_BITS           :3;

}tspkt_t;

typedef struct LC_gate_profile_packet
{
   uint32 SUB_PKT_TYPE               :4;
   uint32 SUB_PKT_LENGTH             :7;
   uint32 LM_LC_INFO_CNT             :5;
   uint32 LM_LC_DISTANCE             :15;
   uint32 LM_LC_ID_NUMERIC           :10;
   uint32 LM_LC_ID_ALPHA_SUFFIX      :3;
   uint32 LM_LC_MANNING_TYPE         :1;
   uint32 LM_LC_CLASS                :3;
   uint32 LM_LC_AUTO_WHISTLE_ENABLED :1;
   uint32 LM_LC_AUTO_WHISTLING_TYPE  :2;
   uint32 PADDING_BITS               :5;

}lcpkt_t;

typedef struct gradient_profile_packet
{
    uint32 SUB_PKT_TYPE          :4;
    uint32 SUB_PKT_LENGTH        :7;
    uint32 LM_GRAD_INFO_CNT      :5;
    uint32 LM_GRADIENT_DISTANCE  :15;
    uint32 LM_GDIR               :1;
    uint32 LM_GRADIENT_VALUE     :5;
    uint32 PADDING_BITS          :3;

}gppkt_t;

typedef struct static_speed_profile_packet
{
    uint32 SUB_PKT_TYPE             :4;
    uint32 SUB_PKT_LENGTH           :7;
    uint32 LM_SPEED_INFO_CNT        :5;
    uint32 LM_STATIC_SPEED_DISTANCE :15;
    uint32 LM_STATIC_SPEED_CLASS    :1;
    uint32 LM_STATIC_SPEED_VALUE    :24;


}sspkt_t;

typedef struct movement_authority_packet
{
    uint32 SUB_PKT_TYPE        :4;
    uint32 SUB_PKT_LENGTH      :7;
    uint32 FRAME_OFFSET        :4;
    uint32 DEST_LOCO_SOS       :4;
    uint32 TRAIN_SECTION_TYPE  :2;
    uint32 CUR_SIG_INFO        :17;
    uint32 CUR_SIG_ASPECT      :6;
    uint32 NEXT_SIG_ASPECT     :6;
    uint32 APPR_SIG_DIST       :15;
    uint32 AUTHORITY_TYPE      :2;
    uint32 AUTHORIZED_SPEED    :6;
    uint32 MA_W_R_T_SIG        :16;
    uint32 REQ_SHORTEN_MA      :1;
    uint32 NEW_MA              :16;
    uint32 TRN_LEN_INFO_STS    :1;
    uint32 TRN_LEN_INFO_TYPE   :1;
    uint32 REF_FRAME_NUM_TLM   :17;
    uint32 REF_OFFSET_INT_TLM  :8;
    uint32 NEXT_STN_COMM       :1;
    uint32 APPR_STN_ILC_IBS_ID :16;
    uint32 PADDING_BITS        :2;

}mapkt_t;


typedef struct station_to_onboard_kavach_packet
{
    uint32 PKT_TYPE                  :4;
    uint32 PKT_LENGTH                :10;
    uint32 FRAME_NUM                 :17;
    uint32 SOURCE_STN_ILC_IBS_ID     :16;
    uint32 SOURCE_STN_ILC_IBS_VERSION:3;
    uint32 DEST_LOCO_ID              :20;
    uint32 REF_PROF_ID               :4;
    uint32 LAST_REF_RFID             :10;
    uint32 DIST_PKT_START            :15;
    uint32 PKT_DIR                   :2;
    uint32 PADDING_BITS              :3;

    mapkt_t  M;
    sspkt_t  S;
    gppkt_t  G;
    lcpkt_t  LC;
    tspkt_t  T;
    tlpkt_t  TL;
    tcpkt_t  TC;
    tsrpkt_t TSR;


    uint32 LOCO_SPECIFIC_MAC_CODE    :32;
    uint32 PKT_CRC                   :32;

}stopkt_t;







#endif /* INCLUDE_RADIO_H_ */
