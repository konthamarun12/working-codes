/*
 * USB_UART.h
 *
 *  Created on: Aug 12, 2024
 *      Author: HP
 */

#ifndef INCLUDE_USB_UART_H_
#define INCLUDE_USB_UART_H_

#define ADL (0xA3u)
extern uint8 u8upr_date;
extern uint8 u8upr_mon;
extern uint16 u16upr_yr;
extern uint8 u8upr_hrs;
extern uint8 u8upr_min;
extern uint8 u8upr_sec;

extern uint8 u8lwr_date;
extern uint8 u8lwr_mon;
extern uint16 u16lwr_yr;
extern uint8 u8lwr_hrs;
extern uint8 u8lwr_min;
extern uint8 u8lwr_sec;

extern uint8 u8USBlink_checkpkt_rcvd;
extern uint8 u8USBdatadwnldstart_pkt_rcvd;
extern uint8 u8USBrqrmt_pkt_rcvd;
extern uint8 u8USBdatadwnldstop_pkt_rcvd;
extern uint8 u8serial_number;
extern uint8 u8ALL_data_packets;
extern volatile uint8 u8contCommun;
extern void delay(uint32 num);


extern uint8_t read_lock;

typedef struct USB_DATA_PACKET
{
   uint8  u8SOF1;
   uint8  u8SOF2;
   uint8  u8msg_len;
   uint8  u8boardtype;
   uint8  u8comm_type;
   uint8  u8msg_type;
   uint8  u8msg_sub_type;
   uint16 u16CRC;
   uint8  u8E0F1;
   uint8  u8EOF2;

}usb_data_pkt_t;

extern usb_data_pkt_t usb_data_pkt;
extern uint64 usb_live_data_line_cnt;
extern uint8 USB_array[200];
extern uint8 u8limit_not_crossed;





extern void get_the_data_from_the_file(const char * str);
extern void get_the_data_from_SD_card_from_each_file(void);
extern void get_link_check_pkt_and_send_rspns_pkt(uint8 *u8buffer);
extern void get_dwnld_rqst_pkt_and_send_rspns_pkt(uint8 *u8buffer);
extern void get_dwnld_stop_pkt_and_send_rspns_pkt(uint8 *u8buffer);
extern void validate_CRC_and_compare_rcvd_and_calc_values(const uint8 *buf, uint32 len);


#endif /* INCLUDE_USB_UART_H_ */
