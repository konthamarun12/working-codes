/*
 * loco_events.h
 *
 *  Created on: Aug 26, 2024
 *      Author: UDAY KIRAN GEMBALI
 */

#ifndef INCLUDE_LOCO_EVENTS_H_
#define INCLUDE_LOCO_EVENTS_H_


#define LOCO_CRITICAL_DATA   (0x90u)
#define LOCO_TRIG_MAINT_DATA (0x91u)
#define LOCO_TRIG_DATA       (0x92u)
#define LOCO_LIVE_DATA       (0x93u)


extern uint8 u8locolivedatalogbuf[200];
extern uint8 u8locotrigmaintdatabuf[200];
extern uint8 u8locotrigdatabuf[200];
extern uint8 u8lococritdatabuf[200];
extern uint8 u8locoSDcardbuf[200];

extern uint64 locolivedatalinecnt;
extern uint64 locotrigdatalinecnt;
extern uint64 locotrigmaintdatalinecnt;
extern uint64 lococritdatalinecnt;



typedef struct loco_event_data
{
    uint8 u8EventID;
    uint8 u8RecieveBuf[255];
    uint8  u8SdCardWriteBuf[255];
    uint8  u8SdCardWriteReady;

}loco_event_data_t;


extern void WriteLocoLiveDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length);
extern void WriteLocoTrigmaintDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length);
extern void WriteLocoTrigDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length);
extern void WriteLocoCritDatatoSDCard(uint8* log_data , uint8 EventID, uint8 data_pkt_length);


extern void ExtractLocoEventdata(uint8 i);
extern void send_loco_evnt_pkt_to_log(uint8 event_type, uint8 event_id, uint16 data_pkt_length, uint8 * log_data);
extern void init_SD_card_for_loco(void);
extern void ProcessLocoEventdata(uint8 u8EventType);

extern uint8 loco_evnt_buf[200]; /*Buffer to store the event data packets*/
extern uint8 ucLocoInfoMsgData[8];
extern uint8 ucLocoMsgData[8];

/*******************************************************************************************
                                           LOCO LIVE DATA
 *******************************************************************************************/

typedef struct loco_live_data
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint32 u24loc_ID;
    uint8  u8speed;
    uint8  u8trndir;
    uint32 u24lastRFIDloc;
    uint16 u16TIN;
    uint8  u8type_of_brk;
    uint8  u8speed_sen1_fault;
    uint8  u8GPS1view_not_avail_since_2hrs;
    uint8  u8GPS2view_not_avail_since_2hrs;
    uint8  u8GSM1fault;
    uint8  u8GSM2fault;
    uint8  u8Radio1_RSSI_weak;
    uint8  u8Radio2_RSSI_weak;
    uint8  u8LPOCIP1_fault;
    uint8  u8LPOCIP2_fault;
    uint8  u8RFIDrdr1fault;
    uint8  u8RFIDrdr2fault;
    uint8  u8Ssn_key_mismatch;
    uint8  u8BIU_cnctvty_fault;
    uint8  u8speedsensor2fault;
    uint8  u8CAB_input_fault;

}loco_live_data_t;

extern loco_live_data_t loco_live_dat;
extern void build_loco_live_data(void);


/*****************************************************************************************************************
                                 LOCO TRIGGERED MAINTENANCE DATA
 *****************************************************************************************************************/

typedef struct loco_trig_maint_data
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8rad1active;
    uint8  u8rad2active;
    uint8  u8rad1health;
    uint8  u8rad2health;
    uint8  u8rad1inputsupply;
    uint8  u8rad2inputsupply;
    uint8  u8rad1temp;
    uint8  u8rad2temp;
    uint8  u8rad1PAtemp;
    uint8  u8rad2PAtemp;
    uint8  u8rad1PAsupply;
    uint8  u8rad2PAsupply;
    uint8  u8rad1_tx_PA_current;
    uint8  u8rad2_tx_PA_current;
    uint16 u16rad1RSSI;
    uint16 u16rad2RSSI;
    uint8  u8rad1Revpwr;
    uint8  u8rad2Revpwr;
    uint8  u8rad1Fwdpwr;
    uint8  u8rad2Fwdpwr;
    uint8  u8GPS1status;
    uint8  u8GPS2status;
    uint8  u8GPS1secs;
    uint8  u8GPS2secs;
    uint8  u8GSM1rssi;
    uint8  u8GSM2rssi;
    uint8  u8LPOCIP1stat;
    uint8  u8LPOCIP2stat;
    uint8  u8RFIDrdr1stat;
    uint8  u8RFIDrdr2stat;
    uint16 u16dup_missing_RFID_tag;
    uint8  u8biuconnectivity;
    uint8  u8rstrt_of_kavach;
    uint8  u8MBT;
    uint8  u8readalltags;
    uint8  u8mode_transition;
    uint8  u8present_mode;
    uint16 u16TLM;

}loco_trig_maint_data_t;

extern loco_trig_maint_data_t loco_trg_maint_dat;
extern void build_loco_trig_maint_data(void);

/*****************************************************************************************************************
                                 LOCO TRIGGERED  DATA
 *****************************************************************************************************************/

/*****************************************************************************************************************
                                 Update of movement authority (Sub message ID 1)
 *****************************************************************************************************************/


typedef struct update_mov_auth
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8authority_type;
    uint8  u8authorized_spd;
    uint16  u16newMA;
}updt_mov_auth_t;

extern updt_mov_auth_t updt_mov_auth;
extern void build_updt_mov_auth(void);


/*****************************************************************************************************************
                                 Brake application (Sub message ID 2)
 *****************************************************************************************************************/

typedef struct loco_brk_appl
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8prsnt_spd;
    uint8  u8applied_rsn;
    uint8  u8brk_type_applied;
}loco_brk_appl_t;


extern loco_brk_appl_t loco_brk_applied;
extern void build_loco_brk_applied(void);

/*****************************************************************************************************************
                             change of Brake application (Sub message ID 3)
 *****************************************************************************************************************/
typedef struct change_of_brk_appli
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8prev_brk_applied;
    uint8  u8new_brk_applied;
}change_of_brk_appli_t;

extern change_of_brk_appli_t change_of_brk_application;
extern void build_change_of_brk_application_pkt(void);

/*****************************************************************************************************************
                             removal of Brake application (Sub message ID 4)
 *****************************************************************************************************************/

typedef struct rmvl_of_brk_appli
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8type_of_brake_releived;
}rmvl_of_brk_appli_t;

extern rmvl_of_brk_appli_t rmvl_of_brk_application;
extern void build_rmvl_of_brk_application_packet(void);

/*****************************************************************************************************************
                             Mode transition of kavach (Sub message ID 5)
 *****************************************************************************************************************/

typedef struct mode_trans_of_kvch
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8prev_mode;
    uint8  u8prsnt_mode;


}mode_trans_of_kvch_t;

extern mode_trans_of_kvch_t mode_trans_of_kavach;
extern void build_mode_trans_of_kavach_pkt(void);

/*****************************************************************************************************************
                             Mode transition of kavach (Sub message ID 6)
 *****************************************************************************************************************/
typedef struct acknmnt_by_LP
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8ackRsn;

}acknmnt_by_LP_t;

extern acknmnt_by_LP_t acknmnt_by_LPilot;
extern void build_acknmnt_by_LPilot_pkt(void);

/*****************************************************************************************************************
                                     SPAD (Sub message ID 7)
 *****************************************************************************************************************/
typedef struct SPAD
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8spd;
    uint16  ref_RFID_tag;

}SPAD_t;

extern SPAD_t signal_passed_at_danger;
extern void build_signal_passed_at_danger_pkt(void);

/*****************************************************************************************************************
                                     Change in TIN (Sub message ID 8)
 *****************************************************************************************************************/
typedef struct chang_in_TIN
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16prev_TIN;
    uint16 u16pres_TIN;
}chang_in_TIN_t;

extern chang_in_TIN_t chang_in_TINumber;
extern void build_chang_in_TINumber_pkt(void);

/*****************************************************************************************************************
                                     One RFID tag missing out of two (Sub message ID 9)
 *****************************************************************************************************************/
typedef struct one_RFID_tg_msng_out_of_two
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16RFID_tag;
    uint8 u8tag_type;
}one_RFID_tg_msng_out_of_two_t;

extern one_RFID_tg_msng_out_of_two_t one_RFID_tg_msng_out_of_two_tags;
extern void build_one_RFID_tg_msng_out_of_two_tags_pkt(void);

/*****************************************************************************************************************
                                     Both RFID tags missing (Sub message ID 10)
 *****************************************************************************************************************/
typedef struct both_rfid_tags_msng
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16RFID_tag;

}both_rfid_tags_msng_t;

extern both_rfid_tags_msng_t both_rfid_tags_missing;
extern void build_both_rfid_tags_missing_pkt(void);

/*****************************************************************************************************************
                                    data mismatch between main duplicate RFID tag (Sub message ID 11)
 *****************************************************************************************************************/
typedef struct data_mismatch_btw_mn_dup_tag
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16RFID_tag;

}data_mismatch_btw_mn_dup_tag_t;

extern data_mismatch_btw_mn_dup_tag_t data_mismatch_btw_mn_nd_dup_tag;
extern void build_data_mismatch_btw_mn_nd_dup_tag_pkt(void);

/*****************************************************************************************************************
                                    Change in signal aspect (Sub message ID 12)
 *****************************************************************************************************************/

typedef struct change_in_aspct
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8trn_sec_type;
    uint16 u16ref_RFID_tag;
    uint8  u8sig_type;
    uint8  u8prev_sig_aspect;
    uint8  u8pres_sig_aspect;

}change_in_aspct_t;

extern change_in_aspct_t change_in_sig_aspect;
extern void build_change_in_sig_aspect(void);

/*****************************************************************************************************************
                                    Passing of signal (Sub message ID 13)
 *****************************************************************************************************************/
typedef struct passing_of_signal
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8trn_sec_type;
    uint16 u16ref_RFID_tag;
    uint8  u8sig_aspect;

}passing_of_signal_t;

extern passing_of_signal_t passing_of_signall;
extern void build_passing_of_signall_pkt(void);

/*****************************************************************************************************************
                                   Transmission of emergency messages (Sub message ID 14)
 *****************************************************************************************************************/
typedef struct tx_of_emer_msg
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8txRsn;

}tx_of_emer_msg_t;
extern tx_of_emer_msg_t tx_of_emer_message;
extern void build_tx_of_emer_message_pkt(void);

/*****************************************************************************************************************
                                   Reception of emergency messages (Sub message ID 15)
 *****************************************************************************************************************/
typedef struct Rx_of_emer_msg
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8sender;
    uint32 u24stnorlocoID;
    uint8  u8RxRsn;

}Rx_of_emer_msg_t;

extern Rx_of_emer_msg_t Rx_of_emer_message;
extern void build_Rx_of_emer_message_pkt(void);

/*****************************************************************************************************************
                                   Entry into new station area (Sub message ID 16)
 *****************************************************************************************************************/
typedef struct entry_into_new_stsn
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16stnID;
}entry_into_new_stsn_t;

extern entry_into_new_stsn_t entry_into_new_station;
extern void build_entry_into_new_station_pkt(void);

/*****************************************************************************************************************
                                   Frequency channel allocation (Sub message ID 17)
 *****************************************************************************************************************/

typedef struct freq_chan_allocation
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16new_stn_ID;
    uint16 u16uplink_freq;
    uint16 u16downlink_freq;

}freq_chan_allocation_t;

extern freq_chan_allocation_t freq_channel_allocation;
extern void build_freq_channel_allocation_event_pkt(void);


/*****************************************************************************************************************
                                          CRITICAL DATA:9A

                               Auhentication key details . Event ID : 01
 *****************************************************************************************************************/

typedef struct auth_key_details
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8current_running_key[16];
    uint8  u8key_mem_loc;
    uint16 u16stn_ID;
    uint8  u8rem_keys;


}auth_key_details_t;

extern auth_key_details_t authen_key_details;
extern void build_authen_key_details_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name : Train Length measurement, event Id : 02
 *****************************************************************************************************************/

typedef struct TLM_meas
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16  u16TLM;

}TLM_meas_t;

extern TLM_meas_t TLM_measure;
extern void build_TLM_measure_event_pkt(void);

/*****************************************************************************************************************
                                   event name : Train configuration change event, event Id : 03
 *****************************************************************************************************************/
typedef struct trn_cfg_chng
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8trn_cfg_chng;
}trn_cfg_chng_t;

extern trn_cfg_chng_t trn_cfg_change;
extern void build_trn_cfg_chng_event(void);

/*****************************************************************************************************************
                                   event name : Bootup sequenceerror event, event Id : 04
 *****************************************************************************************************************/
typedef struct boot_up_seq_err
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8err_type;

}boot_up_seq_err_t;

extern boot_up_seq_err_t boot_up_seq_error;
extern void build_boot_up_seq_error_event_pkt(void);

/*****************************************************************************************************************
                                   event name :cab selection event, event Id : 05
 *****************************************************************************************************************/
typedef struct cab_select_evnt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8cab_slctd;
}cab_select_evnt_t;

extern cab_select_evnt_t cab_select_event;
extern void build_cab_select_event_pkt(void);

/*****************************************************************************************************************
                                   event name : Brake application event, event Id : 06
 *****************************************************************************************************************/
typedef struct brk_appli_evnt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8brk_appli_rsn;
    uint8  u8speed;
    uint8  u8brk_type_applied;

}brk_appli_evnt_t;

extern brk_appli_evnt_t brk_appli_event;
extern void build_brk_appli_event_pkt(void);

/*****************************************************************************************************************
                                   event name : collision detection, event Id : 07
 *****************************************************************************************************************/
typedef struct collision_dtctn
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8colsn_type;
}collision_dtctn_t;

extern collision_dtctn_t collision_detctn;
extern void build_collision_detctn_ent_pkt(void);

/*****************************************************************************************************************
                                   event name : Loco Manual SOS, event Id : 08
 *****************************************************************************************************************/
typedef struct loco_manual_SOS
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8loco_self_sos;
}loco_manual_SOS_t;

extern loco_manual_SOS_t loco_manual_SOS_evnt;
extern void build_loco_manual_SOS_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name : radio  health, event Id : 09,10
 *****************************************************************************************************************/
typedef struct radhlt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8hlt;
    uint8  u8Ipsupply;
    uint8  u8temp;
    uint8  u8PA_temp;
    uint8  u8PA_suply_volt;
    uint8  u8TxPAcrnt;
    uint8  u8revPwr;
    uint8  u8fwdPwr;
    uint16 u16RSSI;
    uint8  u8RxpktCnt;
}radhlt_t;

extern radhlt_t rad1hlt;
extern radhlt_t rad2hlt;

extern void build_rad1hlt_event_pkt(void);
extern void build_rad2hlt_event_pkt(void);

/*****************************************************************************************************************
                                   event name : GSM health event , event Id : 11
 *****************************************************************************************************************/

typedef struct GSM_hlt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8GSM1RSSI;
    uint8  u8GSM2RSSI;
}GSM_hlt_t;

extern void build_GSM_hlt_event(void);
extern GSM_hlt_t GSM_health;

/*****************************************************************************************************************
                                   event name : GPS 1 and 2 health event , event Id : 12,13
 *****************************************************************************************************************/

typedef struct GPS_hlt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8actv_GPS_num;
    uint8  u8view;
    uint8  u8sec;
    uint8  u8satellite_in_vw;
    uint8  u8CNO;
}GPS_hlt_t;

extern GPS_hlt_t GPS1_hlt;
extern GPS_hlt_t GPS2_hlt;

extern void build_GPS1_hlt_event_pkt(void);
extern void bulid_GPS2_hlt_event_pkt(void);

/*****************************************************************************************************************
                                   event name : Interface cards 1 and 2 , event Id : 14,15
 *****************************************************************************************************************/

typedef struct intrfc_crds_hlt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8VPMhlt;
    uint8  u8VIChlt;
    uint8  u8VIMhlt;
    uint8  u8VOMhlt;
    uint8  u8ADLhlt;
}intrfc_crds_hlt_t;

extern intrfc_crds_hlt_t intrfc_crds1_hlt;
extern intrfc_crds_hlt_t intrfc_crds2_hlt;

extern void build_intrfc_crds1_hlt_event_pkt(void);
extern void build_intrfc_crds2_hlt_event_pkt(void);

/*****************************************************************************************************************
                                   event name : EB connection status event , event Id : 16
 *****************************************************************************************************************/
typedef struct EB_cnctn_stat
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8EBcnctn;
}EB_cnctn_stat_t;

extern EB_cnctn_stat_t EB_cnctn_stat_evnt;
extern void build_EB_cnctn_stat_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name : kavach connection status event , event Id : 17
 *****************************************************************************************************************/

typedef struct kvch_cnctn_evnt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8KVCHcnctn;

}kvch_cnctn_evnt_t;

extern kvch_cnctn_evnt_t kvch_cnctn_event;
extern void build_kvch_cnctn_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name : kavach territory exit or entry event , event Id : 18
 *****************************************************************************************************************/
typedef struct kvch_ter_ext_ent
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8kvch_ext_ent;
    uint16 u16stnIBSID;
}kvch_ter_ext_ent_t;

extern kvch_ter_ext_ent_t kvch_ter_ext_entry;
extern void build_kvch_ter_ext_entry_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name : ETCS  exit or entry event , event Id : 19
 *****************************************************************************************************************/
typedef struct ETCS_exit_or_entry
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8ETCS_ext_ent;
    uint16 u16etcsID;

}ETCS_exit_or_entry_t;

extern ETCS_exit_or_entry_t ETCS_exit_or_entry_evnt;
extern void build_ETCS_exit_or_entry_event_pkt(void);

/*****************************************************************************************************************
                                   event name : train trip mode , event Id : 20
 *****************************************************************************************************************/
typedef struct trn_trip_mode_entry
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16refRFID;
}trn_trip_mode_entry_t;

extern trn_trip_mode_entry_t trn_trip_mode_entry_evnt;
extern void build_trn_trip_mode_entry_evnt_pkkt(void);

/*****************************************************************************************************************
                                   event name : Over ride selected , event Id : 21
 *****************************************************************************************************************/

typedef struct ovrd_slctd
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16refRFID;

}ovrd_slctd_t;

extern ovrd_slctd_t ovrd_selected;
extern void build_ovrd_selected_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name :Turnout event  , event Id : 22
 *****************************************************************************************************************/
typedef struct turnout_evnt
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8trnout_spd;
    uint16 u16trnout_dist;
    uint16 u16ref_RFID;


}trnout_evnt_t;

extern trnout_evnt_t trnout_event;
extern void build_trnout_event_pkt(void);

/*****************************************************************************************************************
                                   event name :TSR event  , event Id : 23
 *****************************************************************************************************************/
typedef struct TSR_event
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8TSR_spd;
    uint16 u16TSR_dist;
    uint16 u16ref_RFID;


}TSR_event_t;

extern TSR_event_t TSR_evnt;
extern void build_TSR_event_pkt(void);

/*****************************************************************************************************************
                                   event name :PSR event  , event Id : 24
 *****************************************************************************************************************/
typedef struct PSR_event
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8PSR;
    uint16 u16PSr_dist;
    uint16 refRFID;
}PSR_event_t;

extern PSR_event_t PSR_evnt;
extern void build_PSR_event_pkt(void);

/*****************************************************************************************************************
                                   event name :End of authority  , event Id : 25
 *****************************************************************************************************************/
typedef struct end_of_auth
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16refRFID;

}end_of_auth_t;

extern end_of_auth_t end_of_authority;
extern void build_end_of_auth_event_pkt(void);

/*****************************************************************************************************************
                                   event name :Brake test status  , event Id : 26
 *****************************************************************************************************************/

typedef struct brk_test_stat
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint8  u8brk_test_stat;
}brk_test_stat_t;

extern brk_test_stat_t brk_test_status;
extern void build_brk_test_stat_event_pkt(void);

/*****************************************************************************************************************
                                   event name :Approaching radio hole  , event Id : 27
 *****************************************************************************************************************/
typedef struct appr_rad_hole
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16ref_RFID;
    uint16 u16dist;

}appr_rad_hole_t;

extern appr_rad_hole_t appr_radio_hole;
extern void build_appr_rad_hole_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name :Entry into post trip mode  , event Id : 28
 *****************************************************************************************************************/
typedef struct entry_into_post_trp
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16ref_RFID;

}entry_into_post_trp_t;

extern entry_into_post_trp_t entry_into_post_trip;
extern void build_entry_into_post_trp_evnt_pkt(void);

/*****************************************************************************************************************
                                   event name :Entry of loco into different zone  , event Id : 29
 *****************************************************************************************************************/
typedef struct entry_of_loco_into_diff_zone
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16ref_RFID;
    uint8  u8zone_type;
}entry_of_loco_into_diff_zone_t;

extern entry_of_loco_into_diff_zone_t entry_of_loco_into_differ_zone;
extern void build_entry_of_loco_into_differ_zone_event_pkt(void);

/*****************************************************************************************************************
                                   event name :Gradient profile ; event ID : 30
 *****************************************************************************************************************/

typedef struct grad_prof
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16refRFID;
    uint8  u8auth_speed;
    uint8  u8grad_type;
}grad_prof_t;

extern grad_prof_t grad_profile;
extern void build_grad_profile_event_pkt(void);


/*****************************************************************************************************************
                                   event name : static speed profile ; event ID : 31
 *****************************************************************************************************************/
typedef struct static_spd_prof
{
    uint8  u8day;
    uint8  u8month;
    uint16 u16year;
    uint8  u8hrs;
    uint8  u8min;
    uint8  u8secs;
    uint32 u24absloc;
    uint16 u16refRFID;
    uint8  u8auth_speed;

}static_spd_prof_t;

extern static_spd_prof_t static_spd_profile;
extern void build_static_spd_prof_evnt_pkt(void);


/*******************************END OF LOCO EVENT STRUCTURES************************************************************/

extern void update_loco_time_date(void);










#endif /* INCLUDE_LOCO_EVENTS_H_ */
