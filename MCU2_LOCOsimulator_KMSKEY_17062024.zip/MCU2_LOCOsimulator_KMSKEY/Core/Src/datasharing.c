/*******************************************************************************
 *
 * @FileName         : datasharing.c
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/
#include "kms.h"
#include <stdint.h>
#include "datasharing.h"
#include "crc32.h"
#include "usart.h"
#include "string.h"
/**
 * @brief Represents the data packet structure for receiving data from the DNET network interface.
 *
 * This structure is used to store the information extracted from the received data
 * buffer after a DNET data packet has been successfully received and processed.
 * The structure should align with the expected data format of DNET packets.
 */
Dnet_RxDataPacket_t Dnet_RxDataPacket;
/**
 * @brief Represents the data packet structure for transmitting data to MCU2 interface.
 *
 * This structure is designed to format the data in a way that is compatible with the
 * requirements of the MCU2 interface for transmitting purposes. It might include various
 * fields like headers, payload, and error checking mechanisms designed specifically for
 * the protocol used by MCU2.
 */
MCU2_TxDataPacket_t MCU2_TxDataPacket;
/**
 * @brief Represents the data packet structure for receiving data into MCU2 from another source.
 *
 * This structure is used to capture and process data packets that MCU2 receives.
 * It is structured to decode and handle specific data types or commands according to the
 * needs of the MCU2 processing logic. Each field in the packet should correspond to
 * the specific data points expected to be handled by MCU2.
 */
MCU2_RxDataPacket_t MCU2_RxDataPacket;

extern uint8_t processKeydata;
uint8_t key1[16]; // = {0x58, 0xED, 0x0D, 0x33, 0xC7, 0xFC, 0xBA, 0x56, 0x34, 0x18, 0x1F, 0x52, 0x91, 0x4E, 0xDF, 0x69};
uint8_t key2[16]; //= {0x5D, 0x68, 0xFC, 0x80, 0xB7, 0xA7, 0xA9, 0xF8, 0xBF, 0x7A, 0x0F, 0x63, 0xE9, 0xE9, 0x57, 0x1C};
extern volatile uint8_t Txflag;
void write_bits(uint8_t *buffer, uint32_t *pos, uint32_t value, int num_bits) {
	for (int i = num_bits - 1; i >= 0; --i) {
		if (*pos % 8 == 0)
			buffer[*pos / 8] = 0;  // Initialize the byte when starting
		buffer[*pos / 8] |= ((value >> i) & 1) << (7 - *pos % 8);
		(*pos)++;
	}
}

uint32_t read_bits(const uint8_t *buffer, uint32_t *pos, int num_bits) {
	uint32_t value = 0;
	for (int i = num_bits - 1; i >= 0; --i) {
		uint32_t byte_pos = *pos / 8;
		uint32_t bit_pos = 7 - (*pos % 8);
		uint32_t bit = (buffer[byte_pos] >> bit_pos) & 1;
		value |= (bit << i);
		(*pos)++;
	}
	return value;
}
//
//void Frame_vMCU2TxDataPacket(MCU2_TxDataPacket_t *packet, uint8_t *buffer) {
//
//	uint32_t calculated_crc = 0;
//	size_t crc_length = 0;
//	uint8_t idx = 4;
//	packet->pkt_start[0] = 0xC5;
//	packet->pkt_start[1] = 0xE3;
//	packet->pkt_type = 0x0D;
//	packet->pkt_length[0] = 0x00;
//	packet->pkt_length[1] = 0x39;
//
//	// Start from index 4 of DNET_RXBuf
//	packet->source_loco_id[0] = DNET_RXBuf[4];
//	packet->source_loco_id[1] = DNET_RXBuf[5];
//	packet->source_loco_id[2] = DNET_RXBuf[6];
//
//	packet->abs_loco_loc[0] = DNET_RXBuf[7];
//	packet->abs_loco_loc[1] = DNET_RXBuf[8];
//	packet->abs_loco_loc[2] = DNET_RXBuf[9];
//
//	packet->train_speed[0] = DNET_RXBuf[10];
//	packet->train_speed[1] = DNET_RXBuf[11];
//
//	packet->movement_dir = DNET_RXBuf[12];
//
//	packet->loco_mode = DNET_RXBuf[13];
//
//	packet->last_rfid_tag[0] = DNET_RXBuf[14];
//	packet->last_rfid_tag[1] = DNET_RXBuf[15];
//
//	packet->tag_dup = DNET_RXBuf[16];
//
//	packet->tag_link_info = DNET_RXBuf[17];
//
//	packet->tin[0] = DNET_RXBuf[18];
//	packet->tin[1] = DNET_RXBuf[19];
//
//	packet->sig_ov = DNET_RXBuf[20];
//
//	packet->spare = DNET_RXBuf[21];
//
//	packet->loco_health_status = DNET_RXBuf[22];
//
//	packet->approaching_station_id[0] = DNET_RXBuf[23];
//	packet->approaching_station_id[1] = DNET_RXBuf[24];
//
//
////	packet->source_loco_id[0] = buffer[idx++]; //
////	packet->source_loco_id[1] = buffer[idx++];
////	packet->source_loco_id[2] = buffer[idx++];
////
////	packet->abs_loco_loc[0] = buffer[idx++];
////	packet->abs_loco_loc[1] = buffer[idx++];
////	packet->abs_loco_loc[2] = buffer[idx++];
////
////	packet->train_speed[0] = buffer[idx++];
////	packet->train_speed[1] = buffer[idx++];
////
////	packet->movement_dir = buffer[idx++];
////
////	packet->loco_mode = buffer[idx++];
////
////	packet->last_rfid_tag[0] = buffer[idx++];
////	packet->last_rfid_tag[1] = buffer[idx++];
////
////	packet->tag_dup = buffer[idx++];
////
////	packet->tag_link_info = buffer[idx++];
////
////	packet->tin[0] = buffer[idx++];
////	packet->tin[1] = buffer[idx++];
////
////	packet->sig_ov = buffer[idx++];
////
////	packet->spare = buffer[idx++];
////
////	packet->loco_health_status = buffer[idx++];
////
////	packet->approaching_station_id[0] = buffer[idx++];
////	packet->approaching_station_id[1] = buffer[idx++];
//	for (int i = 0; i < 16; i++) {
//		packet->akey1_at_memory_location_0[i] = key1[i];
//	}
//	for (int i = 0; i < 16; i++) {
//		packet->akey1_at_memory_location_1[i] = key2[i];
//	}
//
////	memcpy(&packet->source_loco_id, &buffer[4], 20); //TODO 22 to 21 change
////	memcpy(&packet->akey1_at_memory_location_0, &key1, 16);
////	memcpy(&packet->akey1_at_memory_location_1, &key2, 16);
//	crc_length = (size_t) (&packet->akey1_at_memory_location_1[15]
//			- (uint8_t*) &packet->pkt_start[0] + 1);
//	calculated_crc = calculate_crc32(&packet->pkt_start[0], crc_length);
//	packet->pkt_crc[0] = (calculated_crc >> 24) & 0xFF;
//	packet->pkt_crc[1] = (calculated_crc >> 16) & 0xFF;
//	packet->pkt_crc[2] = (calculated_crc >> 8) & 0xFF;
//	packet->pkt_crc[3] = calculated_crc & 0xFF;
//
//}

void Frame_vMCU2TxDataPacket(MCU2_TxDataPacket_t *packet, uint8_t *buffer) {
	uint32_t calculated_crc = 0;
	size_t crc_length = 0;
	MCU2_TxDataPacket.pkt_start[0] = 0xC5;
	MCU2_TxDataPacket.pkt_start[1] = 0xE3;
	MCU2_TxDataPacket.pkt_type = 0x0D;
	MCU2_TxDataPacket.pkt_length[0] = 0x00;
	MCU2_TxDataPacket.pkt_length[1] = 0x39;

	memcpy(&MCU2_TxDataPacket.source_loco_id, &buffer[4], 23);
	memcpy(&MCU2_TxDataPacket.akey1_at_memory_location_0, &key1, 16);
	memcpy(&MCU2_TxDataPacket.akey1_at_memory_location_1, &key2, 16);
	crc_length = (size_t) (&MCU2_TxDataPacket.akey1_at_memory_location_1[15]
			- (uint8_t*) &MCU2_TxDataPacket.pkt_start[0] + 1);
	calculated_crc = calculate_crc32(&MCU2_TxDataPacket.pkt_start[0],
			crc_length);
	MCU2_TxDataPacket.pkt_crc[0] = (calculated_crc >> 24) & 0xFF;
	MCU2_TxDataPacket.pkt_crc[1] = (calculated_crc >> 16) & 0xFF;
	MCU2_TxDataPacket.pkt_crc[2] = (calculated_crc >> 8) & 0xFF;
	MCU2_TxDataPacket.pkt_crc[3] = calculated_crc & 0xFF;

}
_Bool MCU2_vExtractRxDataPacket(uint8_t *buffer, MCU2_RxDataPacket_t *packet)

{
	uint32_t pos = 0;  // Position in the buffer in bits
	uint16_t start = (uint16_t) read_bits(buffer, &pos, 16);
//	if (start != 0xB5D3) {
//		printf("Invalid packet start. Expected 0xB5D3, got 0x%X\n", start);
//		return false;  // Start of packet does not match expected value
//	}
	if (start != 0xA593) {
		printf("Invalid packet start. Expected 0xB5D3, got 0x%X\n", start);
		return false;  // Start of packet does not match expected value
	}

	packet->pkt_start = start;
	packet->pkt_type = (uint8_t) read_bits(buffer, &pos, 8);
	packet->pkt_length = (uint8_t) read_bits(buffer, &pos, 8);
	packet->date = (uint8_t) read_bits(buffer, &pos, 8);
	packet->month = (uint8_t) read_bits(buffer, &pos, 8);
	packet->year = (uint8_t) read_bits(buffer, &pos, 8);
	packet->hours = (uint8_t) read_bits(buffer, &pos, 8);
	packet->minutes = (uint8_t) read_bits(buffer, &pos, 8);
	packet->seconds = (uint8_t) read_bits(buffer, &pos, 8);
	packet->pkt_crc = (uint32_t) read_bits(buffer, &pos, 32);

	uint32_t calc_crc = calculate_crc32(&packet->pkt_type,
			(size_t) (&packet->seconds - &packet->pkt_type + 1));
	uint32_t received_crc;
//	memcpy(&received_crc, packet->pkt_crc, sizeof(received_crc));
//	if (calc_crc != packet->pkt_crc) {
//			//  printf("CRC mismatch: Calculated 0x%08X, Received 0x%08X\n", calc_crc, received_crc);
//			return 0; // CRC mismatch
//		}

	return true;
}

_Bool Dnet_vExtractRxDataPacket(Dnet_RxDataPacket_t *pkt) {

	// Validate the start marker
	if (pkt->pkt_start[0] != 0xB5 || pkt->pkt_start[1] != 0xD3) {
		// printf("Invalid packet start.\n");
		return 0; // Invalid packet start
	}

	// Validate the packet type
	if (pkt->pkt_type != 0x0E) {
		// printf("Invalid packet type.\n");
		return 0; // Invalid packet type
	}
	// Calculate and validate CRC
	size_t crc_length = (size_t) (&pkt->approaching_station_id[1]
			- &pkt->pkt_start[0] + 1);
	uint32_t calc_crc = calculate_crc32(&pkt->pkt_start[0], crc_length);

	uint32_t received_crc = (pkt->pkt_crc[0]) | (pkt->pkt_crc[1] << 8)
			| (pkt->pkt_crc[2] << 16) | pkt->pkt_crc[3] << 24;
//	if (calc_crc != received_crc) {
//		//  printf("CRC mismatch: Calculated 0x%08X, Received 0x%08X\n", calc_crc, received_crc);
//		return 0; // CRC mismatch
//	}

	return 1; // Valid packet

}
static uint8_t kmsflag = 1;
/**
 * @brief Processes data packets received from MCU2.
 *
 * This function checks if a complete data packet has been received from MCU2.
 * If a packet has been received and the 'kmsflag' is set, indicating that
 * the data should be treated in a specific context (possibly related to KMS operations),
 * it processes the packet and updates the system date-time based on the contents
 * of the received packet. If 'kmsflag' is not set, it processes the packet for
 * other purposes such as updating system date-time and setting a flag to indicate
 * the processing of key data. The function clears the receive buffer once processing
 * is completed to prepare for the next incoming packet.
 *
 * @note The function relies on global flags and buffers such as RXpos3, kmsflag,
 *       and MCU2_RXBuf to control its behavior and manage data.
 *
 * Conditions:
 * - RXpos3 == 1: Indicates that a new data packet is fully received and ready to process.
 * - kmsflag == 1: Data should be processed in the context of KMS-related operations.
 * - kmsflag == 0: Data should be processed in a general context.
 *
 * The function updates the global DateTime structure and resets specific flags
 * and buffers based on the conditions encountered.
 *
 * Usage:
 * - Should be called within a main loop or interrupt service routine where data
 *   packets from MCU2 are expected to be received.
 *
 * @retval None
 */

void MCU2_vProcessDatapacket(void)

{
	if ((RXpos3 == 1) && (kmsflag == 1)) {
		RXpos3 = 0;
		memcpy(&MCU2_RxDataPacket, &MCU2_RXBuf, sizeof(MCU2_RxDataPacket_t));

		// Correct usage if MCU2_TxDataPacket is a pointer
		if (1
				== MCU2_vExtractRxDataPacket(&MCU2_RXBuf[0],
						&MCU2_RxDataPacket)) {
			memset(&MCU2_RXBuf, 0, 14); // Clear the receive buffer
			DateTime.tm_year = MCU2_RxDataPacket.year;
			DateTime.tm_mon = MCU2_RxDataPacket.month;
			DateTime.tm_mdate = MCU2_RxDataPacket.date;
			DateTime.tm_hour = MCU2_RxDataPacket.hours;
			DateTime.tm_min = MCU2_RxDataPacket.minutes;
			DateTime.tm_sec = MCU2_RxDataPacket.seconds;
			kmsflag = 0;
			Txflag = 1;
			memset(MCU2_RXBuf, 0, 14);
		}

	} else if ((RXpos3 == 1) && (kmsflag == 0)) {
		RXpos3 = 0;
		if (1
				== MCU2_vExtractRxDataPacket(&MCU2_RXBuf[0],
						&MCU2_RxDataPacket)) {
			HAL_GPIO_TogglePin(LED5_GPIO_Port, LED5_Pin);
			DateTime.tm_year = MCU2_RxDataPacket.year;
			DateTime.tm_mon = MCU2_RxDataPacket.month;
			DateTime.tm_mdate = MCU2_RxDataPacket.date;
			DateTime.tm_hour = MCU2_RxDataPacket.hours;
			DateTime.tm_min = MCU2_RxDataPacket.minutes;
			DateTime.tm_sec = MCU2_RxDataPacket.seconds;
			processKeydata = 1;

		}
	}
}

/**
 * @brief Processes data packets received from the DNET network interface.
 *
 * This function checks if a complete data packet has been received from DNET.
 * If a packet has been received, it extracts and processes the data,
 * transferring the relevant packet information to another communication interface
 * (e.g., MCU2). The processed packet can be transmitted to another UART channel
 * (e.g., huart2). The function ensures that the data buffer used for reception is
 * cleared after processing to prepare for the next incoming data.
 *
 * @note The function relies on global flags and buffers like RXpos2 and DNET_RXBuf
 *       to control its operation.
 *
 * Conditions:
 * - RXpos2 == 1: Indicates that a new data packet is fully received and ready to process.
 *
 * The function uses memcpy to copy the received data into a structured data type,
 * then attempts to further process this data packet. If the packet processing is
 * successful (returns 1), it constructs a transmission packet for MCU2, copies this
 * into the transmission buffer, and sends it out via a UART interface. If not successful,
 * the function might set an error status or handle the error appropriately, though these
 * actions are commented out and need implementation.
 *
 * Usage:
 * - Should be called within a main loop or interrupt service routine where DNET
 *   data packets are expected to be received.
 *
 * @retval None
 */


void Dnet_vProcessDataPacket(void)

{
	if (RXpos2 == 1) {
		RXpos2 = 0;
		HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
		memcpy(&Dnet_RxDataPacket, &DNET_RXBuf, sizeof(Dnet_RxDataPacket_t));
		memset(&DNET_RXBuf, 0, 29); // Clear the receive buffer
		// Correct usage if MCU2_TxDataPacket is a pointer
		if (1 == Dnet_vExtractRxDataPacket(&Dnet_RxDataPacket))	// Process the structured data packet
				{
			// Prepare data for transmission to MCU2
			memcpy(MCU2_TXBuf, &Dnet_RxDataPacket,29);
			// Frame the data for transmission
			Frame_vMCU2TxDataPacket(&MCU2_TxDataPacket, MCU2_TXBuf);
			// Copy the framed data into the transmit buffer
			memcpy(MCU2_TXBuf, &MCU2_TxDataPacket, sizeof(MCU2_TxDataPacket_t));
			//HAL_UART_Transmit(&huart5, MCU2_TXBuf, 59, 1000);
			HAL_UART_Transmit(&huart2, MCU2_TXBuf, 62, 1000);
			HAL_UART_Transmit(&huart5, MCU2_TXBuf, 62, 1000);

		}

	}

}
