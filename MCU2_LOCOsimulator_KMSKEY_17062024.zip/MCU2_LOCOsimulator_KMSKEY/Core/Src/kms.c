/*******************************************************************************
 *
 * @FileName         : kms.c
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/
#include "kms.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "datasharing.h"
#include "usart.h"
#include "time.h"
#include "crc32.h"
#include "kms.h"
#include "stm32f1xx_hal_uart.h"
uint8_t KeyData[2000];
uint8_t QueryKeyData[40];
extern uint8_t key1[16];
extern uint8_t key2[16];
DateTime_t DateTime;
uint8_t dateToSearch[4];
uint8_t messageType = 0;
uint8_t kavachType = 0x22;                    // Stationary KAVACH
uint8_t kavachUnitID[3] = { 0x00, 0xFF, 0xF1 }; // Example KAVACH Unit ID
uint8_t KeysetUniqueID[4] = { 0x0A, 0xBC, 0xDE, 0xF1 };
uint8_t Nokeystets = 0x1E;
uint8_t validityStartTime[4] = { 0x01, 0x02, 0x15, 0x08 }; // Example time
uint8_t validityEndTime[4] = { 0x01, 0x06, 0x20, 0x12 };
uint8_t simID = 0x01; // Primary SIM ID
uint32_t KMS_u32Otp = 0;
uint8_t KMS_otpRecived = 0;
uint8_t processKeydata=0;
uint8_t buf[21];
volatile uint8_t AuthKeyFlag = 0;
volatile uint8_t Txflag = 0;
volatile uint8_t Rxflag;

uint8_t ServerRxMessageBuff[2000];
unsigned char response[3];
int messageSize = 0;
unsigned char inital_packet[20] = { 0xA5, 0xC3, 0x90 };
uint32_t u32_stationaryKavachID = 50010;
uint32_t u32_onboardKavachID = 65521;
unsigned char RxMessageBuff[2000];
GSM_packet_t GSM_packet[24]; // Array of 19 GSM_packet_t
extern UART_HandleTypeDef huart1;
extern uint8_t poweron;
static int isDateWithinRange(const uint8_t date[4], const uint8_t start[4], const uint8_t end[4]);
static int compareDate(const uint8_t a[4], const uint8_t b[4]);
uint32_t KMS_vDecodeOTP(uint8_t *data) {
	uint32_t OTP = 0;
	OTP = data[111] << 24 | data[112] << 16 | data[113] << 8 | data[114];
	return OTP;

}
void initialize_GSM_packets(void) {

	char *commands[] = { "ATE0\r",                // 0
			"AT+CNMI=1,2,0,0,0\r", //1
			"AT+CREG=1\r", //2
			"AT+CREG?\r", //3
			"AT+CGREG?\r", //4
			"AT+CGREG=1\r", //5
			"AT+CGREG?\r", //6
			"AT+COPS=0,0\r", //7
			"AT+COPS?\r", //8
			"AT+CGATT?\r", //9
			"AT+XIIC=1\r", //10
			"AT+XIIC?\r", //11
			"AT+NETAPN?\r", //12
			"AT+UDPSETUP=1,112.133.205.6,54143\r", //13
			"AT+UDPSEND=1,20\r", //14
			"AT+CMGF=1\r", //15
			"AT+UDPCLOSE=1\r", //16
			"AT+CGATT=0\r", //17
			"AT+UDPSEND=1,20\r", //18
			NULL, // Placeholder for dynamic data 19
			"AT+UDPSEND=1,24\r", // 20
			NULL, //21
			"AT+UDPSEND=1,19\r", // 22
			NULL //23

			};
	int cmd_lengths[] = { 5, 19, 11, 11, 12, 12, 11, 12, 10, 11, 12, 11, 12, 37,
			18, 11, 15, 13, 15, 21, 15, 19, 15, 0 }; // cmd lengths
	int rxlengths[] = { 6, 6, 20, 20, 6, 20, 56, 29, 19, 6, 36, 11, 40, 20, 6,
			6, 19, 27, 68, 80, 6, 1268, 8, 80 };
	for (int i = 0; i < 24; i++) {
		GSM_packet[i].cmd = malloc(cmd_lengths[i] + 1); // Allocate memory for command + NULL terminator
		if (commands[i]) {
			strcpy(GSM_packet[i].cmd, commands[i]); // Copy command string into allocated memory
		}
		GSM_packet[i].cmdlen = cmd_lengths[i];
		GSM_packet[i].Rxlenen = rxlengths[i];
		GSM_packet[i].Rxbuf = ServerRxMessageBuff;

	}
	KmsATCommand(GSM_packet, 16);
	KmsATCommand(GSM_packet, 15);
	KmsATCommand(GSM_packet, 1);
	for (int i = 0; i < 14; i++) {
		KmsATCommand(GSM_packet, i);
	}
}
static int isDateWithinRange(const uint8_t date[4], const uint8_t start[4], const uint8_t end[4])
{
    return (compareDate(date, start) >= 0 && compareDate(date, end) <= 0);
}
static int compareDate(const uint8_t a[4], const uint8_t b[4])
{
    // Updated indices to compare Year (0), Month (2), Day (1), and Hour (3)
    int indicesToCompare[4] = {3, 2, 1, 0};//{0, 2, 1, 3}; // Including Day now

    for (int i = 0; i <4; i++)
    {
        int index = indicesToCompare[i];
        if (a[index] < b[index])
        {

            return -1;
        }

        else if (a[index] > b[index])
        {
            return 1;
        }

    }
      return 0; // All components must match
}
//time_t time(time_t *t) {
//	if (t != NULL) {
//		*t = (time_t) secondsElapsed;
//	}
//	return (time_t) secondsElapsed;
//}
// KMS Identification Message
unsigned char responseMessage[20000];

//#define offsetof(type, member) ((size_t) & (((type *)0)->member))

#define KAVACH_KMS_HEADER 0xA5C3

#define Kavach_IdentificationAcknowledge_ID 0x90
#define Kms_IdentificationAcknowledge_ID 0x91

#define Kavach_AuthenticationKeyRequest_ID 0x92
#define kms_AuthenticationKeyMessage_ID 0x93

#define Kavach_AuthenticationQurey_ID 0x94
#define Kms_AuthenticationKeystatus_ID 0x95

KAVACH_IdentificationMessagePkt_t KAVACH_IdentificationMessage; // 90
KMS_IdentificationAcKPkt_t KMS_IdentificationAcKPkt;            // 91
KAVACH_Authentication_Key_Request_Message_t KAVACH_Authentication_Key_Request_Message;
KMS_Authentication_Key_Message_t KMS_Authentication_Key_Message;
KAVACH_AuthenticationQueryMessage_t KAVACH_AuthenticationQuery;
Kms_KeyStatusMessage_t Kms_KeyStatusMessage;
uint8_t deriveAuthenticationKey(uint32_t stationaryKavachID,
		uint32_t onboardKavachID);
// Function to derive Authentication Key Ka
typedef enum {
	OTP_STATUS = 0x01, KAVACID_NOTREGISTERD, MESSAGE_DEVLIVERY_FAILURE

} ACK_STATUS;

uint8_t deriveAuthenticationKey(uint32_t stationaryKavachID,
		uint32_t onboardKavachID) {
	// Calculate the sum of IDs and apply modulo 2 operation
	uint8_t index = (stationaryKavachID + onboardKavachID) % 2;
	return index; // This index can be used to select the Authentication Key
}

uint32_t process_kavach_message(uint8_t *message) {

	uint8_t ret = 0;
	uint32_t size = 0;

	if (message[0] != 0xA5 || message[1] != 0xC3) {
		//printf("\r\nHeader mistmatch in KAVACH message");
		return ret;
	}
	messageType = message[2];
	switch (messageType) {
	case Kavach_IdentificationAcknowledge_ID:
		Kavach_vDataPacketKAVACH_IdentificationMessage();
		KmsATCommand(GSM_packet, 15);
		KmsATCommand(GSM_packet, 18);
		udp_send(GSM_packet, 19);
		KmsATCommand(GSM_packet, 1);
		ret =HAL_UART_Receive_IT(&huart1, ServerRxMessageBuff, 115);

		break;

	case Kms_IdentificationAcknowledge_ID: //91
		// TODO
		break;

	case Kavach_AuthenticationKeyRequest_ID: //92

		Kavach_vDataPacketKAVACH_Authentication_Key_Request_Message();
		KmsATCommand(GSM_packet, 20);
		Key_udp_send(GSM_packet, 21);
		memcpy(&KeyData[0], &ServerRxMessageBuff[40], 1224);
		memcpy(&KMS_Authentication_Key_Message, &KeyData[0],
				sizeof(KMS_Authentication_Key_Message_t));
		KeysetUniqueID[0] = KMS_Authentication_Key_Message.KeysetUniqueID[0];
		KeysetUniqueID[1] = KMS_Authentication_Key_Message.KeysetUniqueID[1];
		KeysetUniqueID[2] = KMS_Authentication_Key_Message.KeysetUniqueID[2];
		KeysetUniqueID[3] = KMS_Authentication_Key_Message.KeysetUniqueID[3];
		processKeydata =1;
		// gptr = (void*)&KAVACH_Authentication_Key_Request_Message;
		break;

	case kms_AuthenticationKeyMessage_ID:

		break;

	case Kavach_AuthenticationQurey_ID:

		Kavach_vDataPacketKavach_AuthenticationQueryMessage();
		KmsATCommand(GSM_packet, 22);
		QUREY_udp_send(GSM_packet, 23);
		memcpy(&QueryKeyData[0], &ServerRxMessageBuff[38], 23);
		memcpy(&Kms_KeyStatusMessage, &KeyData[0],
					sizeof(Kms_KeyStatusMessage_t));
		poweron =0;
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
		break;

	case Kms_AuthenticationKeystatus_ID:

		break;

	default:
		// Handle unknown message types
		break;
	}
	return size;
}

void KAVACH_IdentificationMessagePkt(KAVACH_IdentificationMessagePkt_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t simID) {

	packet->startOfFrame[0] = (KAVACH_KMS_HEADER >> 8) & 0xFF; // Higher byte
	packet->startOfFrame[1] = KAVACH_KMS_HEADER & 0xFF;
	packet->messageType = Kavach_IdentificationAcknowledge_ID;
	// Message Length (Calculate this based on included fields)
	size_t payload_size = sizeof(KAVACH_IdentificationMessagePkt_t)
			- sizeof(packet->startOfFrame) - sizeof(packet->crc32);
	payload_size = payload_size + 1;
	packet->messageLength[0] = (uint8_t) (payload_size >> 8);   // High byte
	packet->messageLength[1] = (uint8_t) (payload_size & 0xFF); // Low byte
	payload_size = payload_size + 1;

#if 0
	packet->date[2] = (localTime->tm_year + 1900) % 100;
	packet->date[1] = localTime->tm_mon + 1; // Month
	packet->date[0] = localTime->tm_mday;    // Day
	packet->time[0] = localTime->tm_hour;    // Hour
	packet->time[1] = localTime->tm_min;     // Minute
	packet->time[2] = localTime->tm_sec;     // Second
#endif
	packet->date[2] = DateTime.tm_year;
	packet->date[1] = DateTime.tm_mon;
	; // Month
	packet->date[0] = DateTime.tm_mdate;    // Day
	packet->time[0] = DateTime.tm_hour;    // Hour
	packet->time[1] = DateTime.tm_min;     // Minute
	packet->time[2] = DateTime.tm_sec;     // Second
	// Second
	for (int i = 0; i < 3; i++) {
		packet->kavachUnitID[i] = kavachUnitID[i];
	}

	packet->kavachType = kavachType;
	packet->simID = simID;

	size_t offset = offsetof(KAVACH_IdentificationMessagePkt_t, messageType);
	// Calculate the length from messageType to simID, inclusive.
	size_t length = offsetof(KAVACH_IdentificationMessagePkt_t, simID) - offset
			+ sizeof(packet->simID);
	printf("\r\n length %d\n", length);
	uint32_t crc = calculate_crc32(((uint8_t*) packet) + offset, length);
	// Assuming your 'crc' field is an array of uint8_t to hold the CRC32 bytes:
	packet->crc32[0] = (crc >> 24) & 0xFF;
	packet->crc32[1] = (crc >> 16) & 0xFF;
	packet->crc32[2] = (crc >> 8) & 0xFF;
	packet->crc32[3] = crc & 0xFF;
}

void frame_KMS_IdentificationAcKPkt(KMS_IdentificationAcKPkt_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t ACK_status) {

	// Start of Frame
	packet->startOfFrame[0] = (KAVACH_KMS_HEADER >> 8) & 0xFF; // Higher byte
	packet->startOfFrame[1] = KAVACH_KMS_HEADER & 0xFF;
	// Message Type
	packet->messageType = Kms_IdentificationAcknowledge_ID; // Placeholder, replace if needed

	// Message Length (Calculate this based on included fields)
	size_t payload_size = sizeof(KMS_IdentificationAcKPkt_t)
			- sizeof(packet->startOfFrame) - sizeof(packet->crc32);
	payload_size = payload_size + 1;
	packet->messageLength[0] = (uint8_t) (payload_size >> 8);   // High byte
	packet->messageLength[1] = (uint8_t) (payload_size & 0xFF); // Low byte

	packet->date[2] = DateTime.tm_year;
	packet->date[1] = DateTime.tm_mon;
	; // Month
	packet->date[0] = DateTime.tm_mdate;    // Day
	packet->time[0] = DateTime.tm_hour;    // Hour
	packet->time[1] = DateTime.tm_min;     // Minute
	packet->time[2] = DateTime.tm_sec;     // Second

	// Kavach Type, Unit ID, ACK Status
	packet->kavachType = kavachType;
	for (int i = 0; i < 3; i++) {
		packet->kavachUnitID[i] = kavachUnitID[i];
	}
	packet->ACK_status = ACK_status;

	// CRC32 Calculation
	size_t offset = offsetof(KMS_IdentificationAcKPkt_t, messageType);
	size_t length = offsetof(KMS_IdentificationAcKPkt_t, ACK_status) - offset
			+ sizeof(packet->ACK_status);
	uint32_t crc = calculate_crc32(((uint8_t*) packet) + offset, length);
	packet->crc32[0] = (crc >> 24) & 0xFF;
	packet->crc32[1] = (crc >> 16) & 0xFF;
	packet->crc32[2] = (crc >> 8) & 0xFF;
	packet->crc32[3] = crc & 0xFF;
}

void frame_KAVACH_Authentication_Key_Request_Message(
		KAVACH_Authentication_Key_Request_Message_t *packet, uint8_t kavachType,
		uint8_t *kavachUnitID, uint8_t SIM_ID, uint32_t OTP_value) {

	// Start of Frame
	packet->startOfFrame[0] = (KAVACH_KMS_HEADER >> 8) & 0xFF; // Higher byte
	packet->startOfFrame[1] = KAVACH_KMS_HEADER & 0xFF; // Example, replace if needed

	// Message Type
	packet->messageType = Kavach_AuthenticationKeyRequest_ID; // Example, replace if needed

	// Message Length (Calculate this based on included fields)
	size_t payload_size = sizeof(KAVACH_Authentication_Key_Request_Message_t)
			- sizeof(packet->startOfFrame) - sizeof(packet->crc32);
	payload_size = payload_size + 1;
	packet->messageLength[0] = (uint8_t) (payload_size >> 8);
	packet->messageLength[1] = (uint8_t) (payload_size & 0xFF);

	// Date and Time
	packet->date[2] = DateTime.tm_year;
	packet->date[1] = DateTime.tm_mon;
	; // Month
	packet->date[0] = DateTime.tm_mdate;    // Day
	packet->time[0] = DateTime.tm_hour;    // Hour
	packet->time[1] = DateTime.tm_min;     // Minute
	packet->time[2] = DateTime.tm_sec;     // Second

	// Kavach Type, Unit ID, Sim ID, OTP
	packet->kavachType = kavachType;
	for (int i = 0; i < 3; i++) {
		packet->kavachUnitID[i] = kavachUnitID[i];
	}
	packet->SIM_ID = SIM_ID;
	packet->otp[0] = (OTP_value >> 24) & 0xFF;
	packet->otp[1] = (OTP_value >> 16) & 0xFF;
	packet->otp[2] = (OTP_value >> 8) & 0xFF;
	packet->otp[3] = OTP_value & 0xFF;

	// CRC32 Calculation (Assuming CRC over messageType to OTP inclusive)
	size_t offset = offsetof(KAVACH_Authentication_Key_Request_Message_t,
			messageType);
	size_t length = offsetof(KAVACH_Authentication_Key_Request_Message_t, otp)
			- offset + sizeof(packet->otp);
	uint32_t crc = calculate_crc32(((uint8_t*) packet) + offset, length);
	packet->crc32[0] = (crc >> 24) & 0xFF;
	packet->crc32[1] = (crc >> 16) & 0xFF;
	packet->crc32[2] = (crc >> 8) & 0xFF;
	packet->crc32[3] = crc & 0xFF;
}
uint8_t hexCharToUint(char ch) {
	if (ch >= '0' && ch <= '9')
		return ch - '0';
	if (ch >= 'A' && ch <= 'F')
		return 10 + ch - 'A';
	if (ch >= 'a' && ch <= 'f')
		return 10 + ch - 'a';
	return 0; // Not a valid hex character
}
void hexStringToBytes(const char *hexStr, uint8_t *bytes, size_t bytesLen) {
	for (size_t i = 0; i < bytesLen; ++i) {
		bytes[i] = (hexCharToUint(hexStr[2 * i]) << 4)
				| (hexCharToUint(hexStr[2 * i + 1]));
	}
}

void frameKMSAuthenticationKeyMessage(
		const KMS_Authentication_Key_Message_t *message, uint8_t **outBuffer,
		size_t *outBufferSize) {
	// Initial buffer size estimate. Adjust according to your protocol specifics.
	size_t bufferSize = sizeof(KMS_Authentication_Key_Message_t);
	*outBuffer = malloc(bufferSize);
	if (*outBuffer == NULL) {
		// Handle memory allocation failure
		printf("Failed to allocate memory for outBuffer\n");
		*outBufferSize = 0;
		return;
	}

	size_t offset = 0;

	// Copy each field to the buffer
#define COPY_FIELD_TO_BUFFER(field, fieldName)                              \
    memcpy(*outBuffer + offset, &(message->field), sizeof(message->field)); \
    printf("Copying %s to buffer at offset %zu\n", fieldName, offset);      \
    offset += sizeof(message->field);

	COPY_FIELD_TO_BUFFER(startOfFrame, "Start of Frame");
	COPY_FIELD_TO_BUFFER(messageType, "Message Type");
	// Skip messageLength for now, we'll fill it later
	size_t messageLengthOffset = offset;
	printf("Skipping Message Length, reserved at offset %zu\n", offset);
	offset += sizeof(message->messageLength);
	COPY_FIELD_TO_BUFFER(date, "Date");
	COPY_FIELD_TO_BUFFER(time, "Time");
	COPY_FIELD_TO_BUFFER(kavachType, "Kavach Type");
	COPY_FIELD_TO_BUFFER(kavachUnitID, "Kavach Unit ID");
	COPY_FIELD_TO_BUFFER(KeysetUniqueID, "Keyset Unique ID");
	COPY_FIELD_TO_BUFFER(Nokeystets, "Number of Keysets");

	// Copy each keyset used
	for (int i = 0; i < message->Nokeystets; ++i) {
		printf("Copying Keyset %d\n", i + 1);
		COPY_FIELD_TO_BUFFER(keys[i].validityStart, "Keyset Validity Start");
		COPY_FIELD_TO_BUFFER(keys[i].validityEnd, "Keyset Validity End");
		COPY_FIELD_TO_BUFFER(keys[i].key1, "Keyset Key 1");
		COPY_FIELD_TO_BUFFER(keys[i].key2, "Keyset Key 2");
	}

#undef COPY_FIELD_TO_BUFFER

	// Calculate and fill in the messageLength
	uint16_t messageLength = offset + sizeof(message->crc32); // message length excluding startOfFrame
	//printf("Message Length (excluding Start of Frame): %u bytes\n",messageLength);
	memcpy(*outBuffer + messageLengthOffset, &messageLength,
			sizeof(messageLength));

	// Calculate CRC (excluding crc32 field itself) and append it at the end
	uint32_t crc32 = calculate_crc32(*outBuffer, offset);
//	printf("CRC32 calculated: 0x%08X\n", crc32);
	memcpy(*outBuffer + offset, &crc32, sizeof(crc32));
	offset += sizeof(crc32);

	*outBufferSize = offset;
	//printf("Total Message Size: %zu bytes\n", *outBufferSize);
}
void frame_Kavach_AuthenticationQueryMessage(
		KAVACH_AuthenticationQueryMessage_t *packet, uint8_t kavachType,
		uint8_t *kavachUnitID) {

	// Start of Frame
	packet->startOfFrame[0] = (KAVACH_KMS_HEADER >> 8) & 0xFF; // Higher byte
	packet->startOfFrame[1] = KAVACH_KMS_HEADER & 0xFF;
	// Message Type
	packet->messageType = Kavach_AuthenticationQurey_ID; // Placeholder, replace with appropriate type

	// Message Length (Calculate this based on included fields)
	size_t payload_size = sizeof(KAVACH_AuthenticationQueryMessage_t)
			- sizeof(packet->startOfFrame) - sizeof(packet->crc32);
	//payload_size = payload_size + 1;
	payload_size = 0x0E;//payload_size + 1;
	packet->messageLength[0] = (uint8_t) (payload_size >> 8);
	packet->messageLength[1] = (uint8_t) (payload_size & 0xFF);

	// Date and Time
	packet->date[2] = DateTime.tm_year;
	packet->date[1] = DateTime.tm_mon;
	; // Month
	packet->date[0] = DateTime.tm_mdate;    // Day
	packet->time[0] = DateTime.tm_hour;    // Hour
	packet->time[1] = DateTime.tm_min;     // Minute
	packet->time[2] = DateTime.tm_sec;     // Second

	// Unit, Kavach Unit ID, Keyset Unique ID
	packet->kavachType = kavachType;
	for (int i = 0; i < 3; i++) {
		packet->kavachUnitID[i] = kavachUnitID[i];
	}

	// CRC32 Calculation (Modify range in calculation if needed)
	size_t offset = offsetof(KAVACH_AuthenticationQueryMessage_t, messageType);
	size_t length = sizeof(KAVACH_AuthenticationQueryMessage_t) - offset
			- sizeof(packet->crc32); // Include all fields up to crc32
	uint32_t crc = calculate_crc32(((uint8_t*) packet) + offset, length);
	packet->crc32[0] = (crc >> 24) & 0xFF;
	packet->crc32[1] = (crc >> 16) & 0xFF;
	packet->crc32[2] = (crc >> 8) & 0xFF;
	packet->crc32[3] = crc & 0xFF;
}

void frame_Kms_AuthenticationKeyStatusMessage(Kms_KeyStatusMessage_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t *KeysetUniqueID) {

	// Start of Frame
	packet->startOfFrame[0] = (KAVACH_KMS_HEADER >> 8) & 0xFF; // Higher byte
	packet->startOfFrame[1] = KAVACH_KMS_HEADER & 0xFF;
	// Message Type
	packet->messageType = Kms_AuthenticationKeystatus_ID; // Placeholder, replace with appropriate type

	// Message Length (Calculate this based on included fields)
	size_t payload_size = sizeof(KAVACH_AuthenticationQueryMessage_t)
			- sizeof(packet->startOfFrame) - sizeof(packet->crc32);
	payload_size = payload_size + 1;
	packet->messageLength[0] = (uint8_t) (payload_size >> 8);
	packet->messageLength[1] = (uint8_t) (payload_size & 0xFF);

	// Date and Time
	packet->date[2] = DateTime.tm_year;
	packet->date[1] = DateTime.tm_mon;
	; // Month
	packet->date[0] = DateTime.tm_mdate;    // Day
	packet->time[0] = DateTime.tm_hour;    // Hour
	packet->time[1] = DateTime.tm_min;     // Minute
	packet->time[2] = DateTime.tm_sec;     // Second

	// Unit, Kavach Unit ID, Keyset Unique ID
	packet->kavachType = kavachType;
	for (int i = 0; i < 3; i++) {
		packet->kavachUnitID[i] = kavachUnitID[i];
	}
	for (int i = 0; i < 4; i++) {
		packet->KeysetUniqueID[i] = KeysetUniqueID[i];
	}

	// CRC32 Calculation (Modify range in calculation if needed)
	size_t offset = offsetof(KAVACH_AuthenticationQueryMessage_t, messageType);
	size_t length = sizeof(KAVACH_AuthenticationQueryMessage_t) - offset
			- sizeof(packet->crc32); // Include all fields up to crc32
	uint32_t crc = calculate_crc32(((uint8_t*) packet) + offset, length);
	packet->crc32[0] = (crc >> 24) & 0xFF;
	packet->crc32[1] = (crc >> 16) & 0xFF;
	packet->crc32[2] = (crc >> 8) & 0xFF;
	packet->crc32[3] = crc & 0xFF;
}

void ProcessKms(void) {

	if (1 == Txflag) {
		messageSize = process_kavach_message(inital_packet);
		//KMS_vUdpTxDataPacket(responseMessage, messageSize);
		Txflag = 0;
	} else if (Rxflag == 1) {
		Rxflag = 0;
		response[0] = 0xA5;
		response[1] = 0xc3;
		response[2] = 0x92;
		messageSize = process_kavach_message(response);

		// Sleep(100);
		// Prepare the response based on the received message
		if (ServerRxMessageBuff[19] == 0x91) {
			memset(&ServerRxMessageBuff, 0, sizeof(ServerRxMessageBuff));
			response[0] = 0xA5;
			response[1] = 0xc3;
			response[2] = 0x92;
			messageSize = process_kavach_message(response);

			if (KMS_IdentificationAcKPkt.ACK_status == 0x01) {
			} else if (KMS_IdentificationAcKPkt.ACK_status == 0x02) {
			} else if (KMS_IdentificationAcKPkt.ACK_status == 0x03) {
			} else {
			}
			// handel the data into receviced structure
			memset(ServerRxMessageBuff, 0, 2000);
			// Send the message to the server
			//KMS_vUdpTxDataPacket(responseMessage, messageSize);
		} else if (KeyData[2] == 0x93) {

			response[0] = 0xA5;
			response[1] = 0xc3;
			response[2] = 0x94;
			messageSize = process_kavach_message(response);
			//AuthKeyFlag = 1;
			memset(ServerRxMessageBuff, 0, 2000);

			// Send the message to the server
			//KMS_vUdpTxDataPacket(responseMessage, messageSize);
		} else if (ServerRxMessageBuff[2] == 0x95) {

			response[0] = 0xA5;
			response[1] = 0xc3;
			response[2] = 0x90;
			messageSize = process_kavach_message(response);
			memcpy(&Kms_KeyStatusMessage, ServerRxMessageBuff,
					sizeof(Kms_KeyStatusMessage_t));
			memset(ServerRxMessageBuff, 0, 2000);
			// Send the message to the server
			//KMS_vUdpTxDataPacket(responseMessage, messageSize);
		}
	} else {
		// Handle unknown command or provide a default response
		// messageSize = 0; // No response or set a default response
	}
//	if (AuthKeyFlag == 1) {
//		AuthKeyFlag = 0;
//		uint8_t *buf;
//		uint8_t keysetno = 10;
//		buf = selectAuthenticationKey(&KMS_Authentication_Key_Message,
//				u32_stationaryKavachID, u32_onboardKavachID, keysetno);
//		for (int i = 0; i < 16; i++) {
//			// UART3_Send(&huart3, buf + i, 1);
//		}
//	}
//	else

}

void testdataSend(void)
{

	if(processKeydata ==1)
		{
			processKeydata =0;

			  uint8_t dateToSearch[4];


			  uint8_t data[100];
//			  dateToSearch[0] = KMS_Authentication_Key_Message.time[0];
//
//			     dateToSearch[1] = KMS_Authentication_Key_Message.date[0];
//
//			     dateToSearch[2] = KMS_Authentication_Key_Message.date[1];
//
//			     dateToSearch[3] = KMS_Authentication_Key_Message.date[2];

				  dateToSearch[0] = DateTime.tm_hour;//KMS_Authentication_Key_Message.time[0];

					     dateToSearch[1] = DateTime.tm_mdate;

					     dateToSearch[2] =DateTime.tm_mon;

					     dateToSearch[3] = DateTime.tm_year;

	//		     sprintf(data, "Time: %c, Date: %%c%c",
	//		                 dateToSearch[0], dateToSearch[1], dateToSearch[2], dateToSearch[3]);
	//		     HAL_UART_Transmit(&huart2, (uint8_t *)data, strlen(data), 100);
			     KeySet_t *foundKeySet = getKeySetByDate(&KMS_Authentication_Key_Message, dateToSearch);

			     if (foundKeySet != NULL)
			        {

			            for (int i = 0; i < 16; i++)
			            {
			            	key1[i]= foundKeySet->key1[i];
			            }

			            for (int i = 0; i < 16; i++)
			            {
			             	key2[i]= foundKeySet->key2[i];
			            }

			        }
			        else
			        {

			        }
		}
		else {
		}
}
/**
 * Calculates the Authentication Key for a given pair of Stationary and Onboard Kavach IDs.
 *
 * The Authentication Key is derived by adding the IDs of the Stationary Kavach and the Onboard
 * Kavach, and then taking the modulo 2 of the result. This function is a part of the Key
 * Management System (KMS) module.
 *
 * @param stationaryKavachID The ID of the Stationary Kavach.
 * @param onboardKavachID The ID of the Onboard Kavach.
 * @return The derived Authentication Key as an integer, either 0 or 1.
 */
int kmsCalculateAuthenticationKey(int stationaryKavachID, int onboardKavachID) {
	// Sum the IDs and return the result modulo 2 to get the Authentication Key
	return (stationaryKavachID + onboardKavachID) % 2;
}

// Function to select either key1 or key2 from a KeySet_t structure based on Kavach IDs.
// The choice of key is determined by the result of kmsCalculateAuthenticationKey function.
uint8_t* selectAuthenticationKey(KMS_Authentication_Key_Message_t *keySet,
		int stationaryKavachID, int onboardKavachID, int i) {
	// Calculate the authentication key using the given stationary and onboard Kavach IDs.
	// The result will be either 0 or 1, dictating which key to select.
	int authKey = kmsCalculateAuthenticationKey(stationaryKavachID,
			onboardKavachID);

	if (authKey == 0) {
		// If the authentication key is 0, select key1.
		// Return a pointer to key1 array within the KeySet_t structure.
		return keySet->keys[i].key1;
	} else {
		// If the authentication key is not 0 (i.e., 1 in this case), select key2.
		// Return a pointer to key2 array within the KeySet_t structure.
		return keySet->keys[i].key2;
	}
}

// Function prototype updated to return a pointer to uint8_t
uint8_t* GenerateRData(uint16_t RS, uint16_t RL, int *size) {

	// Calculate the size of the R array
	*size = 16; // Since the pattern is fixed and always generates 16 bytes

	// Allocate memory for the R buffer
	uint8_t *R = (uint8_t*) malloc(*size * sizeof(uint8_t));
	if (R == NULL) {
		// Handle memory allocation failure if needed
		printf("Memory allocation failed\n");
		*size = 0; // No data to return
		return NULL;
	}

	// Break down RS and RL into their bytes
	uint8_t RS_high = RS >> 8;
	uint8_t RS_low = RS & 0xFF;
	uint8_t RL_high = RL >> 8;
	uint8_t RL_low = RL & 0xFF;

	// Constructing R from the pattern described
	uint8_t tempR[] = { RS_high, RS_low, RL_low, RL_high, RS_high, RS_low,
			RL_low, RL_high, RL_low, RL_high, RS_high, RS_low, RL_low, RL_high,
			RS_high, RS_low };

	// Copy the constructed pattern into the allocated memory
	for (int i = 0; i < *size; i++) {
		R[i] = tempR[i];
	}

	// Return the pointer to the allocated memory holding R
	return R;
}

uint8_t KmsATCommand(GSM_packet_t *command, uint8_t cmdid) {
	HAL_StatusTypeDef status;
	memset(ServerRxMessageBuff, 0, 2000);
	status = HAL_UART_Transmit(&huart1, (uint8_t*) command[cmdid].cmd,
			strlen(command[cmdid].cmd), 1000);
	if (status != HAL_OK) {

	}

	status = HAL_UART_Receive(&huart1, (uint8_t*) command[cmdid].Rxbuf,
			command[cmdid].Rxlenen, 1000); // Timeout set to 5000 ms

	status = HAL_UART_Transmit(&huart2, (uint8_t*) command[cmdid].Rxbuf,
			command[cmdid].Rxlenen +5, 1000); // Timeout set to 5000 ms

	if (status != HAL_OK) {
		// Handle errorb

		return 0;
	}


	return 1; // Adjust based on how you want to validate responses
}
uint8_t udp_send(GSM_packet_t *command, uint8_t cmdid) {

	HAL_StatusTypeDef status = 0;

	status = HAL_UART_Transmit(&huart1, (uint8_t*) command[cmdid].cmd,
			command[cmdid].cmdlen, 1000);

	memset(ServerRxMessageBuff,0,2000);

	if (status != HAL_OK) {
		// Handle error
		return 0;
	}
	status = HAL_UART_Receive(&huart1, (uint8_t*) command[cmdid].Rxbuf,command[cmdid].Rxlenen, 1000);
	if (status != HAL_OK) {
		// Handle errorb
		return 0;
	}


	return 0; // Adjust based on how you want to validate responses
}

uint8_t Key_udp_send(GSM_packet_t *command, uint8_t cmdid) {

	HAL_StatusTypeDef status = 0;

	status = HAL_UART_Transmit(&huart1, (uint8_t*) command[cmdid].cmd,
			command[cmdid].cmdlen, 1000);
	memset(ServerRxMessageBuff, 0, 2000);

	if (status != HAL_OK) {
		// Handle error
		return 0;
	}
	status = HAL_UART_Receive(&huart1, &ServerRxMessageBuff[0], 1265, 2700); //(&huart1, (uint8_t*) command[cmdid].Rxbuf,

	if (status != HAL_OK) {
		// Handle error
		return 0;
	}

	return 0; // Adjust based on how you want to validate responses
}

uint8_t QUREY_udp_send(GSM_packet_t *command, uint8_t cmdid) {

	HAL_StatusTypeDef status = 0;
	memset(ServerRxMessageBuff, 0, 2000);
	status = HAL_UART_Transmit(&huart2, (uint8_t*) command[cmdid].cmd,
				command[cmdid].cmdlen, 1000);
	status = HAL_UART_Transmit(&huart1, (uint8_t*) command[cmdid].cmd,
			command[cmdid].cmdlen, 1000);


	if (status != HAL_OK) {
		// Handle error
		//return 0;
	}
	status = HAL_UART_Receive(&huart1, (uint8_t*) command[cmdid].Rxbuf,
			command[cmdid].Rxlenen, 1000);
	if (status != HAL_OK) {
		// Handle error
		return 0;
	}

	return 0; // Adjust based on how you want to validate responses
}

uint8_t Kavach_vDataPacketKAVACH_IdentificationMessage(void) {
	//extern GSM_packet_t GSM_packet[];
	size_t msgSize = sizeof(KAVACH_IdentificationMessagePkt_t);
	size_t totalSize = msgSize + 1;
	// Assuming KAVACH_IdentificationMessage and related functions are defined
	KAVACH_IdentificationMessagePkt(&KAVACH_IdentificationMessage, kavachType,
			kavachUnitID, simID);

	free(GSM_packet[19].cmd);  // Safe to free NULL
	GSM_packet[19].cmd = malloc(totalSize);
	if (!GSM_packet[19].cmd) {
		perror("Failed to allocate memory");
		return 0; // Handle malloc failure
	}
	GSM_packet[19].cmdlen = totalSize;

	// Copy the message into the cmd buffer
	memcpy(GSM_packet[19].cmd, &KAVACH_IdentificationMessage, msgSize);

	// Append 0x0D at the end
	GSM_packet[19].cmd[msgSize] = 0x0D;

	return 1; // Success
}

uint8_t Kavach_vDataPacketKAVACH_Authentication_Key_Request_Message(void) {
	//extern GSM_packet_t GSM_packet[];
	size_t msgSize = sizeof(KAVACH_Authentication_Key_Request_Message_t);
	size_t totalSize = msgSize + 1;
	// Assuming KAVACH_IdentificationMessage and related functions are defined
	frame_KAVACH_Authentication_Key_Request_Message(
			&KAVACH_Authentication_Key_Request_Message, kavachType,
			kavachUnitID, simID, KMS_u32Otp);

	free(GSM_packet[21].cmd);  // Safe to free NULL
	GSM_packet[21].cmd = malloc(totalSize);
	if (!GSM_packet[21].cmd) {
		perror("Failed to allocate memory");
		return 0; // Handle malloc failure
	}
	GSM_packet[21].cmdlen = totalSize;

	// Copy the message into the cmd buffer
	memcpy(GSM_packet[21].cmd, &KAVACH_Authentication_Key_Request_Message,
			msgSize);

	// Append 0x0D at the end
	GSM_packet[21].cmd[msgSize] = 0x0D;
	memset(GSM_packet[21].Rxbuf, 0, 2000);

	return 1; // Success
}

uint8_t Kavach_vDataPacketKavach_AuthenticationQueryMessage(void) {
	//extern GSM_packet_t GSM_packet[];
	size_t msgSize = sizeof(KAVACH_AuthenticationQueryMessage_t);
	size_t totalSize = msgSize + 1;
	// Assuming KAVACH_IdentificationMessage and related functions are defined
	frame_Kavach_AuthenticationQueryMessage(&KAVACH_AuthenticationQuery,
			kavachType, kavachUnitID);

	free(GSM_packet[23].cmd);  // Safe to free NULL
	GSM_packet[23].cmd = malloc(totalSize);
	if (!GSM_packet[23].cmd) {
		perror("Failed to allocate memory");
		return 0; // Handle malloc failure
	}
	GSM_packet[23].cmdlen = totalSize;

	// Copy the message into the cmd buffer
	memcpy(GSM_packet[23].cmd, &KAVACH_AuthenticationQuery, msgSize);

	// Append 0x0D at the end
	GSM_packet[23].cmd[msgSize] = 0x0D;

	return 1; // Success
}

void free_GSM_packets() {
	//extern GSM_packet_t GSM_packet[24];
	for (int i = 0; i < 19; i++) {
		free(GSM_packet[i].cmd); // Free dynamically allocated command string
	}
}
// Function to retrieve key set based on a given date within the validity period
KeySet_t *getKeySetByDate(KMS_Authentication_Key_Message_t *message, const uint8_t date[4])
{

    for (int i = 0; i < message->Nokeystets; ++i)
    {

        if (isDateWithinRange(date, message->keys[i].validityStart, message->keys[i].validityEnd))
        {

            return &message->keys[i];
        }
    }
    return NULL;

}

