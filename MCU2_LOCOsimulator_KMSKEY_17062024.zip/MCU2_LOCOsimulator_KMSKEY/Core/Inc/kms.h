/*******************************************************************************
 *
 * @FileName         : kms.h
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/
#ifndef INC_KMS_H_
#define INC_KMS_H_

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "usart.h"
typedef struct {
	int tm_sec;
	int tm_min;
	int tm_hour;
	int tm_mdate;
	int tm_mon;
	int tm_year;

} DateTime_t;
typedef struct {

	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t simID;
	uint8_t crc32[4];

} KAVACH_IdentificationMessagePkt_t;

typedef struct {
	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t ACK_status;
	uint8_t crc32[4];
} KMS_IdentificationAcKPkt_t;

// Authentication Key Request Message

typedef struct {

	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t SIM_ID;
	uint8_t otp[4];
	uint8_t crc32[4];

} KAVACH_Authentication_Key_Request_Message_t;

typedef struct {
	uint8_t validityStart[4]; // Simplified as 4 bytes
	uint8_t validityEnd[4];   // Simplified as 4 bytes
	uint8_t key1[16];         // Key 1
	uint8_t key2[16];         // Key 2
} KeySet_t;
typedef struct {
	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t KeysetUniqueID[4];
	uint8_t Nokeystets;
	KeySet_t keys[30];
	uint8_t crc32[4];

} KMS_Authentication_Key_Message_t;

// Authentication Query Message, 19 bytes (KAVACH to KMS)
typedef struct {
	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t crc32[4];

} KAVACH_AuthenticationQueryMessage_t;
typedef struct {
	uint8_t startOfFrame[2];
	uint8_t messageType;
	uint8_t messageLength[2];
	uint8_t date[3];
	uint8_t time[3];
	uint8_t kavachType;
	uint8_t kavachUnitID[3];
	uint8_t KeysetUniqueID[4];
	uint8_t crc32[4];
} Kms_KeyStatusMessage_t;

typedef struct {
	char *cmd; // Use const char* instead of uint8_t*
	uint8_t cmdlen;
	uint8_t *Rxbuf;
	uint16_t Rxlenen;
} GSM_packet_t;
extern DateTime_t DateTime;
extern GSM_packet_t GSM_packet[24];
extern volatile uint8_t Rxflag;
extern KMS_IdentificationAcKPkt_t KMS_IdentificationAcKPkt;
uint32_t process_kavach_message(uint8_t *message);
void KAVACH_IdentificationMessagePkt(KAVACH_IdentificationMessagePkt_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t simID);
void frame_KMS_IdentificationAcKPkt(KMS_IdentificationAcKPkt_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t ACK_status);
void frame_KAVACH_Authentication_Key_Request_Message(
		KAVACH_Authentication_Key_Request_Message_t *packet, uint8_t kavachType,
		uint8_t *kavachUnitID, uint8_t SIM_ID, uint32_t OTP_value);

void frame_Kavach_AuthenticationQueryMessage(
		KAVACH_AuthenticationQueryMessage_t *packet, uint8_t kavachType,
		uint8_t *kavachUnitID);
void frame_Kms_AuthenticationKeyStatusMessage(Kms_KeyStatusMessage_t *packet,
		uint8_t kavachType, uint8_t *kavachUnitID, uint8_t *KeysetUniqueID);
// Prototype for utility functions
void send_at_command(const char *cmd);
HAL_StatusTypeDef receive_response(char *buffer, uint32_t buffer_size,
		uint32_t timeout);
void UDP_connection_state_machine(void);
void initialize_GSM_packets(void);
void ProcessKms(void);
void testdataSend(void);
uint8_t udp_send(GSM_packet_t *command, uint8_t cmdid);
uint8_t Key_udp_send(GSM_packet_t *command, uint8_t cmdid);
uint8_t QUREY_udp_send(GSM_packet_t *command, uint8_t cmdid);

uint8_t KmsATCommand(GSM_packet_t *command, uint8_t cmdid);
uint8_t* selectAuthenticationKey(KMS_Authentication_Key_Message_t *keySet,
		int stationaryKavachID, int onboardKavachID, int i);
void frameKMSAuthenticationKeyMessage(
		const KMS_Authentication_Key_Message_t *message, uint8_t **outBuffer,
		size_t *outBufferSize);
uint8_t Kavach_vDataPacketKAVACH_IdentificationMessage(void);
uint8_t Kavach_vDataPacketKavach_AuthenticationQueryMessage(void);
uint8_t Kavach_vDataPacketKAVACH_Authentication_Key_Request_Message(void);
void free_GSM_packets();
KeySet_t *getKeySetByDate(KMS_Authentication_Key_Message_t *message, const uint8_t date[4]);
uint32_t KMS_vDecodeOTP(uint8_t *data);



#endif /* INC_KMS_H_ */
