/*******************************************************************************
 *
 * @FileName         : DATASHARING.h
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/

#ifndef INC_DATASHARING_H_
#define INC_DATASHARING_H_
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
	uint16_t pkt_start;           // 16 bits
	uint8_t pkt_type;             // 4 bits
	uint8_t pkt_length;           // 7 bits
	uint8_t date;                 // 8 bits
	uint8_t month;                // 8 bits
	uint8_t year;                 // 8 bits
	uint8_t hours;                // 8 bits
	uint8_t minutes;              // 8 bits
	uint8_t seconds;              // 8 bits
	uint8_t padding_bits;         // 1 bit
	uint32_t pkt_crc;             // 32 bits
} MCU2_RxDataPacket_t;

typedef struct {
	uint8_t pkt_start[2];              // 16 bits (2 bytes), assuming it needs to be 32 for alignment
	    uint8_t pkt_type;                  // 8 bits
	    uint8_t pkt_length;                // 8 bits
	    uint8_t source_loco_id[3];         // 24 bits, often aligned to 32 bits
	    uint8_t abs_loco_loc[3];           // 24 bits, often aligned to 32 bits
	    uint8_t train_speed[2];            // 16 bits
	    uint8_t movement_dir;              // 8 bits
	    uint8_t loco_mode;                 // 8 bits
	    uint8_t last_rfid_tag[2];          // 16 bits
	    uint8_t tag_dup;                   // 8 bits
	    uint8_t tag_link_info;             // 8 bits
	    uint8_t tin[2];                    // 16 bits
	    uint8_t sig_ov;                    // 8 bits
	    uint8_t spare;                     // 8 bits
	    uint8_t loco_health_status;        // 8 bits
	    uint8_t approaching_station_id[2]; // 16 bits
	    uint8_t pkt_crc[4];                // 32 bits
} Dnet_RxDataPacket_t;

typedef struct {
    uint8_t pkt_start[2];                   // 16 bits
    uint8_t pkt_type;                       // 8 bits
    uint8_t pkt_length[2];                    // 16 bits
    uint8_t source_loco_id[3];              // 24 bits, padded to 32 bits in memory
    uint8_t abs_loco_loc[3];                // 24 bits, padded to 32 bits in memory
    uint8_t train_speed[2];                 // 16 bits
    uint8_t movement_dir;                   // 8 bits
    uint8_t loco_mode;                      // 8 bits
    uint8_t last_rfid_tag[2];               // 16 bits
    uint8_t tag_dup;                        // 8 bits
    uint8_t tag_link_info;                  // 8 bits
    uint8_t tin[2];                         // 16 bits
    uint8_t sig_ov;                         // 8 bits
    uint8_t spare;                          // 8 bits
    uint8_t loco_health_status;             // 8 bits
    uint8_t approaching_station_id[2];      // 16 bits
    uint8_t akey1_at_memory_location_0[16]; // 128 bits
    uint8_t akey1_at_memory_location_1[16]; // 128 bits
    uint8_t pkt_crc[4];                     // 32 bits
} MCU2_TxDataPacket_t;

extern Dnet_RxDataPacket_t Dnet_RxDataPacket;
extern MCU2_TxDataPacket_t MCU2_TxDataPacket;
extern MCU2_RxDataPacket_t MCU2_RxDataPacket;
void write_bits(uint8_t *buffer, uint32_t *pos, uint32_t value, int num_bits);
uint32_t read_bits(const uint8_t *buffer, uint32_t *pos, int num_bits);
_Bool MCU2_vExtractRxDataPacket(uint8_t *buffer, MCU2_RxDataPacket_t *packet);
_Bool Dnet_vExtractRxDataPacket(Dnet_RxDataPacket_t *pkt);
void Frame_vMCU2TxDataPacket(MCU2_TxDataPacket_t *packet, uint8_t *buffer);
void MCU2_vProcessDatapacket(void);
void Dnet_vProcessDataPacket(void);
#endif /* INC_DATASHARING_H_ */
