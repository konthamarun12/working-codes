/*******************************************************************************
 *
 * @FileName         : crc32.h
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/

#ifndef _CRC32_H
#define _CRC32_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

uint32_t calculate_crc32(const uint8_t *data, size_t length);
bool verifyCrc32(uint8_t *data, size_t length);
void Crc_testSampletest (void);



#endif
