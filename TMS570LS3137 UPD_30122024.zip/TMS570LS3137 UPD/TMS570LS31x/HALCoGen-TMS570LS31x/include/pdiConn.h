/*
 * pdiConn.h
 *
 *  Created on: 22-Nov-2024
 *      Author: Admin
 */

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_PDICONN_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_PDICONN_H_

#define PROTOCOL_TYPE_EXPECTED 0xF2

#define  CMDPDI_VER_CHECK          (0x0201u)
#define  MSGPDI_VER_CHECK          (0x0202u)



#define SENDERID (0x0258) /* SKAVACH 600*/
#define RECEIVERID (0x01F4) /*TSRMS 500*/
#define MSG_LENGTH_PDIACK (0x000D)
#define PDI_Version (0x03)
#define RANDOM_NO (0x0462)

#define SENDERID_S (0x0258) /* SKAVACH 600*/
#define RECEIVERID_T (0x01F4) /*TSRMS 500*/

//bool PDI_Result;

#define SET_LOW      (0U)
#define SET_HIGH     (1U)

//#define SET_Match      (0x01U)
//#define SET_NotMatch    (0x02U)

extern uint8 u8udpTxBuff[1024];
extern uint8 TSRRxBuff[1024];
extern uint8 PDIRxPacket[1023];
extern uint8 PDIACKTxPacket[1023];

extern uint16 Rt;
extern uint16 Rs;



typedef struct UDP_DATA
{
    uint8 UDP_Rx;
    uint8 UDP_RxData[1023];

    volatile bool ConnReqRxd;
    volatile bool ConnRespRxd;

    volatile bool TxVPDI;
    volatile bool TxCmndPDI;


} udpData_s;

extern udpData_s Udp_Data;

typedef struct COMMAD_PDI
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint8   u8pdiver;
    uint16  u16Randomnum;

    uint8 PDI_ACK[17];
}commad_pdi_t;

extern commad_pdi_t CPDI_Rxdata;
extern commad_pdi_t CPDI_Txdata;

typedef struct MESSAGE_PDI
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint8   u8Resultpdiver;
    uint8   u8pdiver;
    uint16  u16Randomnum;
    uint32  u32MAC;
}msg_pdi_t;

//extern msg_pdi_t CPDI_Rxdata;
//typedef enum{
//    CMD_PDI_VER     = 0x0201U,
//    RES_PDI_VER     = 0x0202U,
//    ALL_TSR_INFO    = 0x0203U,
//    REQ_TSR_INFO    = 0x0204U,
//    SKAVACH_TSR     = 0x0205U,
//    TSR_INT_TEST    = 0x0206U,
//    ACK_MSG         = 0x0207U
//}TSR_MSG_TYPE;

extern uint32 u32Size;
extern bool EthRxd;


extern void Build_PDIACKMSG(void);
extern void process_pdiRxData(uint32 length);
extern void initRandomSeed();

#endif /* HALCOGEN_TMS570LS31X_INCLUDE_PDICONN_H_ */
