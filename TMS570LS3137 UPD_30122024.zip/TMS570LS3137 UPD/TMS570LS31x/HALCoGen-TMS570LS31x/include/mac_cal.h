/*
 * mac_cal.h
 *
 *  Created on: 25-Nov-2024
 *      Author: Admin
 */

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_MAC_CAL_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_MAC_CAL_H_


#include <stdint.h>
#include "hal_stdtypes.h"


typedef struct MAC_CLCLTN{
    uint16 macNumber[16];
}mac_t;


extern uint32 mac_calulate(uint8 * buffer, uint16 size);
extern void random_Number();



#endif /* HALCOGEN_TMS570LS31X_INCLUDE_MAC_CAL_H_ */
