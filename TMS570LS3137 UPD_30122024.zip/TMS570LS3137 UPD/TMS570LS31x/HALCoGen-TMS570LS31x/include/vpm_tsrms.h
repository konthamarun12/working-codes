/*
 * vpm_tsrms.h
 *
 *  Created on: 15-Dec-2024
 *      Author: Admin
 */
#include "sys_common.h"
#include "string.h"
#include "time.h"
#include <stdio.h>

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_VPM_TSRMS_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_VPM_TSRMS_H_


#define PACKET_SIZE 8        // Size of each received packet
#define BLOCK_SIZE 60        // Size of a complete data block
#define MAX_BLOCKS 31        // Maximum number of blocks
#define MAIN_BUFFER_SIZE (BLOCK_SIZE * MAX_BLOCKS) // Total buffer size (1860 bytes)

#define INFOMSGTYPE (0xABu)

//#define BUFFER_SIZE 1860
#define SEGMENT_SIZE 60
#define MAX_SEGMENTS (MAIN_BUFFER_SIZE / SEGMENT_SIZE)


//uint8_t mainBuffer[BUFFER_SIZE];


#define SET_LOW      (0U)
#define SET_HIGH     (1U)

#define FILLED (0x01u)


struct TSR  /*Store the TSR  related Data*/
{
    uint8_t TSR_ID;
    uint32_t TSR_STRTDTE;
    uint32_t TSR_STRTTIME;
    uint32_t TSR_ENDDATE;
    uint32_t TSR_ENDTIME;
    uint16_t TSR_ROUTE1;
    uint16_t TSR_ROUTE2;
    uint16_t TSR_ROUTE3;
    uint16_t TSR_ROUTE4;
    uint16_t TSR_ROUTE5;
    uint8_t TSR_DIRECTION;
    uint8_t TSR_SRTDSTROUTE;
    uint16_t TSR_LENGTH;
    uint8_t TSR_SPEDDCLS;
    uint8_t TSR_SVALUEUNIVERSAL;
    uint8_t TSR_SVALUECLASSA;
    uint8_t TSR_SVALUECLASSB;
    uint8_t TSR_SVALUECLASSC;
    uint8_t TSR_WHISTLING;
};


extern void processCanTSRData(uint8_t *packet);
extern void initializeBufferStatus();

#endif /* HALCOGEN_TMS570LS31X_INCLUDE_VPM_TSRMS_H_ */
