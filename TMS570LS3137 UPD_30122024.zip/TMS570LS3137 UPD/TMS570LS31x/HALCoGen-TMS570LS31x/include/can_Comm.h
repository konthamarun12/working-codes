/*
 * can_Comm.h
 *
 *  Created on: 30-Nov-2024
 *      Author: Admin
 */

#include "string.h"
#include "time.h"
#include <stdio.h>


#ifndef HALCOGEN_TMS570LS31X_INCLUDE_CAN_COMM_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_CAN_COMM_H_

#define SET_LOW      (0U)
#define SET_HIGH     (1U)
#define Slot (0x02U)
#define canIDVIC (0x2000u)
#define CANIDEXTENDED (0x01u)
#define CANMSGTYPETX (1U)

#define msgTypeCntrlPkt (0xBBu)
#define ActiveChannel (0x01u)
#define HostStanBy (0x00u)

#define msgIDRX (01U)

#define TIMEOUTEVENT (0u)
#define STD_CAN_SEND_VALUE (1u)

/*PDI Connection*/
//#define  CMDPDI_VER_MSGTYPE        (0x0201u)
//#define  MSGPDI_VER_CHECK          (0x0202u)
#define  TOTAL_CAN_PKT ()

extern uint8 u8Hour;
extern uint8 u8Minute;
extern uint8 u8Second;
extern uint8 u8Date;
extern uint8 u8Month;
extern uint8 u8Year;

extern uint32_t chekSum;

typedef struct VPM_INFO
{
    volatile bool VIC1AActive;
    volatile bool VIC2AActive;
} vpm_info;

extern vpm_info VPM_Info;

typedef struct can_info_t
{
    uint8_t u8STDTimeout;

}can_info;
extern can_info CAN0_INFO;

typedef struct CANCOMM1
{
   uint16 CAN_MsgCount;
   uint32 CPUID;
   uint8 CANMSGID;

}CAN1_MSG;

extern CAN1_MSG CAN1_Info;


typedef struct HealthMSG
{
    uint8 DipSwitchAdd;
    uint8 DipSwitchConfg;
    uint8 SlotDet;
    uint8 TSRMS_HSts;

}HEALTH_PACKET;

extern HEALTH_PACKET HEALTH_MSG;

extern void ReadDipSwitcheAdd(void);
extern void ReadDipSwitchConfig(void);
extern void ReadSlotDetected(void);
extern void perform_gps_time (void);

extern void HEALTH_MESSAGE();

extern void sendCANVPM(uint8_t CANID);
extern void wait(uint32_t u32time);
extern void REQUEST_CAN_PKT(uint8 msgID);



#endif /* HALCOGEN_TMS570LS31X_INCLUDE_CAN_COMM_H_ */
