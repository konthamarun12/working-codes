/*
 * tsrms.h
 *
 *  Created on: 22-Nov-2024
 *      Author: Admin
 */

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_TSRMS_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_TSRMS_H_

#define SET_LOW      (0U)
#define SET_HIGH     (1U)


#define  ALL_TSR_INFO              (0x0203u)
#define  GET_TSR_INFOMSG           (0x0204u)
#define  SK_Ack_TSR_DATAMSG        (0x0205u)
#define  TSRINTTEST                (0x0206u)
#define  ACKMSG                    (0x0207u)
#define TSR_VERTYPE                 (0xF2u)

#define ACK_MSG_LENGTH  (0x001A)


#define SENDERID (0x0258) /* SKAVACH 600*/
#define RECEIVERID (0x01F4) /*TSRMS 500*/

#define MACCODE    (4U)

typedef struct UDP_TSRDATA
{
    volatile bool TSRACKRX;
    volatile bool GETTSRACKTX;
    volatile bool DATAINTTX;

    volatile bool VPMTSRTX;
    volatile bool VPMACKMSHTX;
    volatile bool VPMGETTSRTX;
    volatile bool VPMSKACKTx;
    volatile bool VPMDATAINTTX;

} udpData_tsr;

extern udpData_tsr Udp_DataTSR;

typedef struct ALLTSRINFO
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint32  u32Framenum;
    uint16  u16TAN;
    uint8   u8TSRactiveYear;
    uint8   u8TSRactiveMonth;
    uint8   u8TSRactiveDate;
    uint8   u8TSRactiveHours;
    uint8   u8TSRactiveMinets;
    uint8   u8TSRactiveSeconds;
    uint8   u8TSRcount;
    uint8   u8TSRidentity;
    uint8   u8TSRtype;
    uint32  u32Active_TSRstartDate;
    uint32  u32Active_TSRstartTime;
    uint32  u32Actice_TSRendDate;
    uint32  u32Active_TSRendTime;
    uint16  u16TSRRoute1ID;
    uint16  u16TSRRoute2ID;
    uint16  u16TSRRoute3ID;
    uint16  u16TSRRoute4ID;
    uint16  u16TSRRoute5ID;
    uint8   u8TSRDire;
    uint16  u16TSRstartDist;
    uint16  u16TSRLength;
    uint8   u8TrainClass;
    uint8   u8UniversalTSR;
    uint8   u8ClassAtrainTSR;
    uint8   u8ClassBtrainTSR;
    uint8   u8ClassCtrainTSR;
    uint8   u8whistle;
    uint32  u32MAC;
    uint8 SKAVACH_ACK_MSG[1024];

}alltsr_info_t;

extern alltsr_info_t ALLTSR;
extern alltsr_info_t SK_TSRACK_Tx;

typedef struct GET_TSRINFO
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint32  u32Framenum;
    uint16  u16TAN;
}get_tsrinfo_t;

extern get_tsrinfo_t GET_TSRMSG;

typedef struct DATA_INTITSRMSG
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint32  u32Framenum;
    uint16  u16TAN;
    uint8  ACK_TSRMSG_TX[26];
}DATAINT_tsrinfo_t;

extern DATAINT_tsrinfo_t DATA_INTMSG;
extern DATAINT_tsrinfo_t TX_ACK_MSG;

typedef struct SKAVACH_ACK_ALLTSR_INFO
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint32  u32Framenum;
    uint16  u16TAN;
    uint8   u8TSRactiveYear;
    uint8   u8TSRactiveMonth;
    uint8   u8TSRactiveDate;
    uint8   u8TSRactiveHours;
    uint8   u8TSRactiveMinets;
    uint8   u8TSRactiveSeconds;
    uint8   u8TSRcount;
    uint8   u8TSRidentity;
    uint8   u8TSRtype;
    uint32  u32Active_TSRstartDate;
    uint32  u32Active_TSRstartTime;
    uint32  u32Actice_TSRendDate;
    uint32  u32Active_TSRendTime;
    uint16  u16TSRRoute1ID;
    uint16  u16TSRRoute2ID;
    uint16  u16TSRRoute3ID;
    uint16  u16TSRRoute4ID;
    uint16  u16TSRRoute5ID;
    uint8   u8TSRDire;
    uint16  u16TSRstartDist;
    uint16  u16TSRLength;
    uint8   u8TrainClass;
    uint8   u8UniversalTSR;
    uint8   u8ClassAtrainTSR;
    uint8   u8ClassBtrainTSR;
    uint8   u8ClassCtrainTSR;
    uint8   u8whistle;
    uint32  u32MAC;
}sk_ack_alltsr_info_t;


typedef struct ACKNOWLEDGE
{
    uint8   u8protocolType;
    uint16  u16MsgType;
    uint16  u16SendetID;
    uint16  u1ReceID;
    uint16  u16MsgLen;
    uint32  u32Framenum;
    uint16  u16TAN;
    uint8   u8TSRactiveYear;
    uint8   u8TSRactiveMonth;
    uint8   u8TSRactiveDate;
    uint8   u8TSRactiveHours;
    uint8   u8TSRactiveMinets;
    uint8   u8TSRactiveSeconds;
    uint8   u8TSRcount;
    uint8   u8TSRIdentity;
}acknowledge_t;


extern volatile uint8 u8State;
extern void Tx_ACK_MSG(void);
extern void Tx_SKAVACH_GET_ACK(void);
/********************************************************************/

extern uint8 gRxPacket[1023];
extern uint8 GetTSRRxPacket[1023];
extern uint8 DATAIntRxPacket[1023];
extern uint8 SKTSRACKTxPacket[1023];
extern uint8 ACKTxPacket[1023];

//extern void process_TSRRxData(uint32 length);
//extern void udpsend(uint16 u16Len);

extern void process_TSrRxData(uint8_t* pRxData,  uint32 length, uint16 u16msgType);


#endif /* HALCOGEN_TMS570LS31X_INCLUDE_TSRMS_H_ */
