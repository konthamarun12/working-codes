/*
 * pdiConn.c
 *
 *  Created on: 22-Nov-2024
 *      Author: Admin
 */

#include "sys_common.h"
#include "stdlib.h"

/* USER CODE BEGIN (1) */
#include "gio.h"
#include "lwipopts.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "pdiConn.h"
#include "tsrms.h"
#include "string.h"
#include "mac_cal.h"

#include "rti.h"
#include "mibspi.h"


struct COMMAD_PDI CPDI_Rxdata;
struct COMMAD_PDI CPDI_Txdata;
//MESSAGE_PDI PDIACK_Txdata;
struct UDP_DATA Udp_Data;

struct MAC_CLCLTN mac;

uint8 u8udpTxBuff[1024] = {0};
uint16 Rt;
uint16 Rs;

uint8 TSRRxBuff[1024] = {0};
uint32 PDI_Result;
uint8 PDIRxPacket[1023] = {0};
uint8 PDIACKTxPacket[1023] = {0};



#define SET_NotMatch (0x01U)
#define SET_Match   (0x02U)


void process_pdiRxData(uint32 length);

void RX_CmndPDI_MSG(void);

void initRandomSeed();
void generateRandomNo(void);

void process_pdiRxData(uint32 length){

    uint16 u16msgType = 0U;
    u16msgType = (Udp_Data.UDP_RxData[1] << 8U) | Udp_Data.UDP_RxData[2];
    memcpy(TSRRxBuff, Udp_Data.UDP_RxData, length);

    if(u16msgType == CMDPDI_VER_CHECK ){
       gioToggleBit(mibspiPORT5,PIN_SIMO_2);
        memcpy(PDIRxPacket, TSRRxBuff, length);
        Udp_Data.ConnReqRxd = SET_HIGH;
        RX_CmndPDI_MSG();

    }else{

        gioToggleBit(mibspiPORT5,PIN_SIMO_3);
        process_TSrRxData(Udp_Data.UDP_RxData,length,u16msgType);
    }
}

void RX_CmndPDI_MSG(void){

    CPDI_Rxdata.u8protocolType = (Udp_Data.UDP_RxData[0] << 0U);
    CPDI_Rxdata.u16MsgType = ((Udp_Data.UDP_RxData[2]) | (Udp_Data.UDP_RxData[1] << 8U));
    CPDI_Rxdata.u16SendetID =  ((Udp_Data.UDP_RxData[4]) | (Udp_Data.UDP_RxData[3] << 8U));
    CPDI_Rxdata.u1ReceID =  ((Udp_Data.UDP_RxData[6]) | (Udp_Data.UDP_RxData[5] << 8U));
    CPDI_Rxdata.u16MsgLen =  ((Udp_Data.UDP_RxData[8]) | (Udp_Data.UDP_RxData[7] << 8U));
    CPDI_Rxdata.u8pdiver =   (Udp_Data.UDP_RxData[9] << 0U);
    CPDI_Rxdata.u16Randomnum =   ((Udp_Data.UDP_RxData[11]) | (Udp_Data.UDP_RxData[10] << 8U));

     Rt = CPDI_Rxdata.u16Randomnum;
    //Rt = 0x526A;
    if(CPDI_Rxdata.u8pdiver == PDI_Version){
        PDI_Result = SET_Match;
        Udp_Data.ConnReqRxd = SET_HIGH;
        Udp_Data.TxCmndPDI = SET_HIGH;

    }else
    {
        Udp_Data.ConnReqRxd = SET_HIGH;
        PDI_Result = SET_NotMatch;
        Udp_Data.TxCmndPDI = SET_HIGH;
    }
}

void Build_PDIACKMSG(void){

    uint8_t filled_size = 0;
    /*...SOF.....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (char)(((PROTOCOL_TYPE_EXPECTED) >> (0U)) & (0xFFU));

    /*....MSG TYPE....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (char)(((MSGPDI_VER_CHECK) >> (8U)) & (0xFFU));
    CPDI_Txdata.PDI_ACK[filled_size++] = (char)(((MSGPDI_VER_CHECK) >> (0U)) & (0xFFU));

    /*....Sender ID....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((SENDERID_S) >> (8U)) & (0xFFU));
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((SENDERID_S) >> (0U)) & (0xFFU));

    /*....Receiver ID....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((RECEIVERID_T) >> (8U)) & (0xFFU));
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((RECEIVERID_T) >> (0U)) & (0xFFU));

    /*....Message Length....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((MSG_LENGTH_PDIACK) >> (8U)) & (0xFFU));
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((MSG_LENGTH_PDIACK) >> (0U)) & (0xFFU));

    /*....Result PDI....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((PDI_Result) >> (0U)) & (0xFFU));

    /*....PDI Version....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((PDI_Version) >> (0U)) & (0xFFU));

    generateRandomNo();

    /*....Random Number....*/
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((Rs) >> (8U)) & (0xFFU));
    CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((Rs) >> (0U)) & (0xFFU));

            uint32_t padded_size = (filled_size <= 32) ? 32 : 64;

                // Create a padded buffer and fill it
                uint8 padded_temp[64] = {0}; // Initialize with zeros
                memcpy(padded_temp, CPDI_Txdata.PDI_ACK, filled_size);

           uint32 caltedMAC= mac_calulate(padded_temp, padded_size);

       CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((caltedMAC) >> (24U)) & (0xFFU));
       CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((caltedMAC) >> (16U)) & (0xFFU));
       CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((caltedMAC) >> (8U)) & (0xFFU));
       CPDI_Txdata.PDI_ACK[filled_size++] = (uint8)(((caltedMAC) >> (0U)) & (0xFFU));

       memcpy(PDIACKTxPacket, CPDI_Txdata.PDI_ACK, filled_size);

}

void generateRandomNo(void){

    Rs = (uint16_t)(rand() & 0xFFFF);
   // Rs= 0x5694;
}
void initRandomSeed() {
    srand(12345); // Static seed;
}







