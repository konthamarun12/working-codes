/*
 * mac_cal.c
 *
 *  Created on: 25-Nov-2024
 *      Author: Admin
 */

#include "mac_cal.h"
#include "TI_aes_128.h"

#include "gio.h"
#include "lwipopts.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "string.h"
#include "crc.h"
#include <stdio.h>
#include "pdiConn.h"

//#define Rt (0x071A)
//
//#define Rs (0x41C6)

unsigned char Random_Nmbr[16];

void random_Number(){

    uint8 TFN = (uint8)((Rt >> 8) & 0xFF); // Extract high byte of Rt
    uint8 TSN = (uint8)(Rt & 0xFF);        // Extract low byte of Rt

    uint8 SFN = (uint8)((Rs >> 8) & 0xFF); // Extract high byte of Rs
    uint8 SSN = (uint8)(Rs & 0xFF);        // Extract low byte of Rs

    Random_Nmbr[0] = SSN; /*TSRMS*/
    Random_Nmbr[1] = SFN;
    Random_Nmbr[2] = TSN;
    Random_Nmbr[3] = TFN;

    Random_Nmbr[4] = SSN; /*TSRMS*/
    Random_Nmbr[5] = SFN;
    Random_Nmbr[6] = TSN;
    Random_Nmbr[7] = TFN;

    Random_Nmbr[8] = TSN; /*Station*/
    Random_Nmbr[9] = TFN;
    Random_Nmbr[10] = SSN;
    Random_Nmbr[11] = SFN;

    Random_Nmbr[12] = TSN; /*Station*/
    Random_Nmbr[13] = TFN;
    Random_Nmbr[14] = SSN;
    Random_Nmbr[15] = SFN;
}

uint32 mac_calulate(uint8 *buffer, uint16 size){

    uint8 Ks[16];
    uint32 M1;
    uint32 i = 0;
    uint32 Message_Con = 0;

    uint8 text1[32];
    uint8 text2[32];

  //  uint8 Message_temp[128];


//    uint8 temp[] = { 0xB3, 0x2A, 0xB7, 0xF0, 0x21, 0x04, 0x09, 0xD4, 0x90,
//                            0x41, 0x1A, 0x80, 0xCC, 0x16, 0x08, 0x2B, 0x4A, 0x04,
//                            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//                            0x00, 0x00, 0x00, 0x00, 0x00 };
//        uint8 Message[] = { 0x90, 0x70, 0x1C, 0x9E, 0x60, 0x72, 0x87, 0x89, 0x00, 0x44,
//                         0xC0, 0x0C, 0x88, 0x30, 0xE1, 0x06, 0x40, 0x0C, 0x0D, 0x80,
//                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
//        unsigned char buff[] = {0x01, 0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09};

    /******************************** Reversed R(random numbers)********************************/

//        unsigned char state[] = { 0x94, 0x56, 0x6A, 0x52, 0x94, 0x56, 0x6A, 0x52,
//                                  0x6A, 0x52, 0x94, 0x56, 0x6A, 0x52, 0x94, 0x56 };

//    unsigned char state[] = { 0xF6, 0x43, 0x99, 0xFC, 0x50, 0x52, 0x45, 0x98,
//                                     0x27, 0x81, 0xBB, 0x83, 0x5F, 0x8F, 0xB5, 0xC9 };

        unsigned char key1[] = { 0x75, 0x46, 0x20, 0x67, 0x6E, 0x75, 0x4B, 0x20,
                                 0x79, 0x6D, 0x20, 0x73, 0x74, 0x61, 0x68, 0x54 };


//        uint8 temp[] = { 0xF2, 0x02, 0x02, 0x02, 0x58, 0x01, 0xF4, 0x00, 0x0D,
//                                0x01, 0x03, 0x41, 0xC6, 0x00, 0x00, 0x00, 0x00, 0x00,
//                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//                                0x00, 0x00, 0x00, 0x00, 0x00 };

        /*checking whether padding is required or not*/
//
//        if (size < 16U) {
//            // If size is less than 16 bytes, pad to 32 bytes
//            buffer_size = 32U;
//        } else if (size < 32U) {
//            // If size is between 16 and 32 bytes, pad to 32 bytes
//            buffer_size = 32U;
//        } else if (size < 64U) {
//            // If size is between 32 and 64 bytes, pad to 64 bytes
//            buffer_size = 64U;
//        } else {
//            // No padding required if the size is 64 bytes or more
//            buffer_size = size;
//        }
//
//        /*filling the above array with data*/
//
//        for(k = 0U; k < buffer_size; k++)
//        {
//            if(k < size)
//            {
//                buffer_array[k] = buffer[k];
//            }
//            else{
//
//                buffer_array[k] = 0U;
//            }
//        }


        random_Number();

       // unsigned char state[] = Random_Nmbr;
    /******************************** Performing AES128 encryption *************************************/
        aes_enc_dec(Random_Nmbr, key1, 0U);
    /******************************** Performing AES128 encryption *************************************/
        for (i = 0U; i < sizeof(Random_Nmbr); ++i)
        {
            Ks[i] = Random_Nmbr[i];
        }
    /************************************************************************************************/
        for (i = 0U; i <= 1024U; i++)
        {
            if (buffer[i] != *(uint8 *) NULL)
            {
                Message_Con++;
            }
            else
            {
                break;
            }
        }
    /************************************************************************************************/
        /*(Message_Con / 2);*/
        for (M1 = 1U; M1 <= 32U; M1++)
        {
            if ((M1 >= 1U) && (M1 <= 16U))
            {
                text1[M1-1U] = buffer[M1-1U];
            }
            if ((M1 >= 17U) && (M1 <= 32U))
            {
                text2[M1 - 17U] = buffer[M1-1U];
            }
        }
    /******************************** Performing AES128 encryption *************************************/
        aes_enc_dec(text1, Ks, 0U);
    /******************************** Performing AES128 encryption *************************************/
        for (i = 0U; i < 16U; ++i)
        {
            Ks[i] = text1[i];
        }

    /******************************** Performing AES128 encryption *************************************/
        aes_enc_dec(text2, Ks, 0U);
    /******************************** Performing AES128 encryption *************************************/

    /******************************** Calculating CRC for last encrypted data *************************************/
    uint32 MAC = crc_calc(16U, 0U, text2);


    return MAC;
}
