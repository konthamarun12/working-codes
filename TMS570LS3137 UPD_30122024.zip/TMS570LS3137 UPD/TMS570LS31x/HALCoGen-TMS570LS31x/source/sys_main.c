/** @file sys_main.c 
*   @brief Application main file
*   @date 11-Dec-2018
*   @version 04.07.01
*
*   This file contains an empty main function,
*   which can be used for the application.
*/

/* 
* Copyright (C) 2009-2018 Texas Instruments Incorporated - www.ti.com 
* 
* 
*  Redistribution and use in source and binary forms, with or without 
*  modification, are permitted provided that the following conditions 
*  are met:
*
*    Redistributions of source code must retain the above copyright 
*    notice, this list of conditions and the following disclaimer.
*
*    Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the 
*    documentation and/or other materials provided with the   
*    distribution.
*
*    Neither the name of Texas Instruments Incorporated nor the names of
*    its contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*/


/* USER CODE BEGIN (0) */
/* USER CODE END */

/* Include Files */

#include "sys_common.h"


/* USER CODE BEGIN (1) */
#include "can.h"
#include "emif.h"
#include "sci.h"
#include "mibspi.h"
#include "stdio.h"
#include "sys_mpu.h"
#include "pdiConn.h"
#include "tsrms.h"
#include "can_Comm.h"
#include "vpm_tsrms.h"
#include "rti.h"
#include "gio.h"


#define UART scilinREG
#define SDRAM_BASE_ADDRESS (0x80000000)
#define SDRAM_END_ADDREESS (0x807FFFFF)
#define MAX_BUFFER_LEN (512)

#define FPGA_BASE_ADDR (0x60000000)
/* USER CODE END */

/** @fn void main(void)
*   @brief Application main function
*   @note This function is empty by default.
*
*   This function is called after startup.
*   The user can use this function to implement the application.
*/

/* USER CODE BEGIN (2) */
bool EthRxd = SET_LOW;
uint32 u32Size = 0;

extern char TempDataBuf[2048];

extern void EMAC_LwIP_Main (uint8_t * emacAddress);

void sciDisplayText(sciBASE_t *sci, uint8 *text, uint32 length);
void inline wait_forever();
int32_t sci_printf(const char* format, ...);
int32_t sci_vprintf(const char* format, va_list argList);

uint32_t TempBuf[2048];
//__attribute__((far)) volatile int TestBytes[100];
//__attribute__((section(".farbss"))) volatile uint16_t sdram_far[100] = { 0 };
#pragma SET_DATA_SECTION(".farbss")
uint16_t sdram_far[100] = { 0 };
#pragma SET_DATA_SECTION()

#pragma SET_DATA_SECTION(".myFPGA")
    uint32_t efLoc[255];
#pragma SET_DATA_SECTION()
/* USER CODE END */

uint8	emacAddress[6U] = 	{0x00U, 0x08U, 0xEEU, 0x03U, 0xA6U, 0x6CU};
uint32 	emacPhyAddress	=	1U;

int main(void)
{
/* USER CODE BEGIN (3) */

   // mac_calulate(temp,32U);

    void initializeBufferStatus();
    perform_gps_time();
	EMAC_LwIP_Main(emacAddress);

    initRandomSeed();
    mibspiInit();
    gioInit();

    _mpuDisable_();
    _mpuInit_();
    _mpuEnable_();

    emif_SDRAMInit();
    emif_ASYNC1Init();
    canInit();
    sciInit();
    rtiInit();

    rtiEnableNotification(rtiNOTIFICATION_COMPARE0);

    /* Enable IRQ - Clear I flag in CPS register */
    /* Note: This is usually done by the OS or in an svc dispatcher */
   // _enable_IRQ_interrupt_();

    /* Start RTI Counter Block 0 */
    rtiStartCounter(rtiCOUNTER_BLOCK0);


/*    gioSetDirection(gioPORTB,0xFFFFFF00u);*/


    ReadDipSwitcheAdd();
    ReadDipSwitchConfig();

    canEnableErrorNotification(canREG1);
    canEnableErrorNotification(canREG2);

    ReadSlotDetected();

    chekSum = CheckIntCRC(0,0x0013ffffu);

    while(1)
    {

        if(CAN0_INFO.u8STDTimeout == TIMEOUTEVENT)
        {
            gioToggleBit(mibspiPORT5,PIN_SIMO_1);
            HEALTH_MESSAGE();
            CAN0_INFO.u8STDTimeout = STD_CAN_SEND_VALUE;
            //gioSetBit(mibspiPORT5,PIN_SIMO_1, 0U);
        }

        if (EthRxd == 1U) {
            process_pdiRxData(u32Size);
            EthRxd = SET_LOW;
        }

   /*    if (EthRxd == 1U) {
           if(VPM_Info.VIC1AActive == 1U && VPM_Info.VIC2AActive == 0U)
           {
            gioToggleBit(mibspiPORT5,PIN_SIMO_2);
            process_pdiRxData(u32Size);
            EthRxd = SET_LOW;
           }
           else if(VPM_Info.VIC2AActive == 1U && VPM_Info.VIC1AActive == 0U)
           {
               gioToggleBit(mibspiPORT5,PIN_SIMO_3);
               process_pdiRxData(u32Size);
               EthRxd = SET_LOW;
           }else
           {

           }
        }  */

       if (Udp_Data.TxCmndPDI) {
                 Udp_Data.TxCmndPDI = SET_LOW;
                 REQUEST_CAN_PKT(2);
              }


       /*SENDING TO TSRMS SERVER*/
       if (Udp_Data.ConnReqRxd) {
           //gioSetBit(mibspiPORT5,PIN_SIMO_2, 1U);
           Build_PDIACKMSG();
           Udp_Data.ConnReqRxd = SET_LOW;
           memcpy(TempDataBuf,CPDI_Txdata.PDI_ACK,17);
           udpsend(17);
           Udp_Data.TxVPDI = SET_HIGH;
        }

       if (Udp_Data.TxVPDI) {
                 Udp_Data.TxVPDI = SET_LOW;
                 REQUEST_CAN_PKT(3);
              }

       if (Udp_DataTSR.VPMTSRTX) {
           Udp_DataTSR.VPMTSRTX = SET_LOW;
           REQUEST_CAN_PKT(4);
              }

       if (Udp_DataTSR.TSRACKRX) {
           //gioSetBit(mibspiPORT5,PIN_SIMO_2, 1U);
           Tx_ACK_MSG();
           Udp_DataTSR.TSRACKRX = SET_LOW;
           memcpy(TempDataBuf,TX_ACK_MSG.ACK_TSRMSG_TX,26);
           udpsend(26);
           Udp_DataTSR.VPMACKMSHTX = SET_HIGH;
        }

       if (Udp_DataTSR.VPMACKMSHTX) {
           Udp_DataTSR.VPMACKMSHTX = SET_LOW;
           REQUEST_CAN_PKT(8);
          }

       if (Udp_DataTSR.VPMGETTSRTX) {
           Udp_DataTSR.VPMGETTSRTX = SET_LOW;
           REQUEST_CAN_PKT(5);
              }

       if (Udp_DataTSR.GETTSRACKTX) {
           //gioSetBit(mibspiPORT5,PIN_SIMO_3, 1U);
           Tx_SKAVACH_GET_ACK();
           Udp_DataTSR.GETTSRACKTX = SET_LOW;
           memcpy(TempDataBuf,SK_TSRACK_Tx.SKAVACH_ACK_MSG,60);
           udpsend(60);
           Udp_DataTSR.VPMSKACKTx = SET_HIGH;
        }

       if (Udp_DataTSR.VPMSKACKTx) {
           Udp_DataTSR.VPMSKACKTx = SET_LOW;
           REQUEST_CAN_PKT(6);
              }

       if (Udp_DataTSR.VPMDATAINTTX) {
           Udp_DataTSR.VPMDATAINTTX = SET_LOW;
             REQUEST_CAN_PKT(7);
           }

       if (Udp_DataTSR.DATAINTTX) {
           Tx_ACK_MSG();
           Udp_DataTSR.DATAINTTX = SET_LOW;
           memcpy(TempDataBuf,TX_ACK_MSG.ACK_TSRMSG_TX,26);
           udpsend(26);
           Udp_DataTSR.VPMACKMSHTX = SET_HIGH;
        }
    }
/* USER CODE END */

    //return 0;
}


/* USER CODE BEGIN (4) */

void rtiNotification(uint32 notification)
{

    if(notification == rtiNOTIFICATION_COMPARE0)
    {
        if(CAN0_INFO.u8STDTimeout >TIMEOUTEVENT){

            CAN0_INFO.u8STDTimeout = CAN0_INFO.u8STDTimeout -1u;

        }
    }
}

int32_t sci_printf(const char* format, ...)
{
    int length = -1;
    va_list argList;
    va_start(argList, format);
    length = sci_vprintf(format, argList);
    va_end(argList);

    return length;
}

int32_t sci_vprintf(const char* format, va_list argList)
{
    char str[MAX_BUFFER_LEN];
    int length = -1;

    length = vsnprintf(str, sizeof(str), format, argList);

    if(length > 0) {
        if(length > sizeof(str)) {
            length = sizeof(str);
        }
        sciDisplayText(UART, (uint8_t*)str, length);
    }

    return length;
}

void inline wait_forever() {
    while (1) ;
}
/* USER CODE END */
