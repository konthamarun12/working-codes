/*
 * can_Comm.c
 *
 *  Created on: 30-Nov-2024
 *      Author: Admin
 */

#include "sys_common.h"
#include "gio.h"
#include "lwipopts.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "string.h"
#include "time.h"
#include <stdio.h>
#include "can_Comm.h"
#include "can.h"
#include "pdiConn.h"
#include "vpm_tsrms.h"
#include "tsrms.h"
#include "gio.h"


uint8 u8Hour;
uint8 u8Minute;
uint8 u8Second;
uint8 u8Date;
uint8 u8Month;
uint8 u8Year;

uint32_t chekSum;

uint8 GPSTime[100] = {0};
uint8 TSRData[100] = {0};
uint8 ucDataCan1[8];
uint8 DataCan[8];
uint8 ucDataCan[8];

uint8 CAN_SENDDATA[8] = {0};

struct CANCOMM1 CAN1_Info;
struct HealthMSG HEALTH_MSG;

struct can_info_t CAN0_INFO;

struct VPM_INFO VPM_Info;

/*..........GPS DATE TIME..........*/
void perform_gps_time (void);
void processCanTimeData(void);
void processCanVPMData(void);

void ReadDipSwitcheAdd(void);
void ReadDipSwitchConfig(void);
void ReadSlotDetected(void);
static uint32_t Send_MSG_ID(uint8_t u8CANMsgObj, uint8_t u8TxBit, uint8_t u8IdentifierType, uint32_t u32MSGAdd);



void sendCANVPM(uint8_t CANID);
void wait(uint32_t u32time);

void HEALTH_MESSAGE();
void REQUEST_CAN_PKT(uint8 msgID);
void SENDVPMDATAFORMAT(uint16_t msgType, uint8 PktLength, uint8 *buff, uint8 msgID);

void wait(uint32_t u32time)
{
    uint32_t u32Time = 1u *u32time;
    while(u32Time--){

    }
}

void canMessageNotification(canBASE_t *node, uint32 messageBox)
{
    uint8_t u8CANIdentifier = (uint8_t)SET_LOW;
    uint32_t u32RxID = (uint32_t)SET_LOW;

    uint8_t u8CANIdentifier3 = (uint8_t)SET_LOW;
    uint32_t u32RxID3 = (uint32_t)SET_LOW;

    uint8_t u8CANIdentifier4 = (uint8_t)SET_LOW;
    uint32_t u32RxID4 = (uint32_t)SET_LOW;

    if(node==canREG1)
    {
        if(messageBox==canMESSAGE_BOX5)
        {
            CAN1_Info.CAN_MsgCount++;
            u32RxID = canGetID(canREG1,canMESSAGE_BOX5);
            canGetData(canREG1,canMESSAGE_BOX5,ucDataCan1);
            u8CANIdentifier = ((uint8_t)(u32RxID & 0x000ffu));
            processCanTimeData();

        }else if(messageBox==canMESSAGE_BOX3)
        {
            u32RxID3 = canGetID(canREG1,canMESSAGE_BOX3);
            canGetData(canREG1,canMESSAGE_BOX3,DataCan);
            u8CANIdentifier3 = ((uint8_t)(u32RxID3 & 0x000ffu));
            processCanVPMData();

        }
        else if(messageBox==canMESSAGE_BOX1)
            {
                u32RxID4 = canGetID(canREG1,canMESSAGE_BOX1);
                canGetData(canREG1,canMESSAGE_BOX1,ucDataCan);
                u8CANIdentifier4 = ((uint8_t)(u32RxID4 & 0x000ffu));
                processCanTSRData(ucDataCan);

            }else{

        }
    }
    else{

           }

}

void processCanTimeData(void)
{
    memcpy(GPSTime,ucDataCan1,8);
}

void perform_gps_time (void)
{
    u8Hour = GPSTime[0];
    u8Minute = GPSTime[1];
    u8Second = GPSTime[2];
    u8Date = GPSTime[3];
    u8Month = GPSTime[4];
    u8Year = (GPSTime[5] << 0x8u) | (GPSTime[6] << 0x0u);
    //u8Year = u8Year - 2000u;
}

void processCanVPMData(void)
{
    VPM_Info.VIC1AActive = SET_LOW;
    VPM_Info.VIC2AActive = SET_LOW;
    memcpy(TSRData,DataCan,8);

    uint8_t msgType = TSRData[0];
    uint8_t dipSwitchNO = TSRData[1];
    uint8_t VIC1AResult = TSRData[2];
    uint8_t VIC2AResult  = TSRData[3];

    if(msgType == msgTypeCntrlPkt)
    {
            if((VIC1AResult == ActiveChannel) && (VIC2AResult == HostStanBy) && (dipSwitchNO == HEALTH_MSG.DipSwitchConfg))
            {
                VPM_Info.VIC1AActive = SET_HIGH;
                VPM_Info.VIC2AActive = SET_LOW;

            }else if((VIC2AResult == ActiveChannel) && (VIC1AResult == HostStanBy) && (dipSwitchNO == HEALTH_MSG.DipSwitchConfg)){
                VPM_Info.VIC2AActive = SET_HIGH;
                VPM_Info.VIC1AActive = SET_LOW;
            }else{
                VPM_Info.VIC1AActive = SET_LOW;
                VPM_Info.VIC2AActive = SET_LOW;
            }
    }else{

    }

}

void HEALTH_MESSAGE(){

    uint8 INFO_MSG_TYPE = 0xAA;
    HEALTH_MSG.SlotDet = Slot;
    HEALTH_MSG.TSRMS_HSts = SET_HIGH;

    CAN_SENDDATA[0] = INFO_MSG_TYPE;
    CAN_SENDDATA[1] = HEALTH_MSG.DipSwitchAdd;
    CAN_SENDDATA[2] = HEALTH_MSG.DipSwitchConfg;
    CAN_SENDDATA[3] = HEALTH_MSG.TSRMS_HSts;
    CAN_SENDDATA[4] = chekSum>>24u;
    CAN_SENDDATA[5] = chekSum>>16u;
    CAN_SENDDATA[6] = chekSum>>8u;
    CAN_SENDDATA[7] = chekSum>>0u;
    sendCANVPM(1);
}


void sendCANVPM(uint8_t CANID){

    uint16_t address = (uint32_t)SET_LOW;
    uint32_t u32msgarbVal = (uint32_t)SET_LOW;

    address = (canIDVIC + HEALTH_MSG.DipSwitchAdd *256) + CANID ;

    u32msgarbVal = Send_MSG_ID(canMESSAGE_BOX4, CANMSGTYPETX, CANIDEXTENDED,address);

    canUpdateID(canREG1, canMESSAGE_BOX4,u32msgarbVal);
    canTransmit(canREG1, canMESSAGE_BOX4,CAN_SENDDATA);

    wait(100000u);
    while(!canIsTxMessagePending(canREG1,canMESSAGE_BOX4))
    {
        if(canGetLastError(canREG1))
        {
            break;

        }
    }
}

static uint32_t Send_MSG_ID(uint8_t u8CANMsgObj, uint8_t u8TxBit, uint8_t u8IdentifierType, uint32_t u32MSGAdd)
{
    uint32_t u32MSGID = 0U;

     if(u8IdentifierType == CANIDEXTENDED)
     {
         u32MSGID = ((((u8IdentifierType & 0x01) << 30u) | ((u8TxBit & 0x01u) << 29u) | (u32MSGAdd & 0x1FFFFFFFu)) & 0x7FFFFFFFu);
     }
     else
     {
         u32MSGID = 0U;
     }

     return u32MSGID;
}

void ReadDipSwitcheAdd(void){
   uint8 dipAdd = (gioGetPort(gioPORTB) >> 4u);
   HEALTH_MSG.DipSwitchAdd = dipAdd;
}

void ReadDipSwitchConfig(void){
    uint8 dipAdd = gioGetPort(gioPORTA);
    uint8 dipConfg = dipAdd & 0x0F;
    HEALTH_MSG.DipSwitchConfg = dipConfg;
}

void ReadSlotDetected(void){

}

void SENDVPMDATAFORMAT(uint16_t msgType, uint8 PktLength, uint8 *buff, uint8 msgID)
{
    uint8 pktSize = 8u;
    uint8 INFO_MSG_TYPE = 0xAB;

    uint8 tltCANPkt = (PktLength + pktSize - 1)/pktSize;

    uint8 index = 0u;
    uint8 indexPkt = 0u;

    for(index = 0U; index < tltCANPkt; index++)
    {
        CAN_SENDDATA[0] = INFO_MSG_TYPE; /*INFO PACKET*/
        CAN_SENDDATA[1] = tltCANPkt;
        CAN_SENDDATA[2] = msgType>>8u;
        CAN_SENDDATA[3] = msgType>>0u;
        CAN_SENDDATA[4] = PktLength;
        CAN_SENDDATA[5] = index + 1U; /*Current Pkt*/
        CAN_SENDDATA[6] = 0U;
        CAN_SENDDATA[7] = 0U;
        sendCANVPM(msgID);
       /* wait(100000u);*/

        CAN_SENDDATA[0] = 0u; CAN_SENDDATA[1] = 0u; CAN_SENDDATA[2] = 0u; CAN_SENDDATA[3] = 0u;
        CAN_SENDDATA[4] = 0u; CAN_SENDDATA[5] = 0u; CAN_SENDDATA[6] = 0u; CAN_SENDDATA[7] = 0u;

        for(indexPkt = 0U; indexPkt < pktSize; indexPkt++)  /*DATA PACKET*/
        {
            CAN_SENDDATA[indexPkt] = buff[indexPkt + index * pktSize];
        }
        sendCANVPM(msgID);
        /*wait(100000u);*/
    }
}

void REQUEST_CAN_PKT(uint8 msgID){

    switch(msgID)
    {
    case 2:  /*Commond PDI Message*/
    {
        uint8 Total_LENGTH_OFPKT = 0x0C;
        uint16_t CMDPDI_VER_MSGTYPE= 0x0201;
        SENDVPMDATAFORMAT(CMDPDI_VER_MSGTYPE,Total_LENGTH_OFPKT,PDIRxPacket,msgID);
        break;
    }
    case 3:  /*PDI Version ACK*/
    {
        uint8 Total_LENGTH_OFPKT = 0x11;
        uint16_t ACKPDI_VER_MSGTYPE= 0x0202;
        SENDVPMDATAFORMAT(ACKPDI_VER_MSGTYPE,Total_LENGTH_OFPKT,PDIACKTxPacket,msgID);
        break;
    }
    case 4: /*ALL TSR INFO*/
    {
        uint8 Total_TSRLENGTH_OFPKT = 0x3C;
        uint16_t TSR_MSG_MSGTYPE= 0x0203;
        SENDVPMDATAFORMAT(TSR_MSG_MSGTYPE,Total_TSRLENGTH_OFPKT,gRxPacket,msgID);
        break;
    }
    case 5: /*GET TSR MSG*/
    {
        uint8 Total_GETTSRLENGTH_OFPKT = 0x0E;
        uint16_t GETTSR_MSG_MSGTYPE= 0x0204;
        SENDVPMDATAFORMAT(GETTSR_MSG_MSGTYPE,Total_GETTSRLENGTH_OFPKT,GetTSRRxPacket,msgID);
        break;
    }
    case 6: /*SK ACK GET TSR MSG*/
    {
        uint8 Total_TSRLENGTH_OFPKT = 0x3C;
        uint16_t SKACKTSR_MSG_MSGTYPE= 0x0205;
        SENDVPMDATAFORMAT(SKACKTSR_MSG_MSGTYPE,Total_TSRLENGTH_OFPKT,SKTSRACKTxPacket,msgID);
        break;
    }
    case 7: /*DATA INT TSR MSG*/
    {
        uint8 Total_GETTSRLENGTH_OFPKT = 0x0E;
        uint16_t DATAINTTSR_MSG_MSGTYPE= 0x0206;
        SENDVPMDATAFORMAT(DATAINTTSR_MSG_MSGTYPE,Total_GETTSRLENGTH_OFPKT,DATAIntRxPacket,msgID);
        break;
    }

    case 8: /*ACKTSR MSG*/
    {
        uint8 Total_GETTSRLENGTH_OFPKT = 0x1A;
        uint16_t DATAINTTSR_MSG_MSGTYPE= 0x0207;
        SENDVPMDATAFORMAT(DATAINTTSR_MSG_MSGTYPE,Total_GETTSRLENGTH_OFPKT,ACKTxPacket,msgID);
        break;
    }

   }
}


