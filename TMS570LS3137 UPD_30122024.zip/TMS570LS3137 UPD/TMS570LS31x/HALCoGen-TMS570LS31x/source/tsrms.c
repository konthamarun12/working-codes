/*
 * tsrms.c
 *
 *  Created on: 22-Nov-2024
 *      Author: Admin
 */

#include "sys_common.h"

/* USER CODE BEGIN (1) */
#include "gio.h"
#include "lwipopts.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "tsrms.h"
#include "string.h"
#include "time.h"
#include <stdio.h>
#include "mac_cal.h"
#include "can_Comm.h"
#include "pdiConn.h"


#define SK_ACK_GETMSGLNGT (0x003C)

uint8 u32seqCnt        = 0U;
uint32 FramNO        = 0U;
uint64 u32DateTime =0U;
//extern uint8 u8udpTxBuff[1024];
uint8 u8TempBuf1[1024] = {0};


//uint8 u8TempBuf[1024] = {0};
//uint8 u8udpRxBuff[1024] = {0};
//uint8 u8udpTxBuff[1024] = {0};
//struct MAC_CLCLTN mac;

struct ALLTSRINFO ALLTSR;
struct ALLTSRINFO SK_TSRACK_Tx;

struct GET_TSRINFO GET_TSRMSG;

struct DATA_INTITSRMSG DATA_INTMSG;
struct DATA_INTITSRMSG TX_ACK_MSG;

uint8 gRxPacket[1023] = {0};
uint8 GetTSRRxPacket[1023] = {0};
uint8 DATAIntRxPacket[1023] = {0};
uint8 SKTSRACKTxPacket[1023] = {0};
uint8 ACKTxPacket[1023] = {0};



//extern uint8 TSRRxBuff[1024];

struct UDP_TSRDATA Udp_DataTSR;

void process_TSrRxData(uint8_t* pRxData,  uint32 length, uint16 u16msgType);

void Rx_AllTSR_MSG(void);
void Rx_GETTSR_MSG(void);
void Rx_DATAINT_MSG(void);

void Tx_SKAVACH_GET_ACK(void);
void Tx_ACK_MSG(void);
void SquenceCnt(void);
void frameNumberCalculation();


//void udpsend(uint16 u16Len);

volatile uint8 u8State;

void process_TSrRxData(uint8_t* pRxData, uint32 length, uint16 u16msgType)
{
    uint8 u8macy_code[4] = { 0 };

    switch(u16msgType){

    case ALL_TSR_INFO:
    {
        uint32_t receivedMAC = 0U;
        uint32_t calculatedMAC = 0U;
        uint8_t dataWithoutMAC[1024] = { 0 };
        uint32 dataLength = length - 4;

        u8macy_code[3] = (uint8)TSRRxBuff[length - 1U];
        u8macy_code[2] = (uint8)TSRRxBuff[length - 2U];
        u8macy_code[1] = (uint8)TSRRxBuff[length - 3U];
        u8macy_code[0] = (uint8)TSRRxBuff[length - 4U];


        receivedMAC = (uint32_t)(u8macy_code[0] << 24) |
                         (uint32_t)(u8macy_code[1] << 16) |
                         (uint32_t)(u8macy_code[2] << 8) |
                         (uint32_t)(u8macy_code[3]);

        memcpy(dataWithoutMAC, TSRRxBuff, dataLength);

        calculatedMAC = mac_calulate(dataWithoutMAC, dataLength);

        if (receivedMAC != calculatedMAC) {
                /* Indicate failure */

              }else{

                memcpy(gRxPacket, TSRRxBuff, length);
                       Udp_DataTSR.TSRACKRX = SET_HIGH;
                       Udp_DataTSR.VPMTSRTX = SET_HIGH;
                       Rx_AllTSR_MSG();
            }
        break;
    }
    case GET_TSR_INFOMSG:
    {
        memcpy(GetTSRRxPacket, TSRRxBuff, length);
        Udp_DataTSR.GETTSRACKTX = SET_HIGH;
        Udp_DataTSR.VPMGETTSRTX = SET_HIGH;
        Rx_GETTSR_MSG();
        break;
    }
    case TSRINTTEST:
    {
        memcpy(DATAIntRxPacket, TSRRxBuff, length);
        Udp_DataTSR.DATAINTTX = SET_HIGH;
        Udp_DataTSR.VPMDATAINTTX = SET_HIGH;
        Rx_DATAINT_MSG();
        break;
    }
    default:
    {

    }
    }
}

void Rx_AllTSR_MSG(void){

    ALLTSR.u8protocolType = (gRxPacket[0] << 0U);
    ALLTSR.u16MsgType  = (gRxPacket[2] | (gRxPacket[1] << 8U));
    ALLTSR.u16SendetID = (gRxPacket[4] | (gRxPacket[3] << 8U));
    ALLTSR.u1ReceID   = (gRxPacket[6] | (gRxPacket[5] << 8U));
    ALLTSR.u16MsgLen = (gRxPacket[8] | (gRxPacket[7] << 8U));
    ALLTSR.u32Framenum = (gRxPacket[11] | (gRxPacket[10] << 8U) | (gRxPacket[9] << 16U));
    ALLTSR.u16TAN =   (gRxPacket[13] | (gRxPacket[12] << 8U));
    ALLTSR.u8TSRactiveYear = (gRxPacket[14]);
    ALLTSR.u8TSRactiveMonth = (gRxPacket[15]);
    ALLTSR.u8TSRactiveDate =  (gRxPacket[16]);
    ALLTSR.u8TSRactiveHours = (gRxPacket[17]);
    ALLTSR.u8TSRactiveMinets = (gRxPacket[18]);
    ALLTSR.u8TSRactiveSeconds =  (gRxPacket[19]);
    ALLTSR.u8TSRcount = (gRxPacket[20]);
    ALLTSR.u8TSRidentity = (gRxPacket[21]);
    ALLTSR.u8TSRtype = (gRxPacket[22]);
    ALLTSR.u32Active_TSRstartDate = (gRxPacket[25] | (gRxPacket[24] << 8U) | (gRxPacket[23] << 16U));
    ALLTSR.u32Active_TSRstartTime = (gRxPacket[28] | (gRxPacket[27] << 8U) | (gRxPacket[26] << 16U));
    ALLTSR.u32Actice_TSRendDate = (gRxPacket[31] | (gRxPacket[30] << 8U) | (gRxPacket[29] << 16U));
    ALLTSR.u32Active_TSRendTime = (gRxPacket[34] | (gRxPacket[33] << 8U) | (gRxPacket[32] << 16U));
    ALLTSR.u16TSRRoute1ID = (gRxPacket[36] | (gRxPacket[35] << 8U));
    ALLTSR.u16TSRRoute2ID = (gRxPacket[38] | (gRxPacket[37] << 8U));
    ALLTSR.u16TSRRoute3ID = (gRxPacket[40] | (gRxPacket[39] << 8U));
    ALLTSR.u16TSRRoute4ID = (gRxPacket[42] | (gRxPacket[41] << 8U));
    ALLTSR.u16TSRRoute5ID = (gRxPacket[44] | (gRxPacket[43] << 8U));
    ALLTSR.u8TSRDire =  (gRxPacket[45]);
    ALLTSR.u16TSRstartDist= (gRxPacket[47] | (gRxPacket[46] << 8U));
    ALLTSR.u16TSRLength = (gRxPacket[49] | (gRxPacket[48] << 8U));
    ALLTSR.u8TrainClass =  (gRxPacket[50]);
    ALLTSR.u8UniversalTSR =  (gRxPacket[51]);
    ALLTSR.u8ClassAtrainTSR =  (gRxPacket[52]);
    ALLTSR.u8ClassBtrainTSR =  (gRxPacket[53]);
    ALLTSR.u8ClassCtrainTSR =  (gRxPacket[54]);
    ALLTSR.u8whistle =  (gRxPacket[55]);

    if(ALLTSR.u16MsgType == ALL_TSR_INFO){

        if(ALLTSR.u16SendetID == RECEIVERID && ALLTSR.u1ReceID== SENDERID){
            Udp_DataTSR.TSRACKRX = SET_HIGH;
            Udp_DataTSR.VPMTSRTX = SET_HIGH;

           // Tx_ACK_MSG();
        }else{

        }

    }else{

    }
}

void Rx_GETTSR_MSG(void){

    GET_TSRMSG.u8protocolType = (TSRRxBuff[0] << 0U);
    GET_TSRMSG.u16MsgType =  (TSRRxBuff[2] | (TSRRxBuff[1] << 8U));
    GET_TSRMSG.u16SendetID = (TSRRxBuff[4] | (TSRRxBuff[3] << 8U));
    GET_TSRMSG.u1ReceID = (TSRRxBuff[6] | (TSRRxBuff[5] << 8U));
    GET_TSRMSG.u16MsgLen= (TSRRxBuff[8] | (TSRRxBuff[7] << 8U));
    GET_TSRMSG.u32Framenum = (TSRRxBuff[11] | (TSRRxBuff[10] << 8U) | (TSRRxBuff[9] << 16U));
    GET_TSRMSG.u16TAN = (TSRRxBuff[13] | (TSRRxBuff[12] << 8U));

    if(GET_TSRMSG.u16MsgType == GET_TSR_INFOMSG){

        if(GET_TSRMSG.u16SendetID == RECEIVERID && GET_TSRMSG.u1ReceID== SENDERID){

            Udp_DataTSR.GETTSRACKTX = SET_HIGH;
            Udp_DataTSR.VPMGETTSRTX = SET_HIGH;

        }else{

        }

    }else{

    }
}

void Rx_DATAINT_MSG(void){

    DATA_INTMSG.u8protocolType = (TSRRxBuff[0] << 0U);
    DATA_INTMSG.u16MsgType =  (TSRRxBuff[2] | (TSRRxBuff[1] << 8U));
    DATA_INTMSG.u16SendetID = (TSRRxBuff[4] | (TSRRxBuff[3] << 8U));
    DATA_INTMSG.u1ReceID = (TSRRxBuff[6] | (TSRRxBuff[5] << 8U));
    DATA_INTMSG.u16MsgLen= (TSRRxBuff[8] | (TSRRxBuff[7] << 8U));
    DATA_INTMSG.u32Framenum = (TSRRxBuff[11] | (TSRRxBuff[10] << 8U) | (TSRRxBuff[9] << 16U));
    DATA_INTMSG.u16TAN = (TSRRxBuff[13] | (TSRRxBuff[12] << 8U));

    if(GET_TSRMSG.u16MsgType == TSRINTTEST){

        if(GET_TSRMSG.u16SendetID == RECEIVERID && GET_TSRMSG.u1ReceID== SENDERID){
            Udp_DataTSR.DATAINTTX = SET_HIGH;
            Udp_DataTSR.VPMDATAINTTX = SET_HIGH;

        }else{

        }

    }else{

    }
}

void Tx_SKAVACH_GET_ACK(void){

    uint8_t fillSKACK_size = 0;

    /*....Prototype....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (char)(((TSR_VERTYPE) >> (0U)) & (0xFFU));

        /*....Message Type....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (char)(((SK_Ack_TSR_DATAMSG) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (char)(((SK_Ack_TSR_DATAMSG) >> (0U)) & (0xFFU));

        /*....Sender ID....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((SENDERID) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((SENDERID) >> (0U)) & (0xFFU));

        /*....Receiver ID....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((RECEIVERID) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((RECEIVERID) >> (0U)) & (0xFFU));

        /*....Message Length....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((SK_ACK_GETMSGLNGT) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((SK_ACK_GETMSGLNGT) >> (0U)) & (0xFFU));

        /*....Frame Number....*/
    frameNumberCalculation();
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((FramNO) >> (16U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((FramNO) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((FramNO) >> (0U)) & (0xFFU));

        /*...TAN....*/
    SquenceCnt();
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((u32seqCnt) >> (8U)) & (0xFFU));
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((u32seqCnt) >> (0U)) & (0xFFU));

        /*...Activation Date Time....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[14];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[15];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[16];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[17];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[18];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[19];

        /*...TSR Count....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[20];

        /*...TSR ID....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[21];

    /*...TSR Type....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[22];

    /*....Start Date....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[23];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[24];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[25];

    /*....Start Time....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[26];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[27];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[28];

    /*....End Date....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[29];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[30];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[31];

     /*....End DTime....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[32];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[33];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[34];

     /*....Route 1....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[35];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[36];

     /*....Route 2....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[37];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[38];

     /*....Route 3....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[39];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[40];

      /*....Route 4....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[41];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[42];

       /*....Route 5....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[43];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[44];

      /*...TSR Direction....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[45];

       /*...TSR start Distance....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[46];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[47];

      /*...TSR Length....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[48];
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[49];

      /*...Applicabel class...*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[50];

      /*...Universal Speed....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[51];

     /*...Class A....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[52];

      /*...Class B....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[53];

       /*...Class C....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[54];

        /*...Whistle....*/
    SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = gRxPacket[55];

        /*...MAC....*/

    uint32_t padded_size = (fillSKACK_size <= 32) ? 32 : 64;

              // Create a padded buffer and fill it
              uint8 padded_temp[64] = {0}; // Initialize with zeros
              memcpy(padded_temp,SK_TSRACK_Tx.SKAVACH_ACK_MSG, fillSKACK_size);

         uint32 caltedMAC= mac_calulate(padded_temp, padded_size);

         SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((caltedMAC) >> (24U)) & (0xFFU));
         SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((caltedMAC) >> (16U)) & (0xFFU));
         SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((caltedMAC) >> (8U)) & (0xFFU));
         SK_TSRACK_Tx.SKAVACH_ACK_MSG[fillSKACK_size++] = (uint8)(((caltedMAC) >> (0U)) & (0xFFU));

         memcpy(SKTSRACKTxPacket, SK_TSRACK_Tx.SKAVACH_ACK_MSG, fillSKACK_size);


}

void Tx_ACK_MSG(void){

    uint8_t fillACK_size = 0;
    /*....Prototype....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((TSR_VERTYPE) >> (0U)) & (0xFFU));

    /*....Message Length....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((ACKMSG) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((ACKMSG) >> (0U)) & (0xFFU));

    /*....Sender ID....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((SENDERID) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((SENDERID) >> (0U)) & (0xFFU));

    /*....Receiver ID....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((RECEIVERID) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((RECEIVERID) >> (0U)) & (0xFFU));

    /*....Message Length....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((ACK_MSG_LENGTH) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((ACK_MSG_LENGTH) >> (0U)) & (0xFFU));

    frameNumberCalculation();

    /*....Frame Number....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((FramNO) >> (16U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((FramNO) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (char)(((FramNO) >> (0U)) & (0xFFU));

    SquenceCnt();

    /*...TAN....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((u32seqCnt) >> (8U)) & (0xFFU));
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((u32seqCnt) >> (0U)) & (0xFFU));


    /*...Activation Date Time....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[14];
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[15];
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[16];
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[17];
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[18];
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[19];

    /*...TSR Count....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[20];

    /*...TSR ID....*/
    TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = gRxPacket[21];

    /*...MAC....*/

    uint32_t padded_size = (fillACK_size <= 32) ? 32 : 64;

           // Create a padded buffer and fill it
           uint8 padded_temp[64] = {0}; // Initialize with zeros
           memcpy(padded_temp, TX_ACK_MSG.ACK_TSRMSG_TX, fillACK_size);

      uint32 caltedMAC= mac_calulate(padded_temp, padded_size);

      TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((caltedMAC) >> (24U)) & (0xFFU));
      TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((caltedMAC) >> (16U)) & (0xFFU));
      TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((caltedMAC) >> (8U)) & (0xFFU));
      TX_ACK_MSG.ACK_TSRMSG_TX[fillACK_size++] = (uint8)(((caltedMAC) >> (0U)) & (0xFFU));

      memcpy(ACKTxPacket, TX_ACK_MSG.ACK_TSRMSG_TX, fillACK_size);
}

void frameNumberCalculation() /* Calculating the frame number based on 24 hours */
{
    uint32 FrameNumber = 0;

  /*Calculate the frame number*/
        FrameNumber = (((u8Hour * 3600) + (u8Minute * 60) + u8Second) + 1);

//        char hexString[10]; // Buffer to store the hexadecimal string
//        sprintf(hexString, "%03X", FrameNumber);

        FramNO = FrameNumber;
}

void SquenceCnt(void)
{
    if(u32seqCnt < 4294967295U)
    {
        u32seqCnt = u32seqCnt + 1U;
    }
    else
    {
        u32seqCnt = SET_LOW;
    }
}


