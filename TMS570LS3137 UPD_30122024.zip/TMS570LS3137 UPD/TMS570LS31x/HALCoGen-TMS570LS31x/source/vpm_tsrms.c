/*
 * vpm_tsrms.c
 *
 *  Created on: 15-Dec-2024
 *      Author: Admin
 */

#include "vpm_tsrms.h"
#include "sys_common.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "string.h"
#include "time.h"
#include <stdio.h>
#include "can.h"
#include "gio.h"

/*Buffers*/
uint8_t tempBuffer[BLOCK_SIZE]; /* Temporary buffer for one 60-byte block*/
uint8_t mainBuffer[MAIN_BUFFER_SIZE]; /*Main buffer for all blocks*/
uint8_t tempBufferStore[BLOCK_SIZE];
uint8_t bufferStatus[MAX_SEGMENTS];

/* Indices */
uint16_t tempIndex = 0;    // Index for tempBuffer
uint16_t mainIndex = 0;    // Index for mainBuffer
uint16_t blockCount = 0;   // Number of blocks stored in mainBuffer

uint8 TSRRxData[8];
uint8 ucDataCan[8];
uint8 emptyBuff = 0;

struct TSR tsrBlocks[MAX_BLOCKS];

void processCanTSRData(uint8_t *packet);
void storeInMainBuffer(void);
void initializeBufferStatus();
uint8_t findEmptyBufferInMainBuffer();
void readTSRMSData(uint8_t segmentIndex);

void initializeBufferStatus() {
    memset(bufferStatus, 0, sizeof(bufferStatus));
}

void processCanTSRData(uint8_t *packet) /*Processing Received Data From VIC*/
{
    uint8_t i;
    memcpy(TSRRxData,packet,8);

    if(TSRRxData[0] == INFOMSGTYPE){

    }else{

    for (i = 0; i < PACKET_SIZE; i++) {
            tempBuffer[tempIndex + i] = TSRRxData[i];
        }

        /*Update the temporary buffer index*/
        tempIndex += PACKET_SIZE;

        /*Check if the temporary buffer is full (60 bytes)*/
        if (tempIndex >= BLOCK_SIZE) {
            storeInMainBuffer();
            tempIndex = 0;
        }

     }
}

void storeInMainBuffer(void)
{

    uint8_t emptyIndex = findEmptyBufferInMainBuffer();

        if (emptyIndex == -1) {
            /* No empty segment available */
        }
        else
        {
             uint8_t startIndex = emptyIndex * SEGMENT_SIZE; /*Calculate the start index for the segment in mainBuffer*/

             memcpy(&mainBuffer[startIndex], tempBuffer, SEGMENT_SIZE); /* Copy the data to the mainBuffer */

             bufferStatus[emptyIndex] = FILLED; /*Mark Buffer as copied*/
        }
        readTSRMSData(emptyIndex);
}

uint8_t findEmptyBufferInMainBuffer()
{
    uint8_t emptyBuff;
    for (emptyBuff = 0; emptyBuff < MAX_SEGMENTS; emptyBuff++) {
           if (bufferStatus[emptyBuff] != FILLED) {
               return emptyBuff; /* Return the index of the first empty buffer */
           }
       }
    return -1;
}

void readTSRMSData(uint8_t segmentIndex)
{
    if (segmentIndex < MAX_SEGMENTS && bufferStatus[segmentIndex] == FILLED) {

        uint8_t *tempBufferStruct = &mainBuffer[segmentIndex * SEGMENT_SIZE];

            uint8 blockCount = segmentIndex;

            tsrBlocks[blockCount].TSR_ID = tempBufferStruct[21];
            tsrBlocks[blockCount].TSR_STRTDTE = (tempBufferStruct[25] | (tempBufferStruct[24] << 8U) | (tempBufferStruct[23] << 16U));
            tsrBlocks[blockCount].TSR_STRTTIME = (tempBufferStruct[28] | (tempBufferStruct[27] << 8U) | (tempBufferStruct[26] << 16U));
            tsrBlocks[blockCount].TSR_ENDDATE = (tempBufferStruct[31] | (tempBufferStruct[30] << 8U) | (tempBufferStruct[29] << 16U));
            tsrBlocks[blockCount].TSR_ENDTIME = (tempBufferStruct[34] | (tempBufferStruct[33] << 8U) | (tempBufferStruct[32] << 16U));
            tsrBlocks[blockCount].TSR_ROUTE1 = (tempBufferStruct[36] | (tempBufferStruct[35] << 8U));
            tsrBlocks[blockCount].TSR_ROUTE2 = (tempBufferStruct[38] | (tempBufferStruct[37] << 8U));
            tsrBlocks[blockCount].TSR_ROUTE3 = (tempBufferStruct[40] | (tempBufferStruct[39] << 8U));
            tsrBlocks[blockCount].TSR_ROUTE4 = (tempBufferStruct[42] | (tempBufferStruct[41] << 8U));
            tsrBlocks[blockCount].TSR_ROUTE5 = (tempBufferStruct[44] | (tempBufferStruct[43] << 8U));
            tsrBlocks[blockCount].TSR_DIRECTION = tempBufferStruct[45];
            tsrBlocks[blockCount].TSR_SRTDSTROUTE = (tempBufferStruct[47] | (tempBufferStruct[46] << 8U));
            tsrBlocks[blockCount].TSR_LENGTH = (tempBufferStruct[49] | (tempBufferStruct[48] << 8U));
            tsrBlocks[blockCount].TSR_SPEDDCLS = tempBufferStruct[50];
            tsrBlocks[blockCount].TSR_SVALUEUNIVERSAL = tempBufferStruct[51];
            tsrBlocks[blockCount].TSR_SVALUECLASSA = tempBufferStruct[52];
            tsrBlocks[blockCount].TSR_SVALUECLASSB = tempBufferStruct[53];
            tsrBlocks[blockCount].TSR_SVALUECLASSC = tempBufferStruct[54];
            tsrBlocks[blockCount].TSR_WHISTLING = tempBufferStruct[55];

            bufferStatus[blockCount] = FILLED;
        }
}

