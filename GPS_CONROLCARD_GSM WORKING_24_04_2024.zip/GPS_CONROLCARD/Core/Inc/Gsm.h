/*
 * Gsm.h
 *
 *  Created on: Apr 6, 2024
 *      Author: konth
 */

#ifndef INC_GSM_H_
#define INC_GSM_H_





void GSM_Modem_Task(void);
#endif /* INC_GSM_H_ */
