/*
 * datasharing.h
 *
 *  Created on: Apr 16, 2024
 *      Author: Arun K
 */

#ifndef INC_DATASHARING_H_
#define INC_DATASHARING_H_


typedef struct {
	uint16_t pkt_start;           // 16 bits
	uint8_t pkt_type;             // 8 bits
	uint8_t pkt_length;           // 8 bits
	uint8_t date;                 // 8 bits
	uint8_t month;                // 8 bits
	uint8_t year;                 // 8 bits
	uint8_t hours;                // 8 bits
	uint8_t minutes;              // 8 bits
	uint8_t seconds;              // 8 bits

	uint32_t pkt_crc;             // 32 bits
} MCU2_RxDataPacket_t;

typedef struct {
	uint16_t pkt_start;           // 16 bits
	uint8_t pkt_type :4;         // 4 bits
	uint8_t pkt_length :7;       // 7 bits (assume other bits are not used)
	uint32_t source_loco_id :20; // 20 bits
	uint32_t abs_loco_loc :23;   // 23 bits
	uint16_t train_speed :9;     // 9 bits
	uint8_t movement_dir :2;     // 2 bits
	uint8_t loco_mode :4;        // 4 bits
	uint16_t last_rfid_tag :10;  // 10 bits
	uint8_t tag_dup :1;          // 1 bit
	uint8_t tag_link_info :3;    // 3 bits
	uint16_t tin :9;             // 9 bits
	uint8_t sig_ov :1;           // 1 bit
	uint8_t spare :2;            // 2 bits
	uint8_t loco_health_status :6; // 6 bits
	uint8_t padding_bits :3;     // 3 bits
	uint32_t pkt_crc;            // 32 bits
} Dnet_RxDataPacket_t;

typedef struct {
	uint16_t pkt_start;               // 16 bits
	uint8_t pkt_type;                 // 4 bits
	uint16_t pkt_length;              // 9 bits
	uint32_t source_loco_id;          // 20 bits
	uint32_t abs_loco_loc;            // 23 bits
	uint16_t train_speed;             // 9 bits
	uint8_t movement_dir;             // 2 bits
	uint8_t loco_mode;                // 4 bits
	uint16_t last_rfid_tag;           // 10 bits
	uint8_t tag_dup;                  // 1 bit
	uint8_t tag_link_info;            // 3 bits
	uint16_t tin;                     // 9 bits
	uint8_t sig_ov;                   // 1 bit
	uint8_t spare;                    // 2 bits
	uint8_t loco_health_status;       // 6 bits
	uint8_t akey1_at_memory_location_0[16]; // 128 bits
	uint8_t akey1_at_memory_location_1[16]; // 128 bits
	uint8_t padding_bits;             // 1 bit
	uint32_t pkt_crc;                 // 32 bits
} MCU2_TxDataPacket_t;

extern Dnet_RxDataPacket_t Dnet_RxDataPacket;
extern MCU2_TxDataPacket_t MCU2_TxDataPacket;
extern MCU2_RxDataPacket_t MCU2_RxDataPacket;
void write_bits(uint8_t *buffer, uint32_t *pos, uint32_t value, int num_bits);
uint32_t read_bits(const uint8_t *buffer, uint32_t *pos, int num_bits);
_Bool MCU2_vExtractRxDataPacket(uint8_t *buffer, MCU2_RxDataPacket_t *packet);
_Bool Dnet_vExtractRxDataPacket(const uint8_t *buffer, Dnet_RxDataPacket_t *packet);
void Frame_vMCU2TxDataPacket(MCU2_TxDataPacket_t *packet, uint8_t *buffer);
void MCU2_vProcessDatapacket(void);
void Dnet_vProcessDataPacket(void);
#endif /* INC_DATASHARING_H_ */
