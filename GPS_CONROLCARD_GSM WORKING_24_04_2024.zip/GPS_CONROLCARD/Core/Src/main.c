/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "kms.h"
#include "datasharing.h"
#include "crc32.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
#define TX_DATA_SIZE 9
#define RX_BUFFER_SIZE 256
/* USER CODE END PFP */
extern uint8_t ServerRxMessageBuff[2000];
/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t TX[5] = { 11, 22, 22, 22, 33 };
uint8_t RX_UART5[100];
uint8_t Rxdata[1000]; // ={11,22,22,22,33};

/* USER CODE END 0 */
extern uint8_t txflag;
extern volatile uint8_t timer7_flag;
extern volatile uint8_t timer6_flag;

uint8_t txData[TX_DATA_SIZE] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
uint8_t rxBuffer[RX_BUFFER_SIZE];
volatile uint32_t rxWriteIndex = 0;
volatile uint32_t rxReadIndex = 0;
extern uint32_t KMS_u32Otp;
extern uint8_t KMS_otpRecived;
volatile UART_State uartState = STATE_IDLE;

/**
 * @brief  The application entry point.
 * @retval int
 */

typedef struct {
	uint16_t start;              // Start of packet
	uint8_t pkt_type;            // Packet type
	uint8_t pkt_length;          // Packet length
	uint32_t source_loco_id;     // Locomotive ID
	uint32_t abs_loco_loc;       // Absolute locomotive location
	uint16_t train_speed;        // Train speed
	uint8_t movement_dir;        // Movement direction
	uint8_t loco_mode;           // Locomotive mode
	uint16_t last_rfid_tag;      // Last RFID tag
	uint8_t tag_dup;             // Tag duplicate
	uint8_t tag_link_info;       // Tag link information
	uint16_t tin;                // TIN
	uint8_t sig_ov;              // Signal override
	uint8_t spare;               // Spare bits
	uint8_t loco_health_status;  // Locomotive health status
	uint8_t padding;             // Padding bits
	uint32_t pkt_crc;            // Packet CRC
} TrainControlPacket;
TrainControlPacket myPacket;
uint32_t KMS_vDecodeOTP(uint8_t *data) {
	uint32_t OTP = 0;
	OTP = data[111]<<24|data[112]<<16|data[113]<<8|data[114];
	return OTP;

}

uint8_t decodeAndValidatePacket(const uint8_t *buffer, size_t bufferLength,
		TrainControlPacket *packet) {
	// Validate packet header
	if (buffer[0] != 0xB5 || buffer[1] != 0xD3 || buffer[2] != 0xE) {
		return false; // Header mismatch
	}

	// Calculate the length of the packet data, excluding header and CRC
	size_t packetDataLength = sizeof(TrainControlPacket);

	// Validate CRC
	uint32_t receivedCRC = *((uint32_t*) (buffer + 3 + packetDataLength)); // assuming CRC is right after the data
	if (!verifyCrc32(buffer + 3, packetDataLength)) {
		return false; // CRC mismatch
	}

	// If header and CRC are valid, copy the packet
	memcpy(packet, buffer + 3, packetDataLength);
	return true;
}
uint8_t poweron =1;
uint8_t Data_91buf[30];

int main(void) {
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART1_UART_Init();
	MX_RTC_Init();
	MX_USART3_UART_Init();
	//MX_TIM7_Init();
	MX_SPI2_Init();
	MX_UART5_Init();
//	MX_TIM6_Init();
	MX_USART2_UART_Init();

//	HAL_UART_Transmit(&huart5, txData, TX_DATA_SIZE, 100);
	initialize_GSM_packets();
//	KmsATCommand(GSM_packet, 14);
//	udp_send(GSM_packet, 18);
//	KmsATCommand(GSM_packet, 15);
//	KmsATCommand(GSM_packet, 1);
//	HAL_UART_Receive_IT(&huart1, GSM_RXBuf, 118);
	memset(MCU2_RXBuf, 0,14);
	HAL_UART_Receive_IT(&huart3, MCU2_RXBuf, 14);
	uint8_t otpFlag=1;

	while (poweron) {

		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
#if 1
		HAL_UART_Receive_IT(&huart3, MCU2_RXBuf, 14);
		//HAL_UART_Receive_IT(&huart5, MCU2_RXBuf, 14);

		MCU2_vProcessDatapacket();
		//Dnet_vProcessDataPacket();
		ProcessKms();
		if (RXpos1 == 1) {
			RXpos1 = 0;


			if (otpFlag==1)
			{
				otpFlag=0;
			uint8_t data[50];
			uint8_t data1[50];
			KMS_u32Otp = KMS_vDecodeOTP(ServerRxMessageBuff);
			memcpy(&data1[0], &ServerRxMessageBuff[17],20);
			memcpy(&KMS_IdentificationAcKPkt, &data1,sizeof(KMS_IdentificationAcKPkt_t));
			KMS_otpRecived = 1;
			Rxflag = 1;
			sprintf(data, "KMS_u32Otp %x", KMS_u32Otp);
			HAL_UART_Transmit(&huart2, data, 30, 100);
			}


		}

		if (KMS_otpRecived == 1) {
			HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
		}
#else
		HAL_StatusTypeDef status, dststus;
		HAL_Delay(20);
		status = HAL_UART_Transmit(&huart2, txData, TX_DATA_SIZE, 100);
		dststus =status;
#endif

	}

	while(!poweron)
	{
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
		HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
		HAL_UART_Receive_IT(&huart3, MCU2_RXBuf, 14);
	}
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI
			| RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
		Error_Handler();
	}
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) {
		Error_Handler();
	}
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
