//#include <stdint.h>
//#include <string.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <stdbool.h>
//#include "Gsm.h"
//#include "usart.h"
//extern UART_HandleTypeDef huart1;

//#define TRUE 1
//#define FALSE 0
//#define TERMINATE_OFF  	0U
//#define TERMINATE_ON		1U
//
//#define STILL_Process   2U
//extern USART1_TypeDef  	Usart1;
//uint32_t Gsm_CommResponseTimeOut;
//uint16_t  GsmCMD_state = 1;
//typedef enum
//{
//	AT_STARTUP=0,
//	AT_CMD=1,
//	ATE0_CMD,
//	AT_CMGF_CMD,
//	AT_CSCS_CMD,
//	SYS_SARTUP_MSG,
//	SMS_ALERT
//} CMD_IDS;
//char *GsmAT_cmd[20]= {
//												{""},
//												{"AT\r\n"},								/* Check Communication with Modem */
//												{"ATE0\r\n"},							/* Disable Echo 									*/
//												{"AT+CMGF=1\r\n"},				/* Set Text Mode  								*/
//												{"AT+CSCS=\"GSM\"\r\n"},	/* Configure the TE character set */
//												{""},
//											};
//uint8_t SendATCommand(char *StringCommand, bool Terminate, char *ResponseComm);
//
//
//uint8_t SendATCommand(char *StringCommand, bool Terminate, char *ResponseComm)
//{
//	bool ReturnVal;
//	static bool RpsCheckFlag = 0; // Response Flag
//
//	if(!RpsCheckFlag)
//	{
//		memset(Usart1.txBuff, 0x0000, sizeof(Usart1.txBuff));
//		memmove(Usart1.txBuff, StringCommand, strlen(StringCommand));
//		/* Transmite AT Command */
//		UART_TransmitIT(&huart1,(uint8_t *)Usart1.txBuff, strlen(Usart1.txBuff));
//
//		/* Send Terminate String */
//		if(Terminate)
//		{
//			UART_TransmitIT(&huart1,(uint8_t *)"\r\n", 2);
//		}
//		RpsCheckFlag = 1;
//		Gsm_CommResponseTimeOut = 30;
//		/* Check the Response Coomand */
//		if(ResponseComm == 0)
//		{
//			return TRUE;
//		}
//	}
//	else if((RpsCheckFlag && Usart1.pktRcvd) || (!Gsm_CommResponseTimeOut)) /* Wait For Command Response */
//	{
//		RpsCheckFlag = 0;
//		Usart1.pktRcvd = 0;
//		/* Verify the Response Coomand */
//		if(strstr(Usart1.rxBuff, ResponseComm))// || (!Gsm_CommResponseTimeOut))
//		{
//			//WLV_Appl_Test_RS485_SerialCommu();
//			memset(Usart1.rxBuff, 0x0000, sizeof(Usart1.rxBuff));
//			ReturnVal = TRUE;
//		}
//		else
//		{
//			ReturnVal = FALSE;
//		}
//		return ReturnVal;
//	}
//
//	return STILL_Process;
//}
//
//void GSM_Modem_Task(void)
//{
//	static uint8_t Gsm_Once_done;
//	static uint8_t StartUpTime_Load = 0;
//	uint8_t ReturnVal = 0;
//
//	switch(GsmCMD_state)
//	{
//		case AT_STARTUP:
//		{
//			if(!StartUpTime_Load)
//			{
//				StartUpTime_Load = 1;
//				Gsm_CommResponseTimeOut = 100; // 10sec time Load
//			}
//
//			if((Usart1.pktRcvd) || (!Gsm_CommResponseTimeOut))
//			{
//				Usart1.pktRcvd = 0;
//
//				if(strstr(Usart1.rxBuff, "MODEM:STARTUP"))
//				{
//					/* Nothing Do */
//				}
//				else if(strstr(Usart1.rxBuff, "+PBREADY"))
//				{
//					GsmCMD_state = AT_CMD;
//				}
//				else if(!Gsm_CommResponseTimeOut)
//				{
//					GsmCMD_state = AT_CMD;
//				}
//				else
//				{
//					/* Empty Condition */
//				}
//			}
//		}
//		break;
//
//		case AT_CMD:
//		{
//			ReturnVal = SendATCommand(GsmAT_cmd[AT_CMD], TERMINATE_OFF, "OK"); /* Check Communication with Modem   */
//
//			if(ReturnVal == TRUE)
//			{
//				GsmCMD_state = ATE0_CMD;
//			}
//			else if(ReturnVal == FALSE)
//			{
//				GsmCMD_state = AT_STARTUP;
//				Gsm_CommResponseTimeOut = 50; // 10sec time Load
//			}
//		}
//		break;
//
//		case ATE0_CMD:
//		{
//			/* Disable Echo  	*/
//			ReturnVal = SendATCommand(GsmAT_cmd[ATE0_CMD], TERMINATE_OFF, "OK");
//
//			if(ReturnVal == TRUE)
//			{
//				GsmCMD_state = AT_CMGF_CMD;
//			}
//			else if(ReturnVal == FALSE)
//			{
//				GsmCMD_state = AT_STARTUP;
//				Gsm_CommResponseTimeOut = 50; // 10sec time Load
//			}
//		}
//		break;
//
//		case AT_CMGF_CMD:
//		{
//			 /* Set Text Mode */
//			ReturnVal = SendATCommand(GsmAT_cmd[AT_CMGF_CMD], TERMINATE_OFF, "OK");
//
//			if(ReturnVal == TRUE)
//			{
//				GsmCMD_state = AT_CSCS_CMD;
//			}
//			else if(ReturnVal == FALSE)
//			{
//				GsmCMD_state = AT_STARTUP;
//				Gsm_CommResponseTimeOut = 50; // 10sec time Load
//			}
//		}
//		break;
//
//		case AT_CSCS_CMD:
//		{
//			/* Configure the TE character set  	*/
//			ReturnVal = SendATCommand(GsmAT_cmd[AT_CSCS_CMD], TERMINATE_OFF, "OK");
//
//			if(ReturnVal == TRUE)
//			{
//				GsmCMD_state = SYS_SARTUP_MSG;
//			}
//			else if(ReturnVal == FALSE)
//			{
//				GsmCMD_state = AT_STARTUP;
//				Gsm_CommResponseTimeOut = 50; // 10sec time Load
//			}
//		}
//		break;
//
//
//		break;
//
//
//		break;
//
//		default:
//			GsmCMD_state = AT_STARTUP;
//			break;
//	}
//}
//#define SERVER_IP "112.133.205.6"
//#define SERVER_PORT "54143"
//#define APN "Airtel"
//extern uint8_t  txflag;
//extern uint8_t  rxflag;
//typedef enum {
//    STATE_START,
//    STATE_WAIT_OK,
//    STATE_CHECK_SIM,
//    STATE_CHECK_SIGNAL,
//    STATE_CHECK_REGISTRATION,
//    STATE_SET_APN,
//    STATE_SETUP_TCP,
//    STATE_TCP_READY,
//    STATE_ERROR,
//    STATE_DONE
//} ConnectionState;
//
//// Global variables
//ConnectionState currentState = STATE_START;
//
//
//
//
//void send_at_command(const char* cmd) {
//	if(!txflag)
//	{
//
//		HAL_UART_Transmit_IT(&huart1, (uint8_t*)cmd, strlen(cmd));
//	}
//	else
//	{
//		HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
//	}
//   // HAL_UART_Transmit(&huart1, (uint8_t*)"\r", 1, 100); // Command termination
//}
//
//HAL_StatusTypeDef receive_response(char* buffer, uint32_t buffer_size, uint32_t timeout) {
//    memset(buffer, 0, buffer_size); // Clear buffer
//    return HAL_UART_Receive_IT(&huart1, (uint8_t*)buffer, buffer_size);
//}
//
//void UDP_connection_state_machine(void) {
//
//    HAL_StatusTypeDef status;
//
//    switch (currentState) {
//        case STATE_START:
//            send_at_command("AT\r");
//            if(!txflag)
//            {
//             	status = receive_response(data_buffer, 6, 1000);
//            	if(rxflag)
//            	{
//            		rxflag =0;
//            		currentState = STATE_WAIT_OK;
//            	}
//            }
//            break;
//
//        case STATE_WAIT_OK:
//
//
//				if (rxflag == 0 && strstr(data_buffer, "OK") != NULL) {
//					// Next state depends on previous state
//					if (strstr(data_buffer, "+CCID") != NULL) {
//						currentState = STATE_CHECK_SIGNAL;
//					} else {
//						currentState = STATE_CHECK_SIM;
//					}
//				} else {
//					currentState = STATE_ERROR;
//				}
//        	            break;
//
//        case STATE_CHECK_SIM:
//            send_at_command("AT+CCID");
//            currentState = STATE_WAIT_OK;
//            break;
//
//        case STATE_CHECK_SIGNAL:
//            send_at_command("AT+CSQ");
//            currentState = STATE_WAIT_OK;
//            break;
//
//        case STATE_CHECK_REGISTRATION:
//            send_at_command("AT+CREG?");
//            currentState = STATE_WAIT_OK;
//            break;
//
//        case STATE_SET_APN:
//            {
//                char cmd[50];
//                sprintf(cmd, "AT+CGDCONT=1,\"IP\",\"%s\"", APN);
//                send_at_command(cmd);
//                currentState = STATE_WAIT_OK;
//            }
//            break;
//
//        case STATE_SETUP_TCP:
//            {
//                char cmd[100];
//                sprintf(cmd, "AT+TCPSETUP=0,%s,%s", SERVER_IP, SERVER_PORT);
//                send_at_command(cmd);
//                currentState = STATE_WAIT_OK;
//            }
//            break;
//
//        case STATE_TCP_READY:
//            // TCP connection is ready for data transmission
//            currentState = STATE_DONE;
//            break;
//
//        case STATE_ERROR:
//        	currentState = STATE_START;
//            // Handle error, could reset or attempt recovery
//            break;
//
//        case STATE_DONE:
//            // Connection established and ready. Idle or perform other tasks.
//            break;
//
//        default:
//            currentState = STATE_ERROR;
//            break;
//    }
//}
