#include <stdint.h>
#include "datasharing.h"
#include "crc32.h"
#include "usart.h"
#include "kms.h"
#include "string.h"
Dnet_RxDataPacket_t Dnet_RxDataPacket;
MCU2_TxDataPacket_t MCU2_TxDataPacket;
MCU2_RxDataPacket_t MCU2_RxDataPacket;
extern volatile uint8_t Txflag;
void write_bits(uint8_t *buffer, uint32_t *pos, uint32_t value, int num_bits) {
	for (int i = num_bits - 1; i >= 0; --i) {
		if (*pos % 8 == 0)
			buffer[*pos / 8] = 0;  // Initialize the byte when starting
		buffer[*pos / 8] |= ((value >> i) & 1) << (7 - *pos % 8);
		(*pos)++;
	}
}

uint32_t read_bits(const uint8_t *buffer, uint32_t *pos, int num_bits) {
	uint32_t value = 0;
	for (int i = num_bits - 1; i >= 0; --i) {
		uint32_t byte_pos = *pos / 8;
		uint32_t bit_pos = 7 - (*pos % 8);
		uint32_t bit = (buffer[byte_pos] >> bit_pos) & 1;
		value |= (bit << i);
		(*pos)++;
	}
	return value;
}

_Bool MCU2_vExtractRxDataPacket(uint8_t *buffer, MCU2_RxDataPacket_t *packet)

{
	uint32_t pos = 0;  // Position in the buffer in bits
	uint16_t start = (uint16_t) read_bits(buffer, &pos, 16);
//	if (start != 0xB5D3) {
//		printf("Invalid packet start. Expected 0xB5D3, got 0x%X\n", start);
//		return false;  // Start of packet does not match expected value
//	}
	if (start != 0xA593) {
		printf("Invalid packet start. Expected 0xB5D3, got 0x%X\n", start);
		return false;  // Start of packet does not match expected value
	}

	packet->pkt_start = start;
	packet->pkt_type = (uint8_t) read_bits(buffer, &pos, 8);
	packet->pkt_length = (uint8_t) read_bits(buffer, &pos, 8);
	packet->date = (uint8_t) read_bits(buffer, &pos, 8);
	packet->month = (uint8_t) read_bits(buffer, &pos, 8);
	packet->year = (uint8_t) read_bits(buffer, &pos, 8);
	packet->hours = (uint8_t) read_bits(buffer, &pos, 8);
	packet->minutes = (uint8_t) read_bits(buffer, &pos, 8);
	packet->seconds = (uint8_t) read_bits(buffer, &pos, 8);
	packet->pkt_crc = (uint32_t) read_bits(buffer, &pos, 32);

//	uint32_t computed_crc = compute_crc(buffer, (pos - 32) / 8); // compute CRC excluding the CRC field
//	if (computed_crc != packet->pkt_crc) {
//
//		return false;
//	}
	return true;
}

void Frame_vMCU2TxDataPacket(MCU2_TxDataPacket_t *packet, uint8_t *buffer) {
	uint32_t pos = 0;  // Position in the buffer in bits

	write_bits(buffer, &pos, packet->pkt_start, 16);
	write_bits(buffer, &pos, packet->pkt_type, 4);
	write_bits(buffer, &pos, packet->pkt_length, 9);
	write_bits(buffer, &pos, packet->source_loco_id, 20);
	write_bits(buffer, &pos, packet->abs_loco_loc, 23);
	write_bits(buffer, &pos, packet->train_speed, 9);
	write_bits(buffer, &pos, packet->movement_dir, 2);
	write_bits(buffer, &pos, packet->loco_mode, 4);
	write_bits(buffer, &pos, packet->last_rfid_tag, 10);
	write_bits(buffer, &pos, packet->tag_dup, 1);
	write_bits(buffer, &pos, packet->tag_link_info, 3);
	write_bits(buffer, &pos, packet->tin, 9);
	write_bits(buffer, &pos, packet->sig_ov, 1);
	write_bits(buffer, &pos, packet->spare, 2);
	write_bits(buffer, &pos, packet->loco_health_status, 6);
	// Assuming we have 16 bytes of key data to write
	for (int i = 0; i < 16; ++i) {
		write_bits(buffer, &pos, packet->akey1_at_memory_location_0[i], 8);
	}
	for (int i = 0; i < 16; ++i) {
		write_bits(buffer, &pos, packet->akey1_at_memory_location_1[i], 8);
	}
	write_bits(buffer, &pos, packet->padding_bits, 1);
	write_bits(buffer, &pos, packet->pkt_crc, 32);

}

_Bool Dnet_vExtractRxDataPacket(const uint8_t *buffer,
		Dnet_RxDataPacket_t *packet) {
	uint32_t pos = 0;  // Position in the buffer in bits
	uint16_t start = (uint16_t) read_bits(buffer, &pos, 16);
	if (start != 0xB5D3) {
		printf("Invalid packet start. Expected 0xB5D3, got 0x%X\n", start);
		return false;  // Start of packet does not match expected value
	}

	packet->pkt_start = start;
	packet->pkt_type = (uint8_t) read_bits(buffer, &pos, 4);
	packet->pkt_length = (uint8_t) read_bits(buffer, &pos, 7);
	packet->source_loco_id = (uint32_t) read_bits(buffer, &pos, 20);
	packet->abs_loco_loc = (uint32_t) read_bits(buffer, &pos, 23);
	packet->train_speed = (uint16_t) read_bits(buffer, &pos, 9);
	packet->movement_dir = (uint8_t) read_bits(buffer, &pos, 2);
	packet->loco_mode = (uint8_t) read_bits(buffer, &pos, 4);
	packet->last_rfid_tag = (uint16_t) read_bits(buffer, &pos, 10);
	packet->tag_dup = (uint8_t) read_bits(buffer, &pos, 1);
	packet->tag_link_info = (uint8_t) read_bits(buffer, &pos, 3);
	packet->tin = (uint16_t) read_bits(buffer, &pos, 9);
	packet->sig_ov = (uint8_t) read_bits(buffer, &pos, 1);
	packet->spare = (uint8_t) read_bits(buffer, &pos, 2);
	packet->loco_health_status = (uint8_t) read_bits(buffer, &pos, 6);
	packet->padding_bits = (uint8_t) read_bits(buffer, &pos, 3);
	packet->pkt_crc = (uint32_t) read_bits(buffer, &pos, 32);
//	uint32_t computed_crc = compute_crc(buffer, (pos - 32) / 8); // compute CRC excluding the CRC field
//	if (computed_crc != packet->pkt_crc) {
//
//		return false;
//	}
	return true;
}
static uint8_t kmsflag = 1;
void MCU2_vProcessDatapacket(void)

{
	if ((RXpos2 == 1) && (kmsflag == 1)) {
		RXpos2 = 0;

		// Correct usage if MCU2_TxDataPacket is a pointer
		if (1
				== MCU2_vExtractRxDataPacket(&MCU2_RXBuf[0],
						&MCU2_RxDataPacket)) {
			DateTime.tm_year = MCU2_RxDataPacket.year;
			DateTime.tm_mon = MCU2_RxDataPacket.month;
			DateTime.tm_mdate = MCU2_RxDataPacket.date;
			DateTime.tm_hour = MCU2_RxDataPacket.hours;
			DateTime.tm_min = MCU2_RxDataPacket.minutes;
			DateTime.tm_sec = MCU2_RxDataPacket.seconds;
			kmsflag = 0;
			Txflag = 1;
			memset(MCU2_RXBuf, 0, 14);
		}

	} else if ((RXpos2 == 1) && (kmsflag == 0)) {
		RXpos2=0;
		if (1
				== MCU2_vExtractRxDataPacket(&MCU2_RXBuf[0],
						&MCU2_RxDataPacket)) {
			DateTime.tm_year = MCU2_RxDataPacket.year;
			DateTime.tm_mon = MCU2_RxDataPacket.month;
			DateTime.tm_mdate = MCU2_RxDataPacket.date;
			DateTime.tm_hour = MCU2_RxDataPacket.hours;
			DateTime.tm_min = MCU2_RxDataPacket.minutes;
			DateTime.tm_sec = MCU2_RxDataPacket.seconds;
		}

	}
}

void Dnet_vProcessDataPacket(void)

{
	if (RXpos2 == 1) {
		RXpos2 = 0;
		// Correct usage if MCU2_TxDataPacket is a pointer
		if (1
				== Dnet_vExtractRxDataPacket(&DNET_RXBuf[0],
						&Dnet_RxDataPacket)) {
			// update the MCU2 Tx packet
			Frame_vMCU2TxDataPacket(&MCU2_TxDataPacket, MCU2_TXBuf);
			HAL_UART_Transmit(&huart5, MCU2_TXBuf, 51, 1000);
		} else {
			//status=0;
			//return 0;
		}
	}

}
