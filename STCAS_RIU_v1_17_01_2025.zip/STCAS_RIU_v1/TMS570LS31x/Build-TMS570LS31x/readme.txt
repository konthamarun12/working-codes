/***************************************************************************************/
Date 		    		: 01/01/2025
Project Folder Name 		: STCAS_RIU_v1_ATF_DEMO_CODE_01_01_2025
user Source and header files 	: crc32.h,crc32.c,DECODE_MCU.h, DECODE_MCU.csys_main.c,
		     		 RIU_LOGICS.c, RIU_LOGICS.h, RIU_FRAME_DATA_PKT.c,
		      		 RIU_FRAME_DATA_PKT.h, frameNumber.c ,
 		      		 frameNumber.h, user_station_decode.c, user_station_decode.h
CRC VALUE 	    		: 0xC00403D9


/****************************************************************************************/

/***************************************************************************************/
Date 		    		: 09/01/2025
Project Folder Name 		: STCAS_RIU_v1_ATF_DEMO_CODE_01_01_2025
user Source and header files 	: crc32.h,crc32.c,DECODE_MCU.h, DECODE_MCU.csys_main.c,
		     		 RIU_LOGICS.c, RIU_LOGICS.h, RIU_FRAME_DATA_PKT.c,
		      		 RIU_FRAME_DATA_PKT.h, frameNumber.c ,
 		      		 frameNumber.h, user_station_decode.c, user_station_decode.h
CRC VALUE MCU1	    		: 0x81B64AE9
CRC VALUE MCU3				: 0x81B64AE9

change history: update dwith Error and config led in sysmain , gio and riulogics.c and .h file changes for above 
version  


/****************************************************************************************/