/*******************************************************************************
 *
 * @FileName         : RIU_FRAME_DATA_PKT.c
 * @Version		     : V1.0.0
 * @Date			 : 24-04-2024
 * @CPUGroup		 : Platform Dependent Code
 * @Author			 : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include "crc32.h"
#include <time.h>
#include "RIU_FRAME_DATA_Pkt.h"
#include "frameNumber.h"
#include "lwip_main.h"

#define FUNCTION_CODE_RIU 0x02
#define FUNCTION_CODE_STN 0x01
static RIU_FieldInputPkt_t STN_FIELD_InputPkt;
extern uint8_t gu8VimOverallHealth;
extern uint8_t gu8VicoverallHealth;
static RIU_FieldInputPkt_t RIU_FieldInputPkt;
volatile uint8_t rx_buffer[200];

uint8_t gu8UDPRXFLAG;
extern uint16_t gLength;

static uint8_t station_id[4] = { 192, 254, 2, 190 };
static uint8_t first_time_pkt = 0;
static uint8_t no_of_vim = NO_OF_VIM;

uint8_t RIU_u8buffer[50];

uint8_t RIUID[4] = { 192, 254, 2, 190 }; // this id we get from station_kavach in that packet (actually we have to read it from dip_swicth)

uint8_t gua8_CanIoData[16];
/**
 * @brief Generate a frame number based on current time
 *
 * @return The frame number
 * @details This function gets the current time and converts it to a frame number
 *          by multiplying the hours by 3600, minutes by 60 and adding the seconds
 *          to generate the frame number. The frame number is calculated
 *          based on 1 second per frame.
 */
uint32_t create_time_frame()
{
    time_t current_time;
    struct tm *local_time;

    // Get the current time
    time(&current_time);
    // Convert it to local time representation
    local_time = localtime(&current_time);
    unsigned int hours = (local_time->tm_hour);
    unsigned int minutes = local_time->tm_min;
    unsigned int seconds = local_time->tm_sec;
    return CM_u32getFrameNumber(hours, minutes, seconds);

}
/**
 * @brief Verify the received packet and extract the required fields
 *
 * @param STN_FILED_InpputPkt The structure to store the received packet fields
 * @param buffer The buffer containing the received packet
 *
 * @return 1 if the packet is verified and fields are extracted, 0 otherwise
 *
 * @details This function verifies the received packet and extracts the required fields
 *          such as sender IP, receiver IP, frame number, function code, length and number of VIMs.
 *          It also checks if the packet is coming from the same station ID and if the frame number
 *          is same as the current frame number. If all the checks are successful, it raises the flag
 *          for sending the RIU packet. If any of the checks fail, it returns 0.
 */
uint8_t RIU_u8extractPkt(RIU_FieldInputPkt_t STN_FILED_InpputPkt,
                         uint8_t *buffer)
{

    uint32_t frame_number = 0;
    uint8_t contniue = 0;
    if (verifyCrc32(buffer, gLength))
    {
        if ((0xA5 == buffer[0]) && (0xC3 == buffer[1]))
        {
            {
                ///COPY THE STATION ID & CHECK FOR EVERY PACKET WHETHR IT COMES FROM SMAE STATION ID OR NOT
                STN_FILED_InpputPkt.senderIp[0] = buffer[2]; // first time i have received   stati0n_ip
                STN_FILED_InpputPkt.senderIp[1] = buffer[3];
                STN_FILED_InpputPkt.senderIp[2] = buffer[4];
                STN_FILED_InpputPkt.senderIp[3] = buffer[5];

                if (0 == first_time_pkt)
                {
                    station_id[0] = buffer[2]; //copy the station_ip whenever you first you receive to on buffer for checking  every time you receive station-ip
                    station_id[1] = buffer[3];
                    station_id[2] = buffer[4];
                    station_id[3] = buffer[5];

                    first_time_pkt = 1;
                    contniue = 1;
                }
                else if (1 == first_time_pkt) // second time i have received station_ip
                {
                    // check station_ip with first time you received with station_ip
                    if ((station_id[0] == STN_FILED_InpputPkt.senderIp[0])
                            && (station_id[1] == STN_FILED_InpputPkt.senderIp[1])
                            && (station_id[2] == STN_FILED_InpputPkt.senderIp[2])
                            && (station_id[3] == STN_FILED_InpputPkt.senderIp[3]))
                    {
                        contniue = 1;
                    }

                }
                else
                {
                    return 0;    // go to start
                }
            }
            if (contniue == 1)
            {
                //COPY THE RECEIVER IP AND CHECK FOR SAME RIU_ID OR NOT && HERE WE HAVE READ RECEIVER_ID FROM DIP_SWITCH
                STN_FILED_InpputPkt.receiverIp[0] = buffer[6];
                STN_FILED_InpputPkt.receiverIp[1] = buffer[7];
                STN_FILED_InpputPkt.receiverIp[2] = buffer[8];
                STN_FILED_InpputPkt.receiverIp[3] = buffer[9];
                contniue = 0;
            }
            //we have to check, station_receiver_ip(its destination RIU_ID) with OUR OWN RIU_ID which is read from Dip_switch
            if ((RIUID[0] == STN_FILED_InpputPkt.receiverIp[0])
                    | (RIUID[1] == STN_FILED_InpputPkt.receiverIp[1])
                    | (RIUID[2] == STN_FILED_InpputPkt.receiverIp[2])
                    | (RIUID[3] == STN_FILED_InpputPkt.receiverIp[3]))
            {
                //FRAMENUMBER ALSO COOPY AND CHEK SAME FRAME NUBER OR NOT
                STN_FILED_InpputPkt.framenumber[0] = buffer[11];
                STN_FILED_InpputPkt.framenumber[1] = buffer[12];
                STN_FILED_InpputPkt.framenumber[2] = buffer[13];

                frame_number = 58633; //create_time_frame(); // we have to give this fram_number to that frame_number // TODO

                if ((frame_number == (STN_FILED_InpputPkt.framenumber[0]) << 16)
                        | (STN_FILED_InpputPkt.framenumber[1] << 8)
                        | (STN_FILED_InpputPkt.framenumber[2]))
                {

                    //STATION_FUNCTIION CODE ALSO CHECK
                    STN_FILED_InpputPkt.u8Functioncode = buffer[10];

                    //THEN LENGTH COPY & BASED ON LENGTH WE HAVE TO FIND HOW MANY VIM'S WE HAVE TOUSE IN OUR RIU
                    STN_FILED_InpputPkt.length[0] = buffer[14];
                    STN_FILED_InpputPkt.length[1] = buffer[15];

//                    STN_FILED_InpputPkt.no_of_vim = buffer[16];
//                    no_of_vim = STN_FILED_InpputPkt.no_of_vim;
                    //raise the flag for sending the RIU packet
                    //	send_RIU_flag = 1;             //if all are verified ,raise the flags
                    return 1;
                }
                else
                {
                    //	send_RIU_flag = 0;
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    return 0;
}

/**
 * @brief Function to frame RIU packet and send it to station
 * 
 * This function frames the RIU packet based on the given parameters and sends it to the station.
 * The parameters are as follows:
 * - framenumber: 32-bit frame number from GPS
 * - PFips: pointer to the data_payload containing field inputs
 * - status: 8-bit health status of RIU
 * - sendIP: pointer to the IP address of the station to which the packet has to be sent
 * - RIU_ID: pointer to the 4-byte RIU ID
 * - no_of_vims: number of VIMs in the station_config parameters
 * 
 * The function first frames the packet by filling in the necessary fields with the given parameters.
 * Then it calculates the CRC of the packet and appends it to the packet.
 * Finally, it sends the packet to the station using the TCASUDPSend function.
 * 
 * @param[in] framenumber 32-bit frame number from GPS
 * @param[in] PFips pointer to the data_payload containing field inputs
 * @param[in] status 8-bit health status of RIU
 * @param[in] sendIP pointer to the IP address of the station to which the packet has to be sent
 * @param[in] RIU_ID pointer to the 4-byte RIU ID
 * @param[in] no_of_vims number of VIMs in the station_config parameters
 * 
 * @return None
 */
void RIU_vRiu2StationPktFramning(uint32_t framenumber, uint8_t *PFips,
                                 uint8_t *status, uint8_t *sendIP,
                                 uint8_t *RIU_ID, uint8_t no_of_vims)
{
    uint16_t offset = 0;
    uint32_t crc_buf = 0;
    uint8_t cnt = 0;
    uint16_t len1 = 0; //length should have to update from data_pay_load + crc_length
    uint8_t i = 0;
    uint32_t ipaddr = 0;
    // based on no_of_vims in stn_config parameters
    //no_of_vims in stn_config parameters are 2 ,then data_payload is 2x32 = 64
    //64/8 = 8 ----len1
    //len1 = 8 + crc_len = 4+health_status_1_byte; total_len = 9;

    RIU_FieldInputPkt.Sof[0] = (SOF & 0xFF00) >> 8u;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.Sof[0];
    offset += 1;
    RIU_FieldInputPkt.Sof[1] = (SOF & 0x00FF);
    RIU_u8buffer[offset] = RIU_FieldInputPkt.Sof[1];
    offset += 1;

    for (i = 0; i < 4; i++)
    {
        RIU_FieldInputPkt.senderIp[i] = RIU_ID[i]; //THIS ID IS STATION_ID FROM STATION REQUEST PACKET
        RIU_u8buffer[offset] = RIU_FieldInputPkt.senderIp[i];
        offset += 1;
    }
    for (i = 0; i < 4; i++)
    {                                 //RIU_ID from dipswich
        RIU_FieldInputPkt.receiverIp[i] = sendIP[i];
        RIU_u8buffer[offset] = RIU_FieldInputPkt.receiverIp[i];
        offset += 1;
    }

    RIU_FieldInputPkt.u8Functioncode = FUNCTION_CODE_RIU; //it is function code for RIU function code
    RIU_u8buffer[offset] = RIU_FieldInputPkt.u8Functioncode;
    offset += 1;

    RIU_FieldInputPkt.framenumber[0] = (framenumber & 0x00FF0000u) >> 16u; //framenumber shall have to take from gps
    RIU_u8buffer[offset] = RIU_FieldInputPkt.framenumber[0];
    offset += 1;
    RIU_FieldInputPkt.framenumber[1] = (framenumber & 0x0000FF00u) >> 8u;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.framenumber[1];
    offset += 1;
    RIU_FieldInputPkt.framenumber[2] = (framenumber & 0x000000FFu);
    RIU_u8buffer[offset] = RIU_FieldInputPkt.framenumber[2];

    offset += 1;

    cnt = no_of_vims * 4; //each vim has process  32-bit means 4x8 =4bytes ;no of 4 bytes x no_of_vims that much data field input should have to process
    len1 = cnt + 4 + 3; //crc_length+health_status_len
    RIU_FieldInputPkt.length[0] = (len1 & 0xFF00) >> 8;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.length[0];
    offset += 1;
    RIU_FieldInputPkt.length[1] = (len1 & 0x00FF);
    RIU_u8buffer[offset] = RIU_FieldInputPkt.length[1];
    offset += 1;
    for (i = 0; i < cnt; i++)
    {
        RIU_FieldInputPkt.u8SignalInfo[i] = PFips[i];
        RIU_u8buffer[offset] = RIU_FieldInputPkt.u8SignalInfo[i];
        offset += 1;
    }
    RIU_FieldInputPkt.u8health_status[0] = status[0];
    //health sttus
    RIU_u8buffer[offset] = RIU_FieldInputPkt.u8health_status[0];
    offset += 1;
    RIU_FieldInputPkt.u8health_status[1] = status[1];
    //health sttus
    RIU_u8buffer[offset] = RIU_FieldInputPkt.u8health_status[1];
    offset += 1;
    RIU_FieldInputPkt.u8health_status[2] = status[2];
    //health sttus
    RIU_u8buffer[offset] = RIU_FieldInputPkt.u8health_status[2];
    offset += 1;
    crc_buf = calculate_crc32(RIU_u8buffer, offset);         //calculate the crc

    RIU_FieldInputPkt.crc[0] = (crc_buf & 0xFF000000) >> 24u;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.crc[0];
    offset += 1;
    RIU_FieldInputPkt.crc[1] = (crc_buf & 0x00FF0000) >> 16u;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.crc[1];
    offset += 1;
    RIU_FieldInputPkt.crc[2] = (crc_buf & 0x0000FF00) >> 8u;
    RIU_u8buffer[offset] = RIU_FieldInputPkt.crc[2];
    offset += 1;
    RIU_FieldInputPkt.crc[3] = (crc_buf & 0x0000FF);
    RIU_u8buffer[offset] = RIU_FieldInputPkt.crc[3];
    offset += 1;

    ipaddr = RIU_u32IpaddressInteger(sendIP);

    RIU_vUdpTxDataPacket(&RIU_u8buffer[0], offset, ipaddr, SERVER_PORT);

}
/**
 * @brief: This function will handle the UDP RX data packet
 * 
 * It will copy the received data into global buffer and then it will extract the packet and
 * validate the packet if it is valid then it will update the success status else it will update
 * the error status
 * 
 * @return: None
 */
void RIU_vRXHandler(void)
{

    uint8_t status = 0;
    if (gu8UDPRXFLAG == 1)
    {

        gLength = 0;
        gu8UDPRXFLAG = 0;         // need to update the error// status as sucess
        //   status = RIU_u8extractPkt(STN_FILED_InpputPkt, &rx_buffer[0]);
        if (status == 1)
        {
            gLength = 0;
            gu8UDPRXFLAG = 0;     // need to update the error// status as sucess
        }
        else
        {
            gLength = 0;
            gu8UDPRXFLAG = 0;     // need to update the error
        }

    }
    else
    {

    }

}

/**
 * @brief Converts an IP address stored in a uint8_t array to an uint32_t
 * 
 * @param[in] ip The IP address stored in a uint8_t array
 * @return The IP address as an uint32_t
 * 
 * This function takes an IP address stored in a uint8_t array and
 * packs it into a 32-bit unsigned integer. The function assumes that
 * the IP address is in network byte order.
 */
uint32_t RIU_u32IpaddressInteger(uint8_t *ip)
{
    uint32_t result = 0;

    // Pack the bytes into a 32-bit unsigned integer
    result = (ip[0] << 24) | (ip[1] << 16) | (ip[2] << 8) | ip[3];

    return result;
}

//uint8_t nibble1, nibble2, nibble3, nibble4;
void extract_nibbles(uint16_t canId, uint8_t *nibble1, uint8_t *nibble2,
                     uint8_t *nibble3, uint8_t *nibble4)
{

    *nibble1 = (canId >> 12) & 0x0F; // Extracting the first nibble
    *nibble2 = (canId >> 8) & 0x0F;  // Extracting the second nibble
    *nibble3 = (canId >> 4) & 0x0F;  // Extracting the third nibble
    *nibble4 = canId & 0x0F;         // Extracting the fourth nibble
}

/**
 * @brief Identifies VIC type based on CAN IDs
 *
 * This function iterates through an array of CAN IDs and identifies
 * the type of VIC based on the last two bytes of each ID. It checks
 * if the last two bytes are 0x0041, which indicates VIC-1, or 0x0081,
 * which indicates VIC-2. If the CAN ID does not match any of these
 * identifiers, it is not recognized.
 *
 * @param canIds Array of CAN IDs to be checked
 * @param size Number of CAN IDs in the array
 */
void RIU_videntifyVIC(uint16_t canIds[], size_t size)
{
    size_t i = 0;
    for (i = 0; i < size; i++)
    {
        uint16_t id = canIds[i];
        if ((id & 0x00FF) == 0x0041)
        { // Check if the last two bytes are 41
          //printf("CAN ID 0x%04X is for VIC-1\n", id);
        }
        else if ((id & 0x00FF) == 0x0081)
        { // Check if the last two bytes are 81
          //printf("CAN ID 0x%04X is for VIC-2\n", id);
        }
        else
        {
            //printf("CAN ID 0x%04X is not recognized\n", id);
        }
    }
}

/**
 * @brief Processes a CAN message received from the RIU based on the VIC type
 *
 * This function takes a received CAN ID and checks if it matches one of the
 * predefined IDs. If a match is found, it extracts the last two bytes of the
 * ID and processes the message data based on the VIC card number.
 *
 * @param gu16canAdd Received CAN ID
 * @param canIds Predefined array of CAN IDs
 * @param size Number of elements in the canIds array
 * @param u8MSGData Array to store the received CAN message data
 * @param gua8_CanIoData Array to store the processed data for each ID
 * @param send_RIU_flag Flag to indicate if a message was processed
 */
void RIU_vCanBusPkt(uint16_t gu16canAdd, uint16_t canIds[], uint8_t size,
                    uint8_t u8MSGData[], uint8_t gua8_CanIoData[],
                    uint8_t *send_RIU_flag)
{
    uint8_t i = 0;
    uint8_t j = 0;
    for (i = 0; i < size; i++)
    {
        // If the received CAN ID matches one of the predefined IDs
        if (gu16canAdd == canIds[i])
        {
            // Extracting the third and fourth nibbles
            uint8_t su8_riuVicCardNo = (gu16canAdd >> 4) & 0x0F; // Third nibble
            uint8_t su8_riuVimCardNo = gu16canAdd & 0x0F;       // Fourth nibble

            // Get the CAN message data
            //canGetData(1, 5, u8MSGData); // Placeholder for your actual CAN data retrieval function

            // Copy data to appropriate section of gua8_CanIoData
            uint8_t startIndex = i * su8_riuVimCardNo; // Start index for each ID
            for (j = 0; j < MESSAGE_DATA_SIZE; j++)
            {
                gua8_CanIoData[startIndex + j] = u8MSGData[j];
            }

            // Process based on the VIC card number
            if (su8_riuVicCardNo == 4)
            {  // dip value
               // Process VIC-1
               //printf("Processing VIC-1, Card Number: %d\n", su8_riuVimCardNo);
               // Add further processing logic for VIC-1 as needed
            }
            else if (su8_riuVicCardNo == 8)
            {
                // Process VIC-2
                // printf("Processing VIC-2, Card Number: %d\n", su8_riuVimCardNo);
                // Add further processing logic for VIC-2 as needed
            }
            else
            {
                // Handle unexpected VIC card numbers
                //  printf("Unexpected VIC Card Number: %d\n", su8_riuVicCardNo);
            }

            // Set a flag or perform additional operations based on the ID
            *send_RIU_flag = 1; // Set flag to indicate a message was processed

            // Optional: You can return here if only one ID is to be processed
            return;// Comment this line if you want to check for multiple matches
        }
    }
}
