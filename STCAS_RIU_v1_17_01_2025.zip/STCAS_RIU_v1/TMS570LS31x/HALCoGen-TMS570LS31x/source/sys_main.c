/** @file sys_main.c
 *   @brief Application main file
 *   @date 11-Dec-2018
 *   @version 04.07.01
 *
 *   This file contains an empty main function,
 *   which can be used for the application.
 */

/*
 * Copyright (C) 2009-2018 Texas Instruments Incorporated - www.ti.com
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* USER CODE BEGIN (0) */
/* USER CODE END */

/* Include Files */
#include <stdint.h>
#include <string.h>
#include "sys_common.h"
#include "can.h"
#include "gio.h"
#include "mibspi.h"
#include "riulogics.h"

#include "rti.h"
#include "crc32.h"
#include "lwip/timers.h"
#include "het.h"
#include "user_constants.h"
#include "lwiplib.h"
#include "lwip_main.h"
#include "sys_core.h"
#include <stdio.h>
/* USER CODE BEGIN (1) */
extern uint32_t u32VIMfailureCntr1;
_Bool timerflag = 0;
_Bool messageBoxReceived[5] = { false, false, false, false, false };
/* Global time
 * r variable (volatile to prevent optimization issues) */

/* USER CODE END */

/* USER CODE BEGIN (2) */
VIC_enStattes_t VIC_enStattes;
uint8_t enableMCU1 = 0;
uint8_t enableVIC1 = 0;
uint8_t enableMCU3 = 0;
uint8_t enableVIC2 = 0;
uint8_t vicstatus[5] = { 0, 1, 1, 1, 1 };
extern uint8_t gu8VicoverallHealth;
static volatile uint32_t timer_ticks = 0U;
extern RIU_st2002Flags_t RIU_st2002Flags;

DipInfo_t DipInfo;
Riu_stFlags_t HLT_PKT;
uint8_t dipSwitchValue = 0;
uint16_t gu16canAdd = 0;
uint16_t gu16canAddVIC = 0;
uint16_t gu16canAddVICMCU = 0;
uint16_t gu16canAddVIM = 0;
uint32_t error = RESET;
uint32_t emacPhyAddress = 1U;
uint32_t gu32TimerCounter = 0;
uint32_t gu32VimFailureTimCounter = 0;
uint32_t gu32LinkCheckCntr = 0;
uint32_t gu32TimerCounter1 = 0;
uint8_t u8MSGData[40];
uint8_t u8VIMMSGData[40];
uint8_t u8TempMSGData[40];
uint8_t u8HealthMSGData[40];
uint8_t u8HealthTempMSGData[40];
uint8_t u8HealthVICMSGData[8];
uint8_t emacAddress[6U] = { 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU };
extern _Bool gbPowerOnFlag;
extern uint8_t VIC_HLTPKT[8];
extern uint8_t VIC_MCUDATATEST[8];
extern uint8_t gua8_CanIoData[16];
extern uint8_t gua8_CanIoData[16];
extern uint8_t gu8_gpsBuff[8];
extern uint16_t CAN_mcuBase_address;
extern uint16_t CAN_VICBaseAddress;
extern uint16_t CAN_VICGpsAddress;
extern RIU_stPcbFailureflagStatus_t failureFlags;
_Bool vic1heartbeatReceivedMCU1 = true;
_Bool vic1heartbeatReceivedMCU3 = true;
_Bool vic2heartbeatReceivedMCU1 = true;
_Bool vic2heartbeatReceivedMCU3 = true;

uint32_t gu32_ProgramCrc = 0;
/* USER CODE END */

/**
 * @brief Configures MCU and VIC macros based on DIP switch address.
 *
 * @details This function defines and enables specific macros (MCU and VIC)
 * depending on the current DIP switch address value stored in DipInfo.u8Address.
 * It supports up to four address values (1 to 4), with each value determining
 * different macro configurations for the system.
 */
void RIU_vUpdateHealthStatus(void);

// Functions for handling data based on ID
void handleVICData(uint16_t lu16canAdd, uint8_t *data);
void handleGPSData(uint16_t lu16canAdd, uint8_t *data);
void handleMCUData(uint16_t lu16canAdd, const uint8_t *data);
void copyVIMMessageData(uint16_t lu16canAdd, uint8_t *src, uint8_t *dest);
void Delay_ms(uint32_t delay_ms);
uint8_t gu8_slotDetect = 0;

/**
 * @brief Reads the current state of the slot detect DIP switches.
 *
 * @details This function reads the current state of the slot detect DIP switches.
 * The function returns a byte value, with each bit in the returned value corresponding
 * to a slot detect switch. A value of 0 for a bit indicates that the switch is in the
 * off position, and a value of 1 indicates that the switch is in the on position.
 *
 * @return uint8_t The current state of the slot detect DIP switches.
 */
uint8_t Read_Slot_Detect_Dip_Switch(void)

{
    uint8_t lu8_slotDetect = 0u;
    lu8_slotDetect = 0x00u;
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 11u) << 0u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 14u) << 1u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 15u) << 2u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 16u) << 3u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 22u) << 4u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 18u) << 5u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 25u) << 6u);
    lu8_slotDetect |= (uint8_t) (gioGetBit(hetPORT1, 20u) << 7u);
    lu8_slotDetect = ~(lu8_slotDetect);
    return lu8_slotDetect;

}

/**
 * @brief The main entry point of the application.
 *
 * This function initializes all peripherals and sets their directions.
 * It enables interrupts and configures the CAN communication.
 * Furthermore, it initializes the Real-Time Interrupt (RTI) and configures
 * the Message Boxes for the CAN communication.
 * The function then enters an infinite loop where it processes the ring
 * data and sends the health packet to the MCU.
 */
/**
 * @brief Main function to initialize and start the system.
 *
 * This function initializes all peripherals, reads DIP switch values, sets up CAN communication,
 * and starts the RTI module. It also processes various tasks in a loop while the power-on flag is set.
 *
 * @return int
 */
int main(void)
{
    /**<  Power on*/

    /* USER CODE BEGIN (3) */
    /* Initialize all peripherals and set their directions */

    gioInit(); /**< Initialize GIO module */
    hetInit(); /**< Initialize HET module */
    gioSetPort(gioPORTA, 0x00000000); /**< Set all pins of GIO PORTA to low */

    /* Initialize CAN communication */
    canInit(); /**< Initialize CAN module */
    _enable_interrupt_(); /**< Enable interrupts */

    mibspiInit(); /**< Initialize MIBSPI module */
    gioSetPort(mibspiPORT5, 0x0F0F0FFF); /**< Set specific pins of MIBSPI PORT5 */
    RIU_vLedsOn(); /**< Turn on LEDs */
    RIU_vLedsOff(); /**< Turn off LEDs */
    RIU_vLedsOff(); /**< Turn off LEDs again */


//    while(1)
//    {
//
//
//       RIU_vErrorLedOn();
//       RIU_vErrorLedOff();
////       RIU_vConfigLedOff(); // working fine
////       RIU_vConfigLedOn(); // not working fine
//
//    }

    /* Read DIP switch address Based on this value, set the CAN base address */
    /* Read slot detect DIP switch */
    gu8_slotDetect = Read_Slot_Detect_Dip_Switch(); /**< Read slot detect DIP switch */
    DipInfo.u8Address = ReadDipSwitchAdd(); /**< Read DIP switch address */
    /* Read the DIP switch value for MCU CAN base addresses */
    dipSwitchValue = RIU_u8DipSwitchRead(); /**< Read DIP switch value */

    gu32_ProgramCrc = CheckIntCRC(0, 0x2ee000); /**< Check internal CRC */
    // off means not working correctly
    RIU_vConfigLedOff(); /**< Turn off configuration LED */
    RIU_vCheckAndConfigureRiuAddress(DipInfo.u8Address, gu8_slotDetect,
                                     dipSwitchValue); /**< Start up MCU DIP address */

    if (gbPowerOnFlag == RIU_nSET)
    {
        /* Whenever we read the 8-bit DIP switch value, we pass this value to
         * RIU_vassignAddresses. This function separates station address and
         * RIU address */

        /**< Enable MCU EMAC initialization based on DIP switch */
        RIU_vConfigureVicDefaultStatus();

        /**< Read MCU base address from DIP switch */
        CAN_mcuBase_address = VIC_mcuDip_Switch_ReadValue(DipInfo.u8Address);

        /**< Read VIC base address from DIP switch */
        CAN_VICBaseAddress = RIU_u32VICDipSwitchReadValue(DipInfo.u8Address);
        /**< Initialize RTI module */
        rtiInit();
        /**< Enable interrupts */
        _enable_interrupt_();
        /**< Enable notification for RTI compare 0 (100 ms) */
        rtiEnableNotification(rtiNOTIFICATION_COMPARE0);
        /**< Start RTI counter block 0 */
        rtiStartCounter(rtiCOUNTER_BLOCK0);
        /**< Enable notification for RTI compare 1 (50ms */
        rtiEnableNotification(rtiNOTIFICATION_COMPARE1);
        /**< Start RTI counter block 0 again */
        rtiStartCounter(rtiCOUNTER_BLOCK0);
        /**< Enable notification for RTI compare 2 (25s) */
        rtiEnableNotification(rtiNOTIFICATION_COMPARE2);
        /**< Start RTI counter block 1 */
        rtiStartCounter(rtiCOUNTER_BLOCK1);
        /**< Enable notification for RTI compare 3 10 ms) */
        rtiEnableNotification(rtiNOTIFICATION_COMPARE3);
        /**< Start RTI counter block 1 again */
        rtiStartCounter(rtiCOUNTER_BLOCK1);
        /**< Initialize counter */
        uint8_t u8_cntr = RIU_nINITVALUE;

        /* Set health packets for MCU2 and VIC1 */
        for (u8_cntr = 0; u8_cntr < 8; u8_cntr += 2)
        {
            /**< Set health packet value */
            VIC_HLTPKT[u8_cntr] = u8_cntr / 2 + 1;
            /**< Set health packet status */
            VIC_HLTPKT[u8_cntr + 1] = 0x00;
        }

        /* Set test data for MCU2 and VIC1 */
        for (u8_cntr = 0; u8_cntr < 8; u8_cntr++)
        {
            /**< Set test data value */
            VIC_MCUDATATEST[u8_cntr] = u8_cntr + 1;
        }
        /**< Turn off error LED */
        RIU_vErrorLedOff();
    }
    else
    {
        /* NOP */
    }

    while (gbPowerOnFlag)
    {
        RIU_vEnableLANCommunication(); /**< Enable LAN communication */

        /* Process VIM data to MCU */
        RIU_v2oo2ProcessVIMDataToMcu(); /**< Process VIM data to MCU */

        /* Compare V2oo2 data */
        RIU_V2oo2DataComparsion(); /**< Compare V2oo2 data */

        /* Process the field inputs to respective rings */
        RIU_vProcessRingData(); /**< Process field inputs to respective rings */

        /* Process data when any one of VIM failure */
        RIU_2002VimFailureTxToStation(); /**< Process data when any one of VIM failure */

        /* Perform hot standby actions */
        RIU_vHotStandByAction(); /**< Perform hot standby actions */


        RIU_vEthernetLinkCheckHandler();
        /* Check system timeouts */
        sys_check_timeouts(); /**< Check system timeouts */
    }

    return 0; /**< Return from main function */
}

void RIU_vUpdateHealthStatus(void)
{
    if (timerflag == 1)
    {
        /*  Perform link status check and indicates the LAN failure */

        if ((vicstatus[1] == 0) && (vicstatus[2] == 0))
        {
            gu8VicoverallHealth = 1;
            RIU_vErrorLedOn();
            RIU_st2002Flags.u32enableEmac = RIU_nSET;
        }
        else if ((vicstatus[3] == 0) && (vicstatus[4] == 0))
        {
            RIU_vErrorLedOn();
            gu8VicoverallHealth = 2;
        }
        else if ((vicstatus[1] == 1) && (vicstatus[2] == RIU_nSET))
        {
            RIU_vErrorLedOff();
            gu8VicoverallHealth = RIU_nCLEAR;
            RIU_st2002Flags.u32enableEmac = RIU_nCLEAR;
            RIU_st2002Flags.processReduentudpdata = RIU_nCLEAR;
        }
        else if ((vicstatus[3] == RIU_nSET) && (vicstatus[4] == RIU_nSET))
        {
            RIU_vErrorLedOff();
            gu8VicoverallHealth = RIU_nCLEAR;
            RIU_st2002Flags.u32enableEmac = RIU_nCLEAR;
            RIU_st2002Flags.processReduentudpdata = RIU_nCLEAR;
        }
        else
        {
            gu8VicoverallHealth = RIU_nCLEAR;
        }

        timerflag = RIU_nCLEAR;

        switch (DipInfo.u8Address)
        {
        case 1:
            vicstatus[1] = RIU_nSET;
            vicstatus[2] = RIU_nCLEAR;
            vicstatus[3] = RIU_nCLEAR;
            vicstatus[4] = RIU_nCLEAR;
            break;
        case 2:
            vicstatus[1] = RIU_nCLEAR;
            vicstatus[2] = RIU_nSET;
            vicstatus[3] = RIU_nCLEAR;
            vicstatus[4] = RIU_nCLEAR;
            break;
        case 3:
            vicstatus[1] = RIU_nCLEAR;
            vicstatus[2] = RIU_nCLEAR;
            vicstatus[3] = RIU_nSET;
            vicstatus[4] = RIU_nCLEAR;
            break;
        case 4:
            vicstatus[1] = RIU_nCLEAR;
            vicstatus[2] = RIU_nCLEAR;
            vicstatus[3] = RIU_nCLEAR;
            vicstatus[4] = RIU_nSET;
            break;
        default:
            break;
        }

    }
}

/**
 * @brief Handle RTI interrupts
 *
 * @details This function is called when an RTI interrupt occurs.
 * It processes the interrupt by checking the value of the notification
 * and taking appropriate action based on the notification value.
 *
 * @param[in] notification The notification value from the RTI.
 */
void rtiNotification(uint32 notification)
{
    /*  enter user code between the USER CODE BEGIN and USER CODE END. */
    /* Toggle HET pin 0 */
    /**< 1ms*/
    if (rtiNOTIFICATION_COMPARE0 == notification)
    {

    }
    /**<  50ms*/
    else if (rtiNOTIFICATION_COMPARE1 == notification)
    {

    }
    /**< 25 ms*/
    else if (rtiNOTIFICATION_COMPARE2 == notification)
    {

    }
    /**<  10 ms*/
    else if (rtiNOTIFICATION_COMPARE3 == notification)
    {
        gu32TimerCounter1++;
        gu32TimerCounter++;
        gu32VimFailureTimCounter++;
        gu32LinkCheckCntr++;

        if (gu32TimerCounter1 == 34)
        {
            gu32TimerCounter1 = RIU_nCLEAR;
            timerflag = RIU_nSET;
            RIU_vUpdateHealthStatus();
        }
        if (gu32TimerCounter == 30)
        {
            gu32TimerCounter = RIU_nCLEAR;
            u32VIMfailureCntr1++;
            RIU_2002VICheartbeatMessage(VIC_HLTPKT, DipInfo.u8Address); // tx data based on Dip switch
            RIU_vDetectVicSlot();
            /*  Send hot standby heartbeat message*/
            RIU_v2oo2HotstandbyHeartBeatMessage();
        }
        if (gu32VimFailureTimCounter == 100)
        {
            gu32VimFailureTimCounter = 0;
            RIU_st2002Flags.failuredetectflag = 1;
            RIU_st2002Flags.proceesUdpData = 1;
        }

        if(gu32LinkCheckCntr==500)
        {
            gu32LinkCheckCntr=0;
            RIU_st2002Flags.EtehrnetlinkCheck=1;
        }
    }
}

/**
 * @brief Notification function for CAN Message Box
 *
 * This function is called by the CAN peripheral as soon as a message is received
 * in one of the CAN message boxes. This function is responsible for handling the
 * received message and storing the data in the appropriate variables.
 *
 * @param[in] node Pointer to CAN node
 * @param[in] messageBox Message box number of CAN node
 */

// Main notification function
void canMessageNotification(canBASE_t *node, uint32_t messageBox)
{
    volatile static uint32_t su32_messageBox = 0;
    if (node != canREG1)
        return;
    su32_messageBox = messageBox;

    gu16canAdd = canGetID(canREG1, messageBox);  // retrieve ID
    canGetData(canREG1, messageBox, u8HealthMSGData);

    if (su32_messageBox == 5)
    {
        messageBoxReceived[0] = true;

    }

    if (messageBox == canMESSAGE_BOX2)
    {

        // Handle VIC and MCU data based on the ID and enabled features
        handleVICData(gu16canAdd, u8HealthMSGData);
        handleMCUData(gu16canAdd, u8HealthMSGData);
        RIU_vUpdateVicFailureFlags(gu16canAdd);

    }
    else if (messageBox == canMESSAGE_BOX7)
    {

        handleGPSData(gu16canAdd, u8HealthMSGData);
    }
    else if (messageBox == canMESSAGE_BOX5)
    {
        // Handle VIM message data
        copyVIMMessageData(gu16canAdd, u8HealthMSGData, gua8_CanIoData);

        RIU_vUpdateVimFailureFlags(gu16canAdd);

    }
    else
    {
        /*NOP*/
    }
}

// Function to handle VIC data reception

/**
 * @brief Handles GPS data reception
 *
 * This function handles GPS data reception and copies the received data to
 * gu8_gpsBuff. It also sets the GpsDatetimeflag if the received data is from
 * MCU3 and the message ID is 0x2001.
 *
 * @param[in] gu16canAdd CAN message ID to identify GPS data
 * @param[in] data Pointer to the received data buffer
 */
void handleGPSData(uint16_t lu16canAdd, uint8_t *data)
{
    /* Ensure that the data pointer is not NULL before proceeding */
    if (data == NULL)
    {
        return; /* Exit if data is invalid */
    }
    if ((enableMCU3 == RIU_nSET) && (lu16canAdd == 0x2001))
    {
        memcpy(gu8_gpsBuff, data, 8);
        RIU_st2002Flags.GpsDatetimeflag = RIU_nSET;
    }
    else
    {
        /*NOP*/
    }

}
// Function to handle VIC data reception

/**
 * @brief Handles VIC data reception
 *
 * This function handles VIC data reception and copies the received data to
 * u8HealthVICMSGData. It also sets the appropriate flags in RIU_st2002Flags
 * structure based on the received message ID.
 *
 * @param[in] gu16canAdd CAN message ID to identify VIC data
 * @param[in] data Pointer to the received data buffer
 */
void handleVICData(uint16_t lu16canAdd, uint8_t *data)
{
    /* Ensure that the data pointer is not NULL before proceeding */
    if (data == NULL)
    {
        return; /* Exit if data is invalid */
    }

    if ((enableVIC2 == RIU_nSET) && (lu16canAdd == 0x1001))
    {
        // in vic2 data receving from VIC 1
        gu16canAddVIC = lu16canAdd;
        memcpy(u8HealthVICMSGData, data, 8);
        RIU_st2002Flags.u8_VIC1DataReceived = RIU_nSET;
    }
    else if ((enableVIC1 == RIU_nSET) && (lu16canAdd == 0x1003))
    {
        gu16canAddVIC = lu16canAdd;
        memcpy(u8HealthVICMSGData, data, 8);
        RIU_st2002Flags.u8_VIC2DataReceived = RIU_nSET;
    }
    else
    {
        gu16canAddVIC = lu16canAdd;
    }

}
/**
 * @brief Function to handle MCU data reception.
 * @param lu16canAdd CAN message ID to identify MCU data.
 * @param data Pointer to the received data buffer.
 */
void handleMCUData(uint16_t lu16canAdd, const uint8_t *data)
{
    /* Ensure that the data pointer is not NULL before proceeding */
    if (data == NULL)
    {
        return; /* Exit if data is invalid */
    }
    static uint8_t u8Cnt = RIU_nCLEAR;
    static uint8_t u8pos = RIU_nCLEAR;

    /* Handle MCU1 data when connected to VIC1 */
    if ((enableMCU3 == RIU_nSET) && (enableVIC1 == RIU_nSET)
            && (lu16canAdd == 0x1101U))
    {
        gu16canAddVICMCU = lu16canAdd;
        u8Cnt++;
        (void) memcpy(&u8HealthTempMSGData[u8pos], data, 8U); /* Copy received data */
        u8pos += 8;
        if (u8Cnt == 2)
        {
            u8pos = RIU_nCLEAR;
            u8Cnt = RIU_nCLEAR;
            RIU_st2002Flags.u8_MCU1DataReceived = 1U; /* Set flag to indicate MCU1 data received */
        }
    }
    /* Handle MCU3 data when connected to VIC1 */
    else if ((enableMCU1 == RIU_nSET) && (enableVIC1 == RIU_nSET)
            && (lu16canAdd == 0x1102U))
    {
        gu16canAddVICMCU = lu16canAdd;
        u8Cnt++;
        (void) memcpy(&u8HealthTempMSGData[u8pos], data, 8U); /* Copy received data */
        u8pos += 8;
        if (u8Cnt == 2)
        {
            u8pos = RIU_nCLEAR;
            u8Cnt = RIU_nCLEAR;

            RIU_st2002Flags.u8_MCU3DataReceived = 1U;
        }
    }
    /* Handle MCU1 data when connected to VIC2 */
    else if ((enableMCU3 == RIU_nSET) && (enableVIC2 == RIU_nSET)
            && (lu16canAdd == 0x1103U))
    {
        gu16canAddVICMCU = lu16canAdd;
        u8Cnt++;
        (void) memcpy(&u8HealthTempMSGData[u8pos], data, 8U); /* Copy received data */
        u8pos += 8;
        if (u8Cnt == 2)
        {
            u8pos = RIU_nCLEAR;
            u8Cnt = RIU_nCLEAR;
            RIU_st2002Flags.u8_MCU1DataReceived = 1U;
        }
    }
    /* Handle MCU3 data when connected to VIC2 */
    else if ((enableMCU1 == RIU_nSET) && (enableVIC2 == RIU_nSET)
            && (lu16canAdd == 0x1104U))
    {
        gu16canAddVICMCU = lu16canAdd;
        u8Cnt++;
        (void) memcpy(&u8HealthTempMSGData[u8pos], data, 8U); /* Copy received data */
        u8pos += 8;
        if (u8Cnt == 2)
        {
            u8pos = RIU_nCLEAR;
            u8Cnt = RIU_nCLEAR;
            RIU_st2002Flags.u8_MCU3DataReceived = 1U;
        }
    }
    else
    {
        /* If none of the conditions match, log or handle the unrecognized state */
        // LOG_ERROR("Unrecognized message ID or configuration mismatch.");
    }
}
// Function to copy VIM message data based on ID

/**
 * @brief Copies VIM message data based on ID and enabled features
 *
 * This function is used to copy VIM message data into the appropriate section of gua8_CanIoData based on the received CAN ID and enabled features.
 *
 * @param[in] lu16canAdd Received CAN ID
 * @param[in] src Source data array
 * @param[in] dest Destination data array
 *
 * @return void
 */
void copyVIMMessageData(uint16_t lu16canAdd, uint8_t *src, uint8_t *dest)
{
    if ((src == NULL) && (dest == NULL))
    {
        return; /* Exit if data is invalid */
    }

    int offset = RIU_nCLEAR;
    if (enableMCU3)
    {
        switch (lu16canAdd)
        {
        case 0x5141:
            offset = RIU_nCLEAR;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5142:
            offset = 4;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5143:
            offset = 8;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5144:
            offset = 12;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        default:
            break;
        }

    }
    else if (enableMCU1)
    {
        switch (lu16canAdd)
        {
        case 0x5181:
            offset = RIU_nCLEAR;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5182:
            offset = 4;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5183:
            offset = 8;
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            break;
        case 0x5184:
            memcpy(dest + offset, src, 4);
            RIU_st2002Flags.send_RIU_PKT = RIU_nSET;
            offset = 12;
            break;
        default:
            break;
        }

    }
    else
    {
        /*NOP*/
    }
}

/* Delay function (MISRA-compliant) */

/**
 * @brief Delay function using the 32-bit timer variable.
 *
 * @param[in] delay_ms  The delay period in milliseconds.
 *
 * @details This function waits until the specified delay period has elapsed.
 * The function uses the non-blocking 32-bit timer variable (timer_ticks) and
 * is therefore suitable for use in interrupt handlers and other time-critical
 * code. The function is designed to be MISRA-compliant.
 */
void Delay_ms(uint32_t delay_ms)
{
    /* Store the current tick count */
    const uint32_t start_time = timer_ticks;

    /* Wait for the delay to elapse */
    while ((timer_ticks - start_time) < delay_ms)
    {
        /* Intentional empty loop - allowed in MISRA as a "waiting state" */
    }
}
