/*******************************************************************************
 *
 * @FileName         : user_station_decode.c
 * @Version          : V1.0.0
 * @Date             : 24-04-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#include "user_station_decode.h"

#define BLUE 0
#define RED 1

#define RIU_BLUE_RING 0
#define RIU_RED_RING 1
// blue riu nos data
uint8_t RIU_DEC_BUF[2][6][16];
uint8_t u8riu_no = 0;
uint8_t u8dir_no = 0;



uint8_t redStation_ip[4] = { 192, 255, 2, 190 };
uint8_t blueStation_ip[4] = { 192, 254, 2, 190 };


/*----------------------------------------------DECODE RIU PACKET--------------------------------------------------------*/

/**
 * @brief      Extracts the packet from the station to Riu and puts it in the RIU_DEC_BUF
 * @param[in]  receivebuffer  The received buffer
 * @return     error code
 *
 *            This function extracts the packet from the station to Riu and puts it in the RIU_DEC_BUF.
 *            It checks the validity of the packet and stores the data in the RIU_DEC_BUF.
 *            It also checks the crc and returns the error code.
 *
 *            @note    This function will be called from the interrupt service routine.
 */
uint8_t RIU_u8STNextracT_Pkt_function(uint8_t *receivebuffer)
{
    // this is the ip address 192.254.2.1
    //  2nd octet is blue or red ring (254 or 255)
    //  the last 4th octet is for RIU_addresses(1,2,3,4,5,6)

    // // blue riu nos data
    // uint8_t RIU_DEC_BUF[2][6][16];
    uint8_t u8buf_pos = 0;

    uint16_t u16len = 0;
    uint32_t frame_number = 0;
    uint8_t error=0;
    // we have to check verc here
    if ((receivebuffer[0] == 0xA5) && (receivebuffer[1] == 0xC3))
    {
        u8buf_pos += 2;
        // check the station ip
        // check the function code'__ todo
        // check the crc mandatory in ccs__todo
        // 192==192 254==254 2==1
        if ((blueStation_ip[0] == receivebuffer[2])
                && (blueStation_ip[1] == receivebuffer[3])
                && (blueStation_ip[2] == receivebuffer[4]))
        {
            u8riu_no = receivebuffer[5];
            if ((blueStation_ip[0] == receivebuffer[6])
                    && (blueStation_ip[1] == receivebuffer[7])
                    && (blueStation_ip[2] == receivebuffer[8])
                    && (blueStation_ip[3] == receivebuffer[9]))
            {
                // printf("\nstation ip is valid\n");
                //  u8RIU_funcode = receivebuffer[10];
                frame_number = (receivebuffer[11] << 16)
                        | (receivebuffer[12] << 8) | (receivebuffer[13]);
                u16len = (((receivebuffer[14]) << 8) | ((receivebuffer[15])));

                u8buf_pos = 16;
                RIU_st_RiuDirection[u8dir_no].RIU_stbluering[u8riu_no].U8blueriu1 =
                        1;
                uint32_t i = 0;
                for (i = START; i < BUFMAX_SIZE; i++)
                {
                    RIU_DEC_BUF[BLUE_ID][u8riu_no - DEC_ONCE][i] =
                            receivebuffer[u8buf_pos];
                    u8buf_pos += 1;
                }
                //    u8status = receivebuffer[u8buf_pos];
                RIU_vblue_one();
            }
            else
            {
                return error;
            }
        }
        else if ((redStation_ip[0] == receivebuffer[0])
                && (redStation_ip[1] == receivebuffer[1])
                && (redStation_ip[2] == receivebuffer[2]))
        {
            u8riu_no = receivebuffer[5];
            if ((redStation_ip[0] == receivebuffer[6])
                    && (redStation_ip[1] == receivebuffer[7])
                    && (redStation_ip[2] == receivebuffer[8])
                    && (redStation_ip[3] == receivebuffer[9]))
            {
                // printf("\nstation ip is valid\n"
                //  u8RIU_funcode = receivebuffer[10];
                frame_number = (receivebuffer[11] << 16)
                        | (receivebuffer[12] << 8) | (receivebuffer[13]);
                u16len = (((receivebuffer[14]) << 8) | ((receivebuffer[15])));

                u8buf_pos = 16;
                RIU_st_RiuDirection[u8dir_no].RIU_stRedring[u8riu_no].U8redriu1 =
                        1;
                uint32_t i = 0;
                for (i = START; i < BUFMAX_SIZE; i++)
                {
                    RIU_DEC_BUF[RED_ID][u8riu_no - DEC_ONCE][i] =
                            receivebuffer[u8buf_pos];
                    u8buf_pos += 1;
                }
                RIU_vRed_one();
            }
            else
            {
                return error;
            }
        }
        else
        {
            // indicates error
            return error;
        }
    }
    else
    {
         error =23;
    }
    return error;
}

/*-----------------------------------------------RIU_BLUE_DATAPKT----------------------------------------------------------------------*/

/**
 * @brief Processes a blue ring data packet for a specific RIU.
 *
 * @details This function checks if the `U8blueriu1` flag is set to 1 for the current RIU in the blue ring.
 * If the flag is set, it resets the flag to 0 and copies data from the `RIU_DEC_BUF` to the `RIU_vRing`.
 * It also sets a processed flag to indicate the operation was successful.
 * If the flag is not set, the function returns 1 to indicate that no processing occurred.
 *
 * @return 0 if the data is processed successfully, 1 if no processing occurred.
 */

uint8_t RIU_vblue_one()
{
    // printf("\nBLUE_RING_RIU_DATA :");

    if (RIU_st_RiuDirection[u8dir_no].RIU_stbluering[u8riu_no].U8blueriu1 == 1)
    {
        RIU_st_RiuDirection[u8dir_no].RIU_stbluering[u8riu_no].U8blueriu1 = 0;
        buf_copy(RIU_st_RiuDirection->RIU_vRing,
                 &RIU_DEC_BUF[BLUE_ID][u8riu_no - DEC_ONCE][0], BUFFER_SIZE);

//        for (uint8_t i = START; i < BUFMAX_SIZE; i++)
//        {
//        //    printf(" %02x", RIU_st_RiuDirection->RIU_vRing[i]);
//        }
        u8processed_flag = 1;
    }
    else
    {
        return 1;
    }
    return 0u;
}
/*-----------------------------------------------RIU_RED_DATAPKT----------------------------------------------------------------------*/
uint8_t RIU_vRed_one()
{
    // printf("\nRED_RING_RIU_DATA%d: ",u8riu_no);
    if (RIU_st_RiuDirection[u8dir_no].RIU_stRedring[u8riu_no].U8redriu1 == 1)
    {
        RIU_st_RiuDirection[u8dir_no].RIU_stRedring[u8riu_no].U8redriu1 = 0;
        buf_copy(RIU_st_RiuDirection->RIU_vRing,
                 &RIU_DEC_BUF[RED_ID][u8riu_no - DEC_ONCE][0], BUFFER_SIZE);

//        for (uint8_t i = START; i < BUFMAX_SIZE; i++)
//        {
//          //  printf(" %02x", RIU_st_RiuDirection->RIU_vRing[i]);
//        }
        u8processed_flag = 1;
    }
    else
    {
        return 1;
    }
    return 0u;
}

/*-------------------------------------------------------------BUFFER_COPY FROM SOURCE TO DESTINATION--------------------------------------------------------*/
uint8_t buf_copy(uint8_t *u8update_buf, uint8_t *buf, uint16_t buf_size)
{
    uint8_t loop = 0;
    for (loop = 0; loop < buf_size; loop++)
    {
        u8update_buf[loop] = buf[loop];
    }
    return 0;
}
