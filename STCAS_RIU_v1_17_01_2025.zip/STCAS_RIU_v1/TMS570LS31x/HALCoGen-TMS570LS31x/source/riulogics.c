/*

 /** @file riulogics.c
 *   @brief RIU logics Source File
 *   @date 09-Jan-2025
 *   @version 01.00.01
 *
 *   This file contains:
 *   - API Functions
 *   - Interrupt Handlers
 *   .
 *   which are relevant for the riu application .
 */

/*******************************************************************************
 *
 * @FileName         : RIU_LOGICS.c
 * @Version          : V1.0.0
 * @Date             :
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/

#include "gio.h"
#include "reg_mibspi.h"
#include "mibspi.h"
#include "can.h"
#include "riulogics.h"
#include "stdint.h"
#include "RIU_FRAME_DATA_PKT.h"
#include "stdio.h"
#include "user_constants.h"
#include "lwip_main.h"

_Bool gbPowerOnFlag = 0; // Initialize the flag
/** @brief DIP switch value. */
extern uint8_t dipSwitchValue;
/** @brief Enable VIC1 flag. */
extern uint8_t enableVIC1;
/** @brief Enable VIC2 flag. */
extern uint8_t enableVIC2;
/** @brief Enable MCU3 flag. */
extern uint8_t enableMCU3;
/** @brief Enable MCU1 flag. */
extern uint8_t enableMCU1;
/** @brief VIC status array. */
extern uint8_t vicstatus[5];

/** @brief Red IP address. */
uint8_t gu8redip[4] = { 0 };
/** @brief Blue IP address. */
uint8_t gu8blueip[4] = { 0 };
/** @brief Red IP gateway address. */
uint8_t gu8redipGateway[4] = { 0 };
/** @brief Blue IP gateway address. */
uint8_t gu8blueipGateway[4] = { 0 };
/** @brief Red MAC address. */
uint8_t gu8redmac[6] = { 0 };
/** @brief Blue MAC address. */
uint8_t gu8bluemac[6] = { 0 };

/** @brief VIM failure counter 1. */
uint32_t u32VIMfailureCntr1 = RIU_nINITVALUE;
/** @brief VIM failure counter 2. */
uint32_t u32VIMfailureCntr2 = RIU_nINITVALUE;

/** @brief Array of expected VIM addresses. */
const uint16_t vimAddresses[NUM_VIM_ADDRESSES] = {
VIM1A_ADDRESS,
                                                   VIM1B_ADDRESS, VIM2A_ADDRESS,
                                                   VIM2B_ADDRESS,
                                                   VIM3A_ADDRESS,
                                                   VIM3B_ADDRESS,
                                                   VIM4A_ADDRESS,
                                                   VIM4B_ADDRESS };

/** @brief VIM failure flags. */
uint8_t vimFlags[NUM_VIM_ADDRESSES] = { 0 };
/** @brief VIC failure flags. */
uint8_t vicFlags[4] = { 0 };

/** @brief Array of expected VIC addresses. */
const uint16_t vicAddresses[2] = {
VIC1MCU1_ADDRESS,
                                   VIC2MCU1_ADDRESS };

/** @brief Failure count threshold. */
#define FAILURECOUNT (3u)
/** @brief Maximum consecutive count. */
#define MAX_CONSECUTIVE_COUNT 10u

/** @brief Overall VIM health status. */
uint8_t gu8VimOverallHealth = RIU_nINITVALUE;
/** @brief Overall VIC health status. */
uint8_t gu8VicoverallHealth = RIU_nINITVALUE;

/** @brief VIC counters for consecutive occurrences. */
uint8_t vicCounters[4] = { 0 };
/** @brief VIC health counters for consecutive occurrences. */
uint8_t vicHealthCounters[4] = { 0 };
/** @brief VIM counters for consecutive occurrences. */
uint8_t vimCounters[10] = { 0 };

/** @brief PCB failure flag status. */
RIU_stPcbFailureflagStatus_t failureFlags = { 0 };
/** @brief GPS buffer. */
uint8_t gu8_gpsBuff[8] = { 0 };
/** @brief General purpose index. */
uint8_t i = RIU_nINITVALUE;
/** @brief General length variable. */
uint16_t Glength = RIU_nINITVALUE;
/** @brief CAN base MCU address. */
uint16_t CAN_base_mcu_address = RIU_nINITVALUE;
/** @brief CAN base address. */
uint16_t CAN_base_address = 0x1100;
/** @brief VIC health packet. */
uint8_t VIC_HLTPKT[8] = { 0 };
/** @brief VIC MCU data test packet. */
uint8_t VIC_MCUDATATEST[8] = { 0 };
/** @brief CAN MCU base address. */
uint16_t CAN_mcuBase_address = RIU_nINITVALUE;
/** @brief CAN VIC base address. */
uint16_t CAN_VICBaseAddress = RIU_nINITVALUE;
/** @brief CAN VIC GPS address. */
uint16_t CAN_VICGpsAddress = RIU_nINITVALUE;
/** @brief CAN VIC link failure address. */
uint16_t CAN_VICLinkFailAddr = RIU_nINITVALUE;

/** @brief RIU 2002 flags. */
RIU_st2002Flags_t RIU_st2002Flags;
/** @brief RIU flags. */
Riu_stFlags_t Riu_stFlag;

/** @brief DIP information. */
extern DipInfo_t DipInfo;
/** @brief Health temperature message data. */
extern uint8_t u8HealthTempMSGData[40];
/** @brief Health VIC message data. */
extern uint8_t u8HealthVICMSGData[8];
/** @brief Red IP address. */
extern uint8_t gu8redip[4];
/** @brief Blue IP address. */
extern uint8_t gu8blueip[4];
/** @brief CAN IO data. */
extern uint8_t gua8_CanIoData[32];
/** @brief Slot detection flag. */
extern uint8_t gu8_slotDetect;
/** @brief CAN address for VIC MCU. */
extern uint16_t gu16canAddVICMCU;

/** @brief Health data. */
uint8_t u8HealthData[3] = { 0u, 0u, 0u };
/** @brief Sequence number. */
volatile uint32_t gu32SeqNo = RIU_nINITVALUE;

/** @brief Blue ring IP address. */
uint8_t gu8_blueRingIp[4] = { 192, 254, 2, 190 };
/** @brief Red ring IP address. */
uint8_t gu8_redRingIp[4] = { 192, 255, 2, 190 };

/**
 * @brief LED state enumeration.
 */
typedef enum
{
    LED_OFF = 0, /**< LED is off. */
    LED_ON = 1 /**< LED is on. */
} LED_STATE;

/**
 * @brief Updates the health byte.
 */
static void RIU_vUpdateHealthByte(void);

/**
 * @brief Sets the message ID for CAN transmission.
 *
 * @param u8CANMsgBoxObj CAN message box object.
 * @param u8TxBit Transmission bit.
 * @param u8IdentifierType Identifier type.
 * @param u32MSGAdd Message address.
 * @return uint32_t Returns the message ID.
 */
static uint32_t RIU_u32SetMsgIDTx(uint8_t u8CANMsgBoxObj, uint8_t u8TxBit,
                                  uint8_t u8IdentifierType, uint32_t u32MSGAdd);
/**
 * @brief Returns the CAN address for the given dip switch value and base address.
 *
 * @param base_address The base address of the CAN bus.
 * @param dip_value The value read from the dip switch.
 *
 * @return The CAN address for the given dip switch value and base address.
 */
uint32_t RIU_u32CanAddress(uint32_t base_address, uint32_t dip_value)
{
    if (dip_value < 1 || dip_value > 4)
    {
        //  "Error: DIP switch value must be between 1 and 4.
        return base_address; // Return 0 as an error indicator
    }
    return (base_address + dip_value);
}

void RIU_vEnableLANCommunication(void)
{

    if (RIU_st2002Flags.processprimaryvic == RIU_nSET)

    {
        RIU_st2002Flags.processprimaryvic = 0;
        RIU_st2002Flags.primaryVICETHstatus = 1;
        RIU_vassignAddresses(dipSwitchValue, gu8redip, gu8blueip, gu8redmac,
                             gu8bluemac, gu8blueipGateway, gu8redipGateway);
        switch (DipInfo.u8Address)
        {
        case 1:

            EMAC_LwIP_Main(&gu8bluemac[0], &gu8blueip[0], &gu8blueipGateway[0]);

            break;
        case 2:
            EMAC_LwIP_Main(&gu8redmac[0], &gu8redip[0], &gu8redipGateway[0]);

            break;
        default:
            break;

        }

    }
    else if (RIU_st2002Flags.u32enableEmac == RIU_nSET)

    {
        static _Bool flag = 0;
        RIU_st2002Flags.u32enableEmac = 0;
        if (flag == 0)
        {
            RIU_vassignAddresses(dipSwitchValue, gu8redip, gu8blueip, gu8redmac,
                                 gu8bluemac, gu8blueipGateway, gu8redipGateway);

            flag = 1;

            switch (DipInfo.u8Address)
            {
            case 3:

                gu8bluemac[0] = 0x12;
                EMAC_LwIP_Main(&gu8bluemac[0], &gu8blueip[0],
                               &gu8blueipGateway[0]);
                RIU_st2002Flags.processReduentudpdata = 1;
                gu32SeqNo = 0;

                break;
            case 4:
                gu8redmac[0] = 0x13;
                EMAC_LwIP_Main(&gu8redmac[0], &gu8redip[0],
                               &gu8redipGateway[0]);
                RIU_st2002Flags.processReduentudpdata = 1;

                break;
            default:
                break;

            }
        }
    }
    else
    {
        /*Nop */
    }

}

/**
 * @brief Assigns IP and MAC addresses to the RED and BLUE rings based on the
 * given dip switch value.
 *
 * @param dipSwitchValue The value read from the dip switch.
 * @param pu8redip Pointer to the array where the RED ring IP should be stored.
 * @param pu8blueip Pointer to the array where the BLUE ring IP should be stored.
 * @param pu8redmac Pointer to the array where the RED ring MAC should be stored.
 * @param pu8bluemac Pointer to the array where the BLUE ring MAC should be
 Stored.//1234 is a station_address       5678 RIU_addresss
 */
#define ARECA 1
void RIU_vassignAddresses(uint8_t dipSwitchValue, uint8_t *pu8redip,
                          uint8_t *pu8blueip, uint8_t *pu8redmac,
                          uint8_t *pu8bluemac, uint8_t *pu8bluegateway,
                          uint8_t *pu8Redgateway)
{
    /* Extract RIU Address from the dip switch value (use the last 6 bits)*/
    uint8_t StationAddress = (dipSwitchValue >> 4) & 0x0F;
    uint8_t riuAddress = dipSwitchValue & 0x0F;
    uint8_t i = RIU_nINITVALUE;
    /* Base IP addresses for RED and BLUE rings*/
    uint8_t redRingIP[4] = { 192, 255, 0, 0 };
    redRingIP[2] = StationAddress;
    redRingIP[3] = riuAddress;
    uint8_t blueRingIP[4] = { 192, 254, 0, 0 };
    blueRingIP[2] = StationAddress;
    blueRingIP[3] = riuAddress;

    /* Base IP addresses for RED and BLUE rings*/
    uint8_t redRingIPGateway[4] = { 192, 255, 0, 220 };
    redRingIPGateway[2] = StationAddress;
    uint8_t blueRingIPGateway[4] = { 192, 254, 0, 220 };
    blueRingIPGateway[2] = StationAddress;
#if ARECA
    /* Base MAC addresses (example base, modify as per your system's requirement)
     For BLUE ring (last byte is riuAddress)*/
    uint8_t macBlueBase[6] = { 0x11, 0x1A, 0x2B, 0x3C, 0, 0 };
    macBlueBase[4] = StationAddress;
    macBlueBase[5] = riuAddress;
    /* For RED ring (last byte is riuAddress + 1)*/
    uint8_t macRedBase[6] = { 0x11, 0x1A, 0x2B, 0x3C, StationAddress, riuAddress
                                      + 1 };
    macRedBase[4] = StationAddress;
    macRedBase[5] = riuAddress;
#elif !ARECA
    /* Base MAC addresses (example base, modify as per your system's requirement)
     For BLUE ring (last byte is riuAddress)*/
    uint8_t macBlueBase[6] = { 0x70, 0xB3, 0xD5, 0xF1, 0, 0 };
    macBlueBase[4] = 0x50 + (StationAddress & 0x0F);
    macBlueBase[5] = riuAddress;
    /* For RED ring (last byte is riuAddress + 1)*/
    uint8_t macRedBase[6] = { 0x70, 0xB3, 0xD5, 0xF1, 0, 0 };

    macRedBase[4] = 0x50 + (StationAddress & 0x0F);
    macRedBase[5] = riuAddress + 1;

#else
        // teams engineers fix code for checking the valid ADDRESS
        // uint8_t macRedBase[6] = { 0x11, 0x1A, 0x2B, 0x3C, 0x4d, 0x5f };
        uint8_t macBlueBase[6] =
        {   0x4c, 0xdf, 0x3d, 0x00, 0x1a, 0x1b};
        uint8_t macBlueBase[6];
#endif
    for (i = 0; i < 4; i++)
    {
        pu8redip[i] = redRingIP[i]; /**< Assign RED ring IP address */
        pu8blueip[i] = blueRingIP[i]; /**< Assign BLUE ring IP address */
    }
    for (i = 0; i < 6; i++)
    {
        pu8bluemac[i] = macBlueBase[i]; /**< Assign BLUE ring MAC address */
        pu8redmac[i] = macRedBase[i]; /**< Assign RED ring MAC address */
    }
    for (i = 0; i < 4; i++)
    {
        pu8Redgateway[i] = redRingIPGateway[i]; /**< Assign RED ring gateway IP address */
        pu8bluegateway[i] = blueRingIPGateway[i];

    }
    gu8_redRingIp[2] = StationAddress; /**< Set global RED ring IP station address */
    gu8_blueRingIp[2] = StationAddress; /**< Set global BLUE ring IP station address */
}

/**
 * @brief Switches the LEDs on.
 *
 * @details This function is used to switch the LED[1-4] on.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLedsOn(void)
{
    RIU_vLed1On();
    RIU_vLed2On();
    RIU_vLed3On();
    RIU_vLed4On();

}
/**
 * @brief Switches the LED1 on.
 *
 * @details This function is used to switch the LED[1-4]  off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLedsOff(void)
{
    RIU_vLed1Off();
    RIU_vLed2Off();
    RIU_vLed3Off();
    RIU_vLed4Off();

}
/**
 * @brief Switches the LED1 on.
 *
 * @details This function is used to switch the LED1 on.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed1On(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_1, LED_ON); //E16

}

/**
 * @brief Switches the LED1 off.
 *
 * @details This function is used to switch the LED1 off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed1Off(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_1, LED_OFF); //E16
}
/**
 * @brief Toggles the LED1 on and off.
 *
 * @details This function is used to toggle the LED1 on and off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLED1Toggle(void)
{
    gioToggleBit(mibspiPORT5, PIN_SIMO_1); //E16

}

/**
 * @brief Switches the LED1 on.
 *
 * @details This function is used to switch the LED1 on.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed3On(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_3, LED_ON); //E16
}

/**
 * @brief Switches the LED1 off.
 *
 * @details This function is used to switch the LED1 off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed3Off(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_3, LED_OFF); //E16
}
/**
 * @brief Toggles the LED1 on and off.
 *
 * @details This function is used to toggle the LED1 on and off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLED3Toggle(void)
{
    gioToggleBit(mibspiPORT5, PIN_SIMO_3); //E16
}

/**
 * @brief Switches the LED1 on.
 *
 * @details This function is used to switch the LED1 on.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed2On(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_2, LED_ON); //E16
}

/**
 * @brief Switches the LED1 off.
 *
 * @details This function is used to switch the LED1 off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed2Off(void)
{
    gioSetBit(mibspiPORT5, PIN_SIMO_2, LED_OFF); //E16
}
/**
 * @brief Toggles the LED1 on and off.
 *
 * @details This function is used to toggle the LED1 on and off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLED2Toggle(void)
{
    gioToggleBit(mibspiPORT5, PIN_SIMO_2); //E16
}

/**
 * @brief Switches the LED1 on.
 *
 * @details This function is used to switch the LED1 on.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed4On(void)
{
    gioSetBit(mibspiPORT5, PIN_SOMI_1, LED_ON); //E16
}

/**
 * @brief Switches the LED1 off.
 *
 * @details This function is used to switch the LED1 off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLed4Off(void)
{
    gioSetBit(mibspiPORT5, PIN_SOMI_1, LED_OFF); //E16
}
/**
 * @brief Toggles the LED1 on and off.
 *
 * @details This function is used to toggle the LED1 on and off.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vLED4Toggle(void)
{
    gioToggleBit(mibspiPORT5, PIN_SOMI_1); //E16
}

/**
 * @brief turn on the RIU_vErrorLedOn .
 *
 * @details This function is used to on the RIU_vErrorLedOn on .
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vErrorLedOn(void)
{
    gioSetBit(gioPORTB, 2, LED_ON); //E16
}

/**
 * @brief turn on the RIU_vErrorLedOn .
 *
 * @details This function is used to on the RIU_vErrorLedOn on .
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vErrorLedOff(void)
{
    gioSetBit(gioPORTB, 2, LED_OFF); //E16
}
/**
 * @brief turn on the RIU_vConfigLedOn .
 *
 * @details This function is used to on the RIU_vConfigLedOn on .
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vConfigLedOn(void)
{
    gioSetBit(gioPORTB, 3, LED_ON);
}
/**
 * @brief turn on the RIU_vConfigLedOff .
 *
 * @details This function is used to on the RIU_vConfigLedOff off .
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vConfigLedOff(void)
{
    gioSetBit(gioPORTB, 3, LED_OFF);
}

/**
 * @brief Reads the current state of the DIP switches.
 *
 * @details This function is used to read the current state of the DIP switches.
 *
 * @param[in] None
 *
 * @return uint8_t The current state of the DIP switches. The state of the DIP
 * switches is returned as an 8-bit value. Each bit in the returned value
 *  corresponds to one of the DIP switches, with the least significant bit
 *  being the first switch and the most significant bit being the last switch.
 *  A value of 0 for a bit indicates that the switch is in the off position, and
 *  a value of 1 indicates that the switch is in the on position.
 */
uint8_t RIU_u8DipSwitchRead(void)
{

    uint8_t u8dipvalue = RIU_nINITVALUE;
    u8dipvalue = gioGetBit(gioPORTA, 0) << 7
            | gioGetBit(gioPORTA, 1) << RIU_nSHIFT_POS6
            | gioGetBit(gioPORTA, 2) << RIU_nSHIFT_POS5
            | gioGetBit(gioPORTA, 3) << RIU_nSHIFT_POS4
            | gioGetBit(gioPORTA, 4) << RIU_nSHIFT_POS3
            | gioGetBit(gioPORTA, 5) << RIU_nSHIFT_POS2
            | gioGetBit(gioPORTA, 6) << 1 | gioGetBit(gioPORTA, 7) << 0u;

    return (u8dipvalue);

}

/**
 * @brief Compares two buffers.
 *
 * This function compares two buffers of the same length and returns a status based on the comparison.
 *
 * @param u8Buffer1 Pointer to the first buffer.
 * @param u8Buffer2 Pointer to the second buffer.
 * @param u8BufferLength Length of the buffers to compare.
 * @return uint8_t Returns RIU_nRETSUCCESS if buffers are different, otherwise returns RIU_nRETFAILURE.
 */
uint8_t RIU_u8BufferCmparison(uint8_t *u8Buffer1, uint8_t *u8Buffer2,
                              uint8_t u8BufferLength)
{
    /**
     * @brief Initialize the comparison index to the initial value.
     */
    uint8_t u8BufferCmparison = RIU_nINITVALUE;

    /**
     * @brief Loop through each element of the buffers.
     */
    for (u8BufferCmparison = RIU_nINITVALUE; u8BufferCmparison < u8BufferLength;
            u8BufferCmparison++)
    {
        /**
         * @brief Check if the current elements of the buffers are different.
         */
        if (u8Buffer1[u8BufferCmparison] != u8Buffer2[u8BufferCmparison])
        {
            /**
             * @brief Return success if any element is different.
             */
            return (RIU_nRETSUCCESS);
        }
    }

    /**
     * @brief Return failure if all elements are the same.
     */
    return (RIU_nRETFAILURE);
}
/**
 * @brief This function is used to power shutdown the system
 *
 * @details This function is called when the MCU's in VIC 1 and VIC 2 are not
 * sending the HeartBeat message over CAN bus.
 * This function is called when the MCU's in VIC 1 and VIC 2 are not sending
 *  the HeartBeat message over CAN bus.
 *
 * @param[in] None
 *
 * @return None
 */
void RIU_vPowwershutdown(void)
{
    if (RIU_st2002Flags.gu8_powershoutdown == RIU_nSUCCESS)
    {
        RIU_st2002Flags.gu8_powershoutdown = RIU_nINITVALUE;
        //      RIU_vLed1On();

    }
}

/**
 * @brief Sends a heartbeat message to the VIC.
 *
 * This function sends a heartbeat message to the VIC based on the CAN base address.
 *
 * @param u8ptru8HeartBeat Pointer to the heartbeat message.
 * @param u8dipvalue DIP switch value.
 */
void RIU_2002VICheartbeatMessage(uint8_t *u8ptru8HeartBeat, uint8_t u8dipvalue)
{
    /**
     * @brief Check if the CAN base address is 0x1001.
     */
    if (CAN_VICBaseAddress == 0x1001)
    {
        /**
         * @brief Initialize board address and message arbitration value.
         */
        uint32_t u32boardAdd = 0;
        uint32_t u32msgArbVal = 0;
        // uint16_t u16Cnt = 0; // Commented out counter variable.

        /**
         * @brief Calculate the board address.
         */
        u32boardAdd = u8dipvalue + VIC_CAN_BASE_ADDRESS;

        /**
         * @brief Set the message ID for transmission.
         */
        u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX1, CANMSGTYPETX,
        CANID_EXTENDED_IDENTIFIER,
                                         u32boardAdd);

        /**
         * @brief Update the CAN message ID.
         */
        canUpdateID(canREG1, canMESSAGE_BOX1, u32msgArbVal);

        /**
         * @brief Transmit the heartbeat message.
         */
        canTransmit(canREG1, canMESSAGE_BOX1, u8ptru8HeartBeat);

        /**
         * @brief Wait until the message is transmitted or an error occurs.
         */
        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX1))
        {

            /**
             * @brief on the error LED the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;
                //RIU_vErrorLedOn();
            }
            else
            {
                //   RIU_vErrorLedOff();
            }
        }
    }
    /**
     * @brief Check if the CAN base address is 0x1003.
     */
    else if (CAN_VICBaseAddress == 0x1003)
    {
        /**
         * @brief Initialize board address and message arbitration value.
         */
        uint32_t u32boardAdd = 0;
        uint32_t u32msgArbVal = 0;
        // uint16_t u16Cnt = 0; // Commented out counter variable.

        /**
         * @brief Calculate the board address.
         */
        u32boardAdd = u8dipvalue + VIC_CAN_BASE_ADDRESS;

        /**
         * @brief Set the message ID for transmission.
         */
        u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX1, CANMSGTYPETX,
        CANID_EXTENDED_IDENTIFIER,
                                         u32boardAdd);

        /**
         * @brief Update the CAN message ID.
         */
        canUpdateID(canREG1, canMESSAGE_BOX1, u32msgArbVal);

        /**
         * @brief Transmit the heartbeat message.
         */
        canTransmit(canREG1, canMESSAGE_BOX1, u8ptru8HeartBeat);

        /**
         * @brief Wait until the message is transmitted or an error occurs.
         */
        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX1))
        {
            /**
             * @brief Break the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;
                //RIU_vErrorLedOn();
            }
            else
            {
                //  RIU_vErrorLedOff();
            }

        }
    }
    /**
     * @brief Check if the CAN base address is 0x1002.
     */
    else if (CAN_VICBaseAddress == 0x1002)
    {
        /**
         * @brief Initialize board address and message arbitration value.
         */
        uint32_t u32boardAdd = 0;
        uint32_t u32msgArbVal = 0;
        // uint16_t u16Cnt = 0; // Commented out counter variable.

        /**
         * @brief Calculate the board address.
         */
        u32boardAdd = u8dipvalue + VIC_CAN_BASE_ADDRESS;

        /**
         * @brief Set the message ID for transmission.
         */
        u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX1, CANMSGTYPETX,
        CANID_EXTENDED_IDENTIFIER,
                                         u32boardAdd);

        /**
         * @brief Update the CAN message ID.
         */
        canUpdateID(canREG1, canMESSAGE_BOX1, u32msgArbVal);

        /**
         * @brief Transmit the heartbeat message.
         */
        canTransmit(canREG1, canMESSAGE_BOX1, u8ptru8HeartBeat);

        /**
         * @brief Wait until the message is transmitted or an error occurs.
         */

        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX1))
        {
            /**
             * @brief Break the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;
            }
            else
            {
                RIU_vErrorLedOff();
            }
        }
    }
    /**
     * @brief Check if the CAN base address is 0x1004.
     */
    else if (CAN_VICBaseAddress == 0x1004)
    {
        /**
         * @brief Initialize board address and message arbitration value.
         */
        uint32_t u32boardAdd = 0;
        uint32_t u32msgArbVal = 0;
        // uint16_t u16Cnt = 0; // Commented out counter variable.

        /**
         * @brief Calculate the board address.
         */
        u32boardAdd = u8dipvalue + VIC_CAN_BASE_ADDRESS;

        /**
         * @brief Set the message ID for transmission.
         */
        u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX1, CANMSGTYPETX,
        CANID_EXTENDED_IDENTIFIER,
                                         u32boardAdd);

        /**
         * @brief Update the CAN message ID.
         */
        canUpdateID(canREG1, canMESSAGE_BOX1, u32msgArbVal);

        /**
         * @brief Transmit the heartbeat message.
         */
        canTransmit(canREG1, canMESSAGE_BOX1, u8ptru8HeartBeat);

        /**
         * @brief Wait until the message is transmitted or an error occurs.
         */

        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX1))
        {
            /**
             * @brief Break the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;

            }
            else
            {
                //  RIU_vErrorLedOff();
            }
        }
    }
}

/**
 * @brief Reads the value of the dip switch for the MCU and returns
 *  the address value.
 *
 * @details This function reads the value of the dip switch for the MCU and
 *  returns the address value.
 * The address value is a combination of the values of the 4 dip switch bits
 * (DIP4-DIP7) as follows:
 * - DIP4: bit 3
 * - DIP5: bit 2
 * - DIP6: bit 1
 * - DIP7: bit 0
 *
 * @return The address value as a uint8_t.
 */
uint8 ReadDipSwitchAdd(void)
{
    DipInfo_t DipInfo;
    uint8_t u8Add4 = gioGetBit(gioPORTB, 4u);
    uint8_t u8Add5 = gioGetBit(gioPORTB, 5u);
    uint8_t u8Add6 = gioGetBit(gioPORTB, 6u);
    uint8_t u8Add7 = gioGetBit(gioPORTB, 7u);
    DipInfo.u8Address = (u8Add4 << 3) | (u8Add5 << 2) | (u8Add6 << 1) | u8Add7;

    return DipInfo.u8Address;
}
/**
 * @brief Reads the value of the dip switch for the MCU and returns the
 * address value.
 *
 * @details This function reads the value of the dip switch for the MCU and
 * returns the address value.
 *
 * @param[in] Dip4_bit_value The value of the 4th bit of the dip switch.
 *
 * @return The address value based on the dip switch value.
 */
uint32 VIC_mcuDip_Switch_ReadValue(uint8 Dip4_bit_value)
{

    return (CAN_BASE_ADDRESS + Dip4_bit_value);
}

uint32 RIU_vLinkFailureSetAddress(uint8 u8DipValue)
{

    return (VIC_CAN_LINK_FAIL + u8DipValue);
}

/**
 * @brief Reads the value of the dip switch for the VIC and returns the
 * address value.
 *
 * @details This function reads the value of the dip switch for the VIC and
 * returns the address value.
 *
 * @param[in] Dip4_bit_value The value of the dip switch.
 *
 * @return The address value of the dip switch.
 */
uint32 RIU_u32VICDipSwitchReadValue(uint8 Dip4_bit_value)
{

    return (VIC_CAN_BASE_ADDRESS + Dip4_bit_value);
}

/**
 * @brief Sends the Hotstandby HeartBeat message over CAN bus in VIC 1 and VIC 2
 *
 * @details This function is responsible for sending the HeartBeat message
 * over the CAN bus
 * for hot standby communication between MCUs.
 *
 * @param[in] u8ptru8HeartBeat A pointer to the HeartBeat message bytes.
 *
 * @return void
 */
void RIU_v2oo2HotstandbyHeartBeatMessage(void)
{
    static int failureCount_VIC1 = RIU_nINITVALUE; // Failure counter for VIC1
    static int failureCount_VIC3 = RIU_nINITVALUE; // Failure counter for VIC3
    static int failureCount = RIU_nINITVALUE;  // Failure counter for VIC3

    if (RIU_st2002Flags.u8_VIC1DataReceived == RIU_nSUCCESS)

    {
        RIU_st2002Flags.u8_VIC1DataReceived = RIU_nCLEAR;
        if (RIU_u8BufferCmparison(VIC_HLTPKT, u8HealthVICMSGData,
                                  8) == RIU_nSUCCESS)
        {

            RIU_st2002Flags.u8_2oo2SuccessBwVics = RIU_nSET;
            failureCount_VIC1 = RIU_nCLEAR; // Reset failure count on success
        }
        else
        {

            failureCount_VIC1++; // Increment failure count for VIC1
            if (failureCount_VIC1 >= 3)
            {
                RIU_st2002Flags.u8_2oo2SuccessBwVics = RIU_nCLEAR;
                // Trigger Hotstandby action
                RIU_st2002Flags.HotstandbyAction = RIU_nSET;
                // Reset failure count after triggering action
                failureCount_VIC1 = RIU_nCLEAR;
            }

        }
    }

    else if (RIU_st2002Flags.u8_VIC2DataReceived == RIU_nSUCCESS)
    {
        RIU_st2002Flags.u8_VIC2DataReceived = RIU_nCLEAR;
        if (RIU_u8BufferCmparison(VIC_HLTPKT, u8HealthVICMSGData,
                                  8) == RIU_nSUCCESS)
        {
            //   RIU_vLED2Toggle();
            RIU_st2002Flags.u8_2oo2SuccessBwVics = RIU_nSET;
            // Reset failure count on success
            failureCount_VIC3 = RIU_nCLEAR;
        }
        else
        {
            //  RIU_vLed2On();
            failureCount_VIC3++; // Increment failure count for VIC3
            if (failureCount_VIC3 >= 3)
            {
                RIU_st2002Flags.u8_2oo2SuccessBwVics = RIU_nCLEAR;
                // Trigger Hotstandby action
                RIU_st2002Flags.HotstandbyAction = RIU_nSET;
                // Reset failure count after triggering action
                failureCount_VIC3 = RIU_nCLEAR;
            }

        }
    }
    else
    {
        failureCount++;
        if (failureCount >= 4)
        {
            RIU_st2002Flags.u8_2oo2SuccessBwVics = RIU_nCLEAR;
            // Trigger Hotstandby action
            RIU_st2002Flags.HotstandbyAction = RIU_nSET;
            // Reset failure count after triggering action
            failureCount = RIU_nCLEAR;
        }

    }
}
void RIU_2002VimFailureTxToStation(void)
{

    if (RIU_st2002Flags.failuredetectflag == RIU_nSET)
    {
        RIU_st2002Flags.failuredetectflag = 0;
        if ((RIU_st2002Flags.ProcessVimfailure == RIU_nSET)
                && (RIU_st2002Flags.send_RIU_PKT == RIU_nCLEAR)
                && (RIU_st2002Flags.CanGpsDatetimeflag == 1))
        {
            RIU_st2002Flags.CanGpsDatetimeflag = 0;
            RIU_st2002Flags.ProcessVimfailure = RIU_nCLEAR;

            if (gu32SeqNo == MAXSEQNO)
            {
                /*Check if it reached the max value*/
                gu32SeqNo = RIU_nSET; /*Reset to 1*/
            }
            else
            {
                gu32SeqNo++; /*Increment the variable*/
            }

//            uint8_t lower_nibble = (gua8_CanIoData[0]
//                    & RIU_n1BYTE_LOWERNIBBLEMASK);
            uint8_t lower_nibble = (gua8_CanIoData[0]
                    & RIU_n1BYTE_LOWER5BITS_MASK);

            u8HealthData[0] = lower_nibble;
            u8HealthData[1] = gu8VicoverallHealth;
            u8HealthData[2] = gu8VimOverallHealth;
            switch (gu8VimOverallHealth)
            {

            case 0xfe:
                RIU_vErrorLedOn();
                break;
            case 0xfd:
                RIU_vErrorLedOn();
                break;
            case 0xfc:
                RIU_vErrorLedOff();
                break;
            default:
                RIU_vErrorLedOff();
                break;

            }
            if (DipInfo.u8Address == 0x1u)
            {

                RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                            &u8HealthData[0],
                                            &gu8_blueRingIp[0], &gu8blueip[0],
                                            4);
            }
            else if (DipInfo.u8Address == 0x2u)
            {

                RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                            &u8HealthData[0], &gu8_redRingIp[0],
                                            &gu8redip[0], 4);

            }
            else if (DipInfo.u8Address == 0x3u)
            {

                if (RIU_st2002Flags.processReduentudpdata == RIU_nSET)
                {

                    RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                                &u8HealthData[0],
                                                &gu8_blueRingIp[0],
                                                &gu8blueip[0], 4);
                }

            }
            else if (DipInfo.u8Address == 0x4u)
            {
                if (RIU_st2002Flags.processReduentudpdata == RIU_nSET)
                {

                    RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                                &u8HealthData[0],
                                                &gu8_redRingIp[0], &gu8redip[0],
                                                4);
                }
            }
            else
            {
                /*nop*/
                /* Optional: Handle other DIP switch values if needed*/
            }

        }
    }

}

/**
 * @brief Compares two buffers to determine if they are equal.
 *
 * @details This function is used to compare two buffers to determine
 * if they are equal.
 *
 * @param[in] u8Buffer1 A pointer to the first buffer.
 *
 * @param[in] u8Buffer2 A pointer to the second buffer.
 *
 * @param[in] u8BufferLength The number of bytes in the buffers to compare.
 *
 * @return uint8_t A value of 1 indicates that the buffers are equal, and a
 *  value of 0 indicates that the buffers are not equal.
 */
void RIU_V2oo2DataComparsion(void)
{
// Static variable to track consecutive failures
    static uint32_t u32mcuFailureCount = RIU_nINITVALUE;

    if (RIU_st2002Flags.u8_MCU1DataReceived == RIU_nSUCCESS)

    {

        RIU_st2002Flags.u8_MCU1DataReceived = RIU_nCLEAR;
        if (RIU_u8BufferCmparison(gua8_CanIoData, u8HealthTempMSGData,
                                  16) == RIU_nSUCCESS)
        {

            u32VIMfailureCntr1 = 0;

            RIU_st2002Flags.u8_2oo2SuccessBwMcus = RIU_nSET;
            RIU_st2002Flags.ProcessRingData = RIU_nSET; // Process the UDP data
            u32mcuFailureCount = RIU_nCLEAR; // Reset failure count on success
        }
        else
        {

            u32mcuFailureCount++; // Increment failure count
            if (u32mcuFailureCount >= FAILURECOUNT)
            {
                RIU_st2002Flags.u8_2oo2SuccessBwMcus = RIU_nCLEAR;
                RIU_st2002Flags.vimfailure = RIU_nSET;

                // Reset the counter after raising the flag
                u32mcuFailureCount = RIU_nCLEAR;
            }
        }
    }

    else if (RIU_st2002Flags.u8_MCU3DataReceived == RIU_nSUCCESS)

    {
        RIU_st2002Flags.u8_MCU3DataReceived = RIU_nCLEAR;
        if (RIU_u8BufferCmparison(gua8_CanIoData, u8HealthTempMSGData,
                                  16) == RIU_nSUCCESS)
        {

            u32VIMfailureCntr1 = 0;
            RIU_st2002Flags.u8_2oo2SuccessBwMcus = RIU_nSET;
            RIU_st2002Flags.ProcessRingData = RIU_nSET; // Process the UDP data
            u32mcuFailureCount = RIU_nCLEAR; // Reset failure count on success
        }
        else
        {

            u32mcuFailureCount++; // Increment failure count
            if (u32mcuFailureCount >= FAILURECOUNT)
            {
                RIU_st2002Flags.u8_2oo2SuccessBwMcus = RIU_nCLEAR;
                // Reset the counter after raising the flag
                u32mcuFailureCount = RIU_nCLEAR;
                RIU_st2002Flags.vimfailure = RIU_nSET;
            }
        }
    }
}

void RIU_vHotStandByAction(void)
{
    /*This function will trigger when Can communication failure*/
    if (RIU_st2002Flags.HotstandbyAction == RIU_nSUCCESS)
    {
        RIU_st2002Flags.HotstandbyAction = RIU_nCLEAR;
        /*Process the VIC UDP DATA  till that time this function will not activate*/
        // RIU_vLed3On();
        RIU_vPowwershutdown();

    }
    else
    {
        /*NOP*/
    }
}

/**
 * @brief This function is used to send the Regular message over CAN bus
 *
 * @details This function is used to send the Regular message over CAN bus
 *
 * @param[in] u8ptrregularMessage A pointer to the Regular message bytes.
 *
 * @param[in] u8Size A pointer to the size of the message to be sent.
 *
 * @return void
 */
void RIU_v2oo2ProcessVIMDataToMcu(void)
{

    if (RIU_st2002Flags.send_RIU_PKT == RIU_nSUCCESS)
    {
        RIU_st2002Flags.send_RIU_PKT = RIU_nCLEAR;
        /* need to send the regular message  data ouver can bus till its completed  */
        RIU_vcanTxData(&gua8_CanIoData[0]);
    }
    else
    {
        /*NOP */
    }

}
/**
 * @brief Sets the CAN message ID for transmission.
 *
 * This function constructs a CAN message ID based on the specified parameters,
 * including the message box object, transmission bit, identifier type, and message address.
 *
 * @param u8CANMsgBoxObj The CAN message box object.
 * @param u8TxBit The transmission bit.
 * @param u8IdentifierType The identifier type (standard or extended).
 * @param u32MSGAdd The message address.
 * @return The constructed CAN message ID.
 */
static uint32_t RIU_u32SetMsgIDTx(uint8_t u8CANMsgBoxObj, uint8_t u8TxBit,
                                  uint8_t u8IdentifierType, uint32_t u32MSGAdd)
{
    /**
     * @brief Initialize the message ID to a default value.
     */
    uint32_t u32MsgID = RIU_nINITVALUE;

    /**
     * @brief Check if the identifier type indicates an extended identifier.
     */
    if (u8IdentifierType == RIU_nSET)
    {
        /**
         * @brief Construct the message ID using the identifier type, transmission bit, and message address.
         *
         * The identifier type is shifted left by 30 bits, the transmission bit is shifted left by 29 bits,
         * and the message address is masked to fit within 29 bits. The final message ID is masked to ensure
         * it fits within 31 bits.
         */
        u32MsgID = ((((u8IdentifierType & 0x01u) << 30)
                | ((u8TxBit & 0x01u) << 29) | (u32MSGAdd & 0x1fffffff))
                & 0x7fffffff);
    }
    else
    {
        /**
         * @brief Nop.
         */

    }

    /**
     * @brief Return the constructed message ID.
     * @return The constructed CAN message ID.
     */
    return (u32MsgID);
}

/**
 * @brief Process the ring data received from 2002
 *
 * If the MCU3 is healthy and the 2002 communication is successful, this function
 * processes the ring data received from 2002. It extracts the lower nibble of the
 * first byte of the received data, and stores it in the lower nibble of the first
 * byte of the health data array. It also increments a sequence number and stores
 * it in the health data array. The health data array is then used to construct a
 * packet which is sent to the 2002. The LED3 is toggled whenever a packet is sent.
 *
 * If the 2002 communication is not successful, the function does nothing.
 *
 */
void RIU_vProcessRingData(void)
{
    if (RIU_st2002Flags.proceesUdpData == RIU_nSET)
    {
        RIU_st2002Flags.proceesUdpData = 0;

        if ((RIU_st2002Flags.ProcessRingData == RIU_nSET)
                && (RIU_st2002Flags.u8_2oo2SuccessBwMcus == RIU_nSET))
        {
            RIU_st2002Flags.ProcessRingData = RIU_nCLEAR;
            RIU_st2002Flags.u8_2oo2SuccessBwMcus = RIU_nCLEAR;
            if (gu32SeqNo == MAXSEQNO)
            {
                /*Check if it reached the max value*/
                gu32SeqNo = RIU_nSET; /*Reset to 1*/
            }
            else
            {
                gu32SeqNo++; /*Increment the variable*/
            }
            //uint8_t higher_nibble = ((gua8_CanIoData[0] & 0xF0u) >> 4u);

            // Extract the lower nibble
//            uint8_t lower_nibble = (gua8_CanIoData[0]
//                    & RIU_n1BYTE_LOWERNIBBLEMASK);
            uint8_t lower_nibble = (gua8_CanIoData[0]
                    & RIU_n1BYTE_LOWER5BITS_MASK);
            u8HealthData[0] = lower_nibble;
            u8HealthData[1] = gu8VicoverallHealth;
            u8HealthData[2] = gu8VimOverallHealth;
            switch (gu8VimOverallHealth)
            {

            case 0xfe:
                RIU_vErrorLedOn();
                break;
            case 0xfd:
                RIU_vErrorLedOn();
                break;
            case 0xfc:
                RIU_vErrorLedOff();
                break;
            default:
                RIU_vErrorLedOff();
                break;
            }
            /**
             * @brief Handles the processing of redundant UDP data for specific address.
             *
             * If the address in DipInfo is 0x1 and the processReduentudpdata flag is set,
             * this function toggles LED3 and frames a packet for RIU to Station communication.
             */
            if (DipInfo.u8Address == 0x1u)
            {
                /**
                 * @brief Toggles the state of LED3.
                 */
                // RIU_vLED3Toggle();
                /**
                 * @brief Frames a packet for RIU to Station communication.
                 *
                 * @param gu32SeqNo Sequence number for the packet.
                 * @param gua8_CanIoData Pointer to the CAN I/O data array.
                 * @param u8HealthData Pointer to the health data array.
                 * @param gu8_blueRingIp Pointer to the red ring IP address array.
                 * @param gu8blueip Pointer to the redundant IP address array.
                 * @param 4 Number of redundant data bytes.
                 */
                RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                            &u8HealthData[0],
                                            &gu8_blueRingIp[0], &gu8blueip[0],
                                            4);
            }
            /**
             * @brief Handles the processing of redundant UDP data for specific address.
             *
             * If the address in DipInfo is 0x2 and the processReduentudpdata flag is set,
             * this function toggles LED3 and frames a packet for RIU to Station communication.
             */
            else if (DipInfo.u8Address == 0x2u)
            {
                /**
                 * @brief Toggles the state of LED3.
                 */
                //RIU_vLED3Toggle();
                /**
                 * @brief Frames a packet for RIU to Station communication.
                 *
                 * @param gu32SeqNo Sequence number for the packet.
                 * @param gua8_CanIoData Pointer to the CAN I/O data array.
                 * @param u8HealthData Pointer to the health data array.
                 * @param gu8_redRingIp Pointer to the red ring IP address array.
                 * @param gu8redip Pointer to the redundant IP address array.
                 * @param 4 Number of redundant data bytes.
                 */

                RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                            &u8HealthData[0], &gu8_redRingIp[0],
                                            &gu8redip[0], 4);

            }
            /**
             * @brief Handles the processing of redundant UDP data for specific address.
             *
             * If the address in DipInfo is 0x3 and the processReduentudpdata flag is set,
             * this function toggles LED3 and frames a packet for RIU to Station communication.
             */
            else if (DipInfo.u8Address == 0x3u)
            {

                if (RIU_st2002Flags.processReduentudpdata == RIU_nSET)
                {

                    /**
                     * @brief Toggles the state of LED3.
                     */
                    //RIU_vLED3Toggle();
                    /**
                     * @brief Frames a packet for RIU to Station communication.
                     *
                     * @param gu32SeqNo Sequence number for the packet.
                     * @param gua8_CanIoData Pointer to the CAN I/O data array.
                     * @param u8HealthData Pointer to the health data array.
                     * @param gu8_blueRingIp Pointer to the red ring IP address array.
                     * @param gu8blueip Pointer to the redundant IP address array.
                     * @param 4 Number of redundant data bytes.
                     */

                    RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                                &u8HealthData[0],
                                                &gu8_blueRingIp[0],
                                                &gu8blueip[0], 4);
                }

            }

            /**
             * @brief Handles the processing of redundant UDP data for specific address.
             *
             * If the address in DipInfo is 0x4 and the processReduentudpdata flag is set,
             * this function toggles LED3 and frames a packet for RIU to Station communication.
             */
            else if (DipInfo.u8Address == 0x4u)
            {
                /**
                 * @brief Checks if redundant UDP data processing is enabled.
                 *
                 * If processReduentudpdata is 1, toggle LED3 and frame a packet.
                 */
                if (RIU_st2002Flags.processReduentudpdata == RIU_nSET)
                {
                    /**
                     * @brief Toggles the state of LED3.
                     */
                    //RIU_vLED3Toggle();
                    /**
                     * @brief Frames a packet for RIU to Station communication.
                     *
                     * @param gu32SeqNo Sequence number for the packet.
                     * @param gua8_CanIoData Pointer to the CAN I/O data array.
                     * @param u8HealthData Pointer to the health data array.
                     * @param gu8_redRingIp Pointer to the red ring IP address array.
                     * @param gu8redip Pointer to the redundant IP address array.
                     * @param 4 Number of redundant data bytes.
                     */
                    RIU_vRiu2StationPktFramning(gu32SeqNo, &gua8_CanIoData[0],
                                                &u8HealthData[0],
                                                &gu8_redRingIp[0], &gu8redip[0],
                                                4);
                }
            }
            else
            {
                /*nop*/
                /* Optional: Handle other DIP switch values if needed*/
            }

        }

        else
        {
            RIU_st2002Flags.CanGpsDatetimeflag = 1;
        }
    }
    else
    {
        /*nop*/
    }
}

/**
 * @brief Transmits CAN data in segments, ensuring proper handling and
 * error checking.
 *
 * This function sends data over CAN in 8-byte segments.
 * It sets up the message ID,updates the CAN message box, and ensures that
 *  each segment is properly transmitted.
 *
 * @param buf Pointer to the buffer containing data to be transmitted.
 * @return Status of the CAN transmission (success or failure).
 */
uint8_t RIU_vcanTxData(uint8 *buf)
{
    /**
     * @brief Loop variables and CAN byte position initializer.
     */
    uint8_t u8loop = RIU_nINITVALUE;
    uint8_t u8_loopVar = RIU_nINITVALUE;
    uint8 u8canBytePos = RIU_nINITVALUE;

    /**
     * @brief Buffer to hold each 8-byte segment for transmission.
     */
    uint8 u8Buf[8] = { 0 };

    /**
     * @brief Variables for board address, message arbitration value, and counter.
     */
    uint32_t u32boardAdd = RIU_nINITVALUE;
    uint32_t u32msgArbVal = RIU_nINITVALUE;
    uint16_t u16Cnt = RIU_nINITVALUE;
    uint8_t u8status = 0;

    /**
     * @brief Calculate the board address.
     */
    u32boardAdd = DipInfo.u8Address + RIU_VICBASEADDRESS_MCU;

    /**
     * @brief Set the message ID for transmission.
     */
    u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX3, CANMSGTYPETX,
    CANID_EXTENDED_IDENTIFIER,
                                     u32boardAdd);

    /**
     * @brief Update the CAN message box with the new ID.
     */
    canUpdateID(canREG1, canMESSAGE_BOX3, u32msgArbVal);

    /**
     * @brief Loop to handle 2 segments of 8 bytes each.
     */
    for (u8loop = RIU_nINITVALUE; u8loop < 2; u8loop++)
    {
        /**
         * @brief Reset position for each 8-byte segment.
         */
        u8canBytePos = RIU_nINITVALUE;

        /**
         * @brief Copy data from the input buffer to the transmission buffer.
         */
        for (u8_loopVar = u8loop * 8; u8_loopVar < (8 * (u8loop + 1u));
                u8_loopVar++)
        {
            u8Buf[u8canBytePos++] = buf[u8_loopVar];
        }

        /**
         * @brief Transmit the buffer over CAN.
         */
        canTransmit(canREG1, canMESSAGE_BOX3, u8Buf);

        /**
         * @brief Wait until the transmission is complete or an error occurs.
         */
        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX3))
        {
            /**
             * @brief Break the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;
                //RIU_vErrorLedOn();
            }
            else
            {
                //RIU_vErrorLedOff();
            }

        }

        /**
         * @brief Small delay to ensure proper timing between transmissions.
         */
        for (u16Cnt = RIU_nINITVALUE; u16Cnt < 10000; u16Cnt++)
        {
            __nop();
        }

        /**
         * @brief Update status to indicate successful transmission.
         */
        u8status = RIU_nRETSUCCESS;
    }

    /**
     * @return Status of the CAN transmission.
     */
    return (u8status);
}

/**
 * @brief Updates the VIM failure flags based on the CAN address received.
 *        If the address matches one of the VIM addresses, the corresponding
 *        flag is raised and the counter is reset. If no match is found, the
 *        counters are incremented and the flags are cleared if the counter
 *        reaches MAX_CONSECUTIVE_COUNT.
 *
 * @param lu16canAdd The 16-bit CAN address received.
 *
 * @return None
 */
void RIU_vUpdateVimFailureFlags(uint16_t lu16canAdd)
{
    uint8_t isMatch = RIU_nINITVALUE;
    uint8_t i = RIU_nINITVALUE;

    /* Iterate through all addresses*/
    for (i = RIU_nINITVALUE; i < NUM_VIM_ADDRESSES; ++i)
    {
        if (lu16canAdd == vimAddresses[i])
        {
            // Match found, raise the flag and reset the counter
            vimFlags[i] = RIU_nSET;
            vimCounters[i] = RIU_nCLEAR;
            isMatch = RIU_nSET;
            break; // Exit loop early as match is found
        }
    }

    /* If no match, increment counters and clear flags if counter reaches MAX_CONSECUTIVE_COUNT*/
    if (!isMatch)
    {
        for (i = RIU_nINITVALUE; i < NUM_VIM_ADDRESSES; ++i)
        {
            /*        Only operate on active flags*/
            if (vimFlags[i] == RIU_nSUCCESS)
            {
                vimCounters[i]++;
                if (vimCounters[i] >= MAX_CONSECUTIVE_COUNT)
                {
                    /*  Clear the flag*/
                    vimFlags[i] = RIU_nCLEAR;
                    /*        Reset the counter*/
                    vimCounters[i] = RIU_nCLEAR;
                }
            }
        }
    }

    /* Update the health byte based on the failure flags*/
    RIU_vUpdateHealthByte();
}

/**
 * @brief Updates the health byte based on VIM flags.
 *
 * This function resets the health byte and iterates through the VIM flags.
 * If any flag is cleared (indicating failure), it sets the corresponding bit in the overall health byte.
 * After the loop, if any flag was zero, it raises the ProcessVimfailure flag.
 */
static void RIU_vUpdateHealthByte(void)
{
    /**
     * @brief Resets the health byte.
     */
    gu8VimOverallHealth = 0x0000; // Reset the health byte

    uint8_t i = RIU_nINITVALUE;
    uint8_t failureDetected = 0; // Flag to detect any failure

    /**
     * @brief Updates the health status based on VIM flags.
     *
     * Iterates through the VIM flags, and if a flag is cleared (indicating failure),
     * sets the corresponding bit in the overall health byte.
     */
    for (i = RIU_nINITVALUE; i < NUM_VIM_ADDRESSES; ++i)
    {
        if (vimFlags[i] == 0) // Flag cleared indicates failure
        {
            gu8VimOverallHealth |= (1 << i); // Assume failure bits are sequentially mapped
            failureDetected = 1; // Set failure detected flag
        }
    }

    /**
     * @brief Raise the ProcessVimfailure flag if any failure was detected.
     */
    if (failureDetected)
    {
        /**
         * @brief Rise the flag if any failure detected
         */
        RIU_st2002Flags.ProcessVimfailure = 1;
    }
}

/**
 * @brief Updates the VIC failure flags and status based on the given CAN address.
 *
 * This function updates the VIC status and corresponding failure flags
 * based on the input CAN address. It checks for specific addresses and
 * sets the relevant flags and status.
 *
 * @param lu16canAdd The CAN address to check and update flags.
 */
void RIU_vUpdateVicFailureFlags(uint16_t lu16canAdd)
{
    /**
     * @brief Check if the CAN address is 0x1001.
     *
     * If the address is 0x1001, set vicstatus[1] to 1 and
     * failureFlags.u32vic2mcu1Status to 1.
     */
    if (lu16canAdd == 0x1001)
    {
        vicstatus[1] = 1;
        failureFlags.u32vic2mcu1Status = RIU_nSET;

    }
    /**
     * @brief Check if the CAN address is 0x1002.
     *
     * If the address is 0x1002, set vicstatus[2] to 1 and
     * failureFlags.u32vic2mcu3Status to 1.
     */
    else if (lu16canAdd == 0x1002)
    {
        vicstatus[2] = RIU_nSET;
        failureFlags.u32vic2mcu3Status = RIU_nSET;

    }
    /**
     * @brief Check if the CAN address is 0x1003.
     *
     * If the address is 0x1003, set vicstatus[3] to 1.
     */
    else if (lu16canAdd == 0x1003)
    {
        vicstatus[3] = RIU_nSET;

    }
    /**
     * @brief Check if the CAN address is 0x1004.
     *
     * If the address is 0x1004, set vicstatus[4] to 1.
     */
    else if (lu16canAdd == 0x1004)
    {
        vicstatus[4] = RIU_nSET;

    }
    /**
     * @brief Default case for non-matching addresses.
     *
     * If the CAN address does not match any of the above cases, do nothing.
     */
    else
    {

    }

}
/**
 * @brief Detects the VIC slot and toggles LED1 accordingly.
 *
 * This function checks the DIP switch address and slot detection value.
 * If the conditions match, it toggles LED1. Otherwise, it turns off LED1.
 */
void RIU_vDetectVicSlot(void)
{
    /**
     * @brief Check if the DIP switch address is 1 and slot detection is 1.
     */
    if ((DipInfo.u8Address == 1) && (gu8_slotDetect == 1))
    {
        /**
         * @brief Toggle the LED1
         */

        //  RIU_vLED1Toggle();
    }
    /**
     * @brief Check if the DIP switch address is 3 and slot detection is 2.
     */
    else if ((DipInfo.u8Address == 3) && (gu8_slotDetect == 2))
    {
        /**
         * @brief Toggle the LED1
         */
        // RIU_vLED1Toggle();
    }
    else
    {
        /**
         * @brief Turn of the LED1
         */
        //  RIU_vErrorLedOn();
    }
}

void RIU_vRxGpsDateTime(void)
{

    if (RIU_st2002Flags.GpsDatetimeflag == RIU_nSUCCESS)
    {
        RIU_st2002Flags.GpsDatetimeflag = RIU_nCLEAR;
        RIU_2002VICGpsMessageTx(&gu8_gpsBuff[0], DipInfo.u8Address);

    }

}
void RIU_2002VICGpsMessageTx(uint8_t *u8ptrGps, uint8_t u8dipvalue)
{
    if (CAN_VICGpsAddress == 0x2001u)
    {
        uint32_t u32boardAdd = RIU_nINITVALUE;
        uint32_t u32msgArbVal = RIU_nINITVALUE;

        u32boardAdd = u8dipvalue + VIC_CAN_BASE_GPS_ADDRESS;

        u32msgArbVal = RIU_u32SetMsgIDTx(canMESSAGE_BOX6, CANMSGTYPETX,
        CANID_EXTENDED_IDENTIFIER,
                                         u32boardAdd);
        canUpdateID(canREG1, canMESSAGE_BOX6, u32msgArbVal);
        canTransmit(canREG1, canMESSAGE_BOX6, u8ptrGps);
        while (!canIsTxMessagePending(canREG1, canMESSAGE_BOX6))
        {
            /**
             * @brief Break the loop if there is a CAN error.
             */
            if (canGetLastError(canREG1))
            {
                break;
                // RIU_vErrorLedOn();
            }
            else
            {
                //  RIU_vErrorLedOff();
            }
        }
    }

}

/**
 * @brief Configures MCU and VIC macros based on DIP switch address.
 *
 * @details This function defines and enables specific macros (MCU and VIC)
 * depending on the current DIP switch address value stored in DipInfo.u8Address.
 * It supports up to four address values (1 to 4), with each value determining
 * different macro configurations for the system. After setting the flags, it
 * calls EMAC_LwIP_Main to start the lwIP stack. The function does a busy-wait
 * loop of 1000 iterations before returning.
 */
void RIU_vConfigureVicDefaultStatus(void)
{
// Reset all enable flags
    enableMCU1 = RIU_nCLEAR;
    enableVIC1 = RIU_nCLEAR;
    enableMCU3 = RIU_nCLEAR;
    enableVIC2 = RIU_nCLEAR;

// Set flags based on the dip switch value
    if (DipInfo.u8Address == RIU_nSET)
    {
        enableMCU1 = RIU_nSET;
        enableVIC1 = RIU_nSET;
        vicstatus[DipInfo.u8Address] = RIU_nSET;
        RIU_st2002Flags.processprimaryvic = RIU_nSET;

    }
    else if (DipInfo.u8Address == 2)
    {
        enableMCU3 = RIU_nSET;
        enableVIC1 = RIU_nSET;
        vicstatus[DipInfo.u8Address] = RIU_nSET;
        RIU_st2002Flags.processprimaryvic = RIU_nSET;
    }
    else if (DipInfo.u8Address == 3)
    {
        enableMCU1 = RIU_nSET;
        enableVIC2 = RIU_nSET;
        vicstatus[DipInfo.u8Address] = RIU_nSET;

    }
    else if (DipInfo.u8Address == 4)
    {
        enableMCU3 = RIU_nSET;
        enableVIC2 = RIU_nSET;
        vicstatus[DipInfo.u8Address] = RIU_nSET;
    }
    else
    {
        /*NOP*/
    }
}

/**
 * @brief Initializes the MCU DIP address for the RIU.
 *
 * This function validates the RIU address and CAN DIP address, and raises a flag if both are valid.
 * It also configures the LED based on the validation results.
 *
 * @param u8CanDipaddress The CAN DIP address.
 * @param u8SlotAddress The slot address.
 * @param u8RiuAddress The RIU address.
 */
void RIU_vCheckAndConfigureRiuAddress(uint8_t u8CanDipaddress,
                                      uint8_t u8SlotAddress,
                                      uint8_t u8RiuAddress)

{
    /**< Extract the lower 4 bits of the RIU address. */
    uint8_t lu8_riuAddress = (u8RiuAddress & 0x0F);

    /**< Range check for the DIP switch value from RIU_MIN_ADDRESS to RIU_MAX_ADDRESS*/
    if (lu8_riuAddress >= RIU_MIN_ADDRESS && lu8_riuAddress <= RIU_MAX_ADDRESS)
    {

        /**<  Check if u8CanDipaddress is within the valid range*/
        if (u8CanDipaddress >= CAN_DIP_MIN && u8CanDipaddress <= CAN_DIP_MAX)
        {
            switch (u8SlotAddress)
            {
            case SLOT_0:
                if (u8CanDipaddress == CAN_DIP_2 || u8CanDipaddress == CAN_DIP_4)
                {
                    gbPowerOnFlag = 1; /**< Raise the flag if conditions are met. */
                }
                else
                {
                    gbPowerOnFlag = 0; /**< Raise the flag if conditions are met. */
                    RIU_vConfigLedOn(); /**< Turn off the LED if conditions are not met. */
                }
                break;
            case SLOT_1:
                if (u8CanDipaddress == CAN_DIP_1)
                {
                    gbPowerOnFlag = 1; /**< Raise the flag if conditions are met. */
                }
                else
                {
                    gbPowerOnFlag = 0; /**< Raise the flag if conditions are met. */
                    RIU_vConfigLedOn(); /**< Turn off the LED if conditions are not met. */
                }
                break;
            case SLOT_2:
                if (u8CanDipaddress == CAN_DIP_3)
                {

                    gbPowerOnFlag = 1; /**< Raise the flag if conditions are met. */
                }
                else
                {
                    gbPowerOnFlag = 0; /**< Raise the flag if conditions are met. */
                    RIU_vConfigLedOn(); /**< Turn off the LED if conditions are not met. */
                }
                break;

            default:
                RIU_vConfigLedOn(); /**< Turn off the LED for invalid slot address. */

                break;
            }
        }
        else
        {
            gbPowerOnFlag = 0; /**< Raise the flag if conditions are met. */
            RIU_vConfigLedOn(); /**< Turn off the LED if CAN DIP address is out of range. */

        }
    }
    else
    {
        /**< Turn off the LED for invalid RIU address. */
        RIU_vConfigLedOn();
    }

    // Check if the flag is raised
    if (gbPowerOnFlag)
    {
        RIU_vConfigLedOff(); /**< Turn on the LED if the flag is raised. */

    }
    else
    {
        /*NOP*//**< No operation if the flag is not raised. */
    }
}

/**
 * @brief Checks Ethernet link status and handles errors.
 *
 * @details This function is called when the Ethernet link status changes.
 * If the link is down and the redundant UDP data flag is set, or if the
 * primary VIC Ethernet status flag is set, the function calls
 * RIU_vhandleLinkStatusError() to handle the error.
 *
 * @note The function does not return any value.
 */
void RIU_vEthernetLinkCheckHandler(void)
{
    if (RIU_st2002Flags.EtehrnetlinkCheck == RIU_nSET)
    {
        RIU_st2002Flags.EtehrnetlinkCheck = 0;
        if (RIU_st2002Flags.processReduentudpdata == RIU_nSET)
        {
            RIU_vhandleLinkStatusError();
        }
        else if (RIU_st2002Flags.primaryVICETHstatus == RIU_nSET)
        {
            RIU_vhandleLinkStatusError();
        }

    }

}
