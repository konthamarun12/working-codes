/*******************************************************************************
 *
 * @FileName         : Decode_mcu.c
 * @Version          : V1.0.0
 * @Date             : 14-11-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include "DECODE_MCU.h"
#define seq_pos 4
#define print 0
#define START 0

uint8_t Valid = 0;
uint8_t LOOP = 0;
uint8_t u8Decode_mcu_pkt(uint8_t *buf, uint8_t *dec_buf,
                         uint16_t updated_buf_size)
{
    //uint8_t dec_buf[50] = {0};
    uint8_t total_numb_frames = 0;
    uint8_t u8buf_pos = 0;
    uint8_t seq_buf[5] = { 0 };
    uint8_t seq_cnt = 0;
    uint8_t u8dec_buf_pos = 0;
    // uint8_t seq_pos = 4; // Define the sequence position

    // Initial decoding of header values
    dec_buf[u8buf_pos] = buf[u8buf_pos];

    // Check for the first byte (0xA5)
    if (0xA5 == buf[u8buf_pos])
    {
        ++u8buf_pos;
        dec_buf[u8buf_pos] = buf[u8buf_pos];

        // Check for the second byte (0xC3)
        if (dec_buf[u8buf_pos] == 0xC3)
        {
            ++u8buf_pos;
            // Total number of frames
            dec_buf[u8buf_pos] = buf[u8buf_pos];
            total_numb_frames = dec_buf[u8buf_pos];

            ++u8buf_pos;
            // Length of data payload
            dec_buf[u8buf_pos] = buf[u8buf_pos];

            ++u8buf_pos;
        }
        else
        {
            return 0; // Incorrect format
        }
    }
    else
    {
        return 0; // Incorrect format
    }
    uint8_t i = 0;
    // Loop through the total number of frames
    for (i = 0; i < total_numb_frames; i++)
    {

        if (u8buf_pos == seq_pos)
        {
            seq_buf[seq_cnt] = buf[u8buf_pos]; // Store the sequence byte
            ++u8buf_pos;
            uint8_t j = 0;
            // Copy the 3 bytes of payload
            for (j = 0; j < 3; j++)
            {
                uint8_t u8dec_buf_pos = u8buf_pos - 1; // Adjusted buffer position
                dec_buf[u8dec_buf_pos] = buf[u8buf_pos];
                ++u8buf_pos;
            }
            seq_cnt++;
        }
        else if (u8buf_pos == 8 * seq_cnt)
        {
            // Store the sequence byte in seq_buf and increment counters
            seq_buf[seq_cnt] = buf[u8buf_pos];
            seq_cnt++;
            ++u8buf_pos;
            // Copy the next 7 bytes of payload
            uint8_t j = 0;
            for (j = 0; j < 7; j++)
            {
                u8dec_buf_pos = u8buf_pos - 1 * seq_cnt; // Adjusted buffer position
                // printf(" u8dec_buf_pos: %d, u8buf_pos: %d\n", u8dec_buf_pos, u8buf_pos);
                dec_buf[u8dec_buf_pos] = buf[u8buf_pos];
                ++u8buf_pos;
            }
        }
    }
    updated_buf_size = dec_buf[3] + 4; // 4 for crc_code_length

    return 1; // Successfully decoded
}

