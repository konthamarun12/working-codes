#include <stdint.h>
#include "frameNumber.h"
/* Macro for total seconds in a day (24 hours * 3600 seconds) */
#define SECONDS_IN_HOUR    (3600)
#define SECONDS_IN_MINUTE  (60)
#define FRAME_OFFSET       (1)

/* 
 * @brief  Calculate the frame number based on time (hh:mm:ss).
 * 
 * @param  hours: Number of hours (0-23)
 * @param  minutes: Number of minutes (0-59)
 * @param  seconds: Number of seconds (0-59)
 * 
 * @return Frame number corresponding to the input time. Range: 1 to 86400.
 */
uint32_t CM_u32getFrameNumber(unsigned char  hours, unsigned char  minutes, unsigned char  seconds) {
    uint32_t frame_number;

    /* Validate the input range for hours, minutes, and seconds */
    if (hours >= 24 || minutes >= 60 || seconds >= 60) {
        /* Return 0 for invalid time input */
        return 0;
    }

    /* Calculate frame number: (hr * 3600 + min * 60 + sec) + 1 */
    frame_number = (hours * SECONDS_IN_HOUR) + (minutes * SECONDS_IN_MINUTE) + seconds + FRAME_OFFSET;

    return frame_number;
}
/* 
 * @brief  Decode the frame number to time (hh:mm:ss).
 * 
 * @param  frame_number: The frame number (1 to 86400)
 * @param  hours: Pointer to store decoded hours
 * @param  minutes: Pointer to store decoded minutes
 * @param  seconds: Pointer to store decoded seconds
 * 
 * @return 0 if successful, -1 if the frame number is invalid
 */
uint32_t CM_u32decodeFrameNumber(uint32_t frame_number, uint32_t *hours, uint32_t *minutes, uint32_t *seconds) {
    uint32_t total_seconds;

    /* Validate frame number */
    if (frame_number < 1 || frame_number > 86400) {
        return 1;
    }

    /* Frame number starts from 1, so subtract 1 to get total seconds */
    total_seconds = frame_number - FRAME_OFFSET;

    /* Decode hours, minutes, and seconds */
    *hours = total_seconds / SECONDS_IN_HOUR;
    total_seconds %= SECONDS_IN_HOUR;
    *minutes = total_seconds / SECONDS_IN_MINUTE;
    *seconds = total_seconds % SECONDS_IN_MINUTE;

    return 0;
}

