/*
 * kavach.h
 *
 *  Created on: 24-Jun-2024
 *      Author: TCAS 1
 */

#ifndef INCLUDE_KAVACH_H_
#define INCLUDE_KAVACH_H_

#include "sys_common.h"
#include "emif.h"

#define SET_LOW         (0u)
#define SET_HIGH        (1u)
#define ENABLE          (0xFFFFFFFFu)
#define DISABLE         (0x00000000u)

#define EMIFPORT        (hetPORT1)

#pragma SET_DATA_SECTION(".farbss")
extern  uint16_t u16TestSdRam[256];
#pragma SET_DATA_SECTION()

typedef struct
{
    uint8_t u8Address;
    uint8_t u8Config;
    uint8_t u8Slot;
}gDipinfo_t;

 typedef struct
 {
     uint32_t u32IPdata;
     uint8_t u8IPData1;
     uint8_t u8IPData2;
     uint8_t u8IPData3;
     uint8_t u8IPData4;
     uint16_t u16IPdatamsb;
     uint16_t u16IPdatalsb;
     uint32_t u32IPData;
     bool IPbitData[32];
 }gInputData;

extern gDipinfo_t DipInfo;
extern gInputData IPData;

extern void wait(uint32_t u32time);

#endif /* INCLUDE_KAVACH_H_ */
