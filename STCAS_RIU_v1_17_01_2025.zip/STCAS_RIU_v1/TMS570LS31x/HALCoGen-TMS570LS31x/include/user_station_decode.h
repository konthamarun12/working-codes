/*******************************************************************************
 *
 * @FileName         : user_station_decode.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#ifndef HALCOGEN_TMS570LS31X_USER_STATION_DECODE_H_
#define HALCOGEN_TMS570LS31X_USER_STATION_DECODE_H_
#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>
#include <stdint.h>

#define NUM_TRACK_CKT 50
#define NUM_SIGNALS 50
#define SOF 0xa5c3
#define FUNCTION_CODE_RIU 0x02
#define FUNCTION_CODE_STN 0x01
/*----------------------------------------------DECODE RIU PACKET--------------------------------------------------------*/

#define BLUE_RING 254
#define RED_RING 255
#define DECODE_SUCCESS 1
#define START 0
#define BLUE_ID 0
#define RED_ID 1
#define BUFMAX_SIZE 16
#define DEC_ONCE 1
#define IP_SIZE 4
#define print 0
#define BUFFER_SIZE 37
#define SIX_RIU_DATASIZE 222

uint8_t u8processed_flag;

typedef struct
{
    uint8_t U8blueriu1 :1;

} RIU_stbluering_t;
typedef struct
{
    uint8_t U8redriu1 :1;
} RIU_stRedring_t;

typedef struct
{
    RIU_stbluering_t RIU_stbluering[6];
    RIU_stRedring_t RIU_stRedring[6];
    uint8_t RIU_vRing[37];
} RIU_st_RiuDirection_t;

RIU_st_RiuDirection_t RIU_st_RiuDirection[6];
typedef struct
{

    uint8_t u8SignalInfo[NUM_TRACK_CKT];
    uint8_t u8trackCktInfo[NUM_SIGNALS];

} RIU_PktDatapayload_t;

uint8_t RIU_vblue_one();
uint8_t RIU_vRed_one();

uint8_t buf_copy(uint8_t *u8update_buf, uint8_t *buf, uint16_t buf_size);


uint8_t RIU_u8STNextracT_Pkt_function(uint8_t *receivebuffer);
#ifdef __cplusplus
}
#endif
#endif /* HALCOGEN_TMS570LS31X_USER_STATION_DECODE_H_ */
