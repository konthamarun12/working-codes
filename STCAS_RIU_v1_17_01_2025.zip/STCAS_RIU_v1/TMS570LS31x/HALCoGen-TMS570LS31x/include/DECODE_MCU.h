/*******************************************************************************
 *
 * @FileName         : Decode_mcu.h
 * @Version          : V1.0.0
 * @Date             : 14-11-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/

#ifndef DRIVERS_INCLUDE_DECODE_MCU_H_
#define DRIVERS_INCLUDE_DECODE_MCU_H_
#ifdef __cplusplus
extern "C" {
#endif

uint8_t u8Decode_mcu_pkt(uint8_t *buf, uint8_t *dec_buf,
                         uint16_t updated_buf_size);

#ifdef __cplusplus
}
#endif /* DRIVERS_INCLUDE_DECODE_MCU_H_ */
#endif
