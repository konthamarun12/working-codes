
/*******************************************************************************
 *
 * @FileName         : framenumber.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#ifndef FRAMENUMBER_H
#define FRAMENUMBER_H
#ifdef __cplusplus
extern "C" {
#endif

// Function declaration for CRC calculation
uint32_t CM_u32getFrameNumber(unsigned char  hours, unsigned char  minutes, unsigned char  seconds);
uint32_t CM_u32decodeFrameNumber(uint32_t frame_number, uint32_t *hours, uint32_t *minutes, uint32_t *seconds);
#ifdef __cplusplus
}
#endif
#endif /* CRC_H */
