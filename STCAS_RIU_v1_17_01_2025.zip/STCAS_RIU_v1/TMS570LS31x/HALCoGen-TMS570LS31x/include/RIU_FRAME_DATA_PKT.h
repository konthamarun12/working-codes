/*
 * RIU_FRAME_DATA_PKT.h
 *
 *  Created on: 09-Jan-2025
 *      Author: konth
 */

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_RIU_FRAME_DATA_PKT_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_RIU_FRAME_DATA_PKT_H_

/*******************************************************************************
 *
 * @FileName         : RIU_FRAME_DATA_Pkt.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/


#ifdef __cplusplus
extern "C" {
#endif
#define SOF_LEN 2
#define MAX_CAN_IDS 4
#define MESSAGE_DATA_SIZE 4

#define NUM_TRACK_CKT 50
#define NUM_SIGNALS 50
#define NO_OF_VIM 2

#define SOF 0xa5c3
/*------------------------------------RIU_DATA_FRAME_PKT---------------------------------------------*/
typedef struct
{
    uint8_t Sof[SOF_LEN];         // 2bytes SOF
    uint8_t senderIp[4];    // 4 bytes address
    uint8_t receiverIp[4];  // 4 bytes Ip address
    uint8_t u8Functioncode; // 1byte function code
    uint8_t framenumber[3]; // 2bytes frame number from GPS
    uint8_t length[2];    // 2bytes Length of Data payload
    uint8_t u8SignalInfo[16]; // signal info in bits 16*8 =128
//    uint8_t no_of_vim;
    uint8_t u8health_status[3];// 1byte function code
    uint8_t crc[4];
} RIU_FieldInputPkt_t;
// Function declaration for CRC calculation
uint32_t create_time_frame();
void SEND_RIU_PAKCET(void);
void RIU_vRiu2StationPktFramning(uint32_t framenumber, uint8_t *PFips,
                                 uint8_t *status, uint8_t *sendIP,
                                 uint8_t *RIU_ID, uint8_t no_of_vims);
uint8_t RIU_u8extractPkt(RIU_FieldInputPkt_t STN_FILED_InpputPkt,
                         uint8_t *buffer);
void RIU_vRXHandler(void);
uint32_t RIU_u32IpaddressInteger(uint8_t *ip);
void RIU_vCanBusPkt(uint16_t gu16canAdd, uint16_t canIds[], uint8_t size,
                    uint8_t u8MSGData[], uint8_t gua8_CanIoData[],
                    uint8_t *send_RIU_flag);




#endif /* HALCOGEN_TMS570LS31X_INCLUDE_RIU_FRAME_DATA_PKT_H_ */
