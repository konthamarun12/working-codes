/*******************************************************************************
 *
 * @FileName         : Crc32.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#ifndef CRC32_H
#define CRC32_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Function declaration for CRC calculation
uint32_t CheckIntCRC(uint32_t start_addr, uint32_t end_addr);
uint32_t crc_calc(uint32_t cnt, uint32_t crc, uint8_t*buf);
uint32_t calculate_crc32(const uint8_t *data, size_t length);
bool verifyCrc32(uint8_t *data, size_t length);
#ifdef __cplusplus
}
#endif
#endif/* CRC_H */
