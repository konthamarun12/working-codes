
/*******************************************************************************
 *
 * @FileName         : mcu_pkt.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/
#ifndef MCU_PKT_H
#define MCU_PKY_H

#ifdef __cplusplus
}
#endif
#include <stdint.h>
#include "sys_common.h"
uint8 u8mcu_pkt(uint8 *buf, uint16 buf_size,uint8 * update_buf,uint16 update_buf_size);

#ifdef __cplusplus
}
#endif
#endif
