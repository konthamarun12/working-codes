/*******************************************************************************
 *
 * @FileName         : User_constants.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * Description       :
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 *********************************************************************************/
#ifndef HALCOGEN_TMS570LS31X_INCLUDE_USER_CONSTANTS_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_USER_CONSTANTS_H_

// Define constants for the ranges and slot addresses
#define RIU_MIN_ADDRESS 1
#define RIU_MAX_ADDRESS 6
#define CAN_DIP_MIN 1
#define CAN_DIP_MAX 4
#define SLOT_1 1
#define SLOT_2 2
#define SLOT_0 0xFF
#define CAN_DIP_1 1
#define CAN_DIP_2 2
#define CAN_DIP_3 3
#define CAN_DIP_4 4
#define RIU_nMAXNO (6u)
#define RIU_nMINNO (1U)
#define RIU_nSET                (0x1u)
#define RIU_nCLEAR              (0x0u)


#define  RIU_nSHIFT_POS0        (0x0u)
#define  RIU_nSHIFT_POS1        (0x1u)
#define  RIU_nSHIFT_POS2        (0x2u)
#define  RIU_nSHIFT_POS3        (0x3u)
#define  RIU_nSHIFT_POS4        (0x4u)
#define  RIU_nSHIFT_POS5        (0x5u)
#define  RIU_nSHIFT_POS6        (0x6u)
#define  RIU_nSHIFT_POS7        (0x7u)
#define  RIU_nSHIFT_POS8        (0x8u)
#define  RIU_nSHIFT_POS9        (0x9u)
#define  RIU_nSHIFT_POS10        (0x10u)
#define  RIU_nSHIFT_POS11        (0x11u)
#define  RIU_nSHIFT_POS12        (0x12u)
#define  RIU_nSHIFT_POS13        (0x13u)
#define  RIU_nSHIFT_POS14        (0x14u)
#define  RIU_nSHIFT_POS15        (0x15u)
#define  RIU_nSHIFT_POS16        (0x16u)
#define  RIU_nSHIFT_POS17        (0x17u)
#define  RIU_nSHIFT_POS18        (0x18u)
#define  RIU_nSHIFT_POS19        (0x19u)
#define  RIU_nSHIFT_POS20        (0x20u)
#define  RIU_nSHIFT_POS21        (0x21u)
#define  RIU_nSHIFT_POS22        (0x22u)
#define  RIU_nSHIFT_POS23        (0x23u)
#define  RIU_nSHIFT_POS24        (0x24u)


#define RIU_n1BYTE_LOWER5BITS_MASK 0x1F
#define RIU_n1BYTE_LOWERNIBBLEMASK (0x0Fu)
#define RIU_n1BYTE_HIGHERNIBBLEMASK (0xF0u)

#define RIU_nSUCCESS              (0x01u)
#define RIU_nFAILURE              (0x00u)


#define MAXSEQNO                (0xFFFFFFU)

#define RIU_nINITVALUE  (0x00u)

#define RIU_nRETSUCCESS (0x00u)
#define RIU_nRETFAILURE (0x01u)

#define RIU_VICBASEADDRESS_MCU (0x1100u)
#define VIC_CAN_LINK_FAIL (0x1200u)
#define CAN_BASE_ADDRESS 0x1100
#define VIC_CAN_BASE_ADDRESS 0x1000
#define VIC_CAN_BASE_GPS_ADDRESS 0x2000
#define CANID_EXTENDED_IDENTIFIER (1u)
#define CANMSGTYPETX (1u)
#define NUM_VIM_ADDRESSES 8

#define TRANS_SIZE 8
#define RESET 0
#define START 0
#define MAX_TRANS_SIZE 50
#define MAX_REC_SIZE 50
#define CHUNK_SIZE 8
#endif /* HALCOGEN_TMS570LS31X_INCLUDE_USER_CONSTANTS_H_ */
