/*
 * riulogics.h
 *
 *  Created on: 09-Jan-2025
 *      Author: konth
 */

#ifndef HALCOGEN_TMS570LS31X_INCLUDE_RIULOGICS_H_
#define HALCOGEN_TMS570LS31X_INCLUDE_RIULOGICS_H_


/*******************************************************************************
 *
 * @FileName         : riu_logics.h
 * @Version          : V1.0.0
 * @Date             : 14-12-2024
 * @CPUGroup         : Platform Dependent Code
 * @Author           : Arun KONTHAM
 * @Description      : This file contains the declarations for RIU logic
 * functions and data structures.
 *
 * This file is a controlled copy of M/S Areca Embedded Systems Pvt. Ltd.,
 * Plot No. 5B, Survey No. 184 & 185, Phase-V, IDA, Cherlapally,
 * Ranga Reddy Dst., Hyderabad, Telangana-500051
 *
 ******************************************************************************/


/**
 * @brief Structure to hold DIP switch information.
 */
typedef struct
{
    uint8 u8Address; /**< Address from DIP switch. */
} DipInfo_t;

/**
 * @brief Structure to hold RIU status flags.
 */
typedef struct
{
    uint32 VIC_MCU1_HEALTH_OK :1; /**< VIC MCU1 health status flag. */
    uint32 VIC_MCU3_HEALTH_OK :1; /**< VIC MCU3 health status flag. */
    uint32 VIC_CARD1_HEALTH_OK :1; /**< VIC Card1 health status flag. */
    uint32 VIC_CARD2_HEALTH_OK :1; /**< VIC Card2 health status flag. */
    uint32 HEALTH_NOT_OK :1; /**< General health not OK flag. */
} Riu_stFlags_t;

/**
 * @brief Enumeration for VIC health packet status.
 */
typedef enum
{
    HEALTH_NOT_OK = 0, /**< Health not OK. */
    VIC_MCU1_HEALTH_OK = 1, /**< VIC MCU1 health OK. */
    VIC_MCU3_HEALTH_OK = 2, /**< VIC MCU3 health OK. */
    VIC_CARD1_HEALTH_OK = 3, /**< VIC Card1 health OK. */
    VIC_CARD2_HEALTH_OK = 4 /**< VIC Card2 health OK. */
} VIC_Health_pkt;

/**
 * @brief Enumeration for VIC states.
 */
typedef enum
{
    BOOT_MODE, /**< Boot mode. */
    EVALUATING_MODE, /**< Evaluating mode. */
    POST_BOOTUPMODE, /**< Post boot-up mode. */
    IDEAL_BOOT_UP_MODE /**< Ideal boot-up mode. */
} VIC_enStattes_t;

/**
 * @brief Structure to hold RIU 2002 flags.
 */
typedef struct
{
    uint32_t u8_2oo2Flag :1; /**< 2oo2 flag. */
    uint32_t u8_2oo2SuccessBwMcus :1; /**< 2oo2 success between MCUs. */
    uint32_t u8_2oo2SuccessBwVics :1; /**< 2oo2 success between VICs. */
    uint32_t u8_MCU1DataReceived :1; /**< MCU1 data received flag. */
    uint32_t u8_MCU3DataReceived :1; /**< MCU3 data received flag. */
    uint32_t u8_VIC1DataReceived :1; /**< VIC1 data received flag. */
    uint32_t u8_VIC2DataReceived :1; /**< VIC2 data received flag. */
    uint32_t u8_MCU1DataTx :1; /**< MCU1 data transmission flag. */
    uint32_t u8_MCU3DataTx :1; /**< MCU3 data transmission flag. */
    uint32_t ProcessRingData :1; /**< Process ring data flag. */
    uint32_t HotstandbyAction :1; /**< Hot standby action flag. */
    uint32_t gu8_powershoutdown :1; /**< Power shutdown flag. */
    uint32_t send_RIU_PKT :1; /**< Send RIU packet flag. */
    uint32_t GpsDatetimeflag :1; /**< GPS date-time flag. */
    uint32_t CanGpsDatetimeflag :1; /**< CAN GPS date-time flag. */
    uint32_t u32enableEmac :1; /**< Enable EMAC flag. */
    uint32_t vimfailure :1; /**< VIM failure flag. */
    uint32_t processprimaryvic :1; /**< Process primary VIC flag. */
    uint32_t processReduentudpdata :1; /**< Process redundant UDP data flag. */
    uint32_t ProcessVimfailure :1;
    uint32_t failuredetectflag :1;
    uint32_t proceesUdpData :1;
    uint32_t primaryVICETHstatus :1;
    uint32_t EtehrnetlinkCheck :1;
} RIU_st2002Flags_t;

/**
 * @brief Structure to hold PCB failure flag status.
 */
typedef struct
{
    uint32_t u32vim1aFlag :1; /**< VIM1A flag  */
    uint32_t u32vim1bFlag :1; /**< VIM1B flag  */
    uint32_t u32vim2aFlag :1; /**< VIM2A flag  */
    uint32_t u32vim2bFlag :1; /**< VIM2B flag  */
    uint32_t u32vim3aFlag :1; /**< VIM3A flag . */
    uint32_t u32vim3bFlag :1; /**< VIM3B flag*/
    uint32_t u32vim4aFlag :1; /**< VIM4A flag*/
    uint32_t u32vim4bFlag :1; /**< VIM4B flag*/
    uint32_t u32vic1Flag :1; /**< VIC1 flag*/
    uint32_t u32vic2Flag :1; /**< VIC2 flag*/
    uint32_t u32vic1mcu1Status :1; /**< VIC1 MCU1 status flag*/
    uint32_t u32vic2mcu1Status :1; /**< VIC2 MCU1 status flag*/
    uint32_t u32vic1mcu3Status :1; /**< VIC1 MCU3 status flag*/
    uint32_t u32vic2mcu3Status :1; /**< VIC2 MCU3 status flag*/
    uint32_t u32processVic1 :1; /**< Process VIC1 flag*/
    uint32_t u32processVic2 :1; /**< Process VIC2 flag*/
} RIU_stPcbFailureflagStatus_t;

/** @brief Define failure flags for VIM and VIC addresses. */
#define VIM1A_FAIL   0x0001   /**< VIM1A failure flag (Bit 0). */
#define VIM1B_FAIL   0x0002   /**< VIM1B failure flag (Bit 1). */
#define VIM2A_FAIL   0x0004   /**< VIM2A failure flag (Bit 2). */
#define VIM2B_FAIL   0x0008   /**< VIM2B failure flag (Bit 3). */
#define VIM3A_FAIL   0x0010   /**< VIM3A failure flag (Bit 4). */
#define VIM3B_FAIL   0x0020   /**< VIM3B failure flag (Bit 5). */
#define VIM4A_FAIL   0x0040   /**< VIM4A failure flag (Bit 6). */
#define VIM4B_FAIL   0x0080   /**< VIM4B failure flag (Bit 7). */
#define VIC1_FAIL    0x0100   /**< VIC1 failure flag (Bit 8). */
#define VIC2_FAIL    0x0200   /**< VIC2 failure flag (Bit 9). */

/** @brief Define addresses for simplicity. */
#define VIM1A_ADDRESS    0x5141 /**< VIM1A address. */
#define VIM1B_ADDRESS    0x5181 /**< VIM1B address. */
#define VIM2A_ADDRESS    0x5142 /**< VIM2A address. */
#define VIM2B_ADDRESS    0x5182 /**< VIM2B address. */
#define VIM3A_ADDRESS    0x5143 /**< VIM3A address. */
#define VIM3B_ADDRESS    0x5183 /**< VIM3B address. */
#define VIM4A_ADDRESS    0x5144 /**< VIM4A address. */
#define VIM4B_ADDRESS    0x5184 /**< VIM4B address. */
#define VIC1MCU1_ADDRESS 0x1001 /**< VIC1 MCU1 address. */
#define VIC2MCU1_ADDRESS 0x1002 /**< VIC2 MCU1 address. */
#define VIC1MCU2_ADDRESS 0x1003 /**< VIC1 MCU2 address. */
#define VIC2MCU2_ADDRESS 0x1004 /**< VIC2 MCU2 address. */

#define VIC1MCU1_HEALTH 0x1001 /**< VIC1 MCU1 health address. */
#define VIC2MCU1_HEALTH 0x1002 /**< VIC2 MCU1 health address. */
#define VIC1MCU2_HEALTH 0x1003 /**< VIC1 MCU2 health address. */
#define VIC2MCU2_HEALTH 0x1004 /**< VIC2 MCU2 health address. */

/**
 * @brief Detects the VIC slot.
 */
void RIU_vDetectVicSlot(void);

/**
 * @brief Updates the VIM failure flags.
 *
 * @param lu16canAdd CAN address.
 */
void RIU_vUpdateVimFailureFlags(uint16_t lu16canAdd);

void RIU_vUpdateVicFailureFlags(uint16_t lu16canAdd);
/**
 * @brief Transmits CAN data.
 *
 * @param buf Pointer to the data buffer.
 * @return uint8_t Returns status of the transmission.
 */
uint8_t RIU_vcanTxData(uint8 *buf);

/**
 * @brief Sends a 2oo2 hot standby heartbeat message.
 */
void RIU_v2oo2HotstandbyHeartBeatMessage(void);

/**
 * @brief Compares 2oo2 data.
 */
void RIU_V2oo2DataComparsion(void);

/**
 * @brief Processes data based on DIP switch settings.
 *
 * @param u8ptrData Pointer to the data buffer.
 */
void processBasedOnDipSwitch(uint8 *u8ptrData);

/**
 * @brief Processes VIC health data.
 *
 * @param u8VICptrdata Pointer to the VIC data buffer.
 */
void RIU_vProcessVICHealthData(uint8 *u8VICptrdata);

/**
 * @brief Processes ring data.
 */
void RIU_vProcessRingData(void);

/**
 * @brief Reads the VIC DIP switch value.
 *
 * @param Dip4_bit_value DIP switch value.
 * @return uint32 Returns the read value.
 */
uint32 RIU_u32VICDipSwitchReadValue(uint8 Dip4_bit_value);

/**
 * @brief Assigns IP and MAC addresses based on DIP switch value.
 *
 * @param dipSwitchValue DIP switch value.
 * @param pu8redip Pointer to the red IP address buffer.
 * @param pu8blueip Pointer to the blue IP address buffer.
 * @param pu8redmac Pointer to the red MAC address buffer.
 * @param pu8bluemac Pointer to the blue MAC address buffer.
 * @param pu8bluegateway Pointer to the blue gateway address buffer.
 * @param pu8Redgateway Pointer to the red gateway address buffer.
 */
void RIU_vassignAddresses(unsigned char dipSwitchValue, uint8_t *pu8redip,
                          uint8_t *pu8blueip, uint8_t *pu8redmac,
                          uint8_t *pu8bluemac, uint8_t *pu8bluegateway,
                          uint8_t *pu8Redgateway);

/**
 * @brief Enables LAN communication.
 */
void RIU_vEnableLANCommunication(void);

/**
 * @brief Reads the DIP switch address.
 *
 * @return uint8 Returns the DIP switch address.
 */
uint8 ReadDipSwitchAdd(void);

/**
 * @brief Reads the MCU DIP switch value.
 *
 * @param Dip4_bit_value DIP switch value.
 * @return uint32 Returns the read value.
 */
uint32 VIC_mcuDip_Switch_ReadValue(uint8 Dip4_bit_value);

/**
 * @brief Sets the link failure address based on DIP switch value.
 *
 * @param u8DipValue DIP switch value.
 * @return uint32 Returns the link failure address.
 */
uint32 RIU_vLinkFailureSetAddress(uint8 u8DipValue);

/**
 * @brief Toggles LED1.
 */
void RIU_vLED1Toggle(void);

/**
 * @brief Turns on LED1.
 */
void RIU_vLed1On(void);

/**
 * @brief Sends UDP data to the station.
 */
void RiuSendUDPDatatostation(void);

/**
 * @brief Processes VIM data to MCU in 2oo2 mode.
 */
void RIU_v2oo2ProcessVIMDataToMcu(void);

/**
 * @brief Shuts down the power.
 */
void RIU_vPowwershutdown(void);

/**
 * @brief Turns off LED1.
 */
void RIU_vLed1Off(void);

/**
 * @brief Turns off LED2.
 */
void RIU_vLed2Off(void);

/**
 * @brief Turns off LED3.
 */
void RIU_vLed3Off(void);

/**
 * @brief Turns on LED3.
 */
void RIU_vLed3On(void);

/**
 * @brief Turns on LED2.
 */
void RIU_vLed2On(void);

/**
 * @brief Turns off LED4.
 */
void RIU_vLed4Off(void);

/**
 * @brief Turns on LED4.
 */
void RIU_vLed4On(void);

/**
 * @brief Toggles LED2.
 */
void RIU_vLED2Toggle(void);

/**
 * @brief Toggles LED3.
 */
void RIU_vLED3Toggle(void);

/**
 * @brief Toggles LED4.
 */
void RIU_vLED4Toggle(void);
/**
 * @brief Turns on ErrorLed.
 */
void RIU_vErrorLedOn(void);
/**
 * @briefTurns off ErrorLed.
 */
void RIU_vErrorLedOff(void);


void RIU_vConfigLedOn(void);
void RIU_vConfigLedOff(void);
void RIU_vEthernetLinkCheckHandler(void);
/**
 * @brief Sends a heartbeat message to the VIC.
 *
 * @param u8ptru8HeartBeat Pointer to the heartbeat message.
 * @param u8dipvalue DIP switch value.
 */
void RIU_2002VICheartbeatMessage(uint8_t *u8ptru8HeartBeat, uint8_t u8dipvalue);

/**
 * @brief Sends a GPS message to the VIC.
 *
 * @param u8ptrGps Pointer to the GPS message.
 * @param u8dipvalue DIP switch value.
 */
void RIU_2002VICGpsMessageTx(uint8_t *u8ptrGps, uint8_t u8dipvalue);

/**
 * @brief Transmits VIM failure data to the station.
 */
void RIU_2002VimFailureTxToStation(void);

/**
 * @brief Performs hot standby action.
 */
void RIU_vHotStandByAction(void);

/**
 * @brief Receives GPS date and time.
 */
void RIU_vRxGpsDateTime(void);

/**
 * @brief Turns on all LEDs.
 */
void RIU_vLedsOn(void);

/**
 * @brief Turns off all LEDs.
 */
void RIU_vLedsOff(void);

/**
 * @brief Reads the DIP switch value.
 *
 * @return uint8_t Returns the DIP switch value.
 */
uint8_t RIU_u8DipSwitchRead(void);
/**
 * @brief Configures MCU and VIC macros based on DIP switch address.
 */
void RIU_vConfigureVicDefaultStatus(void);


void RIU_vCheckAndConfigureRiuAddress(uint8_t u8CanDipaddress, uint8_t u8SlotAddress,
                               uint8_t u8RiuAddress);




#endif /* HALCOGEN_TMS570LS31X_INCLUDE_RIULOGICS_H_ */
