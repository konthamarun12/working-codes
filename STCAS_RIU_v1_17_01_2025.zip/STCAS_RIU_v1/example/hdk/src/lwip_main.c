/** @file sys_main.c 
 *   @brief Application main file
 *   @date 15.July.2009
 *   @version 1.01.000
 *
 *   This file contains the initialization & control path for the LwIP & EMAC driver
 *   and can be called from system main.
 */

/* (c) Texas Instruments 2011, All rights reserved. */

#if defined(_TMS570LC43x_) || defined(_RM57Lx_)
#include "HL_sys_common.h"
#include "HL_system.h"
#include "HL_emac.h"
#include "HL_mdio.h"
#include "HL_phy_dp83640.h"
#include "HL_sci.h"
#else
#include "sys_common.h"
#include "system.h"
#include "emac.h"
#include "mdio.h"
#include "phy_dp83640.h"
#include "sci.h"
#include "het.h"
#include "gio.h"
#endif

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "lwipopts.h"
#include "lwiplib.h"
#include "httpd.h"
#include "lwip\inet.h"
#include "locator.h"
#include "lwip_main.h"
#include "riulogics.h"
#include "emif.h"
#include "RIU_FRAME_DATA_Pkt.h"
#include "user_constants.h"
extern uint32_t lwIPStatusGetIsNum;
#define TMS570_MDIO_BASE_ADDR 	0xFCF78900u /* Same base address for TMS570 & RM48 devices */
#define TMS570_EMAC_BASE_ADDR	0xFCF78000u /* Same base address for TMS570 & RM48 devices */
#define DPS83640_PHYID			0x20005CE1u	/** PHY ID Register 1 & 2 values for DPS83640 (Same for TMS570 & RM devices */
#define PHY_ADDR				1			/** EVM/Hardware dependent & is same for TMS570 & RM48 HDKs */

/* Choosing the SCI module used depending upon the device HDK */
#if defined(_TMS570LC43x_) || defined(_RM57Lx_)
#define sciREGx	sciREG1
#else
#define sciREGx	(scilinREG)
#endif
extern volatile uint8_t rx_buffer[200];




uint8_t *txtIPAddrItoA;



char DispBuf[100];
uint16_t gCount = 0;
uint16_t gLength = 0;

uint16_t gTxBit = 0;
unsigned int ipAddr;
extern uint8_t gu8UDPRXFLAG;
void *pcb;
err_t err;

uint32_t g_ui32tcpPollTick = 0;



void iommUnlock(void);
void iommLock(void);
void iommMuxEnableMdio(void);
void iommMuxEnableRmii(void);
void iommMuxEnableMii(void);
void IntMasterIRQEnable(void);
void smallDelay(void);
static bool attemptLinkStatusReset(void);
void FormatIPAddress(uint32_t ui32Addr, char *pucBuffer);
uint8 TCASUDPSend(uint32_t ipAddr, uint16_t port);
void TCASUDPInit( uint8_t *ip_addr);

/** @fn void main(void)
 *   @brief Application main function
 *   @note This function is empty by default.
 *
 *   This function is called after startup.
 *   The user can use this function to implement the application.
 */

/* USER CODE BEGIN (2) */
void smallDelay(void)
{
    static volatile unsigned int delayval;
    delayval = 10000U; /* 100000 are about 10ms */
    while (delayval--)
    {
    };
}
/* USER CODE END */
/*****************************************************************************/
/* Format an lwIP type IP Address. */
/*****************************************************************************/
void FormatIPAddress(uint32_t ui32Addr, char *pucBuffer)
{
    /* Convert the IP Address into a string. */
    sprintf(pucBuffer, "%d.%d.%d.%d\r", (ui32Addr >> 24) & 0xff,
            (ui32Addr >> 16) & 0xff, (ui32Addr >> 8) & 0xff, (ui32Addr) & 0xff);

    /* Display the string.
     UARTprintf(pcBuf);*/
}

/*****************************************************************************/
static void TCASUDPReceive(void *arg, struct udp_pcb *pcb, struct pbuf *p,
                           struct ip_addr *addr, u16_t port)
{
    uint8_t *pui8Data;
    uint16_t i =0;
    uint16_t _len =0;
    pui8Data = p->payload;
    _len = p->len;
    for (i = 0; i < _len; i++)
    {

        rx_buffer[i] = pui8Data[i];
    }


    gLength = _len;
    gu8UDPRXFLAG = 1;
    pbuf_free(p);

}

/*****************************************************************************/
void TCASUDPInit( uint8_t *ip_addr)
{
    struct udp_pcb *pcb;
    err_t err;
    /* Create a new UDP control block  */
    pcb = udp_new();

    if (pcb)
    {
      /* Bind the upcb to the UDP_PORT port */
      /* Using IP_ADDR_ANY allow the upcb to be used by any local interface */
       err = udp_bind(pcb, IP_ADDR_ANY, 2300);

       if(err == ERR_OK)
       {
         /* Set a receive callback for the upcb */
                 udp_recv(pcb, TCASUDPReceive, NULL);
         //udp_recv(upcb, udp_server_receive_callback, NULL);
       }
       else
       {

       }
    }
    else
    {

    }
 }



/**
 * @brief Function to send data using UDP protocol
 * @param data pointer to data to be sent
 * @param size size of data to be sent
 * @param ipAddr IP address of destination
 * @param port destination port
 * @return None
 */
void RIU_vUdpTxDataPacket(uint8_t *data, uint32_t size, uint32_t ipAddr,
                          uint16_t port)
{

    /*
     Formats the destination IP address as a string using FormatIPAddress.
     Creates a string TempDataBuf containing a count and the formatted IP address.
     Allocates a pbuf (a buffer structure used by the lwIP library) to hold the data to be sent.
     Copies the data into the pbuf payload.
     Sets the destination IP address and port using struct ip_addr.
     Sends the data using udp_sendto.
     Frees the pbuf using pbuf_free. */
    struct pbuf *p;
//    unsigned char status = 0;
//    uint16_t u16index = 0u;

    struct ip_addr addr;

    uint32_t ui32NewIPAddress;

    ui32NewIPAddress = ipAddr; //lwIPLocalIPAddrGet();
    FormatIPAddress(ui32NewIPAddress, DispBuf);

    p = pbuf_alloc(PBUF_TRANSPORT, size, PBUF_RAM); //sizeof(g_pui8LocatorData), PBUF_RAM);
    if (p == NULL)
    {
        // return err;
    }

    addr.addr = ipAddr; //0x2e01a8c0;
    memcpy(p->payload, data, size + 1);

    err = udp_sendto(pcb, p, &addr, port); //port);

    pbuf_free(p);

}

/*********************************************************************/
void EMAC_LwIP_Main(uint8_t *macAddress, uint8_t *ip_addr, uint8_t *gateway)
{
    struct in_addr devIPAddress;
    uint8_t netmask[4] = { 255, 255, 255, 0 };
    uint32_t ipAddr;
    // Check for NULL pointers to prevent runtime errors
    if (macAddress == NULL || ip_addr == NULL || gateway == NULL) {
        // Log error or handle it appropriately
        return;
    }
    /* Enable the interrupt generation in CPSR register */
    IntMasterIRQEnable();
    _enable_FIQ();


    ipAddr = lwIPInit(0U, macAddress, *((uint32_t*) ip_addr),
                      *((uint32_t*) netmask), *((uint32_t*) gateway),
                      (unsigned int) IPADDR_USE_STATIC);


    if (0U == ipAddr)
    {

        RIU_vLed2Off();
        return ;
    }
    else
    {
        /* Convert IP Address to string */
        devIPAddress.s_addr = ipAddr;
        txtIPAddrItoA = (uint8_t*) inet_ntoa(devIPAddress);
        TCASUDPInit(ipAddr);  //LocatorConfig(macAddress, "HDK enet_lwip");
        RIU_vLed2On();


    }
}

void iommUnlock(void)
{
    /*Unlock the IOMM Register*/
    *(int*) 0xFFFFEA38 = 0x83E70B13; /* kicker 0 register, unlock CPU write access to PINMMR registers */
    *(int*) 0xFFFFEA3C = 0x95A4F1E0; /* kicker 1 register, */
}

void iommLock(void)
{
    /*lock the IOMM Register*/
    *(int*) 0xFFFFEA38 = 0x00000000; /* kicker 0 register, lock CPU write access to PINMMR registers */
    *(int*) 0xFFFFEA3C = 0x00000000; /* kicker 1 register, */
}

void iommMuxEnableMdio(void)
{
    *(int*) 0xFFFFEB2C = 0x00000400;
    *(int*) 0xFFFFEB30 = 0x00000400;
}

void iommMuxEnableRmii(void)
{
    *(int*) 0xFFFFEB38 = 0x02010204;  //P10  //RMIIRXER
    *(int*) 0xFFFFEB3C = 0x08020101;  //P11  //RMII_RXD0
    *(int*) 0xFFFFEB40 = 0x01010204;  //P12  //RMII RXD1
    *(int*) 0xFFFFEB54 = 0x02040200;  //P17  //RMII_RMCRSDV
    *(int*) 0xFFFFEB44 = 0x01080808; //P13  //RMII_TXEN , RMII_TX_D1 ,RMII_TX_D0
    *(int*) 0xFFFFEB48 = 0x01010401;  //P14; //RMII_REFCLK
}

void iommMuxEnableMii(void)
{
    *(int*) 0xFFFFEB38 &= 0xFFFFFF00; //P10[1]  //Mux 10 Rx_ER
    *(int*) 0xFFFFEB38 |= (1 << 1);   //P10[1]  //Mux 10 Rx_ER

    *(int*) 0xFFFFEB3C &= 0x00FFFFFF; //P11[26]   //Mux 11 Rx[0]
    *(int*) 0xFFFFEB3C |= (1 << 26);  //P11[26]   //Mux 11 Rx[0]

    *(int*) 0xFFFFEB40 &= 0x0000FF00; //P12[1,18,26]    //Mux 12 Rx[3],Rx[2],Rx[1]
    *(int*) 0xFFFFEB40 |= ((1 << 26) | (1 << 18) | (1 << 1)); //P12[1,18,26]    //Mux 12 Rx[3],Rx[2],Rx[1]

    *(int*) 0xFFFFEB44 &= 0x00000000; //P13[2, 10, 26,18]   //Mux 13 Tx[2],TxEn,Tx[1],Tx[0]
    *(int*) 0xFFFFEB44 |= ((1 << 26) | (1 << 18) | (1 << 10) | (1 << 2)); //P13[2, 10, 26,18]   //Mux 13 Tx[2],TxEn,Tx[1],Tx[0]

    *(int*) 0xFFFFEB48 &= 0xFFFF0000; //P14[9,2,11]   //Mux 14 Tx[3],RxClk
    *(int*) 0xFFFFEB48 |= ((1 << 9) | (1 << 2)); //P14[9,2]   //Mux 14 Tx[3],RxClk

    *(int*) 0xFFFFEB54 &= 0xFF00FF00;    //P17[17,1,3]   //Mux 17 CRS,TxClk
    *(int*) 0xFFFFEB54 |= ((1 << 17) | (1 << 1)); //P17[17,1]   //Mux 17 CRS,TxClk

    *(int*) 0xFFFFEB5C &= 0xFFFF00FF;  //P19[9]   //Mux 19 RxDV
    *(int*) 0xFFFFEB5C |= (1 << 9);      //P19[9]   //Mux 19 RxDV

    *(int*) 0xFFFFEB60 &= 0xFF00FFFF;  //P20[18]   //Mux 20 COL
    *(int*) 0xFFFFEB60 |= (1 << 18);     //P20[18]   //Mux 20 COL

    *(int*) 0xFFFFEB84 &= 0x00FFFFFF; //P29[24]  //Mux 29 MII Select pin (24 bit - 0(MII),1(RMII))
    *(int*) 0xFFFFEB84 |= (0 << 24); //P29[24]  //Mux 29 MII Select pin (24 bit - 0(MII),1(RMII))
}

/*
 ** Interrupt Handler for Core 0 Receive interrupt
 */
volatile int countEMACCore0RxIsr = 0;
#pragma INTERRUPT(EMACCore0RxIsr, IRQ)
void EMACCore0RxIsr(void)
{
    countEMACCore0RxIsr++;
    lwIPRxIntHandler(0);
}

/*
 ** Interrupt Handler for Core 0 Transmit interrupt
 */
volatile int countEMACCore0TxIsr = 0;
#pragma INTERRUPT(EMACCore0TxIsr, IRQ)
void EMACCore0TxIsr(void)
{
    countEMACCore0TxIsr++;
    lwIPTxIntHandler(0);
}

void IntMasterIRQEnable(void)
{
    _enable_IRQ();
    return;
}

void IntMasterIRQDisable(void)
{
    _disable_IRQ();
    return;
}

unsigned int IntMasterStatusGet(void)
{
    return (0xC0 & _get_CPSR());
}

/* Function to handle link status error */
void RIU_vhandleLinkStatusError(void)
{
    /* Log the error */
    /* Attempt to reset the link status */
    if (attemptLinkStatusReset())
    {
        RIU_vErrorLedOff();
        RIU_vLed2On();
    }
    else
    {
        RIU_vErrorLedOn();
        RIU_vLed2Off();
    }
}

/* Function to attempt resetting the link status */
static bool attemptLinkStatusReset(void)
{
    /* Implement the logic to reset the link status */
    /* This is a placeholder implementation and should be replaced with actual reset logic */
    bool resetSuccessful = false;
    uint32_t lwIPLinkStatus = 0;
    /* Example reset logic */
    lwIPLinkStatus = lwIPLinkStatusGet(lwIPStatusGetIsNum);
    if (lwIPLinkStatus == RIU_nSET)
    {
        resetSuccessful = true;
    }
    else
    {
        resetSuccessful = false;
    }

    return resetSuccessful;
}
