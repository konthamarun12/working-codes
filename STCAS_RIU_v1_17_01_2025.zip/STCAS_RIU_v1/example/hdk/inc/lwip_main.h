/*
 * lwip_main.h
 *
 *  Created on: 19-Oct-2024
 *      Author: konth
 */

#ifndef EXAMPLE_HDK_INC_LWIP_MAIN_H_
#define EXAMPLE_HDK_INC_LWIP_MAIN_H_
#define SERVER_PORT 2300
void EMAC_LwIP_Main(uint8_t *macAddress, uint8_t *ip_addr, uint8_t *gateway);
void RIU_vhandleLinkStatusError(void);

void RIU_vUdpTxDataPacket(uint8_t *data, uint32_t size, uint32_t ipAddr, uint16_t port);
#endif /* EXAMPLE_HDK_INC_LWIP_MAIN_H_ */
